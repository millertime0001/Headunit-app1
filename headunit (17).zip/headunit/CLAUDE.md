# Pi 5 car head unit (Ryan's 2011 Subaru Outback)

Claude Code runs on the Pi itself; Ryan drives it from the Claude app on his Galaxy Z Fold7 (Remote Control).
He hates typing on the car screen: give short, one-per-line commands; do the work yourself where you can.

## System
- Raspberry Pi 5, Pi OS Lite (Trixie). labwc + Chromium kiosk. Python aiohttp backend.
- Code: ~/headunit (this repo). Version in VERSION (bump the letter suffix on every change, e.g. 2026.10.31-t → -u).
- backend/server.py (one file), web/ (app.js, style.css, styles.css, fx.js, ripple.js, editor.js, appview.js,
  preview.js, studio.html/js/css, themes.json, knob_faces.json), scripts/, knob/ (ESP32 firmware), phone-app/ (Android).
- Logs: ~/.config/headunit/logs/backend.log (use `grep -a`, it has binary bytes). Settings: ~/.config/headunit/settings.json.
- Restart the head unit after backend changes: Settings > Tools > Restart, or scripts in scripts/. Screen picks up
  web/ changes on reload; the screen reloads itself when VERSION changes.
- 10.1" 1024x600 HDMI, HiFiBerry DAC8x, USB mic, Elecrow 1.28" rotary knob (ESP32-S3, firmware in knob/).
- Pi runs hotspot "Pi Head Unit" (NetworkManager con HeadUnitHotspot, 10.42.0.1, password in
  ~/.config/headunit/hotspot.json). It hands out NO gateway/DNS (dnsmasq-shared.d/headunit-local-only.conf) so the
  phone keeps mobile data for internet. Samsung "Switch to mobile data" must stay ON.

## Phone link (adb)
- Phone = Galaxy Z Fold7 (Android 17). USB serial RFCY61T5TAA. Wireless adb on port 5555 (adb tcpip); the backend
  re-arms it whenever the phone is plugged in and it's off. Phone's Wi-Fi IP changes (e.g. 10.42.0.164); the backend
  learns it from the phone app's websocket connection (hub.phone_ip), then `ip neigh`, then leases (root-only file).
- Phone app "Head Unit Link" (com.headunit.link, phone-app/), v6.0. Built by GitHub Actions in Ryan's repo
  millertime0001/Headunit-app1 from an uploaded headunit zip (workflow builds the newest *.zip, publishes a Release
  with HeadUnitLink.apk). Signed with phone-app/app/headunit.keystore so updates install over the old one.
  It holds the Pi Wi-Fi with a WifiNetworkSpecifier request (Pi sends ssid/password on phone_hello) and contains the
  Design Studio (WebView of web/ + studio). Bump versionCode in phone-app/app/build.gradle.kts for app changes.

## Maps / YouTube Music streaming
- Default: in-page stream (PageStream in server.py). Runs scrcpy-server 3.1 directly: push jar EVERY time (it deletes
  itself), adb reverse localabstract (phone dials in; forward mode broke restarts), START_APP control message (type 16)
  after codec meta (start_app server option is unknown on this phone). Video relayed over /appws, decoded in Chromium
  with WebCodecs (web/appview.js) onto a canvas: rounded corners, "map only" crop, live map background.
- Wi-Fi: 30 fps / 4 Mbit. USB: 60 fps / 8 Mbit. Falls back to the classic scrcpy window after 3 failed starts.
- Live map background: setting map_bg (+ map_dim, map_glass frost|tint), Home only, #mapBg in .bg layer.

## Look system
- 120 themes (themes.json), 13 Styles (STYLES in app.js + styles.css), 34 background effects (fx.js, FXN map),
  26 Home layouts (LAYOUTS in app.js; gen:true ones built from wireframes), button styles, knob ripple (ripple.js).
- Designs: JSON files {format:"headunit-design", name, settings, colors, vars, css}. POST /design applies one;
  stored in ~/.config/headunit/designs. Studio at /studio (and in the phone app). Samples: "Chrome Night", "Night Pilot".
- Knob turns do NOT flash panels any more (only presses do).

## Open items
- Wireless link is still slow to connect / sometimes stalls (push timeout → reconnect+retry added in -t).
- More knob animations; knob faces that match the screen's background animation (needs knob firmware build +
  a way to flash it from the Pi over USB).
- Bluetooth: Pi says connected but phone says can't connect; calls "Not ready", "No music player found".
- Planned: splash style picker, theme builder, knob face builder, synced startup across knob/head unit/cluster,
  instrument-cluster display.
