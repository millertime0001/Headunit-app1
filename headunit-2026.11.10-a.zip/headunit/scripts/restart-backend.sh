#!/usr/bin/env bash
# Restart only the backend (start-headunit.sh's loop brings it back in ~2 s). The screens reload when VERSION changed.
P=$(pgrep -f "^/home/ryan/headunit/venv/bin/python /home/ryan/headunit/backend/server.py")
[ -n "$P" ] && kill $P; sleep 2; [ -n "$P" ] && kill -9 $P 2>/dev/null
for _ in $(seq 40); do curl -s -m1 -o /dev/null http://127.0.0.1:8080/ && { echo "backend up"; exit 0; }; sleep 0.5; done
echo "backend did not come back"; exit 1
