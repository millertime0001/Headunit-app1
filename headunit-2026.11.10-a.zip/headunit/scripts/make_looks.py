#!/usr/bin/env python3
"""Builds web/looks.json (the built-in Looks) from the table below.
Run again after adding Flow scenes: each Look names the scene it wants and a stand-in for when that scene
doesn't exist yet. Checks every id against themes.json, knob_faces.json, flow.js and the backend enums."""
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
WEB = ROOT / "web"
PAL = {t["id"]: t for t in json.loads((WEB / "themes.json").read_text())}
KNOBS = {k["id"] for k in json.loads((WEB / "knob_faces.json").read_text())}
SCENES = set(re.findall(r"^\s*\['([a-z0-9]+)',", (WEB / "flow.js").read_text().split("window.FLOW_SCENES = [", 1)[1].split("];", 1)[0], re.M))
SRV = (ROOT / "backend" / "server.py").read_text()


def enum(name, inside=None):
    src = SRV if inside is None else SRV[SRV.index(inside):]
    m = re.search(r'"%s": \("enum", \(([^)]*)\)' % name, src)
    return set(re.findall(r'"([a-z0-9-]*)"', m.group(1)))


STYLES = enum("style")
FACES = enum("face", "CLUSTER_SCHEMA")
NEEDLES = enum("needle", "CLUSTER_SCHEMA")
MAPS = enum("map_style")
SPLASH = enum("splash_style")

# per panel style: buttons, knob ripple, clock
STYLE_BITS = {
    "glass": ("glass", "waves", "thin"), "carbon": ("chrome", "shock", "bold"), "synth": ("neon", "waves", "glow"),
    "minimal": ("glass", "edge", "thin"), "hud": ("neon", "sparks", "glow"), "lux": ("chrome", "aurora", "thin"),
    "rally": ("liquid", "shock", "bold"), "soft": ("liquid", "aurora", "bold"), "pop": ("liquid", "sparks", "bold"),
    "sea": ("pulse", "aurora", "glow"), "paper": ("glass", "edge", "thin"), "holo": ("holo", "sparks", "thin"),
    "slime": ("liquid", "aurora", "bold"), "rainy": ("glass", "rain", "thin"),
    "neon": ("neon", "waves", "glow"), "chrome": ("chrome", "shock", "bold"), "aero": ("glass", "aurora", "thin"),
    "tech": ("glass", "edge", "outline"), "oled": ("glass", "edge", "thin"), "jdm": ("chrome", "shock", "bold"),
    "retro": ("liquid", "waves", "bold"), "blueprint": ("glass", "edge", "outline"),
}
CLEAR = {"opacity": 10, "blur": 16, "depth": 80, "shine": 90, "tint": "clear"}
FROST = {"opacity": 22, "blur": 30, "depth": 70, "shine": 70, "tint": "theme"}
SMOKE = {"opacity": 48, "blur": 22, "depth": 75, "shine": 45, "tint": "smoke"}
SOLID = {"opacity": 80, "blur": 10, "depth": 45, "shine": 30, "tint": "theme"}

# id, name, group, description, palette, panel style, (wanted scene, stand-in), strength, knob face, splash,
# map colors, cluster {face, look, needle, ...}, extra settings
L = [
    # ---------------------------------------------------------------- Night drive
    ("northern-lights", "Northern Lights", "Night drive", "Aurora curtains ripple across the cluster, the screen and the knob",
     "aurora", "glass", ("aurora", "aurora"), 80, "auroraclock", "dawn", "theme",
     {"face": "aurora", "needle": "comet", "arc": "gradient"}, {"glass": CLEAR}),
    ("midnight-run", "Midnight Run", "Night drive", "Deep blue night, city lights drifting past out of focus",
     "midnight", "glass", ("bokeh", "liquid"), 70, "nightdrive", "warp", "night",
     {"face": "glass", "needle": "blade", "numerals": "thin"}, {"glass": FROST}),
    ("hyperdrive", "Hyperdrive", "Night drive", "Stars stream past every screen, faster the faster you drive",
     "deepspace", "hud", ("warp", "warp"), 90, "starfield", "warp", "neon",
     {"face": "hologram", "needle": "laser", "ticks": "fine"}, {}),
    ("galaxy", "Galaxy", "Night drive", "A slow spiral galaxy turning behind the whole dash",
     "nebula", "aero", ("galaxy", "vortex"), 75, "orbit", "plasma", "night",
     {"face": "galaxy", "needle": "comet"}, {"glass": CLEAR}),
    ("moonlit-sea", "Moonlit Drive", "Night drive", "A moon over the head unit, silver waves under the whole dash",
     "ocean", "sea", ("ocean", "ocean"), 85, "halo", "dawn", "night",
     {"face": "chrome", "needle": "classic", "numerals": "thin"}, {}),
    ("starry-peaks", "Starry Peaks", "Night drive", "Mountains under a sky full of stars, a shooting star now and then",
     "royal", "aero", ("mountains", "warp"), 70, "starfield", "dawn", "night",
     {"face": "glass", "needle": "comet", "numerals": "thin"}, {"glass": CLEAR}),
    ("night-city", "Night City", "Night drive", "Neon signs and city lights blurred through the windshield",
     "night-city", "neon", ("neoncity", "ribbons"), 80, "nightdrive", "hyper", "neon",
     {"face": "neon", "needle": "laser", "arc": "gradient"}, {}),
    ("deep-sonar", "Deep Sonar", "Night drive", "Rings and a radar sweep spread out from the knob to every screen",
     "ice-hud", "tech", ("sonar", "sonar"), 85, "radar", "warp", "blueprint",
     {"face": "hud", "look": "black", "needle": "laser", "ticks": "fine"}, {}),
    # ---------------------------------------------------------------- Neon
    ("outrun", "Outrun", "Neon", "A neon sun and a racing grid floor spanning every screen",
     "outrun", "synth", ("grid", "grid"), 85, "nightdrive", "hyper", "synthwave",
     {"face": "synthwave", "needle": "laser", "arc": "gradient"}, {}),
    ("miami-nights", "Miami Nights", "Neon", "Pink and teal ribbons, synthwave dials",
     "miami", "synth", ("ribbons", "ribbons"), 85, "neon", "hyper", "synthwave",
     {"face": "synthwave", "needle": "laser"}, {}),
    ("mainframe", "Mainframe", "Neon", "Pulses of light race along circuit traces between the screens",
     "tron", "tech", ("circuit", "circuit"), 90, "digital", "hyper", "neon",
     {"face": "tron", "look": "black", "numerals": "digital", "ticks": "fine"}, {}),
    ("the-matrix", "The Matrix", "Neon", "Green code rain falling down all three screens",
     "matrix", "hud", ("matrix", "circuit"), 80, "dotmatrix", "hyper", "neon",
     {"face": "hologram", "look": "black", "numerals": "digital"}, {}),
    ("cyberpunk", "Cyberpunk", "Neon", "Magenta and cyan glitching neon, spiral arms around the knob",
     "cyberpunk", "neon", ("vortex", "vortex"), 80, "orbit", "hyper", "neon",
     {"face": "neon", "needle": "comet"}, {}),
    ("vaporwave", "Vaporwave", "Neon", "Pastel sunset grid, palm-tree pink and dreamy teal",
     "vaporwave", "synth", ("grid", "grid"), 65, "neon", "dawn", "synthwave",
     {"face": "synthwave", "needle": "blade"}, {}),
    ("neon-tubes", "Neon Tubes", "Neon", "Glowing neon tubes bending across the dash",
     "neon", "neon", ("neon", "ribbons"), 80, "neon", "hyper", "neon",
     {"face": "neon", "needle": "laser", "arc": "gradient"}, {}),
    ("hologram", "Hologram", "Neon", "Shimmering holographic light, rainbow edges",
     "hologram", "holo", ("plasma", "plasma"), 70, "pulse", "plasma", "neon",
     {"face": "hologram", "needle": "laser"}, {}),
    # ---------------------------------------------------------------- Racing
    ("carbon-race", "Carbon Race", "Racing", "Carbon fiber, red ribbons, race gauges with shift lights",
     "redline", "carbon", ("ribbons", "ribbons"), 70, "sport", "ignition", "mono",
     {"face": "carbon", "look": "carbon", "needle": "blade", "numerals": "bold"}, {}),
    ("papaya", "Papaya Racing", "Racing", "Papaya orange on carbon, stars streaking past as you drive",
     "papaya", "carbon", ("warp", "warp"), 75, "turbo", "ignition", "mono",
     {"face": "carbon", "look": "carbon", "needle": "blade", "numerals": "bold"}, {}),
    ("gulf-livery", "Gulf Livery", "Racing", "Powder blue and orange, endurance racing classic",
     "gulf", "rally", ("speedlines", "ribbons"), 75, "rally", "ignition", "mono",
     {"face": "real", "needle": "classic", "numerals": "bold"}, {}),
    ("stage-rally", "Stage Rally", "Racing", "Rally blue and yellow, gravel flying past",
     "rally-blue", "rally", ("speedlines", "warp"), 80, "rally", "ignition", "theme",
     {"face": "carbon", "needle": "blade", "numerals": "bold"}, {}),
    ("touge", "Touge", "Racing", "80s Japanese mountain-pass racer: bold stripes, white gauges",
     "drift", "jdm", ("speedlines", "ribbons"), 75, "sport", "ignition", "mono",
     {"face": "retro", "needle": "classic", "numerals": "bold"}, {}),
    ("le-mans", "Le Mans Night", "Racing", "Endurance racing at night: dark, precise, a single red line",
     "le-mans", "tech", ("ribbons", "ribbons"), 60, "chrono", "ignition", "night",
     {"face": "minimal", "look": "black", "needle": "blade", "ticks": "fine"}, {}),
    ("stealth", "Stealth", "Racing", "Matte black and graphite, almost nothing glows",
     "stealth", "oled", ("topo", "plasma"), 35, "minimal", "ignition", "mono",
     {"face": "minimal", "look": "black", "needle": "blade", "ticks": "minimal"}, {}),
    # ---------------------------------------------------------------- Weather
    ("rainy-window", "Rainy Window", "Weather", "Night city through wet glass, drops running over the tiles",
     "rainy-night", "rainy", ("rainwindow", "rain"), 80, "rainy", "dawn", "night",
     {"face": "glass", "needle": "comet", "numerals": "thin"},
     {"rain_over": True, "rain_glass": True, "glass": {"opacity": 16, "blur": 14, "depth": 60, "shine": 80, "tint": "theme"}}),
    ("thunderstorm", "Thunderstorm", "Weather", "Rain sweeping across all three screens, lightning behind it",
     "midnight", "glass", ("rain", "rain"), 85, "rainy", "dawn", "night",
     {"face": "glass", "needle": "comet", "numerals": "thin"}, {"rain_glass": True, "rain_amount": "heavy"}),
    ("snowfall", "Snowfall", "Weather", "Soft snow drifting down every screen, icy blue light",
     "arctic", "aero", ("snow", "aurora"), 70, "ice", "dawn", "night",
     {"face": "crystal", "needle": "blade", "numerals": "thin"}, {"glass": CLEAR}),
    ("fog", "Fog", "Weather", "Slow smoke and mist, muted grey light",
     "ghost", "minimal", ("smoke", "plasma"), 55, "minimal", "dawn", "mono",
     {"face": "minimal", "needle": "blade", "numerals": "thin"}, {}),
    ("arctic", "Arctic", "Weather", "Icy blue lights, clean glass gauges",
     "arctic", "glass", ("aurora", "aurora"), 65, "ice", "dawn", "night",
     {"face": "glass", "needle": "blade", "numerals": "thin"}, {"glass": CLEAR}),
    ("sunny-day", "Sunny Day", "Weather", "Bright lagoon blues, light glass, easy to read in the sun",
     "lagoon", "aero", ("caustics", "ocean"), 55, "classic", "dawn", "original",
     {"face": "glass", "needle": "blade"}, {"glass": FROST}),
    # ---------------------------------------------------------------- Warm
    ("campfire", "Campfire", "Warm", "Embers rise off the knob and drift up across the dash",
     "ember", "glass", ("embers", "embers"), 90, "bloom", "ignition", "thermal",
     {"face": "lava", "needle": "blade"}, {}),
    ("lava-lamp", "Lava Lamp", "Warm", "Molten blobs drifting between the screens and melting together",
     "lava", "slime", ("lava", "liquid"), 85, "liquid", "ignition", "theme",
     {"face": "lava", "needle": "blade"}, {}),
    ("desert-dunes", "Desert Dunes", "Warm", "Sand dunes under a hot sunset sky",
     "desert", "retro", ("dunes", "plasma"), 70, "sunburst", "dawn", "theme",
     {"face": "retro", "needle": "classic"}, {}),
    ("sunset-drive", "Sunset Drive", "Warm", "Orange to violet sunset sky, warm and calm",
     "sunset-drive", "glass", ("dunes", "aurora"), 70, "sunburst", "dawn", "theme",
     {"face": "synthwave", "needle": "comet"}, {}),
    ("fireworks", "Fireworks", "Warm", "Bursts of color going off across the whole dash",
     "bloodmoon", "neon", ("fireworks", "embers"), 80, "pulse", "plasma", "night",
     {"face": "neon", "needle": "comet"}, {}),
    # ---------------------------------------------------------------- Nature
    ("deep-sea", "Deep Sea", "Nature", "Light rippling under water, glowing round panels",
     "abyss", "sea", ("caustics", "plasma"), 70, "bloom", "dawn", "blueprint",
     {"face": "glass", "needle": "comet"}, {}),
    ("jellyfish", "Jellyfish", "Nature", "Glowing drifting creatures in a dark sea",
     "jellyfish", "sea", ("fireflies", "liquid"), 75, "bloom", "plasma", "night",
     {"face": "liquid", "needle": "comet"}, {}),
    ("firefly-forest", "Firefly Forest", "Nature", "Fireflies blinking in a deep green night forest",
     "forest", "glass", ("fireflies", "embers"), 75, "bloom", "dawn", "theme",
     {"face": "glass", "needle": "comet"}, {}),
    ("sakura", "Sakura", "Nature", "Cherry blossom petals drifting from screen to screen",
     "sakura", "soft", ("petals", "liquid"), 65, "bloom", "dawn", "theme",
     {"face": "glass", "needle": "blade", "numerals": "thin"}, {}),
    ("topographic", "Topographic", "Nature", "Contour lines of a map slowly shifting, like terrain from above",
     "forest-stage", "blueprint", ("topo", "circuit"), 70, "minimal", "dawn", "blueprint",
     {"face": "blueprint", "needle": "blade", "ticks": "fine"}, {}),
    # ---------------------------------------------------------------- Luxury
    ("silk", "Silk", "Luxury", "Ribbons of light flowing from the cluster across the head unit",
     "amethyst", "lux", ("ribbons", "ribbons"), 75, "halo", "chrome", "mono",
     {"face": "luxe", "needle": "blade", "numerals": "thin"}, {}),
    ("gold-luxe", "Gold Luxe", "Luxury", "Champagne and gold silk, chrome dials",
     "gold", "lux", ("silk", "ribbons"), 60, "chrono", "chrome", "mono",
     {"face": "chrome", "look": "black", "needle": "classic", "numerals": "thin"}, {}),
    ("liquid-chrome", "Liquid Chrome", "Luxury", "Polished metal flowing like mercury",
     "platinum", "chrome", ("chrome", "plasma"), 70, "chrono", "chrome", "mono",
     {"face": "chrome", "needle": "classic", "numerals": "thin"}, {}),
    ("rose-gold", "Rose Gold", "Luxury", "Soft rose gold light on black",
     "rose-gold", "lux", ("silk", "liquid"), 60, "halo", "chrome", "mono",
     {"face": "luxe", "needle": "blade", "numerals": "thin"}, {}),
    ("emerald", "Emerald", "Luxury", "Deep green and gold, a private-club feel",
     "emerald-lux", "lux", ("silk", "ribbons"), 60, "chrono", "chrome", "theme",
     {"face": "luxe", "needle": "classic", "numerals": "thin"}, {}),
    ("sapphire", "Sapphire", "Luxury", "Cut-gem blues, crystal gauges",
     "sapphire", "chrome", ("crystal", "plasma"), 65, "halo", "chrome", "night",
     {"face": "crystal", "needle": "blade", "numerals": "thin"}, {}),
    # ---------------------------------------------------------------- Calm
    ("liquid-light", "Liquid Light", "Calm", "Glowing blobs drift from screen to screen and melt into each other",
     "nebula", "glass", ("liquid", "liquid"), 80, "liquid", "plasma", "theme",
     {"face": "liquid", "needle": "blade", "arc": "gradient"}, {}),
    ("plasma", "Plasma", "Calm", "Slow waves of color rolling across the dash",
     "twilight", "aero", ("plasma", "plasma"), 70, "bloom", "plasma", "theme",
     {"face": "plasma", "needle": "comet"}, {}),
    ("pure-black", "Pure Black", "Calm", "True black, no animation, only your accent color lights up",
     "obsidian", "oled", ("plasma", "plasma"), 20, "minimal", "ignition", "night",
     {"face": "minimal", "look": "black", "needle": "blade", "ticks": "minimal"},
     {"flow": {"on": False}, "effect": "off"}),
    ("minimal", "Minimal", "Calm", "No boxes, giant thin type, hairlines",
     "mono", "minimal", ("topo", "plasma"), 30, "minimal", "warp", "mono",
     {"face": "minimal", "look": "black", "needle": "blade", "ticks": "minimal"}, {}),
    ("lavender", "Lavender", "Calm", "Soft lavender light, rounded clay panels",
     "lavender", "soft", ("liquid", "liquid"), 55, "bloom", "dawn", "theme",
     {"face": "glass", "needle": "blade", "numerals": "thin"}, {}),
    # ---------------------------------------------------------------- Bright (light colors, for daytime)
    ("paper", "Paper", "Bright", "Ink on paper, crisp and easy to read in daylight",
     "paper-ink", "paper", ("topo", "plasma"), 35, "classic", "dawn", "original",
     {"face": "real", "look": "glow", "needle": "classic"}, {}),
    ("cloud", "Cloud", "Bright", "White frosted glass and sky blue, made for sunny days",
     "cloud", "aero", ("liquid", "liquid"), 50, "classic", "dawn", "original",
     {"face": "glass", "look": "glow", "needle": "blade"}, {"glass": FROST}),
    ("blueprint", "Blueprint", "Bright", "Technical drawing: white lines on blueprint blue",
     "blueprint-light", "blueprint", ("topo", "circuit"), 50, "minimal", "warp", "blueprint",
     {"face": "blueprint", "needle": "blade", "ticks": "fine"}, {}),
    # ---------------------------------------------------------------- Fun
    ("pop-art", "Pop Art", "Fun", "Thick outlines, hard shadows, comic-book color",
     "comic", "pop", ("kaleido", "plasma"), 70, "pulse", "plasma", "theme",
     {"face": "retro", "needle": "classic", "numerals": "bold"}, {}),
    ("toxic-slime", "Toxic Slime", "Fun", "Glossy goo panels that drip, oozing green",
     "toxic-slime", "slime", ("lava", "liquid"), 85, "liquid", "plasma", "thermal",
     {"face": "lava", "needle": "blade"}, {}),
    ("kaleidoscope", "Kaleidoscope", "Fun", "Mirrored patterns turning around the knob",
     "prism", "holo", ("kaleido", "vortex"), 75, "orbit", "plasma", "neon",
     {"face": "hologram", "needle": "comet"}, {}),
    ("arcade", "Arcade", "Fun", "Pixel-bright arcade colors, chunky retro gauges",
     "arcade", "retro", ("grid", "grid"), 75, "dotmatrix", "hyper", "synthwave",
     {"face": "retro", "needle": "classic", "numerals": "digital"}, {}),
]


def build():
    out, scenes_used = [], {}
    for (lid, name, group, desc, pal, style, (want, standin), amount, knob, splash, mapst, cl, extra) in L:
        assert pal in PAL, (lid, pal)
        assert style in STYLES or style in STYLE_BITS, (lid, style)
        assert knob in KNOBS, (lid, knob)
        assert splash in SPLASH and mapst in MAPS, lid
        scene = want if want in SCENES else standin
        assert scene in SCENES, (lid, scene)
        scenes_used[lid] = scene
        p = PAL[pal]
        colors = {k: p[k] for k in ("base", "b1", "b2", "b3", "accent")}
        colors["light"] = bool(p.get("light"))
        bfx, rip, clock = STYLE_BITS[style]
        face = cl.get("face", "neon")
        if face not in FACES:
            face = "neon"
        st = {"style": style if style in STYLES else "glass", "button_fx": bfx, "ripple_style": rip, "clock_style": clock,
              "knob_style": knob, "splash_style": splash, "map_style": mapst, "effect": "off",
              "flow": {"on": True, "scene": scene, "amount": amount},
              "cluster": dict({"look": "scene", "needle": "face", "ticks": "face", "numerals": "face", "arc": "face"},
                              **{k: v for k, v in cl.items() if k != "face" and (k != "needle" or v in NEEDLES)}, face=face)}
        for k, v in extra.items():
            st[k] = dict(st.get(k) or {}, **v) if isinstance(v, dict) else v
        out.append({"id": lid, "name": name, "group": group, "desc": desc, "colors": colors, "set": st,
                    "want": want if want != scene else None})
    return out


if __name__ == "__main__":
    looks = build()
    (WEB / "looks.json").write_text(json.dumps(looks, indent=1) + "\n")
    missing = sorted({x["want"] for x in looks if x["want"]})
    print(f"{len(looks)} looks; scenes still to come: {', '.join(missing) or 'none'}")
