#!/home/ryan/headunit/venv/bin/python
"""Talk to the screens' Chromium over the localhost debugging port (for measuring and profiling).

  cdp.py ui|cluster eval "<js expression>"     run JS in the page, print the result
  cdp.py ui|cluster fps [seconds]              frame rate measured inside the page (default 4 s)
  cdp.py ui|cluster css "<css>"                add a test stylesheet live (cdp.py ... css "" removes it)
  cdp.py ui|cluster layers                     composited layers: size, what they are, how often they repaint

ui = head unit (port 9222), cluster = instrument cluster (port 9223). Nothing is saved: a reload undoes it all.
"""
import asyncio
import json
import sys

import aiohttp

PORTS = {"ui": 9222, "cluster": 9223}

FPS_JS = """new Promise(res => { const t = [], t0 = performance.now(), d = %d;
  (function f(n) { t.push(n); if (n - t0 < d) requestAnimationFrame(f); else {
    const g = t.slice(1).map((v, i) => v - t[i]).sort((a, b) => a - b);
    res({ fps: +((t.length - 1) / ((t[t.length - 1] - t[0]) / 1000)).toFixed(1), p50: Math.round(g[g.length >> 1]),
          p95: Math.round(g[Math.floor(g.length * .95)]), worst: Math.round(g[g.length - 1]) }); } })(t0); })"""

CSS_JS = """(() => { let s = document.getElementById('__cdp_css'); if (!s) { s = document.createElement('style');
  s.id = '__cdp_css'; document.head.appendChild(s); } s.textContent = %s; return 'ok'; })()"""


async def layers(port, secs=3):
    async with aiohttp.ClientSession() as http:
        async with http.get(f"http://127.0.0.1:{port}/json") as r:
            pages = [p for p in await r.json() if p.get("type") == "page"]
        page = next((p for p in pages if "127.0.0.1:8080" in p.get("url", "")), pages[0])
        async with http.ws_connect(page["webSocketDebuggerUrl"], max_msg_size=0) as ws:
            await ws.send_json({"id": 1, "method": "DOM.enable"})
            await ws.send_json({"id": 2, "method": "LayerTree.enable"})
            tree, end = None, asyncio.get_event_loop().time() + secs
            while asyncio.get_event_loop().time() < end:
                try:
                    m = await asyncio.wait_for(ws.receive(), timeout=max(0.1, end - asyncio.get_event_loop().time()))
                except asyncio.TimeoutError:
                    break
                d = json.loads(m.data)
                if d.get("method") == "LayerTree.layerTreeDidChange" and d["params"].get("layers"):
                    tree = d["params"]["layers"]
            if not tree:
                return "no layer tree"
            rows, total = [], 0
            for i, l in enumerate(tree):
                if not l.get("drawsContent"):
                    continue
                area = l["width"] * l["height"]
                total += area
                desc = ""
                if l.get("backendNodeId"):
                    await ws.send_json({"id": 100 + i, "method": "DOM.describeNode", "params": {"backendNodeId": l["backendNodeId"]}})
                    while True:
                        d = json.loads((await ws.receive()).data)
                        if d.get("id") == 100 + i:
                            n = d.get("result", {}).get("node", {})
                            attrs = dict(zip(n.get("attributes", [])[::2], n.get("attributes", [])[1::2]))
                            desc = n.get("nodeName", "").lower() + ("#" + attrs["id"] if attrs.get("id") else "") + \
                                ("." + ".".join(attrs.get("class", "").split()[:2]) if attrs.get("class") else "")
                            break
                rows.append((area, f'{int(l["width"])}x{int(l["height"])}  paints={l.get("paintCount", 0)}  {desc or l.get("name", "")}'))
            rows.sort(reverse=True)
            return f"{len(rows)} drawing layers, total {total / 1e6:.2f} Mpx\n" + "\n".join(r for _, r in rows[:25])


async def evaluate(port, expr):
    async with aiohttp.ClientSession() as http:
        async with http.get(f"http://127.0.0.1:{port}/json") as r:
            pages = [p for p in await r.json() if p.get("type") == "page"]
        page = next((p for p in pages if "127.0.0.1:8080" in p.get("url", "")), pages[0])
        async with http.ws_connect(page["webSocketDebuggerUrl"], max_msg_size=0) as ws:
            await ws.send_json({"id": 1, "method": "Runtime.evaluate",
                                "params": {"expression": expr, "awaitPromise": True, "returnByValue": True}})
            async for m in ws:
                d = json.loads(m.data)
                if d.get("id") == 1:
                    res = d.get("result", {})
                    if "exceptionDetails" in res:
                        return "ERROR: " + json.dumps(res["exceptionDetails"].get("exception", {}).get("description", res))
                    return res.get("result", {}).get("value")


def main():
    if len(sys.argv) < 3 or sys.argv[1] not in PORTS:
        print(__doc__)
        sys.exit(1)
    port, cmd = PORTS[sys.argv[1]], sys.argv[2]
    if cmd == "eval":
        expr = sys.argv[3]
    elif cmd == "fps":
        expr = FPS_JS % int(float(sys.argv[3] if len(sys.argv) > 3 else 4) * 1000)
    elif cmd == "css":
        expr = CSS_JS % json.dumps(sys.argv[3] if len(sys.argv) > 3 else "")
    elif cmd == "layers":
        print(asyncio.run(layers(port)))
        return
    else:
        print(__doc__)
        sys.exit(1)
    out = asyncio.run(evaluate(port, expr))
    print(out if isinstance(out, str) else json.dumps(out))


if __name__ == "__main__":
    main()
