#!/usr/bin/env bash
# How busy the Pi 5 GPU (V3D) render queue is over N seconds (default 3). ~100% = the screens are GPU-bound (laggy).
F=/sys/devices/platform/axi/1002000000.v3d/gpu_stats
r() { awk '$1=="render"{print $4}' $F; }
S=${1:-3}; a=$(r); t0=$(date +%s%N); sleep "$S"; b=$(r); t1=$(date +%s%N)
echo "GPU render busy: $(( (b - a) * 100 / (t1 - t0) ))%"
