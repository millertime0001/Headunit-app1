#!/usr/bin/env bash
# Restart the whole head unit software (both Chromiums + backend) inside the running labwc session, without rebooting.
pkill -f "scripts/start-headunit.sh"; sleep 0.3
pkill -f "user-data-dir=$HOME/.config/headunit/chromium"   # both profiles (chromium and chromium-cluster)
pkill -f "^$HOME/headunit/venv/bin/python $HOME/headunit/backend/server.py"
sleep 2
pkill -9 -f "^$HOME/headunit/venv/bin/python $HOME/headunit/backend/server.py" 2>/dev/null
export WAYLAND_DISPLAY=wayland-0 XDG_SESSION_TYPE=wayland XDG_RUNTIME_DIR=/run/user/$(id -u) DBUS_SESSION_BUS_ADDRESS=unix:path=/run/user/$(id -u)/bus
setsid nohup "$HOME/headunit/scripts/start-headunit.sh" >/dev/null 2>&1 < /dev/null &
for _ in $(seq 60); do curl -s -m1 -o /dev/null http://127.0.0.1:8080/ && { echo "head unit restarted"; exit 0; }; sleep 0.5; done
echo "backend did not come back"; exit 1
