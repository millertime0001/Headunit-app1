package com.headunit.link

import android.location.Location
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sqrt

/**
 * The speed limit of the road you're on, for the cluster. Google Maps doesn't share its speed limit with other
 * apps, so this uses OpenStreetMap (the maxspeed tags). The roads around you (2 km) are downloaded once over
 * mobile data and matched to every GPS fix on the phone; a new area is fetched after ~1.3 km of driving.
 */
class SpeedLimit(private val scope: CoroutineScope, private val send: (JSONObject) -> Unit) {
    private class Seg(val wayId: Long, val ax: Double, val ay: Double, val bx: Double, val by: Double,
                      val kmh: Double?, val mph: Boolean, val name: String)

    private val http = OkHttpClient.Builder().callTimeout(25, TimeUnit.SECONDS).build()
    @Volatile private var segs: List<Seg> = emptyList()
    @Volatile private var lat0 = 0.0
    @Volatile private var lon0 = 0.0
    @Volatile private var have = false
    @Volatile private var fetching = false
    private var lastTry = 0L
    private var curWay = -1L
    private var lastSent = ""
    private var lastSentAt = 0L

    // metres east/north of the area's center (flat-earth is plenty for 2 km)
    private fun xy(lat: Double, lon: Double): Pair<Double, Double> =
        Pair((lon - lon0) * 111_320.0 * cos(Math.toRadians(lat0)), (lat - lat0) * 110_540.0)

    fun onFix(loc: Location) {
        val now = System.currentTimeMillis()
        if (!fetching && now - lastTry > 20_000L) {
            val far = !have || run { val (x, y) = xy(loc.latitude, loc.longitude); sqrt(x * x + y * y) > 1300.0 }
            if (far) fetch(loc.latitude, loc.longitude)
        }
        if (!have) return
        val (px, py) = xy(loc.latitude, loc.longitude)
        val moving = loc.hasBearing() && loc.hasSpeed() && loc.speed > 3f
        var best: Seg? = null; var bestScore = 1e9; var curScore = 1e9
        for (s in segs) {
            val dx = s.bx - s.ax; val dy = s.by - s.ay
            val len2 = dx * dx + dy * dy
            val t = if (len2 > 0) (((px - s.ax) * dx + (py - s.ay) * dy) / len2).coerceIn(0.0, 1.0) else 0.0
            val ex = s.ax + t * dx - px; val ey = s.ay + t * dy - py
            val d = sqrt(ex * ex + ey * ey)
            if (d > 35.0) continue
            var score = d
            if (moving && len2 > 4) {
                // road direction vs. your heading (either way along the road)
                val roadDeg = Math.toDegrees(atan2(dx, dy))
                var diff = abs(((loc.bearing - roadDeg) % 180.0 + 180.0) % 180.0)
                if (diff > 90) diff = 180 - diff
                score += diff / 90.0 * 30.0
            }
            if (s.wayId == curWay && score < curScore) curScore = score
            if (score < bestScore) { bestScore = score; best = s }
        }
        // stick with the road you were on unless another one clearly fits better (no flicker at junctions)
        val pick = if (curWay >= 0 && curScore < 1e8 && curScore - bestScore < 8.0) segs.firstOrNull { it.wayId == curWay } else best
        curWay = pick?.wayId ?: -1L
        val msg = JSONObject().put("cmd", "limit_push")
        if (pick?.kmh != null) {
            msg.put("kmh", pick.kmh).put("unit", if (pick.mph) "mph" else "kmh")
                .put("value", if (pick.mph) Math.round(pick.kmh / 1.609344) else Math.round(pick.kmh))
        } else msg.put("kmh", JSONObject.NULL)
        msg.put("road", pick?.name ?: "")
        val key = msg.toString()
        if (key != lastSent || now - lastSentAt > 15_000L) { lastSent = key; lastSentAt = now; send(msg) }
    }

    private fun fetch(lat: Double, lon: Double) {
        fetching = true
        lastTry = System.currentTimeMillis()
        scope.launch(Dispatchers.IO) {
            try {
                val q = "[out:json][timeout:20];way(around:2000,$lat,$lon)[highway~\"^(motorway|trunk|primary|secondary|" +
                    "tertiary|unclassified|residential|motorway_link|trunk_link|primary_link|secondary_link|tertiary_link)$\"];" +
                    "out tags geom;"
                val req = Request.Builder().url("https://overpass-api.de/api/interpreter")
                    .post(FormBody.Builder().add("data", q).build()).build()
                http.newCall(req).execute().use { r ->
                    if (!r.isSuccessful) return@use
                    val j = JSONObject(r.body?.string() ?: return@use)
                    val els = j.optJSONArray("elements") ?: return@use
                    val out = ArrayList<Seg>()
                    val oLat = lat; val oLon = lon
                    val k = cos(Math.toRadians(oLat))
                    for (i in 0 until els.length()) {
                        val e = els.getJSONObject(i)
                        val tags = e.optJSONObject("tags") ?: JSONObject()
                        val (kmh, mph) = parse(tags.optString("maxspeed"))
                        val name = tags.optString("name").ifBlank { tags.optString("ref") }
                        val g = e.optJSONArray("geometry") ?: continue
                        var px = 0.0; var py = 0.0
                        for (n in 0 until g.length()) {
                            val p = g.getJSONObject(n)
                            val x = (p.getDouble("lon") - oLon) * 111_320.0 * k
                            val y = (p.getDouble("lat") - oLat) * 110_540.0
                            if (n > 0) out += Seg(e.getLong("id"), px, py, x, y, kmh, mph, name)
                            px = x; py = y
                        }
                    }
                    lat0 = oLat; lon0 = oLon; segs = out; have = true; curWay = -1L
                }
            } catch (_: Exception) {
            } finally { fetching = false }
        }
    }

    /** OSM maxspeed: "45 mph", "50", "none", "signals", "US:urban"... -> (km/h, signposted in mph) */
    private fun parse(v: String): Pair<Double?, Boolean> {
        val m = Regex("""^\s*(\d+(?:\.\d+)?)\s*(mph|km/h|kmh|kph)?\s*$""").find(v) ?: return Pair(null, false)
        val n = m.groupValues[1].toDouble()
        return if (m.groupValues[2] == "mph") Pair(n * 1.609344, true) else Pair(n, false)
    }
}
