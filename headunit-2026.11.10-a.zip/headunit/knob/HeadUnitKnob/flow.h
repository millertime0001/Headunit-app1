/*
  Flow on the knob: the same scenes as web/flow.js (FLOW_GLSL + FLOW_MAIN), drawn for the knob's own patch of the
  dash so the colors and motion carry on from the head unit and the cluster next to it.
  World coordinates are millimetres (x right, y down). The scene is worked out at N x N (inside the circle only)
  in linear light, then mixed with the base by the amount, ripples added, tone mapped (1 - exp(-1.6c), gamma 1/2.2)
  and stretched to 240 x 240 with bilinear filtering and a little ordered dither.
  Fields from the Pi (S line, 23-29): scene, phase, rate, speed, "cx,cy,d", amount, ripples "x,y,ageMs,k;...".
*/
#pragma once
#include <math.h>

namespace flow {

const int N = 80;  // scene resolution: 80 x 80, shown 3x
enum { F_LIQUID, F_RIBBONS, F_AURORA, F_VORTEX, F_WARP, F_GRID, F_PLASMA, F_CALIBRATE,
       F_RAIN, F_OCEAN, F_CIRCUIT, F_EMBERS, F_SONAR,
       F_RAINWINDOW, F_SNOW, F_BOKEH, F_GALAXY, F_MATRIX, F_LAVA, F_FIREFLIES, F_PETALS, F_TOPO, F_SPEEDLINES, F_CAUSTICS, F_SMOKE, F_SILK, F_MOUNTAINS, F_NEON, F_NEONCITY, F_DUNES, F_CRYSTAL, F_CHROME, F_KALEIDO, F_FIREWORKS, F_COUNT };
const char *const NAMES[F_COUNT] = {"liquid", "ribbons", "aurora", "vortex", "warp", "grid", "plasma", "calibrate",
                                    "rain", "ocean", "circuit", "embers", "sonar",
                                    "rainwindow", "snow", "bokeh", "galaxy", "matrix", "lava", "fireflies", "petals", "topo", "speedlines", "caustics", "smoke", "silk", "mountains", "neon", "neoncity", "dunes", "crystal", "chrome", "kaleido", "fireworks"};
const float TAU = 6.2831853f;

struct V3 { float r, g, b; };
inline V3 operator+(V3 a, V3 b) { return {a.r + b.r, a.g + b.g, a.b + b.b}; }
inline V3 operator-(V3 a, V3 b) { return {a.r - b.r, a.g - b.g, a.b - b.b}; }
inline V3 operator*(V3 a, float k) { return {a.r * k, a.g * k, a.b * k}; }
inline V3 &operator+=(V3 &a, V3 b) { a.r += b.r; a.g += b.g; a.b += b.b; return a; }
inline V3 mixv(V3 a, V3 b, float t) { return {a.r + (b.r - a.r) * t, a.g + (b.g - a.g) * t, a.b + (b.b - a.b) * t}; }
const V3 WHITE = {1, 1, 1};

// ---- state from the Pi
int scene = -1;  // -1 = Flow off for the knob
double P0 = 0;
float rate = 1, speed = 0, amount = 0.75f;
unsigned long atMs = 0;
float kcx = 554, kcy = 218, kd = 32;  // knob center and diameter in the dash, mm
V3 B = {0, 0, 0}, H1 = {0, 1, 1}, H2 = {1, 0, 1}, H3 = {0, 1, 1}, HA = {0, 1, 1};  // base (linear) and hue() of blobs, accent
struct Pulse { float x, y; unsigned long start; uint8_t k; bool used; };
Pulse pulses[4];

// ---- fast math
float SINT[1025];
uint8_t TONE[1537];  // linear light 0..6 (x256) -> tone mapped sRGB 0..255
uint8_t TONEL[1537]; // the same for light themes: no tone curve, just clipped (keeps paper white)
bool lightT = false;
bool ready = false;
inline int ifloor(float f) { int i = (int)f; return f < i ? i - 1 : i; }
inline float fract(float x) { return x - floorf(x); }
inline float fsin(float x) {
  float f = x * (1024.0f / TAU);
  int i = ifloor(f);
  float fr = f - i;
  i &= 1023;
  return SINT[i] + (SINT[i + 1] - SINT[i]) * fr;
}
inline float fcos(float x) { return fsin(x + 1.5707963f); }
inline float fexp(float x) {
  if (x < -80) return 0;
  if (x > 80) x = 80;
  float t = x * 1.4426950f;
  int ii = ifloor(t);
  float f = t - ii;
  float p = 1 + f * (0.6931472f + f * (0.2402265f + f * (0.0555041f + f * 0.0096181f)));
  union { float f; int32_t i; } u;
  u.f = p;
  u.i += ii << 23;
  return u.f;
}
inline float clamp01(float x) { return x < 0 ? 0 : x > 1 ? 1 : x; }
inline float sstep(float e0, float e1, float x) { float t = clamp01((x - e0) * (1 / (e1 - e0))); return t * t * (3 - 2 * t); }  // 1/(e1-e0) folds away for constant edges
inline float h11(float p) { p = fract(p * .1031f); p *= p + 33.33f; p *= p + p; return fract(p); }
inline float h21(float x, float y) {
  float a = fract(x * .1031f), b = fract(y * .1031f), c = a;
  float d = a * (b + 33.33f) + b * (c + 33.33f) + c * (a + 33.33f);
  a += d; b += d; c += d;
  return fract((a + b) * c);
}
inline void h22(float x, float y, float &ox, float &oy) {
  float a = fract(x * .1031f), b = fract(y * .1030f), c = fract(x * .0973f);
  float d = a * (b + 33.33f) + b * (c + 33.33f) + c * (a + 33.33f);
  a += d; b += d; c += d;
  ox = fract((a + b) * c); oy = fract((a + c) * b);
}
inline float modp(float x, float y) { return x - y * floorf(x / y); }  // GLSL mod
inline V3 hue(V3 c) { float m = fmaxf(fmaxf(c.r, fmaxf(c.g, c.b)), 1e-3f); return c * (1 / m); }

// ---- buffers
float X[N], Y[N];                  // world mm of each scene cell
int8_t rowL[N], rowR[N];           // cells worth working out on each row (the circle + a margin for filtering)
float *tA = nullptr, *tB = nullptr, *tC = nullptr, *tD = nullptr;  // per-cell tables for vortex and warp
int tableFor = -1;
float geoKey[3] = {-1, -1, -1};
uint8_t *rgb = nullptr;            // N*N*3 result
uint8_t upI[240];                  // bilinear: lower cell and weight (0..256) for each screen column/row
uint16_t upW[240];

void init() {
  for (int i = 0; i <= 1024; i++) SINT[i] = sinf(i * TAU / 1024);
  for (int i = 0; i <= 1536; i++) {
    float c = i / 256.0f;
    float v = powf(1 - expf(-c * 1.6f), 0.4545f) * 255 + 0.5f;
    TONE[i] = v > 255 ? 255 : (uint8_t)v;
    v = powf(c > 1 ? 1 : c, 0.4545f) * 255 + 0.5f;
    TONEL[i] = v > 255 ? 255 : (uint8_t)v;
  }
  for (int x = 0; x < 240; x++) {
    float s = (x + 0.5f) * N / 240.0f - 0.5f;
    if (s < 0) s = 0;
    int i = ifloor(s);
    if (i > N - 2) i = N - 2;
    float w = s - i;
    if (w > 1) w = 1;
    upI[x] = i; upW[x] = (uint16_t)(w * 256 + 0.5f);
  }
  for (int j = 0; j < N; j++) {
    float dy = j + 0.5f - N / 2.0f, rr = N / 2.0f + 1.6f;
    float h = dy * dy < rr * rr ? sqrtf(rr * rr - dy * dy) : -1;
    if (h < 0) { rowL[j] = 1; rowR[j] = 0; continue; }
    int l = ifloor(N / 2.0f - 0.5f - h), r = (int)ceilf(N / 2.0f - 0.5f + h);
    rowL[j] = l < 0 ? 0 : l; rowR[j] = r > N - 1 ? N - 1 : r;
  }
  size_t n = N * N * sizeof(float);
  tA = (float *)ps_malloc(n); tB = (float *)ps_malloc(n); tC = (float *)ps_malloc(n); tD = (float *)ps_malloc(n);
  if (!tA || !tB || !tC || !tD) { tA = (float *)malloc(n); tB = (float *)malloc(n); tC = (float *)malloc(n); tD = (float *)malloc(n); }
  rgb = (uint8_t *)malloc(N * N * 3);
  memset(rgb, 0, N * N * 3);
  ready = tA && tB && tC && tD && rgb;
}

// ---- messages
V3 linHex(const String &h) {
  uint32_t v = strtoul(h.c_str(), nullptr, 16);
  float c[3];
  for (int k = 0; k < 3; k++) {
    float x = ((v >> (16 - 8 * k)) & 255) / 255.0f;
    c[k] = x <= 0.04045f ? x / 12.92f : powf((x + 0.055f) / 1.055f, 2.4f);
  }
  return {c[0], c[1], c[2]};
}
void colors(const String &accent, const String &base, const String &b1, const String &b2, const String &b3) {
  HA = hue(linHex(accent)); B = linHex(base);
  lightT = B.r * .2126f + B.g * .7152f + B.b * .0722f > .3f;
  H1 = hue(linHex(b1)); H2 = hue(linHex(b2)); H3 = hue(linHex(b3));
}
void addPulses(const String &s) {
  unsigned long now = millis();
  int from = 0;
  while (from < (int)s.length()) {
    int semi = s.indexOf(';', from);
    String one = semi < 0 ? s.substring(from) : s.substring(from, semi);
    from = semi < 0 ? s.length() : semi + 1;
    float x, y; long age; int k;
    if (sscanf(one.c_str(), "%f,%f,%ld,%d", &x, &y, &age, &k) != 4 || age < 0 || age >= 2600 || k <= 0) continue;
    unsigned long start = now - age;
    bool dup = false;
    for (auto &p : pulses)
      if (p.used && fabsf(p.x - x) < 1.5f && fabsf(p.y - y) < 1.5f && labs((long)(p.start - start)) < 150) { dup = true; break; }
    if (dup) continue;
    Pulse *slot = nullptr;  // a free slot, else the oldest
    for (auto &p : pulses) if (!p.used || now - p.start >= 2600) { slot = &p; break; }
    if (!slot) { slot = &pulses[0]; for (auto &p : pulses) if (p.start < slot->start) slot = &p; }
    *slot = {x, y, start, (uint8_t)k, true};
  }
}
// Fields 23..29 of the S line (n = how many fields the line had).
void fields(const String *f, int n) {
  int sc = -1;
  if (n > 23) for (int i = 0; i < F_COUNT; i++) if (f[23] == NAMES[i]) sc = i;
  scene = sc;
  if (sc < 0) return;
  if (n > 24 && f[24].length()) { P0 = f[24].toDouble(); atMs = millis(); }
  if (n > 25 && f[25].length()) rate = f[25].toFloat();
  if (n > 26 && f[26].length()) speed = constrain(f[26].toFloat(), 0.0f, 1.0f);
  if (n > 27) { float a, b, c; if (sscanf(f[27].c_str(), "%f,%f,%f", &a, &b, &c) == 3 && c > 1) { kcx = a; kcy = b; kd = c; } }
  if (n > 28 && f[28].length()) amount = constrain(f[28].toFloat() / 100.0f, 0.1f, 1.0f);
  if (n > 29) addPulses(f[29]);
}

// ---- per-cell tables (only the scenes that need them; rebuilt when the scene or the knob's place changes)
void tables() {
  bool geo = geoKey[0] != kcx || geoKey[1] != kcy || geoKey[2] != kd;
  if (geo) {
    geoKey[0] = kcx; geoKey[1] = kcy; geoKey[2] = kd;
    for (int i = 0; i < N; i++) { X[i] = kcx - kd / 2 + (i + 0.5f) * kd / N; Y[i] = kcy - kd / 2 + (i + 0.5f) * kd / N; }
    tableFor = -1;
  }
  if (tableFor == scene) return;
  tableFor = scene;
  if (scene == F_VORTEX) {
    for (int j = 0; j < N; j++) for (int i = 0; i < N; i++) {
      float dx = (X[i] - kcx) / 100, dy = (Y[j] - kcy) / 100;
      float r = sqrtf(dx * dx + dy * dy), a = atan2f(dy, dx), lr = logf(r + .12f);
      int k = j * N + i;
      tA[k] = a * 3 + lr * 5; tB[k] = a * 5 - lr * 7; tC[k] = lr * 2; tD[k] = r;
    }
  } else if (scene == F_WARP) {
    for (int j = 0; j < N; j++) for (int i = 0; i < N; i++) {
      float dx = (X[i] - 345) / 100, dy = (Y[j] - 70) / 100;
      int k = j * N + i;
      tA[k] = sqrtf(dx * dx + dy * dy); tB[k] = (atan2f(dy, dx) + (float)PI) / TAU;
    }
  } else if (scene == F_KALEIDO) {
    for (int j = 0; j < N; j++) for (int i = 0; i < N; i++) {
      float dx = (X[i] - kcx) / 70, dy = (Y[j] - kcy) / 70, r = sqrtf(dx * dx + dy * dy);
      int k = j * N + i;
      tA[k] = r; tB[k] = atan2f(dy, dx); tC[k] = fexp(-r * r * 4) * .3f; tD[k] = .35f + .65f * fexp(-r * .25f);
    }
  } else if (scene == F_SONAR) {
    for (int j = 0; j < N; j++) for (int i = 0; i < N; i++) {
      float dx = X[i] - kcx, dy = Y[j] - kcy, r = sqrtf(dx * dx + dy * dy);
      float g = (fract(r / 11) - .5f) * 11 / .6f;
      int k = j * N + i;
      tA[k] = r; tB[k] = atan2f(dy, dx); tC[k] = expf(-g * g) * .025f;
    }
  }
}

// ---- the finishing step (FLOW_MAIN): amount, ripples, tone map
struct LivePulse { float x, y, front, w, amp; V3 col; float gain; };
LivePulse live[4];
int nLive = 0;
inline void put(int i, int j, V3 c) {
  c = mixv(B, c, amount);
  for (int q = 0; q < nLive; q++) {
    const LivePulse &u = live[q];
    float dx = X[i] - u.x, dy = Y[j] - u.y, e = (sqrtf(dx * dx + dy * dy) - u.front) / u.w;
    if (e > 3 || e < -3) continue;
    float ring = fexp(-e * e) * u.amp;
    c += u.col * (ring * u.gain);
    float wr = ring * ring * .15f;
    c += V3{wr, wr, wr};
  }
  uint8_t *o = rgb + (j * N + i) * 3;
  int r = (int)(c.r * 256), g = (int)(c.g * 256), b = (int)(c.b * 256);
  const uint8_t *T = lightT ? TONEL : TONE;
  o[0] = T[r < 0 ? 0 : r > 1536 ? 1536 : r];
  o[1] = T[g < 0 ? 0 : g > 1536 ? 1536 : g];
  o[2] = T[b < 0 ? 0 : b > 1536 ? 1536 : b];
}

// ---- the scenes (same math as FLOW_GLSL in web/flow.js; phases that grow with P are wrapped in double first)
double Pd;
float Pf;
inline float ph(double k, double c = 0) { return (float)fmod(k * Pd + c, (double)TAU); }

void sceneLiquid() {
  float bx[7], by[7], r2[7];
  V3 bc[7];
  for (int i = 0; i < 7; i++) {
    bx[i] = 300 + 330 * sinf(ph(.045 + i * .011, i * 1.9));
    by[i] = 115 + 120 * sinf(ph(.06 + i * .013, i * 2.7));
    float r = 48 + 14 * sinf(ph(.2, i));
    r2[i] = r * r;
    bc[i] = i == 6 ? HA : i % 3 == 0 ? H1 : i % 3 == 1 ? H2 : H3;
  }
  for (int j = 0; j < N; j++) for (int i = rowL[j]; i <= rowR[j]; i++) {
    float f = 0, ws = 0;
    V3 col = {0, 0, 0};
    for (int k = 0; k < 7; k++) {
      float dx = X[i] - bx[k], dy = Y[j] - by[k], w = r2[k] / (dx * dx + dy * dy + 1);
      f += w; ws += w; col += bc[k] * w;
    }
    col = col * (1 / fmaxf(ws, 1e-3f));
    float inside = sstep(.85f, 1.25f, f);
    float rim = sstep(.7f, 1, f) * (1 - sstep(1, 1.5f, f));
    V3 c = B * .9f + col * (.003f + .035f * sstep(.25f, .95f, f));
    c += col * (inside * (.2f + .3f * sstep(1.2f, 4, f)));
    c += mixv(col, WHITE, .55f) * (rim * .3f);
    if (lightT) {   // light themes: tinted glass blobs on the paper
      V3 m = mixv(WHITE, col * .85f, clamp01(inside * .5f + rim * .3f + .12f * sstep(.25f, .95f, f)));
      c = V3{B.r * m.r, B.g * m.g, B.b * m.b};
    }
    put(i, j, c);
  }
}

void sceneRibbons() {
  V3 cols[7];
  float a1[7], a2[7], a3[7];
  for (int k = 0; k < 7; k++) {
    cols[k] = k == 3 ? HA : k % 3 == 0 ? H1 : k % 3 == 1 ? H2 : H3;
    a1[k] = ph(-(.5 + k * .07), k * 1.7); a2[k] = ph(.31, k * 4.0); a3[k] = ph(.4, k);
  }
  float yc[7], th[7], ith2[7];
  V3 base = B * .85f + H2 * .005f;
  for (int i = 0; i < N; i++) {  // ribbons only depend on x: work them out once per column
    float ux = X[i] / 100;
    for (int k = 0; k < 7; k++) {
      yc[k] = .3f + k * .26f + .22f * fsin(ux * (.9f + k * .13f) + a1[k]) + .1f * fsin(ux * 2.1f + a2[k]);
      th[k] = .01f + .025f * (.5f + .5f * fsin(ux * 1.3f + a3[k]));
      ith2[k] = 1 / (th[k] * th[k]);
    }
    for (int j = 0; j < N; j++) {
      if (i < rowL[j] || i > rowR[j]) continue;
      float uy = Y[j] / 100;
      V3 c = base;
      for (int k = 0; k < 7; k++) {
        float d = fabsf(uy - yc[k]);
        float e = d * d * ith2[k];
        if (d > 1.3f && e > 20) continue;  // both terms below 1e-7
        c += cols[k] * ((e < 20 ? fexp(-e) * .5f : 0) + fexp(-d * 9) * .012f);
      }
      put(i, j, c);
    }
  }
}

void sceneAurora() {
  // x = u.x - P*.12 folded into each phase
  float pa[3], pb[3], pr[3], pq[3], pin = ph(.14);
  for (int k = 0; k < 3; k++) { pa[k] = ph(.026, k * 2.1); pb[k] = ph(-.646, k); pr[k] = ph(-1.08, k * 7.0); pq[k] = ph(-1.66, k); }
  V3 cols[3] = {H1, H3, H2};
  float y0[3], rays[3];
  for (int i = 0; i < N; i++) {
    float ux = X[i] / 100, inner = fsin(ux * 3 + pin);
    for (int k = 0; k < 3; k++) {
      y0[k] = .75f + k * .45f + .28f * fsin(ux * .7f + pa[k]) + .1f * fsin(ux * 2.3f + pb[k]);
      rays[k] = (.55f + .45f * fsin(ux * 9 + inner * 2 + pr[k])) * (.65f + .35f * fsin(ux * 23 + pq[k]));
    }
    for (int j = 0; j < N; j++) {
      if (i < rowL[j] || i > rowR[j]) continue;
      float uy = Y[j] / 100;
      V3 c = B * .8f + H3 * (.007f * sstep(2.6f, 0, uy));
      for (int k = 0; k < 3; k++) {
        float d = uy - y0[k];
        float body = d < 0 ? fexp(d * 2.4f) * rays[k] : fexp(-d * d * 140);
        c += cols[k] * (body * .3f);
      }
      put(i, j, c);
    }
  }
}

void sceneVortex() {
  float p1 = ph(-1.1), p2 = ph(.75), p3 = ph(-.3);
  for (int j = 0; j < N; j++) for (int i = rowL[j]; i <= rowR[j]; i++) {
    int k = j * N + i;
    float r = tD[k];
    float s1 = fsin(tA[k] + p1), s2 = fsin(tB[k] + p2);
    float arms = sstep(.2f, 1, s1) * .8f + sstep(.55f, 1, s2) * .35f;
    float fall = 1 / (1 + r * 1.2f);
    V3 col = mixv(H1, H2, .5f + .5f * fsin(tC[k] + p3));
    col = mixv(col, H3, (.5f + .5f * s2) * .4f);
    V3 c = B * .85f + col * (arms * arms * (.03f + .35f * fall)) + HA * (fexp(-r * r * 30) * .8f);
    put(i, j, c);
  }
}

void sceneWarp() {
  V3 white3 = mixv(H3, WHITE, .5f);
  float lenK = .12f + .5f * speed, spK = .14f;
  for (int j = 0; j < N; j++) for (int i = rowL[j]; i <= rowR[j]; i++) {
    int k = j * N + i;
    float r = tA[k], s01 = tB[k];
    V3 c = B * .85f + H2 * (.02f * fexp(-r * .8f));
    for (int l = 0; l < 2; l++) {
      float sec = s01 * (l == 0 ? 160 : 260), id = floorf(sec);
      float rnd = h11(id * 1.37f + l * 7.1f);
      if (rnd < .35f) continue;
      float s = fract(rnd * 3.1f + Pf * (spK * (.5f + rnd)));
      float rs = .05f * fexp(s * 4.2f), len = rs * lenK;
      if (r < rs - len || r > rs) continue;
      float on = sstep(rs - len, rs, r);
      float w = fabsf(fract(sec) - .5f) * 2;
      float line = on * sstep(1, .3f, w) * sstep(0, .25f, s);
      if (line <= 0) continue;
      V3 col = rnd > .8f ? HA : rnd > .55f ? H1 : white3;
      c += col * (line * (.7f + .8f * s));
    }
    put(i, j, c);
  }
}

void sceneGrid() {
  const float H = 78;
  float pix = kd / 240;  // one screen pixel on the knob, mm (stands in for fwidth)
  float cutPh = (float)fmod(Pd * 5, 9.0), gzPh = (float)fmod(Pd * 1.2, 1.0);
  for (int j = 0; j < N; j++) for (int i = rowL[j]; i <= rowR[j]; i++) {
    float px = X[i], py = Y[j];
    V3 c;
    if (py < H) {
      float k = (H - py) / 120;
      c = mixv(H2 * .12f, B * .9f, sstep(0, 1, k)) + HA * (.05f * fexp(-k * 6));
      float sdx = px - 205, sdy = py - (H - 6), sl = sqrtf(sdx * sdx + sdy * sdy), sr = 58;
      float sun = sstep(sr, sr - 2, sl);
      float cut = py > H - 38 ? sstep(.34f, .42f, fract((py + cutPh) / 9)) : 1;
      V3 sc = mixv(HA, H2, sstep(H - 70, H, py));
      c = mixv(c, sc * 1.1f, sun * cut);
      c += sc * (.35f * fexp(-fmaxf(sl - sr, 0) * .05f) * (1 - sun));
    } else {
      float dy = (py - H) / 100 + .015f, z = 1 / dy;
      float gx = (px - 345) / 100 * z * .55f, gz = z * .9f + gzPh;
      float dz = z * z / 100;  // |dz/dy| per mm
      float fwx = (z * .55f / 100 + fabsf((px - 345) / 100 * .55f) * dz) * pix * 1.5f + .02f;
      float fwy = .9f * dz * pix * 1.5f + .02f;
      float gxx = fabsf(fract(gx) - .5f), gzz = fabsf(fract(gz) - .5f);
      float line = fmaxf(sstep(fwx, 0, .5f - gxx), sstep(fwy, 0, .5f - gzz));
      float fade = fexp(-z * .12f);
      c = B * .7f + H2 * .006f + HA * (line * fade * .9f) + H2 * (.12f * fexp(-(py - H) * .06f));
    }
    put(i, j, c);
  }
}

void scenePlasma() {
  float a1 = ph(.3), a2 = ph(.39), a3 = ph(.21), a4 = ph(.3), a5 = ph(.3), a6 = ph(.6);
  float cx = 3.5f + sinf(ph(.09)) * 2;
  float colX[N], rowY[N];
  for (int i = 0; i < N; i++) colX[i] = fsin(X[i] / 100 * 1.6f + a1);
  for (int j = 0; j < N; j++) rowY[j] = fsin(Y[j] / 100 * 2.1f - a2);
  for (int j = 0; j < N; j++) for (int i = rowL[j]; i <= rowR[j]; i++) {
    float ux = X[i] / 100, uy = Y[j] / 100, dx = ux - cx, dy = uy - 1;
    float v = colX[i] + rowY[j] + fsin((ux + uy) * 1.2f + a3) + fsin(sqrtf(dx * dx + dy * dy) * 2.4f - a4);
    v *= .25f;
    V3 col = mixv(mixv(H1, H2, .5f + .5f * fsin(v * (float)PI)), H3, .5f + .5f * fcos(v * 4 + a5));
    float s = .5f + .5f * fsin(v * TAU + a6);
    put(i, j, B * .75f + col * (.01f + .22f * s * s * s));
  }
}

void sceneCalibrate() {
  float bx = (float)fmod(Pd * 110, 700.0) - 30, by = (float)fmod(Pd * 45, 280.0) - 20;
  for (int j = 0; j < N; j++) for (int i = rowL[j]; i <= rowR[j]; i++) {
    float px = X[i], py = Y[j];
    V3 c = B * .5f;
    float gx = fabsf(fract(px / 50 + .5f) - .5f) * 50, gy = fabsf(fract(py / 50 + .5f) - .5f) * 50;
    float g = .12f * sstep(1.2f, 0, fminf(gx, gy));
    gx = fabsf(fract(px / 100 + .5f) - .5f) * 100; gy = fabsf(fract(py / 100 + .5f) - .5f) * 100;
    g += .25f * sstep(1.4f, 0, fminf(gx, gy));
    c += V3{g, g, g};
    c += HA * (sstep(9, 0, fabsf(px - bx)) * 1.4f);
    c += H2 * (sstep(7, 0, fabsf(py - by)) * 1.1f);
    float dx = px - kcx, dy = py - kcy, ring = sstep(6, 4, fabsf(sqrtf(dx * dx + dy * dy) - 16));
    c += V3{ring, ring, ring};
    put(i, j, c);
  }
}

void sceneRain() {
  float fs = sinf(ph(.71)) * sinf(ph(1.33)) * sinf(ph(.57));
  float flash = fs > 0 ? powf(fs, 14) * 6 : 0;
  V3 drop = mixv(H3, V3{.9f, .9f, .9f}, .5f);
  // each rain column's random numbers and its phase (worked out in double, P * speed gets big)
  const int MAXC = 64;
  struct Col { float r, invPer, base, len; };
  static Col cols[3][MAXC];
  int c0[3], nc[3];
  float qMin = X[0] + Y[0] * .2f - 1, qMax = X[N - 1] + Y[N - 1] * .2f + 1;
  for (int l = 0; l < 3; l++) {
    float cw = 2.6f + l * 1.7f;
    c0[l] = (int)floorf(qMin / cw);
    nc[l] = min(MAXC, (int)floorf(qMax / cw) - c0[l] + 1);
    for (int k = 0; k < nc[l]; k++) {
      float col = float(c0[l] + k), r = h11(col * 1.7f + l * 13.0f);
      double sp = (190. + r * 150.) * 1.4 * (1. - l * .22), per = 90. + r * 110.;
      double b = -Pd * sp / per + r * 7.;
      cols[l][k] = {r, (float)(1 / per), (float)(b - floor(b)), .16f + .1f * r};
    }
  }
  for (int j = 0; j < N; j++) {
    float py = Y[j];
    V3 bg = B * .85f + H3 * .006f + H2 * (flash * .05f * sstep(260, 0, py)) + H1 * (.02f * sstep(140, 260, py));
    for (int i = rowL[j]; i <= rowR[j]; i++) {
      float qx = X[i] + py * .2f;
      V3 c = bg;
      for (int l = 0; l < 3; l++) {
        float cw = 2.6f + l * 1.7f, u = qx / cw;
        int k = (int)floorf(u) - c0[l];
        if (k < 0 || k >= nc[l]) continue;
        const Col &C = cols[l][k];
        if (C.r < .25f) continue;
        float t = fract(py * C.invPer + C.base);
        if (t > C.len) continue;
        float d = fabsf(u - floorf(u) - .5f) * cw;
        c += drop * ((t / C.len) * fexp(-d * d / (.12f + l * .1f)) * (.5f - l * .12f));
      }
      put(i, j, c);
    }
  }
}

void sceneOcean() {
  const float H = 72, mx = 470, my = 34;
  double k = .6;
  float o1 = ph(3.1 * k), o2 = ph(5.3 * k, 1.3), o3 = ph(9.1 * k), sp2 = ph(2);
  V3 moon = mixv(WHITE, HA, .2f), gl = mixv(WHITE, HA, .3f);
  for (int j = 0; j < N; j++) for (int i = rowL[j]; i <= rowR[j]; i++) {
    float px = X[i], py = Y[j];
    V3 c;
    if (py < H) {
      float kk = (H - py) / 90;
      c = mixv(H3 * .05f, B * .8f, sstep(0, 1, kk));
      float fx = floorf(px / 1.6f), fy = floorf(py / 1.6f), h = h21(fx, fy);
      if (h >= .996f) { float st = .5f + .5f * fsin(sp2 + h * 40); c += V3{.5f, .5f, .5f} * (st * sstep(0, .4f, kk)); }
      float dx = px - mx, dy = py - my, dm = sqrtf(dx * dx + dy * dy);
      c += moon * (sstep(13, 12, dm) * .9f);
      c += HA * (.12f * fexp(-fmaxf(dm - 12, 0) * .04f));
    } else {
      float dy = (py - H) / 100 + .01f, z = 1 / dy;
      float gx = (px - mx) / 100 * z, gz = z * 1.4f;   // + P * k, folded into o1..o3
      float w = fsin(gx * 2.1f + gz * 3.1f + o1) * .5f + fsin(gx * -3.7f + gz * 5.3f + o2) * .3f + fsin(gz * 9.1f - gx * 1.3f + o3) * .2f;
      c = mixv(H3 * .03f, B * .9f, sstep(0, 2.5f, dy * 10));
      if (w > 0) {
        float w3 = w * w * w;
        c += gl * (w3 * w3 * fexp(-fabsf(px - mx) / (25 + (py - H) * 1.2f)) * 1.4f);
        c += H1 * (w3 * .05f * fexp(-z * .15f));
      }
    }
    put(i, j, c);
  }
}

void sceneCircuit() {
  const float G = 16;
  // pulse phases per row of cells (along x) and per column of cells (along y), in double
  float rowInv[N], rowBase[N], colInv[N], colBase[N];
  for (int j = 0; j < N; j++) {
    float cy = floorf(Y[j] / G), rr = h11(cy * 3.3f);
    double sp = (60. + rr * 90.) * 1.6, per = 180. + rr * 220., b = -Pd * sp / per + rr;
    rowInv[j] = (float)(1 / per); rowBase[j] = (float)(b - floor(b));
  }
  for (int i = 0; i < N; i++) {
    float cx = floorf(X[i] / G), rc = h11(cx * 5.1f);
    double sp = (40. + rc * 70.) * 1.6, per = 120. + rc * 160., b = -Pd * sp / per + rc;
    colInv[i] = (float)(1 / per); colBase[i] = (float)(b - floor(b));
  }
  for (int j = 0; j < N; j++) for (int i = rowL[j]; i <= rowR[j]; i++) {
    float px = X[i], py = Y[j];
    float cx = floorf(px / G), cy = floorf(py / G), fx = px / G - cx - .5f, fy = py / G - cy - .5f;
    float hx = h21(floorf(px / (G * 3)) + 3.1f, cy + 3.1f), hy = h21(cx + 7.7f, floorf(py / (G * 3)) + 7.7f);
    bool onH = hx >= .42f, onV = hy >= .55f;
    float dh = fabsf(fy) * G, dv = fabsf(fx) * G;
    float th = onH ? fexp(-dh * dh * 1.6f) : 0, tv = onV ? fexp(-dv * dv * 1.6f) : 0;
    V3 c = B * .85f + H3 * ((th + tv) * .045f);
    if (onH && onV) c += H1 * (sstep(2.6f, 2, sqrtf(dh * dh + dv * dv)) * .25f);
    if (th > 1e-4f) {
      float s = fract(px * rowInv[j] + rowBase[j]);
      c += HA * (th * sstep(0, .1f, s) * sstep(.16f, .1f, s) * (s / .16f) * 1.3f);
    }
    if (tv > 1e-4f) {
      float s = fract(py * colInv[i] + colBase[i]);
      c += H2 * (tv * sstep(0, .1f, s) * sstep(.16f, .1f, s) * (s / .16f) * 1.1f);
    }
    put(i, j, c);
  }
}

// Embers: each layer is a grid of cells drifting up and right, each cell maybe holding one ember; a pixel only
// sees the embers of its own cell and the 8 around it (like the shader). The cells near the knob are worked out
// once per frame; the drift is split into whole cells (for the hash ids) and a remainder (for positions).
void sceneEmbers() {
  const int M = 8;  // cells per side covered by the knob plus neighbours (32 mm / 14 mm + 3, rounded up)
  struct Em { float x, y, inv2, amp; V3 col; bool on; };
  static Em em[2][M][M];
  int bx0[2], by0[2];
  float offx[2], offy[2], Gs[2];
  for (int l = 0; l < 2; l++) {
    float G = 14 + l * 9;
    Gs[l] = G;
    double ox = Pd * (4. + l * 3.), oy = Pd * (20. + l * 9.) * 1.3;
    double cxD = floor(ox / G), cyD = floor(oy / G);
    offx[l] = (float)(ox - cxD * G); offy[l] = (float)(oy - cyD * G);   // remainder, 0..G
    float cxW = (float)cxD, cyW = (float)cyD;                              // whole cells (hash ids)
    bx0[l] = (int)floorf((X[0] + offx[l]) / G) - 1; by0[l] = (int)floorf((Y[0] + offy[l]) / G) - 1;
    for (int a = 0; a < M; a++) for (int b = 0; b < M; b++) {
      float lx = float(bx0[l] + b), ly = float(by0[l] + a);   // local cell (q minus the whole-cell drift)
      float rx, ry;
      h22(lx + cxW + l * 17.0f, ly + cyW + l * 17.0f, rx, ry);
      Em &e = em[l][a][b];
      e.on = rx >= .45f;
      if (!e.on) continue;
      float wob = sinf((float)fmod(Pd * (.8 + ry), (double)TAU) + rx * 30) * 3;
      e.x = (lx + .5f + (rx - .5f) * .7f) * G + wob;
      e.y = (ly + .5f + (ry - .5f) * .7f) * G;
      float sz = .5f + ry * 1.1f;
      e.inv2 = 1 / (sz * sz);
      float fl2 = .55f + .45f * sinf((float)fmod(Pd * (5. + rx * 6.), (double)TAU) + ry * 20);
      e.amp = fl2 * (1 - l * .35f);
      e.col = mixv(HA, mixv(H1, V3{1, .85f, .6f}, .4f), ry);
    }
  }
  V3 glow = mixv(HA, H2, .4f);
  for (int j = 0; j < N; j++) for (int i = rowL[j]; i <= rowR[j]; i++) {
    V3 c = B * .85f + glow * (.05f * sstep(120, 260, Y[j]));
    for (int l = 0; l < 2; l++) {
      float qx = X[i] + offx[l], qy = Y[j] + offy[l], G = Gs[l];
      int ix = (int)floorf(qx / G) - bx0[l], iy = (int)floorf(qy / G) - by0[l];
      for (int a = iy - 1; a <= iy + 1; a++) for (int b = ix - 1; b <= ix + 1; b++) {
        if (a < 0 || b < 0 || a >= M || b >= M) continue;
        const Em &e = em[l][a][b];
        if (!e.on) continue;
        float dx = qx - e.x, dy = qy - e.y, d2 = dx * dx + dy * dy;
        if (d2 > 400) continue;  // > 20 mm: nothing left of the halo
        float g = d2 * e.inv2;
        float v = (g < 14 ? fexp(-g) * .9f : 0) + fexp(-sqrtf(d2) * .5f) * .03f;
        c += e.col * (v * e.amp);
      }
    }
    put(i, j, c);
  }
}

void sceneSonar() {
  float sw = (float)fmod(Pd * 1.1, (double)TAU), rph = (float)fmod(Pd * .22, 1.0);
  V3 blipC = mixv(HA, WHITE, .4f);
  for (int j = 0; j < N; j++) for (int i = rowL[j]; i <= rowR[j]; i++) {
    int k = j * N + i;
    float px = X[i], py = Y[j], r = tA[k], a = tB[k];
    V3 c = B * .85f + H3 * (.01f * fexp(-r * .004f));
    float g = (fract(r / 55 - rph) - .5f) * 55 / 2.2f;
    c += H3 * (fexp(-g * g) * .22f * fexp(-r * .0035f));
    c += H1 * tC[k];
    float da = modp(sw - a, TAU);
    c += HA * (fexp(-da * 2.6f) * .3f * fexp(-r * .002f));
    float bcx = floorf(px / 30), bcy = floorf(py / 30);
    if (h21(bcx + 9, bcy + 9) >= .8f) {
      float hx, hy;
      h22(bcx, bcy, hx, hy);
      float bpx = (bcx + .2f + .6f * hx) * 30, bpy = (bcy + .2f + .6f * hy) * 30;
      float dx = px - bpx, dy = py - bpy, dl = sqrtf(dx * dx + dy * dy);
      if (dl < 3) {
        float bd = modp(sw - atan2f(bpy - kcy, bpx - kcx), TAU);
        c += blipC * (sstep(3, 1.5f, dl) * fexp(-bd * 1.2f) * 1.5f);
      }
    }
    put(i, j, c);
  }
}

// ================================================================ scenes added 2026-11-08 (same math as web/flow.js)
// Per-pixel time terms use Pf (float, like the GPU); per-frame ones use ph() (double, wrapped).
inline float vn(float x, float y) {
  float ix = floorf(x), iy = floorf(y), fx = x - ix, fy = y - iy;
  fx = fx * fx * (3 - 2 * fx); fy = fy * fy * (3 - 2 * fy);
  float a = h21(ix, iy), b = h21(ix + 1, iy), c = h21(ix, iy + 1), d = h21(ix + 1, iy + 1);
  return a + (b - a) * fx + (c - a) * fy + (a - b - c + d) * fx * fy;
}
inline float vn1(float x) { float i = floorf(x), f = x - i; f = f * f * (3 - 2 * f); float a = h11(i); return a + (h11(i + 1) - a) * f; }
inline float fbm(float x, float y, int o) {
  float s = 0, a = .5f;
  for (int i = 0; i < o; i++) { s += a * vn(x, y); x = x * 2.03f + 1.7f; y = y * 2.03f + 9.2f; a *= .5f; }
  return s;
}
inline float cmp(float d, float r) { float k = clamp01(1 - d / r); return k * k; }
inline float gx(int i) { return kcx - kd / 2 + (i + 0.5f) * kd / N; }
inline float gy(int j) { return kcy - kd / 2 + (j + 0.5f) * kd / N; }
inline float sqf(float x) { return x * x; }
inline float len2(float x, float y) { return sqrtf(x * x + y * y); }
V3 stars(float px, float py, float G, float dens) {
  float ix = floorf(px / G), iy = floorf(py / G), h = h21(ix + 3.7f, iy + 3.7f);
  if (h < dens) return V3{0, 0, 0};
  float rx, ry; h22(ix, iy, rx, ry);
  float d = len2(px - (ix + .25f + .5f * rx) * G, py - (iy + .25f + .5f * ry) * G);
  if (d >= .55f) return V3{0, 0, 0};
  float k = sstep(.55f, 0, d) * (.55f + .45f * fsin(Pf * (1.3f + rx * 2) + ry * 50)) * (.25f + (h - dens) / (1 - dens) * .9f);
  return mixv(WHITE, H3, rx * .5f) * k;
}

// Smooth scenes are worked out at half resolution (41 x 41) and interpolated; detail(px, py, smooth) finishes each cell.
V3 *hr = nullptr;
template <typename S, typename D> void halfRes(S smooth, D detail) {
  if (!hr) { hr = (V3 *)ps_malloc(41 * 41 * sizeof(V3)); if (!hr) hr = (V3 *)malloc(41 * 41 * sizeof(V3)); }
  if (!hr) return;
  for (int b = 0; b <= 40; b++) {
    int j = min(2 * b, N - 1), L = N, R = -1;
    for (int k = max(0, j - 2); k <= min(N - 1, j + 2); k++) if (rowL[k] <= rowR[k]) { L = min(L, (int)rowL[k]); R = max(R, (int)rowR[k]); }
    float py = gy(2 * b);
    for (int a = 0; a <= 40; a++) { int i = 2 * a; if (i < L - 2 || i > R + 2) continue; hr[b * 41 + a] = smooth(gx(i), py); }
  }
  for (int j = 0; j < N; j++) for (int i = rowL[j]; i <= rowR[j]; i++) {
    int a = i >> 1, b = j >> 1;
    const V3 &p00 = hr[b * 41 + a];
    V3 v = p00;
    if (i & 1) v = mixv(p00, hr[b * 41 + a + 1], .5f);
    if (j & 1) { V3 w = hr[(b + 1) * 41 + a]; if (i & 1) w = mixv(w, hr[(b + 1) * 41 + a + 1], .5f); v = mixv(v, w, .5f); }
    put(i, j, detail(X[i], Y[j], v));
  }
}

// Particle scenes: the background goes into acc, then each particle near the knob is drawn only over the cells it
// covers (splat), instead of every cell hashing its way to every layer. Then acc is finished with put().
V3 *acc = nullptr;
bool accBegin() {   // 77 KB: PSRAM if there is any
  if (!acc) { acc = (V3 *)ps_malloc(N * N * sizeof(V3)); if (!acc) acc = (V3 *)malloc(N * N * sizeof(V3)); }
  return acc != nullptr;
}
template <typename F> void splat(float cx, float cy, float rad, F f, bool square = false) {
  float st = kd / N;
  int j0 = max(0, (int)ceilf((cy - rad - Y[0]) / st)), j1 = min(N - 1, (int)floorf((cy + rad - Y[0]) / st));
  int i0 = max(0, (int)ceilf((cx - rad - X[0]) / st)), i1 = min(N - 1, (int)floorf((cx + rad - X[0]) / st));
  for (int j = j0; j <= j1; j++) {
    int a = square ? i0 : max(i0, (int)rowL[j]), b = square ? i1 : min(i1, (int)rowR[j]);
    float dy = Y[j] - cy;
    for (int i = a; i <= b; i++) f(X[i] - cx, dy, acc[j * N + i]);
  }
}
void accPut() { for (int j = 0; j < N; j++) for (int i = rowL[j]; i <= rowR[j]; i++) put(i, j, acc[j * N + i]); }
inline int cfl(float x) { return (int)floorf(x); }

void sceneBokeh() {
  if (!accBegin()) return;
  V3 warm = mixv(HA, V3{1, .8f, .55f}, .6f);
  for (int j = 0; j < N; j++) for (int i = rowL[j]; i <= rowR[j]; i++) acc[j * N + i] = B * .82f + mixv(H2, H3, clamp01(Y[j] / 240)) * .012f;
  for (int l = 0; l < 3; l++) {
    float fl = l, G = 44 - fl * 12, offx = (float)(Pd * (6 - l * 1.6)), offy = fl * 17;
    for (int cxi = cfl((X[0] + offx) / G); cxi <= cfl((X[N - 1] + offx) / G); cxi++) {
      float cx = cxi, sh = h11(cx * 1.9f + fl * 5) * G;
      for (int cyi = cfl((Y[0] + offy + sh) / G); cyi <= cfl((Y[N - 1] + offy + sh) / G); cyi++) {
        float cy = cyi, rx, ry;
        h22(cx + fl * 31, cy + fl * 31, rx, ry);
        float pw = h21(cx + fl * 7 + 3, cy + fl * 7 + 3);
        if (pw < .45f) continue;
        float r = G * (.1f + .12f * ry), rr = r * 1.3f, soft = 2.4f - fl * .7f;
        float ox = (cx + .5f + (rx - .5f) * .4f) * G - offx, oy = (cy + .5f + (ry - .5f) * .4f) * G - offy - sh;
        float tw = .65f + .35f * fsin(Pf * (.25f + rx * .5f) + ry * 40), q = (pw - .45f) / .55f;
        float amp = tw * (.35f + 1.4f * q * q * q) * (1 - fl * .2f);
        V3 col = (rx < .3f ? H1 : rx < .55f ? H3 : rx < .8f ? HA : warm) * amp;
        splat(ox, oy, rr, [&](float dx, float dy, V3 &a) {
          float d = len2(dx, dy);
          if (d > rr) return;
          float disk = sstep(r, r - soft, d), rim = sstep(r - 2.4f, r - .4f, d) * disk;
          a += col * (disk * (.07f + fl * .03f) + rim * .05f + cmp(d, rr) * .018f);
        });
      }
    }
  }
  accPut();
}

void sceneSnow() {
  if (!accBegin()) return;
  V3 fc = mixv(H3, WHITE, .8f);
  for (int j = 0; j < N; j++) for (int i = rowL[j]; i <= rowR[j]; i++) acc[j * N + i] = B * .85f + H3 * (.025f * sstep(60, 240, Y[j]));
  for (int l = 0; l < 4; l++) {
    float fl = l, G = 8 + fl * 5, offx = (float)(Pd * (3 + l * 2)), offy = (float)(Pd * (8 + l * 5));
    for (int cyi = cfl((Y[0] - offy) / G); cyi <= cfl((Y[N - 1] - offy) / G); cyi++)
      for (int cxi = cfl((X[0] - offx) / G); cxi <= cfl((X[N - 1] - offx) / G); cxi++) {
        float cx = cxi, cy = cyi, rx, ry;
        h22(cx + fl * 11, cy + fl * 11, rx, ry);
        if (rx < .35f) continue;
        float ctx = (cx + .5f) * G + fsin(Pf * (.6f + ry * .8f) + rx * 20) * G * .2f + offx, cty = (cy + .5f) * G + (ry - .5f) * G * .25f + offy;
        float sz = .3f + fl * .2f + ry * .25f, bl = .25f + fl * .22f, reach = fmaxf(sz * 3.5f, sz + bl);
        float a1 = .25f + fl * .08f;
        splat(ctx, cty, reach, [&](float dx, float dy, V3 &a) {
          float d = len2(dx, dy);
          a += fc * (sstep(sz + bl, sz - bl * .5f, d) * a1 + cmp(d, sz * 3.5f) * .02f);
        });
      }
  }
  accPut();
}

void sceneMatrix() {
  const float cw = 4.6f, ch = 5.8f;
  V3 gc = mixv(H1, HA, .3f), hc = mixv(HA, WHITE, .6f);
  for (int j = 0; j < N; j++) for (int i = rowL[j]; i <= rowR[j]; i++) {
    float px = X[i], py = Y[j];
    float cx = floorf(px / cw), cy = floorf(py / ch), fx = px / cw - cx, fy = py / ch - cy;
    float rc = h11(cx * 1.31f + .7f);
    V3 c = B * .8f;
    float gxx = floorf((fx - .14f) / .24f), gyy = floorf((fy - .1f) / .16f);
    float gd = 0;
    if (gxx >= 0 && gxx <= 2 && gyy >= 0 && gyy <= 4) {
      float fl = floorf(Pf * (1.5f + rc * 3) + h21(cx, cy) * 9);
      gd = h21(cx * 1.1f + gxx * 17 + fl * 3.3f, cy * 1.7f + gyy * 31 + fl * 3.3f) >= .42f ? 1 : 0;
    }
    c += gc * (gd * (.012f + .02f * h21(cx + 5, cy + 5)));
    if (rc >= .12f) {
      float sp = 22 + rc * 34, len = 50 + rc * 110, per = len + 60 + h11(cx * 7.3f) * 180;
      float dt = modp(Pf * sp + rc * 977 - (cy + .5f) * ch, per);
      float tr = dt < len ? powf(1 - dt / len, 1.6f) : 0;
      float head = sstep(ch * 1.5f, 0, dt);
      c += gc * (gd * tr * .5f + tr * .012f) + hc * (gd * head * .9f);
    }
    put(i, j, c);
  }
}

void sceneGalaxy() {
  float rot = (float)fmod(Pd * .03, (double)TAU), cr = cosf(rot), sr = sinf(rot);
  V3 core = mixv(HA, V3{1, .9f, .75f}, .5f);
  halfRes([&](float px, float py) {
    float dx = (px - 285) / 110, dy = (py - 62) / 110 * 1.7f;
    float qx = cr * dx + sr * dy, qy = -sr * dx + cr * dy;   // GLSL mat2(cr,-sr,sr,cr) * d
    float r = len2(dx, dy), a = atan2f(qy, qx);
    float arms = powf(.5f + .5f * fcos(2 * (a + logf(r + .05f) * 2.4f)), 2.5f);
    float n = fbm(qx * 2.2f + 3, qy * 2.2f + 3, 3), disc = fexp(-r * 1.1f);
    V3 col = mixv(H2, H3, sstep(.2f, 1.4f, r));
    col = mixv(col, H1, arms * .3f);
    V3 c = B * .8f + col * (arms * (.35f + 1.4f * n * n) * disc * .45f + disc * .03f);
    c = c * (1 - .55f * sstep(.5f, .75f, n) * arms * disc);
    c += core * (fexp(-r * r * 30) * .9f + fexp(-r * 3.5f) * .06f);
    return c;
  }, [&](float px, float py, V3 c) { return c + stars(px, py, 3.5f, .93f) * .8f; });
}

void sceneLava() {
  float bx[8], by[8], R2[8];
  for (int k = 0; k < 8; k++) {
    bx[k] = 40 + k * 80 + 25 * sinf(ph(.07 + k * .01, k * 3.0));
    by[k] = 120 - 110 * sinf(ph(.09 + k * .017, k * 2.3));
    float r = 26 + 12 * h11(k * 3.1f); R2[k] = r * r * 4;
  }
  const float Lx = -.4f / 1.0050f, Ly = -.6f / 1.0050f, Lz = .7f / 1.0050f;   // normalize(-.4,-.6,.7)
  for (int j = 0; j < N; j++) for (int i = rowL[j]; i <= rowR[j]; i++) {
    float px = X[i], py = Y[j];
    V3 c = B * .8f + H2 * (.03f * sstep(60, 240, py)) + HA * (.012f * sstep(120, 0, py));
    float f = 0, gxx = 0, gyy = 0;
    for (int k = 0; k < 8; k++) {
      float dx = px - bx[k], dy = py - by[k], u = (dx * dx + dy * dy) / R2[k];
      if (u < 1) { f += (1 - u) * (1 - u); float w = 4 * (1 - u) / R2[k]; gxx -= w * dx; gyy -= w * dy; }
    }
    float inside = sstep(.22f, .27f, f);
    V3 col = mixv(HA, H1, sstep(20, 220, py));
    c += col * ((sstep(.02f, .24f, f) * .05f + sstep(.15f, .24f, f) * .05f) * (1 - inside));
    if (inside > 0) {
      float k = 38 / sqrtf(fmaxf(f - .2f, .004f)) * .15f, nx = gxx * k, ny = gyy * k, nz = 1;
      float il = 1 / sqrtf(nx * nx + ny * ny + 1); nx *= il; ny *= il; nz *= il;
      float nl = nx * Lx + ny * Ly + nz * Lz, dif = fmaxf(nl, 0);
      float rz = 2 * nl * nz - Lz;                       // reflect(-L, n).z
      float s = fmaxf(rz, 0), s2 = s * s, s4 = s2 * s2, s8 = s4 * s4, s16 = s8 * s8, spec = s16 * s8 * s4;
      V3 blob = col * ((.04f + .22f * dif) * (.6f + .4f * sstep(.22f, .6f, f))) + mixv(col, WHITE, .6f) * (spec * .35f);
      c = mixv(c, blob, inside);
    }
    put(i, j, c);
  }
}

void sceneFireflies() {
  if (!accBegin()) return;
  V3 fc = mixv(HA, V3{1, 1, .55f}, .35f);
  for (int j = 0; j < N; j++) for (int i = rowL[j]; i <= rowR[j]; i++) acc[j * N + i] = B * .85f + H1 * (.03f * sstep(80, 240, Y[j])) + H2 * .01f;
  float offy = (float)(Pd * .6);
  for (int l = 0; l < 3; l++) {
    float fl = l, G = 40 - fl * 10, ox = (float)(Pd * (1.2 + l)) + fl * 50, oy = offy + fl * 50;
    for (int cyi = cfl((Y[0] + oy) / G); cyi <= cfl((Y[N - 1] + oy) / G); cyi++)
      for (int cxi = cfl((X[0] + ox) / G); cxi <= cfl((X[N - 1] + ox) / G); cxi++) {
        float cx = cxi, cy = cyi, rx, ry;
        h22(cx + fl * 5, cy + fl * 5, rx, ry);
        if (rx < .3f) continue;
        float bl = sstep(.2f, 1, fsin(Pf * (.5f + ry * .7f) + rx * 40));
        if (bl <= 0) continue;
        float ctx = (cx + .5f) * G + G * .2f * fsin(Pf * (.23f + rx * .25f) + ry * 9) - ox;
        float cty = (cy + .5f) * G + G * .2f * fsin(Pf * (.19f + ry * .2f) + rx * 7) - oy;
        float sz = .8f + ry * .5f - fl * .2f, reach = G * .28f;
        V3 col = fc * (bl * (1 - fl * .2f));
        splat(ctx, cty, reach, [&](float dx, float dy, V3 &a) {
          float d = len2(dx, dy);
          a += col * (sstep(sz, 0, d) * .9f + cmp(d, reach) * .12f);
        });
      }
  }
  accPut();
}

void scenePetals() {
  if (!accBegin()) return;
  V3 pale = {1, .92f, .95f};
  for (int j = 0; j < N; j++) for (int i = rowL[j]; i <= rowR[j]; i++) acc[j * N + i] = mixv(B * .85f + H2 * .03f, B * .9f + HA * .02f, sstep(0, 240, Y[j]));
  for (int l = 0; l < 3; l++) {
    float fl = l, G = 30 + fl * 12, offx = (float)(Pd * (9 + l * 5)), offy = (float)(Pd * (6 + l * 3.5));
    for (int cyi = cfl((Y[0] - offy) / G); cyi <= cfl((Y[N - 1] - offy) / G); cyi++)
      for (int cxi = cfl((X[0] - offx) / G); cxi <= cfl((X[N - 1] - offx) / G); cxi++) {
        float cx = cxi, cy = cyi, rx, ry;
        h22(cx + fl * 3.7f, cy + fl * 3.7f, rx, ry);
        if (rx < .45f) continue;
        float ctx = (cx + .5f) * G + (rx - .5f) * G * .25f + fsin(Pf * .8f + ry * 30) * G * .1f + offx;
        float cty = (cy + .5f) * G + (ry - .5f) * G * .25f + offy;
        float an = Pf * (.6f + rx * 1.4f) + ry * 6.28f, ca = fcos(an), sa = fsin(an);
        float tum = .3f + .7f * fabsf(fsin(Pf * (.9f + ry) + rx * 9)), sz = 2.6f + fl * 1.3f + ry * 1.2f;
        float isz = 1 / sz, iszy = 1 / (tum * sz * .62f), kk = (.12f + fl * .05f) * (.7f + .3f * tum);
        splat(ctx, cty, sz * 1.05f, [&](float lx, float ly, V3 &a) {
          float ex = (ca * lx - sa * ly) * isz, ey = (sa * lx + ca * ly) * iszy;
          float e2 = ex * ex + ey * ey;
          if (e2 >= 1) return;
          float pet = sstep(1, .82f, sqrtf(e2)) * (1 - sstep(.34f, .2f, len2(ex - 1.02f, ey)));
          if (pet <= 0) return;
          a = mixv(a, mixv(HA, pale, .35f + .3f * clamp01(-ex)) * kk, pet);
        });
      }
  }
  accPut();
}

void sceneTopo() {
  float t = (float)fmod(Pd * .02, 1000.0);   // a slow drift; the wrap is 14 hours away
  bool light = lightT;
  float sx = (float)fmod(Pd * 40, 900.0) - 100;
  halfRes([&](float px, float py) {
    float ux = px / 120, uy = py / 120;
    float h = fbm(ux + t, uy + t * .6f, 3) + .3f * vn(ux * .6f - t * .5f, uy * .6f + t * .3f);
    return V3{h, 0, 0};
  }, [&](float px, float py, V3 v) {
    float h = v.r, lv = h * 16, d = .5f - fabsf(fract(lv) - .5f);
    float major = modp(floorf(lv + .5f), 5) == 0 ? 1 : 0;
    const float fw = .03f;                    // about what fwidth gives on the screens (lines as thin as theirs)
    float line = 1 - sstep(fw * (.6f + major), fw * (1.6f + major * 1.2f), d);
    V3 col = mixv(H3, H1, sstep(.35f, .7f, h));
    col = mixv(col, HA, sstep(.7f, .9f, h));
    float sc = fexp(-sqf((px - sx) / 30));
    if (light) {
      float k = clamp01(line * ((major > .5f ? .75f : .45f) + sc * .2f));
      V3 m = mixv(WHITE, col * .35f, k);
      float b = 1 - .05f * h;
      return V3{B.r * b * m.r, B.g * b * m.g, B.b * b * m.b};
    }
    return B * .82f + col * (.012f + .02f * h + line * ((major > .5f ? .34f : .13f) + sc * .4f));
  });
}

void sceneSpeedlines() {
  float lenK = .6f + 4 * speed, gain = .8f + .6f * speed;
  for (int j = 0; j < N; j++) {
    float py = Y[j];
    struct { bool on; float sh, per, len, ilen, a, b; V3 col; } L[3];
    for (int l = 0; l < 3; l++) {   // everything here depends on the row only
      float fl = l, lane = 2.4f + fl * 1.7f, rn = h11(floorf(py / lane) * 1.37f + fl * 11);
      L[l].on = rn >= .2f;
      if (!L[l].on) continue;
      double v = (70. + rn * 110.) * (1. + fl * .6);
      L[l].per = 150 + rn * 260;
      L[l].sh = (float)fmod(Pd * v, (double)L[l].per) + rn * 911;
      L[l].len = (14 + rn * 30) * lenK * (1 + fl * .4f); L[l].ilen = 1 / L[l].len;
      float dy = fabsf(fract(py / lane) - .5f) * lane, th = .16f + fl * .1f;
      L[l].a = fexp(-dy * dy / (th * th)) * (.3f + .15f * fl) * gain; L[l].b = fexp(-dy * .9f) * .02f * gain;
      L[l].col = rn > .85f ? HA : rn > .6f ? H1 : mixv(H3, WHITE, .3f);
    }
    for (int i = rowL[j]; i <= rowR[j]; i++) {
      V3 c = B * .82f + H2 * .012f;
      for (int l = 0; l < 3; l++) {
        if (!L[l].on) continue;
        float x = modp(X[i] + L[l].sh, L[l].per);
        if (x >= L[l].len) continue;
        float s = 1 - x * L[l].ilen;
        c += L[l].col * (s * sqrtf(s) * L[l].a + s * L[l].b);
      }
      put(i, j, c);
    }
  }
}

void sceneCaustics() {
  float t = (float)fmod(Pd * .35, 6283.1853) + 23;   // a whole number of turns: every term stays continuous
  float tt[5];
  for (int n = 0; n < 5; n++) tt[n] = t * (1 - 3.5f / (n + 1));
  V3 cc = mixv(H3, WHITE, .35f);
  float rph = (float)fmod(Pd * .11, (double)TAU);
  halfRes([&](float px, float py) {
    float qx = px / 36 - 250 + 2.2f * vn(px / 110, py / 110), qy = py / 36 - 250 + 2.2f * vn(px / 110 + 7.3f, py / 110 + 7.3f);
    float ix = qx, iy = qy, s = 1;
    for (int n = 0; n < 5; n++) {
      float T = tt[n], nx = qx + fcos(T - ix) + fsin(T + iy), ny = qy + fsin(T - iy) + fcos(T + ix);
      ix = nx; iy = ny;
      float a = qx * .005f / fsin(ix + T), b = qy * .005f / fcos(iy + T);
      s += 1 / sqrtf(a * a + b * b);
    }
    s = 1.17f - powf(s / 5, 1.4f);
    float caus = powf(fabsf(s), 8);
    float rays = powf(.5f + .5f * fsin((px + py * .45f) * .05f + fsin(px * .013f + rph) * 2.5f), 4) * sstep(230, 0, py);
    V3 c = mixv(H3 * .05f + B * .6f, B * .75f, sstep(0, 240, py));
    return c + cc * (caus * .4f * (.5f + .5f * sstep(240, 0, py))) + H1 * (rays * .05f);
  }, [](float, float, V3 c) { return c; });
}

void sceneSmoke() {
  float t = (float)fmod(Pd * .05, 2000.0);
  halfRes([&](float px, float py) {
    float ux = px / 75, uy = py / 75;
    float w = fbm(ux * 1.3f, uy * .8f + t * 1.2f, 2);
    float n = fbm(ux + w * 1.6f - t * .2f, uy * .7f + t * 1.8f, 4);
    float r = clamp01(1 - fabsf(n * 2 - .95f)); r = r * r * r;
    V3 col = mixv(H3, H1, sstep(.3f, .65f, w));
    float r2 = r * r;
    return B * .82f + col * (r * (.06f + .09f * sstep(240, 40, py))) + H2 * (n * .025f) + mixv(col, WHITE, .5f) * (r2 * r2 * r2 * .05f);
  }, [](float, float, V3 c) { return c; });
}

void sceneSilk() {
  float t = (float)fmod(Pd * .1, 6283.1853);
  V3 pale = {1, .95f, .88f};
  for (int j = 0; j < N; j++) for (int i = rowL[j]; i <= rowR[j]; i++) {
    float ux = X[i] / 60, uy = Y[j] / 60;
    float w = ux * .8f + uy * .45f + .9f * fsin(uy * .55f - ux * .25f + t) + .45f * fsin(ux * .8f + uy * .3f - t * .7f);
    float a = w * 2.4f, s1 = fsin(a), s2 = fsin(a * 2.1f + 1.3f + fsin(uy * .7f + t * .5f));
    float slope = fcos(a) * .75f + fcos(a * 2.1f + 1.3f) * .35f, dif = clamp01(.5f + .5f * slope);
    float sb = fmaxf(0, slope * .8f + .25f * s2), s5 = sb * sb * sb * sb * sb, sheen = s5 * s5;
    V3 col = mixv(H1, HA, .5f + .5f * fsin(w * .6f + t * .3f));
    put(i, j, B * .5f + col * (.006f + .11f * dif * dif * (.8f + .2f * s1)) + mixv(col, pale, .45f) * (sheen * .25f));
  }
}

inline float ridgeF(float x, float s) { return vn1(x * .02f + s) * .55f + vn1(x * .05f + s * 3) * .3f + vn1(x * .13f + s * 7) * .15f; }
void sceneMountains() {
  const float lake = 196;
  float sdrift = (float)fmod(Pd * .3, 40000.0), x0d = (float)(Pd * .3);
  float wob = (float)fmod(Pd * 2, (double)TAU);
  // a shooting star now and then
  double ts = Pd * .11; float sk = (float)floor(ts), sf = (float)(ts - floor(ts));
  bool shoot = h11(sk * 3.3f) > .4f && sf < .12f;
  float ax = 60 + h11(sk) * 500, ay = 10 + h11(sk * 1.7f) * 50, dxn = 1 / 1.0595f, dyn = .35f / 1.0595f;
  float hx = ax + dxn * sf * 1500, hy = ay + dyn * sf * 1500;
  V3 shootC = mixv(HA, WHITE, .7f);
  float ry[3][N];
  for (int i = 0; i < N; i++) for (int k = 0; k < 3; k++)
    ry[k][i] = 95 + k * 50 - ridgeF((X[i] + x0d) * (1 + k * .4f) + k * 300, k * 17) * (80 - k * 20);
  for (int j = 0; j < N; j++) for (int i = rowL[j]; i <= rowR[j]; i++) {
    float px = X[i], py = Y[j], sx = px, sy = py;
    if (py > lake) sy = 2 * lake - py + fsin(py * .9f + wob) * .7f;
    V3 c = mixv(B * .7f + H2 * .02f, H3 * .07f + B * .6f, sstep(0, 180, sy));
    float top = fminf(ry[0][i], fminf(ry[1][i], ry[2][i]));
    if (sy < top + .5f) {   // sky shows: stars, the milky way, the shooting star
      c += stars(sx + sdrift, sy, 4, .95f) * .8f;
      float mw = fbm((sx + sy * .7f) / 60, (sy - sx * .35f) / 25, 3);
      float band = fexp(-sqf((sy - 70 + (sx - 300) * .25f) / 35));
      c += mixv(H2, H3, mw) * (band * sstep(.35f, .8f, mw) * .12f);
      if (shoot) {
        float rx = sx - hx, ryy = sy - hy, al = rx * dxn + ryy * dyn, pd = len2(rx - dxn * al, ryy - dyn * al);
        if (al <= 0) c += shootC * (fexp(-pd * pd * 2) * sstep(-60, 0, al) * (1 - sf / .12f) * .9f);
      }
    }
    int ks = 0;
    for (int k = 2; k > 0; k--) if (sy - ry[k][i] >= .4f) { ks = k; break; }
    for (int k = ks; k < 3; k++) {
      float y = ry[k][i], dd = sy - y, inM = sstep(-.4f, .4f, dd);
      if (inM <= 0) continue;
      V3 mc = mixv(H3 * .045f + B * .5f, B * .45f, k / 2.0f) + H3 * (fexp(-fmaxf(dd, 0) * .5f) * (.06f - k * .015f));
      float sn = .06f * sstep(60, 30, y) * fexp(-fmaxf(dd, 0) * .15f) * (1 - k * .5f);
      mc += V3{sn, sn, sn};
      c = mixv(c, mc, inM);
    }
    if (py > lake) c = c * .55f + H3 * .006f;
    put(i, j, c);
  }
}

float neonCore[641], neonWhite[641];
bool neonReady = false;
void sceneNeon() {
  if (!neonReady) {
    for (int k = 0; k <= 640; k++) { float d = k / 8.0f; neonCore[k] = sstep(1.6f, .4f, d) * .5f + fexp(-d * .35f) * .07f + fexp(-d * .08f) * .012f; neonWhite[k] = sstep(.6f, 0, d) * .4f; }
    neonReady = true;
  }
  V3 cols[5] = {HA, H1, H2, H3, HA}, white[5];
  float pa[5], pb[5];
  for (int k = 0; k < 5; k++) {
    float kk = floorf((float)fmod(Pd * 3 + k * 7, 100000.0)), buzz = h11(kk * 1.3f + k) > .93f ? .35f : 1;
    white[k] = mixv(cols[k], WHITE, .8f) * buzz; cols[k] = cols[k] * buzz;
    pa[k] = ph(.08 + k * .015, k); pb[k] = ph(-1.4 * (.08 + k * .015), k * 3.0);
  }
  float yc[5], ys[5];
  V3 base = B * .8f + H2 * .008f;
  for (int i = 0; i < N; i++) {
    for (int k = 0; k < 5; k++) {
      float x = X[i] * .008f + k * 1.7f;
      yc[k] = 25 + k * 46 + 22 * fsin(x + pa[k]) + 12 * fsin(x * 2.3f + pb[k]);
      float sl = 22 * .008f * fcos(x + pa[k]) + 12 * .0184f * fcos(x * 2.3f + pb[k]);
      ys[k] = 8 / sqrtf(1 + sl * sl);
    }
    for (int j = 0; j < N; j++) {
      if (i < rowL[j] || i > rowR[j]) continue;
      V3 c = base;
      for (int k = 0; k < 5; k++) {
        int q = (int)(fabsf(Y[j] - yc[k]) * ys[k]);
        if (q < 640) c += cols[k] * neonCore[q] + white[k] * neonWhite[q];
      }
      put(i, j, c);
    }
  }
}

struct CellMemo { float ix = 1e9f, iy = 1e9f, rx, ry, k; };   // neighbouring cells share their cell's random numbers
V3 neonSign(float qx, float qy, float G, float s, float fl4, CellMemo &mm) {
  float ix = floorf(qx / G), iy = floorf(qy / G);
  if (ix != mm.ix || iy != mm.iy) { mm.ix = ix; mm.iy = iy; h22(ix + s, iy + s, mm.rx, mm.ry); mm.k = h21(ix + s + 9, iy + s + 9); }
  float rx = mm.rx, ry = mm.ry;
  if (rx < .5f) return V3{0, 0, 0};
  float kind = mm.k;
  float lx = qx - (ix + .5f + (rx - .5f) * .2f) * G, ly = qy - (iy + .5f + (ry - .5f) * .2f) * G;
  if (fabsf(lx) > 26 || fabsf(ly) > 26) return V3{0, 0, 0};
  float d;
  if (kind < .3f) d = fabsf(len2(lx, ly) - (8 + ry * 6));
  else if (kind < .65f) {
    float bx = fabsf(lx) - (8 + rx * 5), by = fabsf(ly) - (3.5f + ry * 3);
    d = fabsf(len2(fmaxf(bx, 0), fmaxf(by, 0)) + fminf(fmaxf(bx, by), 0) - 1.5f);
  } else {
    float bx = modp(lx + 14, 5) - 2.5f;
    d = fmaxf(len2(fmaxf(fabsf(bx) - 1.1f, 0), fmaxf(fabsf(ly) - 3, 0)), fabsf(lx) - 13);
  }
  if (d > 9) return V3{0, 0, 0};
  V3 col = kind < .2f ? HA : kind < .45f ? H1 : kind < .7f ? H2 : kind < .85f ? H3 : HA;
  float f = h11(floorf(fl4 + ry * 9) + rx * 7) > .9f ? .3f : 1;
  return (col * (sstep(1, .3f, d) * .45f + cmp(d, 9) * .12f) + mixv(col, WHITE, .7f) * (sstep(.45f, 0, d) * .25f)) * f;
}
void sceneNeoncity() {
  const float H = 150;
  float drift = (float)(Pd * 2), wob = (float)fmod(Pd * 3, (double)TAU), fl4 = (float)fmod(Pd * 4, 100000.0);
  V3 warm = mixv(HA, V3{1, .8f, .5f}, .5f), rainC = mixv(H3, V3{.9f, .9f, .9f}, .5f);
  CellMemo m1, m2, mb[2];
  for (int j = 0; j < N; j++) for (int i = rowL[j]; i <= rowR[j]; i++) {
    float px = X[i], py = Y[j], qx = px, qy = py;
    bool refl = py > H;
    if (refl) { qx = px + fsin(py * .7f + wob) * 1.4f; qy = 2 * H - py; }
    qx += drift;
    V3 c = B * .8f + mixv(H2, H3, .5f) * (.02f * sstep(0, H, qy));
    for (int l = 0; l < 2; l++) {
      float fl = l, G = 26 - fl * 8, bx = qx * (1 - fl * .2f), by = qy * (1 - fl * .2f) + fl * 9;
      float ix = floorf(bx / G), iy = floorf(by / G);
      CellMemo &mm = mb[l];
      if (ix != mm.ix || iy != mm.iy) { mm.ix = ix; mm.iy = iy; h22(ix + fl * 3, iy + fl * 3, mm.rx, mm.ry); mm.k = h21(ix + 4 + fl, iy + 4 + fl); }
      float rx = mm.rx, ry = mm.ry;
      if (mm.k < .5f) continue;
      float d = len2(bx - (ix + .5f + (rx - .5f) * .3f) * G, by - (iy + .5f + (ry - .5f) * .3f) * G), rr = G * (.1f + .1f * ry);
      if (d > rr * 1.4f) continue;
      c += (rx < .5f ? H3 : warm) * ((sstep(rr, rr - 2, d) * .05f + cmp(d, rr * 1.4f) * .012f) * sstep(20, 140, by));
    }
    c += neonSign(qx, qy, 70, 2, fl4, m1) + neonSign(qx + 31, qy + 21, 52, 5, fl4, m2) * .8f;
    if (refl) { V3 d = c - B * .8f; c = B * .7f + d * (.45f * sstep(240, H, py)); }
    float rx = px + py * .15f, cw = 3.2f, col = floorf(rx / cw), rr = h11(col * 1.7f);
    if (rr >= .35f) {
      float tt = fract((py - Pf * (230 + rr * 120)) / (70 + rr * 90) + rr * 7);
      if (tt <= .14f) { float dd = fabsf(fract(rx / cw) - .5f) * cw; c += rainC * ((tt / .14f) * fexp(-dd * dd * 6) * .16f); }
    }
    put(i, j, c);
  }
}

void sceneRainwindow() {
  if (!accBegin()) return;
  for (int j = 0; j < N; j++) { V3 bg = B * .75f + mixv(H2, HA, sstep(40, 240, Y[j])) * .02f; for (int i = 0; i < N; i++) acc[j * N + i] = bg; }
  for (int l = 0; l < 2; l++) {          // the city behind the glass, out of focus
    float fl = l, G = 34 - fl * 12, offx = (float)(Pd * (1.5 - l * .5)), offy = fl * 13;
    for (int cxi = cfl((X[0] + offx) / G); cxi <= cfl((X[N - 1] + offx) / G); cxi++) {
      float cx = cxi, sh = h11(cx * 2.3f + fl) * G;
      for (int cyi = cfl((Y[0] + offy + sh) / G); cyi <= cfl((Y[N - 1] + offy + sh) / G); cyi++) {
        float cy = cyi, rx, ry;
        h22(cx + fl * 19, cy + fl * 19, rx, ry);
        float pw = h21(cx + fl * 3 + 1, cy + fl * 3 + 1);
        if (pw < .4f) continue;
        float q = (pw - .4f) / .6f, amp = (.3f + 1.5f * q * q * q) * (.7f + .3f * fsin(Pf * .3f + ry * 30));
        float r = G * (.13f + .12f * ry), rr = r * 1.3f, soft = 3 - fl;
        float ox = (cx + .5f + (rx - .5f) * .35f) * G - offx, oy = (cy + .5f + (ry - .5f) * .35f) * G - offy - sh;
        V3 col = (rx < .35f ? H1 : rx < .6f ? H3 : mixv(HA, V3{1, .75f, .45f}, .45f * rx)) * amp;
        splat(ox, oy, rr, [&](float dx, float dy, V3 &a) {
          float d = len2(dx, dy);
          if (d > rr) return;
          a += col * (sstep(r, r - soft, d) * (.08f + fl * .04f) + cmp(d, rr) * .02f);
        }, true);
      }
    }
  }
  const float W = 15, G = 6.5f, st = kd / N;
  V3 rimC = mixv(H3, WHITE, .5f);
  float mbx = -1e9f, mby = -1e9f, brx = 0, bry = 0;   // the bead cell last worked out (neighbours share it)
  float dcx = -1e9f, dr = 0, dyh = 0;                  // the same for the running drop's column
  for (int j = 0; j < N; j++) for (int i = rowL[j]; i <= rowR[j]; i++) {
    float px = X[i], py = Y[j], nx = 0, ny = 0, m = 0;
    float cx = floorf(px / W);
    if (cx != dcx) { dcx = cx; dr = h11(cx * 3.7f + 1); float per = 300 + dr * 200; dyh = modp((float)fmod(Pd * (12 + dr * 22), (double)per) + dr * 400, per) - 20; }
    float r = dr, yh = dyh;
    float xc = (cx + .5f) * W + fsin(py * .07f + r * 10) * 2.5f + (r - .5f) * 5;
    float trail = (py <= yh ? 1 : 0) * sstep(yh - 90, yh - 10, py);
    float bx = floorf(px / G), bpy = py + h11(bx * 1.7f) * G, by = floorf(bpy / G);
    if (bx != mbx || by != mby) { mbx = bx; mby = by; h22(bx + 1.3f, by + 1.3f, brx, bry); }
    if (brx > .3f && !(fabsf(px - xc) < 4 && py < yh && py > yh - 140)) {
      float rad = .6f + 1.6f * bry * bry, dx = (px - (bx + .5f + (brx - .5f) * .4f) * G) / rad, dy = (bpy - (by + .5f + (bry - .5f) * .4f) * G) / rad;
      float dd = dx * dx + dy * dy;
      if (dd < 1) { m = sstep(1, .7f, dd); nx = dx; ny = dy; }
    }
    { float dx = (px - xc) / 2.4f, dy = (py - yh) * .7f / 2.4f, dd = dx * dx + dy * dy; if (dd < 1) { m = sstep(1, .75f, dd); nx = dx; ny = dy; } }
    if (trail > 0 && m == 0) {
      float ty = floorf(py / 3.2f), rt = (.35f + .6f * h11(ty + cx * 7)) * trail;
      if (rt > .2f) { float dx = (px - xc) / rt, dy = (fract(py / 3.2f) * 3.2f - 1.6f) / rt, dd = dx * dx + dy * dy; if (dd < 1) { m = sstep(1, .7f, dd); nx = dx; ny = dy; } }
    }
    V3 c;
    if (m > 0) {   // looks through the drop: the city, flipped and pulled in from 12 mm away
      int si = constrain((int)lroundf(i - nx * 12 * m / st), 0, N - 1), sj = constrain((int)lroundf(j - ny * 12 * m / st), 0, N - 1);
      V3 bg = acc[sj * N + si];
      c = mixv(bg * .8f, bg * 1.6f + H3 * .006f, m);
      float g = fmaxf(0, 1 - len2(nx + .35f, ny + .45f) * 2.2f), n2 = nx * nx + ny * ny;
      c += V3{1, 1, 1} * (m * g * g * g * .35f);
      c += rimC * (m * sstep(.6f, 1, n2) * sstep(0, .8f, ny) * .06f);
      c = c * (1 - m * sstep(.6f, 1, n2) * sstep(.2f, -.8f, ny) * .5f);
    } else c = acc[j * N + i] * .8f;
    put(i, j, c);
  }
}

void sceneDunes() {
  const float hz = 95, sunX = 330, sunY = 86;
  V3 warm = mixv(HA, V3{1, .55f, .25f}, .35f), sunC = mixv(warm, V3{1, .85f, .6f}, .5f);
  float yv[4][N], dv[4][N];
  for (int k = 0; k < 4; k++) {
    float fr = .006f + k * .0025f, amp = 14 * (1 + k * .35f), sh = (float)fmod(Pd * (.6 + k * .7), 1e5);
    for (int i = 0; i < N; i++) {
      float x = X[i] + sh + k * 137, a = x * fr + k * 2, b = x * fr * 2.3f + k * 5;
      yv[k][i] = hz - 6 + k * 38 - amp * (.55f + .45f * fsin(a)) - 5 * fsin(b);
      dv[k][i] = -amp * .45f * fr * fcos(a) - 5 * fr * 2.3f * fcos(b);
    }
  }
  for (int j = 0; j < N; j++) for (int i = rowL[j]; i <= rowR[j]; i++) {
    float px = X[i], py = Y[j], ds = len2(px - sunX, py - sunY), hy = sstep(0, hz, py);
    V3 c = mixv(H2 * .05f + B * .6f, warm * .22f, hy * hy);
    if (py < 60) c += stars(px, py, 5, .965f) * (sstep(60, 0, py) * .6f);
    c += sunC * (sstep(16, 15, ds) * .9f + fexp(-ds * .025f) * .12f);
    int ks = 0;   // dunes hidden behind a nearer one don't matter (one is kept for the haze)
    for (int k = 3; k > 0; k--) if (py - yv[k][i] >= .4f) { ks = k - 1; break; }
    for (int k = ks; k < 4; k++) {
      float dd = py - yv[k][i], inD = sstep(-.4f, .4f, dd);
      if (inD <= 0) continue;
      float lit = .5f + .5f * fmaxf(-1, fminf(1, dv[k][i] * 4 * fmaxf(-1, fminf(1, (px - sunX) / 80))));
      V3 dc = mixv(warm, H2, k / 3.0f) * ((.025f + .09f * lit) * fexp(-dd * .012f) * (1 - k * .12f));
      dc = mixv(dc, c, .45f * (1 - k / 3.0f) * fexp(-dd * .05f));
      dc += warm * (fexp(-fmaxf(dd, 0) * .6f) * lit * .05f);
      c = mixv(c, dc, inD);
    }
    put(i, j, c);
  }
}

// Crystal: the Voronoi sites near the knob are worked out once per frame (cells are 36 mm, the knob 32 mm).
void sceneCrystal() {
  const float G = 36;
  const int M = 5;
  int c0x = (int)floorf(X[0] / G) - 1, c0y = (int)floorf(Y[0] / G) - 1;
  float sx[M][M], sy[M][M];
  V3 scol[M][M];
  float slit[M][M];
  float Lx = sinf(ph(.13)), Ly = cosf(ph(.1)) * .7f, Lz = .8f, il = 1 / sqrtf(Lx * Lx + Ly * Ly + Lz * Lz);
  Lx *= il; Ly *= il; Lz *= il;
  for (int b = 0; b < M; b++) for (int a = 0; a < M; a++) {
    float cx = c0x + a, cy = c0y + b, hx, hy;
    h22(cx, cy, hx, hy);
    sx[b][a] = cx + .5f + .4f * fsin(hx * 6.28f + Pf * .05f * (hy + .5f));
    sy[b][a] = cy + .5f + .4f * fsin(hy * 6.28f + Pf * .05f * (hx + .5f));
    float nx, ny; h22(cx + 7, cy + 7, nx, ny);
    float vx = (nx - .5f) * 1.4f, vy = (ny - .5f) * 1.4f, iv = 1 / sqrtf(vx * vx + vy * vy + 1);
    float lit = fmaxf((vx * Lx + vy * Ly + Lz) * iv, 0); lit = lit * lit * lit; lit *= lit;
    V3 col = mixv(mixv(H3, H1, nx), H2, ny * .4f);
    slit[b][a] = lit; scol[b][a] = col;
  }
  V3 edgeC = mixv(HA, WHITE, .4f);
  for (int j = 0; j < N; j++) for (int i = rowL[j]; i <= rowR[j]; i++) {
    float qx = X[i] / G, qy = Y[j] / G;
    int ix = (int)floorf(qx) - c0x, iy = (int)floorf(qy) - c0y;
    float d1 = 9, d2 = 9; int ba = 0, bb = 0;
    for (int b = iy - 1; b <= iy + 1; b++) for (int a = ix - 1; a <= ix + 1; a++) {
      if (a < 0 || b < 0 || a >= M || b >= M) continue;
      float d = sqf(qx - sx[b][a]) + sqf(qy - sy[b][a]);
      if (d < d1) { d2 = d1; d1 = d; ba = a; bb = b; } else if (d < d2) d2 = d;
    }
    float lit = slit[bb][ba], edge = sqrtf(d2) - sqrtf(d1), l4 = lit * lit; l4 *= l4;
    V3 col = scol[bb][ba];
    V3 c = B * .75f + col * (.015f + lit * .2f) + mixv(col, WHITE, .5f) * (l4 * .2f);
    c += edgeC * (sstep(.04f, 0, edge) * (.06f + lit * .4f));
    put(i, j, c);
  }
}

void sceneChrome() {
  float t = (float)fmod(Pd * .35, 6283.1853);
  V3 skyHi = mixv(H3, WHITE, .55f) * .55f, skyLo = H3 * .12f, gHi = H2 * .05f, gLo = B * .3f, accS = mixv(HA, WHITE, .4f);
  halfRes([&](float px, float py) {
    float ux = px / 42, uy = py / 42;
    float wx = ux + .3f * fsin(uy * 1.3f + t * .4f), wy = uy + .3f * fsin(ux * 1.1f - t * .3f);
    float c1 = .5f * fcos(wx * .9f + wy * .4f + t), c2 = .35f * fcos(-wx * .5f + wy * 1.1f - t * .8f);
    float c3 = .2f * fcos(wx * 1.6f - wy * .9f + t * 1.3f), c4 = .12f * fcos(wx * .3f + wy * 1.9f - t * 1.1f);
    float gxx = c1 * .9f - c2 * .5f + c3 * 1.6f + c4 * .3f, gyy = c1 * .4f + c2 * 1.1f - c3 * .9f + c4 * 1.9f;
    float nx = -gxx * 1.3f, ny = -gyy * 1.3f, iv = 1 / sqrtf(nx * nx + ny * ny + 1), nz = iv;
    nx *= iv; ny *= iv;
    float rx = 2 * nz * nx, ryy = 2 * nz * ny, hz = ryy + .1f;
    V3 sky = mixv(skyHi, skyLo, sstep(-1.2f, 0, hz)), gnd = mixv(gHi, gLo, sstep(0, 1, hz));
    V3 env = mixv(sky, gnd, sstep(-.015f, .015f, hz));
    float hl = fexp(-hz * hz * 900) * .5f;
    env += V3{hl, hl, hl};
    if (hz < 0) env += accS * (sstep(.08f, 0, fabsf(rx - .45f)) * .5f);
    env += H1 * (sstep(.1f, 0, fabsf(rx + .5f)) * .3f);
    return B * .2f + env;
  }, [](float, float, V3 c) { return c; });
}

void sceneKaleido() {
  float rot = ph(.04), t = (float)fmod(Pd * .25, 6283.1853), seg = (float)PI / 6, seg2i = 1 / (2 * seg);
  float kx0 = 1.2f + .4f * fsin(t * .3f), t7 = t * .7f, t13 = t * 1.3f, t2 = t * 2;
  for (int j = 0; j < N; j++) for (int i = rowL[j]; i <= rowR[j]; i++) {
    int k = j * N + i;
    float r = tA[k], a = tB[k] + rot;
    a -= 2 * seg * floorf(a * seg2i); a = fabsf(a - seg);
    float kx = r * fcos(a), ky = r * fsin(a);
    float v3 = fsin((kx + ky) * 5 + t7);
    float v = fsin(kx * 7 - t13) * fsin(ky * 9 + t) + fsin(len2(kx - kx0, ky - .2f) * 10 - t2) * .7f + v3 * .5f;
    V3 col = mixv(mixv(H1, H2, .5f + .5f * fsin(r * 3 - t + a * 2)), H3, .3f + .3f * v3);
    put(i, j, B * .82f + col * ((fexp(-fabsf(v) * 5) * .3f + sstep(.2f, 1.2f, v) * .06f) * tD[k]) + HA * tC[k]);
  }
}

void sceneFireworks() {
  struct Burst { float x, y, R, f, k, fade, flash; V3 col; };
  Burst bs[4];
  for (int b = 0; b < 4; b++) {
    double T = 3.1 + b * .6, tb = Pd / T + b * .37;
    float k = (float)floor(tb), f = (float)(tb - floor(tb));
    float s1 = h11(k * 1.31f + b * 5.7f), s2 = h11(k * 2.17f + b * 1.3f), s3 = h11(k * 4.71f + b * 3.3f);
    V3 col = s3 < .25f ? H1 : s3 < .5f ? H2 : s3 < .75f ? H3 : HA;
    bs[b] = {40 + s1 * 570, 25 + s2 * 170 + 22 * f * f, (45 + 35 * h11(k * 9.1f + b)) * (1 - expf(-f * 5)), f, k,
             (1 - f) * (1 - f), expf(-f * 14) * .3f, mixv(col, WHITE, .2f)};
  }
  float tw9 = (float)fmod(Pd * 9, 1000.0);
  for (int j = 0; j < N; j++) for (int i = rowL[j]; i <= rowR[j]; i++) {
    float px = X[i], py = Y[j];
    V3 c = mixv(B * .8f, B * .9f + H2 * .03f, sstep(0, 240, py)) + stars(px, py, 6, .95f) * .5f;
    for (int b = 0; b < 4; b++) {
      const Burst &u = bs[b];
      float rx = px - u.x, ry = py - u.y, r = len2(rx, ry);
      if (u.flash > 1e-3f) c += u.col * (fexp(-r * .025f) * u.flash);
      if (r > u.R + 12) continue;
      float sec = (atan2f(ry, rx) + (float)PI) / TAU * 26, sid = floorf(sec);
      float rr = u.R * (.8f + .2f * h11(sid + u.k * 13)), ds = fabsf(fract(sec) - .5f) * TAU / 26 * r, dr = r - rr;
      float spark = fexp(-ds * ds * 2) * (fexp(-dr * dr * .6f) + (dr <= 0 ? fexp(dr * .18f) * .3f : 0));
      float tw = u.f > .5f ? .5f + .5f * (fract(tw9 + sid * .37f) >= .5f ? 1 : 0) : 1;
      c += u.col * (spark * u.fade * tw * 1.4f);
    }
    put(i, j, c);
  }
}

// ---- stretch the N x N result over the round screen
const uint8_t BAYER[16] = {0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5};
uint16_t *hbuf = nullptr;  // each scene row stretched to 240 wide (r, g, b x 256)
void stretchRow(int j, uint16_t *out) {
  const uint8_t *src = rgb + j * N * 3;
  for (int x = 0; x < 240; x++) {
    const uint8_t *a = src + upI[x] * 3;
    int w = upW[x], iw = 256 - w;
    out[x * 3] = a[0] * iw + a[3] * w; out[x * 3 + 1] = a[1] * iw + a[4] * w; out[x * 3 + 2] = a[2] * iw + a[5] * w;
  }
}
void upscale(uint16_t *fb) {
  if (!hbuf) hbuf = (uint16_t *)malloc(2 * 240 * 3 * sizeof(uint16_t));
  if (!hbuf) return;
  int held[2] = {-1, -1};
  for (int y = 0; y < 240; y++) {
    int dyc = y - 120;
    int half = (int)sqrtf((float)max(0, 14400 - dyc * dyc)) + 1;
    int x0 = max(0, 120 - half), x1 = min(239, 120 + half);
    uint16_t *row = fb + y * 240;
    for (int x = 0; x < x0; x++) row[x] = 0;
    for (int x = x1 + 1; x < 240; x++) row[x] = 0;
    int j = upI[y], wy = upW[y], iy = 256 - wy;
    uint16_t *h0 = hbuf + (j & 1) * 720, *h1 = hbuf + ((j + 1) & 1) * 720;  // rows j and j+1 live in slots by parity
    if (held[j & 1] != j) { stretchRow(j, h0); held[j & 1] = j; }
    if (held[(j + 1) & 1] != j + 1) { stretchRow(j + 1, h1); held[(j + 1) & 1] = j + 1; }
    const uint8_t *bay = BAYER + (y & 3) * 4;
    for (int x = x0; x <= x1; x++) {
      const uint16_t *a = h0 + x * 3, *b = h1 + x * 3;
      int d = bay[x & 3];
      int r = (a[0] * iy + b[0] * wy) >> 16, g = (a[1] * iy + b[1] * wy) >> 16, bl = (a[2] * iy + b[2] * wy) >> 16;
      r = min(255, r + (d >> 1)); g = min(255, g + (d >> 2)); bl = min(255, bl + (d >> 1));
      row[x] = ((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (bl >> 3);
    }
  }
}

bool active() { return ready && scene >= 0; }

// Draws the Flow scene as the whole background (outside the circle black).
void draw(uint16_t *fb) {
  unsigned long now = millis();
  Pd = P0 + (double)rate * (double)(long)(now - atMs) / 1000.0;
  Pf = (float)Pd;
  tables();
  nLive = 0;
  for (auto &p : pulses) {
    if (!p.used) continue;
    float age = (now - p.start) / 1000.0f;
    if (age >= 2.6f) { p.used = false; continue; }
    LivePulse &u = live[nLive++];
    u.x = p.x; u.y = p.y; u.front = age * 430; u.w = 10 + age * 22;
    u.amp = powf(1 - age / 2.6f, 1.5f);
    u.col = p.k > 1 ? V3{1, .16f, .1f} : HA;
    u.gain = p.k > 1 ? 1.1f : .8f;
  }
  switch (scene) {
    case F_LIQUID: sceneLiquid(); break;
    case F_RIBBONS: sceneRibbons(); break;
    case F_AURORA: sceneAurora(); break;
    case F_VORTEX: sceneVortex(); break;
    case F_WARP: sceneWarp(); break;
    case F_GRID: sceneGrid(); break;
    case F_PLASMA: scenePlasma(); break;
    case F_RAIN: sceneRain(); break;
    case F_OCEAN: sceneOcean(); break;
    case F_CIRCUIT: sceneCircuit(); break;
    case F_EMBERS: sceneEmbers(); break;
    case F_SONAR: sceneSonar(); break;
    case F_RAINWINDOW: sceneRainwindow(); break;
    case F_SNOW: sceneSnow(); break;
    case F_BOKEH: sceneBokeh(); break;
    case F_GALAXY: sceneGalaxy(); break;
    case F_MATRIX: sceneMatrix(); break;
    case F_LAVA: sceneLava(); break;
    case F_FIREFLIES: sceneFireflies(); break;
    case F_PETALS: scenePetals(); break;
    case F_TOPO: sceneTopo(); break;
    case F_SPEEDLINES: sceneSpeedlines(); break;
    case F_CAUSTICS: sceneCaustics(); break;
    case F_SMOKE: sceneSmoke(); break;
    case F_SILK: sceneSilk(); break;
    case F_MOUNTAINS: sceneMountains(); break;
    case F_NEON: sceneNeon(); break;
    case F_NEONCITY: sceneNeoncity(); break;
    case F_DUNES: sceneDunes(); break;
    case F_CRYSTAL: sceneCrystal(); break;
    case F_CHROME: sceneChrome(); break;
    case F_KALEIDO: sceneKaleido(); break;
    case F_FIREWORKS: sceneFireworks(); break;
    default: sceneCalibrate(); break;
  }
  upscale(fb);
}

}  // namespace flow
