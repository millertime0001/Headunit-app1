// Frame-rate probe: every 60 s, watch 5 s of frames and report fps + janky frames to the backend
// ("perf:" lines in backend.log). Costs nothing between samples.
(function () {
  var page = window.FLOW_SCREEN === 'cluster' || /cluster/.test(location.pathname) ? 'cluster' : 'ui';
  function sample() {
    if (document.hidden) return;
    var times = [], t0 = performance.now();
    function f(now) {
      times.push(now);
      if (now - t0 < 5000) return requestAnimationFrame(f);
      var gaps = [], worst = 0, long = 0;
      for (var i = 1; i < times.length; i++) { var g = times[i] - times[i - 1]; gaps.push(g); if (g > worst) worst = g; if (g > 34) long++; }
      gaps.sort(function (a, b) { return a - b; });
      var fps = (times.length - 1) / ((times[times.length - 1] - times[0]) / 1000);
      var body = JSON.stringify({ page: page, screen: (window.S && S.screen) || '', fps: +fps.toFixed(1), long: long,
        worst: Math.round(worst), p95: Math.round(gaps[Math.floor(gaps.length * 0.95)] || 0) });
      fetch('/perf', { method: 'POST', keepalive: true, body: body }).catch(function () {});
    }
    requestAnimationFrame(f);
  }
  setTimeout(sample, 15000);
  setInterval(sample, 60000);
})();
