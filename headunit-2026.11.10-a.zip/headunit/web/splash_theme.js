window.HU_THEME = {"base": "#020617", "b1": "#000000", "b2": "#000000", "b3": "#0F172A", "accent": "#000000", "style": "plasma", "name": "Pi Head Unit"};
