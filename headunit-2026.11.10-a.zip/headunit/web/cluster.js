// Instrument cluster: the second screen behind the steering wheel (or wherever it's mounted).
// Its own page, with its own connection to the backend, so it keeps running whatever the touch screen is doing.
// Settings live in settings.cluster and are changed from the head unit (Settings > Cluster); the screen has no touch.
// gauges.js draws the dials; it needs the globals S, OBDS, settings(), speedUnits() and tempUnits() defined here.
'use strict';
const S = { state: null };
window.FLOW_SCREEN = 'cluster';   // flow.js: this screen's slice of the dash-wide animation
const OBDS = { cur: {} };
const PREVIEW = /[?&]preview\b/.test(location.search);
const settings = () => (S.state && S.state.settings) || {};
function speedUnits(st) {
  const u = (st.settings || {}).speed_units || 'auto';
  if (u !== 'auto') return u;
  return (((st.settings || {}).location || {}).units === 'celsius') ? 'kmh' : 'mph';
}
const tempUnits = () => (((settings().location || {}).units) === 'celsius' ? 'C' : 'F');
// for the head unit's background effects (fx.js, rain.js), so "Same as head unit" runs the very same animation
const $ = (q) => document.querySelector(q);
const g = (k) => settings()[k];

(function () {
  const $ = (q) => document.querySelector(q);
  const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  let real = null;          // the backend's state, as sent
  let queue = null;         // "Up next" from the phone: its songs carry artwork too
  let themes = [];
  let built = '';
  // test hook (preview only): ?layout=<id>&slots=a,b,c... override the saved layout
  const QS = new URLSearchParams(location.search), QL = {};
  if (PREVIEW && QS.get('layout')) QL.layout = QS.get('layout');
  if (PREVIEW && QS.get('slots')) QL.slots = QS.get('slots').split(',');
  const cfg = () => Object.assign({}, window.CLUSTER_DEFAULT, settings().cluster || {}, QL);
  window.gaugeFace = () => (cfg().layout === 'real' ? 'real' : cfg().face || 'neon');
  const obdData = () => ((real && real.obd) || {}).data || {};

  // ---------------------------------------------------------------- connection
  let ws = null, art = null;
  function connect() {
    ws = new WebSocket(`ws://${location.host}/ws`);
    ws.onopen = () => { $('#offline').classList.add('hidden'); reportSize(); try { ClusterMap.sync.size = null; } catch (e) { /* not set up yet */ } };
    ws.onclose = () => { if (!PREVIEW) $('#offline').classList.remove('hidden'); setTimeout(connect, 1500); };
    ws.onmessage = (e) => {
      const m = JSON.parse(e.data);
      if (m.type === 'state') { const st = m.state; if (st.art && !st.art.data && art && art.rev === st.art.rev) st.art = art; onState(st); }
      else if (m.type === 'art') art = m.art;   // album art: once per song, states carry only art.rev
      else if (m.type === 'obd' && real) { real.obd = Object.assign(real.obd || {}, { data: m.data }); view(); }
      else if (m.type === 'reload') location.reload();
      else if (m.type === 'queue') queue = m.queue;
    };
  }

  // the backend checks that the window really fills the cluster screen (and opens it again if not)
  function reportSize() {
    if (PREVIEW || !ws || ws.readyState !== 1) return;
    ws.send(JSON.stringify({ cmd: 'cluster_size', w: innerWidth, h: innerHeight }));
  }
  addEventListener('resize', () => { clearTimeout(reportSize.t); reportSize.t = setTimeout(reportSize, 500); });

  // ---------------------------------------------------------------- needle sweep at start
  // Like a real cluster: every needle swings to full and back when the screen wakes up.
  let sweepT0 = 0, sweepData = null;
  const SWEEP_MS = 1900;
  function sweepTick(now) {
    const p = (now - sweepT0) / SWEEP_MS;
    if (p >= 1) { sweepData = null; OBDS.cur = {}; view(); return; }
    const f = p < 0.42 ? Math.sin((p / 0.42) * Math.PI / 2) : p < 0.55 ? 1 : Math.cos(((p - 0.55) / 0.45) * Math.PI / 2);
    sweepData = { rpm: 7000 * f, speed: 225 * f, fuel: 100 * f, coolant: 38 + 89 * f, volts: 10 + 6 * f, maf: f > 0.02 ? 4 : null,
      intake: -20 + 100 * f, load: 100 * f, throttle: 100 * f };
    OBDS.cur = { rpm: sweepData.rpm, speed: sweepData.speed };
    view();
    requestAnimationFrame(sweepTick);
  }
  // what the gauges see: the real readings, or the sweep while it runs
  function view() {
    if (!real) return;
    if (sweepData) S.state = Object.assign({}, real, { obd: Object.assign({}, real.obd, { data: sweepData }) });
    else { S.state = real; OBDS.cur = {}; }
  }

  // ---------------------------------------------------------------- state
  function onState(st) {
    const first = !real;
    if (!first && st.version && real.version && st.version !== real.version) { location.reload(); return; }   // updated
    const pv = st.look_preview;   // a Look being edited on the phone shows here too, without being saved
    if (pv && pv.set) {
      const base = st.settings || {};
      st.settings = Object.assign({}, base, pv.set);
      for (const k of ['glass', 'flow', 'cluster']) if (pv.set[k]) st.settings[k] = Object.assign({}, base[k], pv.set[k]);
    }
    real = st;
    view();
    const c = cfg();
    const sig = JSON.stringify([c.layout, c.slots, c.center === 'off', c.bar, c.layout === 'custom' ? c.custom : 0]);
    applyLook(c);   // first: it sets the width correction, and the map panel's size depends on it
    if (sig !== built) { built = sig; build(c); }
    updateBar(c);
    updateMid(c);
    ClusterMap.sync();
    if (first && c.sweep && !PREVIEW) { sweepT0 = performance.now(); requestAnimationFrame(sweepTick); }
  }

  // ---------------------------------------------------------------- layout
  // a 3D pod: hood, chrome ring, a deep tube with the dial at the bottom of it, glass on top
  const pod = (id, cls = '') => `<div class="pod ${cls}"><div class="hood"></div><div class="rim"></div><div class="tube"><canvas data-gauge="${esc(id)}"></canvas></div><div class="lens"></div></div>`;
  const tile = (id, cls = '') => `<div class="gt ${cls}"><canvas data-gauge="${esc(id)}"></canvas></div>`;
  // one piece of a custom layout
  function piece(p, speed) {
    const [GW, GH] = window.CLUSTER_GRID || [24, 9], pct = (v, n) => `${((v / n) * 100).toFixed(3)}%`;
    const opts = String(p.o || '').split(','), boxed = opts.includes('box');
    const shape = p.t === '@map' ? opts.find((o) => (window.MAP_SHAPES || []).some(([k]) => k === o)) || '' : '';
    const inner = {
      '@map': `<div class="cmap" id="cmap" data-shape="${esc(shape)}"><canvas></canvas><div class="cmap-msg"></div></div>`,
      '@nav': '<div class="navp"></div>', '@limit': '<div class="limp"></div>', '@speed': speed,
      '@music': '<div class="mid" data-mode="music"></div>', '@trip': '<div class="mid" data-mode="trip"></div>',
      '@time': '<div class="mid" data-mode="clock"></div>', '@info': '<div class="mid"></div>', '@weather': '<div class="wxp"></div>',
    }[p.t] || tile(p.t);
    return `<div class="cp k${esc(p.t.replace('@', '-'))}${boxed ? ' boxed' : ''}" style="left:${pct(p.x, GW)};top:${pct(p.y, GH)};width:${pct(p.w, GW)};height:${pct(p.h, GH)}">${inner}</div>`;
  }
  function build(c) {
    const s = (c.slots || []).concat(window.CLUSTER_DEFAULT.slots.slice((c.slots || []).length)).slice(0, 8);
    const map = '<div class="cmap" id="cmap"><canvas></canvas><div class="cmap-msg"></div></div>';
    const mid = c.center === 'off' ? '' : c.center === 'map' ? map : '<div class="mid" id="mid"></div>';
    const speed = '<div class="dig"><div class="dnum" data-spd>--</div><div class="dunit" data-unit></div></div>';
    const L = {
      classic: `<div class="ga">${tile(s[0], 'big')}</div><div class="gc">${mid}${tile(s[2], 'bar')}${tile(s[3], 'bar')}</div><div class="gb">${tile(s[1], 'big')}</div>`,
      sport: `<div class="col">${tile(s[1], 'side')}${tile(s[2], 'side')}</div>${tile(s[0], 'big')}<div class="col">${tile(s[3], 'side')}${tile(s[4], 'side')}</div>`,
      digital: `${tile('tach', 'rev')}<div class="col">${tile(s[2], 'side')}${tile(s[3], 'side')}</div><div class="gc">${speed}${mid}</div><div class="col">${tile(s[4], 'side')}${tile(s[5], 'side')}</div>`,
      trio: s.slice(0, 3).map((id) => tile(id, 'big')).join(''),
      six: s.slice(0, 6).map((id) => tile(id)).join(''),
      minimal: `<div class="gc">${speed}</div>${mid ? `<div class="gc">${mid}</div>` : ''}`,
      map: `${tile(s[0], 'big')}${map}${tile(s[1], 'big')}`,
      mapfull: `${map}<div class="strip">${tile(s[0], 'bar')}${tile(s[1], 'bar')}${tile(s[2], 'bar')}</div>`,
      quad: s.slice(0, 4).map((id) => tile(id, 'big')).join(''),
      race: `${tile('revleds', 'rev')}<div class="col">${tile(s[2], 'side')}${tile(s[3], 'side')}</div>${tile(s[0], 'big')}<div class="col">${tile(s[4], 'side')}${tile(s[5], 'side')}</div>`,
      eight: s.slice(0, 8).map((id) => tile(id)).join(''),
      real: `<div class="binnacle">${tile(s[1], 'big')}<div class="mfd"><div class="mfd-top"><span class="dnum" data-spd>--</span><span class="dunit" data-unit></span></div>${mid || '<div class="mid" data-mode="none"></div>'}</div>${tile(s[0], 'big')}</div>`,
      pods: `<div class="podrow">${pod(s[1], 'big l')}<div class="podmid">${pod(s[2], 'small')}${pod(s[3], 'small')}</div>${pod(s[0], 'big r')}</div>`,
      grand: `${tile(s[1], 'big')}<div class="gc"><div class="mid np" id="mid" data-mode="music"></div><div class="duo">${tile(s[2])}${tile(s[3])}</div></div>${tile(s[0], 'big')}`,
      cockpit3d: `<div class="floor"></div><div class="stage">${tile(s[2], 'p0')}${tile(s[0], 'p1')}${tile(s[1], 'p2')}${tile(s[4], 'p3')}${tile(s[3], 'p4')}</div>`,
      // gauges agent: tall side arcs with Maps between (gauges.js draws .arcL/.arcR tiles as arcs and masks #cmap to match)
      arcs: `${map}${tile(s[1], 'arcL')}${tile(s[0], 'arcR')}<div class="arcs-minis">${tile(s[2], 'bar')}${tile(s[3], 'bar')}</div>`,
      scope: `${tile(s[0], 'big')}<div class="gc">${tile(s[2], 'scope')}<div class="duo">${tile(s[3])}${tile(s[4])}</div></div>${tile(s[1], 'big')}`,
      strip: `<div class="srow">${tile(s[0], 'bar')}${tile(s[1], 'bar')}${tile(s[2], 'bar')}${tile(s[3], 'bar')}</div><div class="gc">${speed}</div><div class="srow">${tile(s[4], 'bar')}${tile(s[5], 'bar')}${tile(s[6], 'bar')}${tile(s[7], 'bar')}</div>`,
      // round 3 (2026.11.08)
      hero: `<div class="col">${tile(s[1], 'side')}${tile(s[2], 'side')}${tile(s[3], 'side')}</div>${tile(s[0], 'big')}<div class="col">${tile(s[4], 'side')}${tile(s[5], 'side')}${tile(s[6], 'side')}</div>`,
      twinplus: `<div class="col">${tile(s[2], 'side')}${tile(s[3], 'side')}${tile(s[4], 'side')}</div>${tile(s[0], 'big')}${tile(s[1], 'big')}<div class="col">${tile(s[5], 'side')}${tile(s[6], 'side')}${tile(s[7], 'side')}</div>`,
      orbit: `<div class="orbit-ring"></div>${tile(s[0], 'big oc')}${[1, 2, 3, 4, 5, 6].map((i) => tile(s[i], `orb o${i}`)).join('')}`,
      wings: `<div class="col wl">${tile(s[0], 'side')}${tile(s[1], 'side')}${tile(s[2], 'side')}</div><div class="gc">${speed}${tile(s[6], 'bar')}</div><div class="col wr">${tile(s[3], 'side')}${tile(s[4], 'side')}${tile(s[5], 'side')}</div>`,
      dash80: `${tile(s[0], 'rev')}<div class="col">${tile(s[1], 'side')}${tile(s[2], 'side')}</div><div class="gc">${speed}</div><div class="col">${tile(s[3], 'side')}${tile(s[4], 'side')}</div><div class="srow">${tile(s[5], 'bar')}${tile(s[6], 'bar')}${tile(s[7], 'bar')}</div>`,
      bars: s.slice(0, 8).map((id) => tile(id, 'bar')).join(''),
      mapside: `${map}<div class="quad4">${tile(s[0])}${tile(s[1])}${tile(s[2])}${tile(s[3])}</div>`,
      // navigator + custom: pieces placed on a 24 x 9 grid (cluster_layouts.js), later ones on top
      navigator: '', custom: '',
    };
    if (c.layout === 'navigator' || c.layout === 'custom') L[c.layout] = window.clusterPieces(c).map((p) => piece(p, speed)).join('');
    const lay = L[c.layout] !== undefined ? c.layout : 'classic';
    const m = $('#main');
    m.className = `cl-main L-${lay}${c.center === 'off' ? ' nomid' : ''}${lay === 'navigator' ? ' L-custom' : ''}`;
    document.body.classList.toggle('free', lay === 'navigator' || lay === 'custom');
    m.innerHTML = L[lay];
    document.body.classList.toggle('nobar', c.bar === false);
    ClusterMap.sync();
  }

  // ---------------------------------------------------------------- colors and looks
  function applyLook(c) {
    const s = settings(), st = real || {};
    // colors: the Look every screen shares (state.look), unless the cluster was given its own palette
    const lk = st.look_preview || st.look || {};
    let t = Object.assign({ base: '#05070B', b1: '#14B8A6', b2: '#7C3AED', b3: '#0EA5E9', accent: '#5EEAD4' }, lk.colors || {});
    const own = c.theme && themes.find((x) => x.id === c.theme);
    if (own) t = own;
    const id = own ? c.theme : lk.id || 'look';
    const r = document.documentElement.style;
    const light = !!t.light && c.look === 'glow';
    const vars = { base: c.look === 'black' ? '#000000' : t.base, b1: t.b1, b2: t.b2, b3: t.b3, accent: t.accent,
      text: light ? '#0B1220' : '#F5F7FA', sub: light ? 'rgba(15,23,42,.68)' : 'rgba(245,247,250,.62)' };
    for (const [k, v] of Object.entries(vars)) if (r.getPropertyValue(`--${k}`) !== v) r.setProperty(`--${k}`, v);
    const b = document.body;
    for (const [k] of window.CLUSTER_LOOKS) b.classList.toggle(`look-${k}`, (c.look || 'scene') === k);
    // "Same as head unit": the head unit's own animated background (fx.js) in the cluster's colors
    S.theme = Object.assign({ id: `${id}~${t.accent}${t.b1}${t.b2}${t.b3}` }, t);
    if (typeof fxApply === 'function') {
      const want = c.look === 'scene';
      if (want) fxApply();
      else if (FX.kind !== 'off') { cancelAnimationFrame(FX.raf); FX.kind = 'off'; FX.ctx = null; $('#fx').style.display = 'none'; }
    }
    if (typeof flowApply === 'function') flowApply();
    b.classList.toggle('mirror', !!c.mirror);
    b.classList.toggle('is-real', c.layout === 'real');
    b.classList.toggle('anim', s.animate !== false);
    b.classList.toggle('preview', PREVIEW);
    // brightness: its own level, lower at night (time of day only)
    const lvl = c.lock !== false ? 100 : c.night_dim && isNight() ? Math.min(c.bright, c.night) : c.bright;   // lock = always 100%
    // with the screen's own backlight (DDC) the backend dims it for real; otherwise the page darkens itself
    const hw = !!(st.cluster && st.cluster.ddc);
    // the screen stretches a smaller mode to fill itself: draw narrower by the same amount so dials stay round
    const k = PREVIEW ? 1 : +((st.cluster || {}).stretch || 1), sideways = c.rotate === '90' || c.rotate === '270';
    const fix = k !== 1 && !sideways ? `scaleX(${1 / k})` : '';
    // canvases draw at the screen's real width (the page is laid out 1/xs wider and squeezed): map + gauges use this
    window.CL_XS = fix ? 1 / k : 1;
    if (b.style.transform !== fix) {
      b.style.transformOrigin = '0 0';
      b.style.transform = fix;
      b.style.width = fix ? `${innerWidth * k}px` : '';
    }
    $('#dim').style.opacity = PREVIEW || hw ? '0' : String(((100 - clamp(lvl, 5, 100)) / 100) * 0.95);
  }
  function lights() { return null; }   // headlight detection removed (2026.11.05-c)
  // Night for dimming: time of day only (sunset from the weather, else 7 pm - 7 am), same as the backend's is_night().
  function isNight() {
    const w = real && real.weather;
    if (w && typeof w.day === 'boolean') return !w.day;
    const h = new Date().getHours();
    return h >= 19 || h < 7;
  }

  // ---------------------------------------------------------------- top bar
  function updateBar(c) {
    const s = settings(), now = new Date();
    const clock = now.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit', hour12: !s.clock_24h }).replace(/\s?[AP]M$/i, '');
    if ($('#clock').textContent !== clock) $('#clock').textContent = clock;
    const w = real && real.weather;
    const wx = w ? `${w.temp}°<small>${esc(w.text || '')}</small>` : '';
    if ($('#wx')._v !== wx) { $('#wx').innerHTML = wx; $('#wx')._v = wx; }
    const l = lights() || {}, o = (real && real.obd) || {};
    document.body.classList.toggle('ind-hb', !!l.high);
    document.body.classList.toggle('ind-lights', !!(l.low || l.parking));
    document.body.classList.toggle('ind-cel', !!(o.codes && (o.codes.stored || []).length));
  }

  // ---------------------------------------------------------------- the middle panel
  const trip = { km: 0, secs: 0, fuelL: 0, lastT: 0 };
  function tripTick(now) {
    const d = obdData(), dt = trip.lastT ? Math.min(2, (now - trip.lastT) / 1000) : 0;
    trip.lastT = now;
    if (sweepData) return;
    const kmh = d.speed ?? (real && real.speed ? real.speed.mps * 3.6 : null);
    if (kmh != null && kmh > 2) { trip.km += (kmh * dt) / 3600; trip.secs += dt; }
    if (d.maf) trip.fuelL += (d.maf / 14.7 / 737) * dt;   // grams of air -> liters of gas
  }
  function mediaPos(m) {
    let p = m.position || 0;
    if (m.status === 'playing') p += (Date.now() / 1000 - (m.at || 0)) * 1000;
    return m.duration ? Math.min(p, m.duration) : p;
  }
  function midMode(c) {
    const st = real || {}, nav = st.nav || {}, m = st.media || {};
    if (c.center !== 'auto') return c.center;
    if (nav.active) return 'nav';
    if (m.title && (m.status === 'playing' || m.status === 'paused')) return 'music';
    return 'trip';
  }
  const TURN = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M7 21v-8a4 4 0 0 1 4-4h8"/><path d="M15 5l4 4-4 4"/></svg>';
  const NOTE = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>';
  // ---- speed limit (phone app: OpenStreetMap) and directions (Google Maps' notification)
  const SAMPLE_NAV = { active: true, title: '0.3 mi', text: 'Turn right onto Main St', sub: '12 min · 4.2 mi · 3:45 PM', icon: null };
  function limitNow() {
    const l = real && real.limit;
    if (l && l.kmh && Date.now() / 1000 - (l.at || 0) < 90) return l;
    return PREVIEW ? { kmh: 72.4, unit: 'mph', value: 45 } : null;
  }
  // the sign, in your speed units: a US "SPEED LIMIT" plate for mph, a red ring for km/h
  function limitSign() {
    const l = limitNow();
    if (!l) return '';
    const mph = speedUnits(real || {}) !== 'kmh';
    const v = mph ? (l.unit === 'mph' && l.value ? l.value : Math.round(l.kmh / 1.609344 / 5) * 5)
      : (l.unit === 'kmh' && l.value ? l.value : Math.round(l.kmh / 5) * 5);
    return mph ? `<div class="lim us"><small>SPEED<br>LIMIT</small><b>${v}</b></div>` : `<div class="lim eu"><b>${v}</b></div>`;
  }
  const navNow = () => { const n = (real && real.nav) || {}; return n.active ? n : PREVIEW ? SAMPLE_NAV : n; };
  const navIcon = (n) => (n.icon ? `<img src="data:image/png;base64,${n.icon}" alt="">` : TURN);
  function updatePieces() {
    const n = navNow(), sign = limitSign(), road = (real && real.limit && real.limit.road) || '';
    const nav = n.active ? `<div class="ni">${navIcon(n)}</div><div class="nt"><b>${esc(n.title)}</b><span>${esc(n.text)}</span>${n.sub ? `<small>${esc(n.sub)}</small>` : ''}</div>${sign}`
      : `<div class="nt idle">${road ? `<span>${esc(road)}</span>` : ''}<small>No directions</small></div>${sign}`;
    document.querySelectorAll('.navp').forEach((el) => { if (el._v !== nav) { el.innerHTML = nav; el._v = nav; el.classList.toggle('on', !!n.active); } });
    document.querySelectorAll('.limp').forEach((el) => { if (el._v !== sign) { el.innerHTML = sign; el._v = sign; } });
    const w = real && real.weather;
    const wx = w ? `<b>${Math.round(w.temp)}°</b><span>${esc(w.text || '')}</span>` : '<span>No weather yet</span>';
    document.querySelectorAll('.wxp').forEach((el) => { if (el._v !== wx) { el.innerHTML = wx; el._v = wx; } });
  }
  // over the limit: the sign glows red (checked 10x a second with the speed)
  function overLimit() {
    const l = limitNow(), v = speedNow();
    const over = !!(l && v != null && !sweepData && v > l.kmh + 2);
    document.body.classList.toggle('over-limit', over);
  }
  function updateMid(c) {
    updatePieces();
    document.querySelectorAll('.mid').forEach((el) => midOne(c, el));
  }
  function midOne(c, el) {
    const st = real || {}, s = settings(), mode = el.dataset.mode || midMode(c);
    let html = '';
    if (mode === 'nav') {
      const n = navNow();
      html = n.active ? `<div class="m-nav"><div class="ni">${navIcon(n)}</div>
        <div class="nt"><b>${esc(n.title)}</b><span>${esc(n.text)}</span><small>${esc(n.sub)}</small></div>${limitSign()}</div>`
        : '<div class="m-idle">No directions right now</div>';
    } else if (mode === 'music') {
      const m = st.media || {}, a = st.art;
      // the song's own art, else the same song's art from the phone's queue (the notification art can lag a song)
      const qa = ((queue && queue.items) || []).find((q) => q.art && q.title === m.title);
      const art = a && a.data && a.title === m.title ? `<img src="data:image/jpeg;base64,${a.data}" alt="">`
        : qa ? `<img src="data:image/jpeg;base64,${qa.art}" alt="">` : NOTE;
      const pct = m.duration ? clamp(mediaPos(m) / m.duration, 0, 1) * 100 : 0;
      html = m.title ? `<div class="m-music"><div class="art">${art}</div><div class="mt"><b>${esc(m.title)}</b><span>${esc(m.artist)}</span>
        <div class="prog"><i style="width:${pct.toFixed(1)}%"></i></div></div></div>` : '<div class="m-idle">Nothing playing</div>';
    } else if (mode === 'trip') {
      const metric = speedUnits(st) === 'kmh';
      const dist = metric ? trip.km : trip.km * 0.621371;
      const h = Math.floor(trip.secs / 3600), mi = Math.floor((trip.secs % 3600) / 60);
      const econ = trip.fuelL > 0.05 ? (metric ? `${((trip.fuelL / Math.max(trip.km, 0.1)) * 100).toFixed(1)}` : `${((trip.km * 0.621371) / (trip.fuelL * 0.264172)).toFixed(1)}`) : '--';
      const w = st.weather;
      html = `<div class="m-trip"><h4>This drive</h4><div class="tg">
        <div><b>${dist.toFixed(1)}</b><span>${metric ? 'km' : 'miles'}</span></div>
        <div><b>${h ? `${h}:${String(mi).padStart(2, '0')}` : mi}</b><span>${h ? 'hours' : 'minutes'}</span></div>
        <div><b>${econ}</b><span>${metric ? 'L/100 km' : 'mpg'}</span></div>
        <div><b>${w ? `${w.temp}°` : '--'}</b><span>outside</span></div></div></div>`;
    } else if (mode === 'clock') {
      const now = new Date();
      html = `<div class="m-clock"><b>${now.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit', hour12: !s.clock_24h }).replace(/\s?[AP]M$/i, '')}</b>
        <span>${now.toLocaleDateString([], { weekday: 'long', month: 'long', day: 'numeric' })}</span></div>`;
    }
    if (el._v !== html) { el.innerHTML = html; el._v = html; }
  }

  // ---------------------------------------------------------------- big digital speed, warnings, shift light
  function speedNow() {
    const d = sweepData || obdData();
    return d.speed ?? (real && real.speed ? real.speed.mps * 3.6 : null);
  }
  function warnings(c) {
    if (!c.warn || sweepData || !real) return [];
    const d = obdData(), out = [];
    if (((real.obd || {}).status) !== 'connected') return out;
    if (d.coolant != null && d.coolant * 9 / 5 + 32 >= 240) out.push(['hot', 'Engine overheating. Pull over when it’s safe.']);
    if (d.fuel != null && d.fuel < 12) out.push(['amber', `Low fuel: ${Math.round(d.fuel)}%`]);
    if (d.volts != null && (d.rpm || 0) > 500 && d.volts < 12.2) out.push(['amber', 'Battery isn’t charging']);
    if (d.volts != null && d.volts > 15.6) out.push(['amber', 'Charging voltage is high']);
    return out;
  }
  let lastSlow = 0, slowN = 0;
  function tick(now) {
    requestAnimationFrame(tick);
    if (now - lastSlow < 100) return;   // 10 times a second is plenty for text
    lastSlow = now;
    tripTick(now);
    const c = cfg();
    const v = speedNow(), km = speedUnits(real || {}) === 'kmh';
    const t = v == null ? '--' : String(Math.round(km ? v : v * 0.621371)), u = km ? 'km/h' : 'mph';
    document.querySelectorAll('[data-spd]').forEach((el) => { if (el.textContent !== t) el.textContent = t; });
    document.querySelectorAll('[data-unit]').forEach((el) => { if (el.textContent !== u) el.textContent = u; });
    overLimit();
    const rpm = (sweepData || obdData()).rpm;
    // 3D cockpit: the grid floor races with your speed, and the whole thing pitches when you brake or speed up
    if (c.layout === 'cockpit3d' || c.layout === 'pods') {
      const root = document.documentElement.style, kmhNow = v || 0;
      tick.acc = (tick.acc || 0) * 0.8 + 0.2 * (tick.lastV == null ? 0 : (kmhNow - tick.lastV) / 0.1);
      tick.lastV = kmhNow;
      root.setProperty('--spd', `${(3.2 - Math.min(2.8, kmhNow / 50)).toFixed(2)}s`);
      root.setProperty('--pitch', `${clamp(-tick.acc * 0.35, -6, 6).toFixed(2)}deg`);
    }
    document.body.classList.toggle('shift', !sweepData && c.shift > 0 && rpm != null && rpm >= c.shift);
    const ws = warnings(c), wEl = $('#warn');
    const cur = ws.length ? ws[Math.floor(now / 3000) % ws.length] : null;
    const html = cur ? `<b class="${cur[0]}">${esc(cur[1])}</b>` : '';
    if (wEl._v !== html) { wEl.innerHTML = html; wEl._v = html; wEl.classList.toggle('on', !!cur); }
    if (++slowN % 10 === 0) { updateBar(c); updateMid(c); applyLook(c); }   // once a second: clock, song progress, night dimming
  }

  // ---------------------------------------------------------------- Google Maps from the phone
  // The same phone stream the touch screen uses (/appws). The backend keeps Maps running in the background while
  // a cluster layout shows it. Drawn to fill the panel (cropped, not squashed), map-only crop applied.
  const sendCmd = (o) => { if (ws && ws.readyState === 1) ws.send(JSON.stringify(o)); };
  const ClusterMap = (() => {
    let ws = null, dec = null, cfg = null, needKey = true, ts = 0, vw = 0, vh = 0, crop = [0, 0], live = false, frameAt = 0, askAt = 0, fx = null, demo = null;
    // a new map panel (or one that fell behind) needs a full frame: ask the phone for one instead of waiting
    const askKey = () => { const n = performance.now(); if (n - askAt > 3000) { askAt = n; sendCmd({ cmd: 'stream_keyframe' }); } };
    const el = () => document.getElementById('cmap');
    const msg = (t) => { const m = el() && el().querySelector('.cmap-msg'); if (m && m.textContent !== t) m.textContent = t; };
    function codecFrom(c) {
      for (let i = 0; i + 4 < c.length; i++) if (c[i] === 0 && c[i + 1] === 0 && c[i + 2] === 1 && (c[i + 3] & 0x1f) === 7) {
        const h = (n) => n.toString(16).padStart(2, '0'); return `avc1.${h(c[i + 4])}${h(c[i + 5])}${h(c[i + 6])}`;
      }
      return 'avc1.42e01f';
    }
    const puck = { at: 0, pos: null, key: '' }, view = { ok: false };   // following your position while navigating
    function draw(frame) {
      const box = el(), cv = box && box.querySelector('canvas');
      if (!cv) return;
      // fit in layout pixels (W x H); the canvas itself holds only the screen's real pixels (xs narrower)
      const W = box.clientWidth, H = box.clientHeight, xs = window.CL_XS || 1, BW = Math.max(1, Math.round(W * xs));
      if (cv.width !== BW || cv.height !== H) { cv.width = BW; cv.height = H; }
      // map looks (mapfx.js): one renderer per panel canvas; a new layout = a new canvas = a new renderer
      if (window.MapFX && (!fx || fx.canvas !== cv)) { if (fx) fx.destroy(); fx = MapFX.attach(cv, { style: MapFX.clusterStyle, amt: MapFX.clusterAmt, sync: true }); }   // sync: a low-latency canvas skipped part of the fade mask
      const fw = frame.displayWidth || frame.width, fh = frame.displayHeight || frame.height;
      // Navigating: Google puts your position low in the picture, where the usual bottom trim would cut it off.
      // Keep the bottom and follow the puck: centered across, a little below the middle.
      // (the phone's "navigating" flag can stay on after directions end, so the picture decides: the bottom is only
      // un-trimmed when your position was actually found down there)
      const nav = !!(real && real.nav && real.nav.active);
      const top = crop[0], low = nav && puck.pos && performance.now() - puck.seen < 10000 && puck.pos.y > fh - crop[1] - 40;
      const bot = low ? 0 : crop[1];
      const sw = fw, sh = fh - top - bot;
      // fill the panel unless the picture is much narrower than it (a square map in a wide panel: show it whole)
      const near = sw / sh >= (W / H) / 1.35;
      let src, dst;
      if (near) {
        const k = Math.max(W / sw, H / sh), ww = W / k, wh = H / k;
        let tx = (sw - ww) / 2, ty = top + (sh - wh) / 2;
        if (nav) {
          const now = performance.now(), key = `${fw}x${fh}`;
          if (now - (puck.at || 0) > 1500 && window.MapFX && MapFX.findPuck) {
            puck.at = now;
            const p = MapFX.findPuck(frame);
            if (p) { puck.pos = p; puck.key = key; puck.seen = now; }
            else if (puck.key !== key || now - (puck.seen || 0) > 10000) puck.pos = null;   // not found: the usual view
          }
          if (puck.pos) {
            tx = clamp(puck.pos.x - ww / 2, 0, sw - ww);
            ty = clamp(puck.pos.y - wh * 0.62, top, fh - bot - wh);
          }
        }
        // glide to the new spot instead of jumping
        if (!view.ok || view.w !== ww || view.h !== wh) Object.assign(view, { x: tx, y: ty, w: ww, h: wh, ok: true });
        else { view.x += (tx - view.x) * 0.12; view.y += (ty - view.y) * 0.12; }
        src = [view.x, view.y, ww, wh]; dst = [0, 0, W, H];
      } else {
        const k = Math.min(W / sw, H / sh), dw = sw * k, dh = sh * k;
        src = [0, top, sw, sh]; dst = [(W - dw) / 2, (H - dh) / 2, dw, dh];
      }
      dst = [dst[0] * xs, dst[1], dst[2] * xs, dst[3]];
      if (fx) {
        if (!near || fx.mode === 'gl') fx.clear('#0b0d10');
        fx.draw(frame, ...src, ...dst);
      } else {
        if (!near) { const g2 = cv.getContext('2d'); g2.fillStyle = '#0b0d10'; g2.fillRect(0, 0, BW, H); }
        cv.getContext('2d').drawImage(frame, ...src, ...dst);
      }
      box.classList.add('live'); frameAt = performance.now();
    }
    let pending = null;
    (function pump(now) {
      requestAnimationFrame(pump);
      if (!pending || (window.halfRate && !halfRate(now))) return;
      const f = pending; pending = null;
      try { draw(f); } finally { f.close(); }
    })(performance.now());
    function configure(c) {
      cfg = c;
      if (!('VideoDecoder' in window)) return;
      if (dec) { try { dec.close(); } catch (e) { /* closed */ } }
      // keep only the newest decoded frame; it's drawn on the page's shared 30 fps beat (pump), in step with the gauges
      dec = new VideoDecoder({ output: (f) => { if (pending) pending.close(); if (live) pending = f; else { pending = null; f.close(); } },
        error: () => { needKey = true; } });
      dec.configure({ codec: codecFrom(c), optimizeForLatency: true });
      needKey = true;
    }
    function onPacket(buf) {
      const u = new Uint8Array(buf), kind = u[0], data = u.subarray(1);
      if (kind === 1) return configure(data.slice());
      if (!live || !dec || dec.state !== 'configured') { needKey = true; return; }
      if (kind === 3 && needKey) return askKey();
      if (dec.decodeQueueSize > 20) { needKey = true; if (kind === 3) return; }
      let chunk = data;
      if (kind === 2 && cfg) { chunk = new Uint8Array(cfg.length + data.length); chunk.set(cfg); chunk.set(data, cfg.length); }
      try { dec.decode(new EncodedVideoChunk({ type: kind === 2 ? 'key' : 'delta', timestamp: (ts += 16667), data: chunk })); if (kind === 2) needKey = false; } catch (e) { needKey = true; }
    }
    function connect() {
      ws = new WebSocket(`ws://${location.host}/appws`);
      ws.binaryType = 'arraybuffer';
      ws.onmessage = (m) => {
        if (typeof m.data === 'string') { const d = JSON.parse(m.data); if (d.type === 'meta') { vw = d.w; vh = d.h; crop = d.crop || [0, 0]; } return; }
        onPacket(m.data);
      };
      ws.onclose = () => { ws = null; setTimeout(sync, 1500); };
    }
    function sync() {
      const box = el();
      if (box) {   // panel shape (cluster.map_shape): CSS classes, see the end of cluster.css
        const shp = box.dataset.shape || ((settings().cluster || {}).map_shape) || 'rect';   // a custom layout's map has its own
        for (const [id] of (window.MAP_SHAPES || [])) box.classList.toggle(`shape-${id}`, id === shp);
        // see-through map (cluster.map_opacity, %): the animated background shows through it
        const op = String(Math.max(10, Math.min(100, +((settings().cluster || {}).map_opacity ?? 100) || 100)) / 100);
        if (box.style.getPropertyValue('--map-op') !== op) box.style.setProperty('--map-op', op);
        // how far the soft edges reach in (cluster.map_fade, %; Arcs layout with Melt / 3D tilt)
        const fd = Math.max(0, Math.min(100, +((settings().cluster || {}).map_fade ?? 35))) / 100;
        const fa = `${(0.5 + fd * 16).toFixed(2)}vh`, fv = `${(fd * 30).toFixed(1)}%`;
        if (box.style.getPropertyValue('--fade-a') !== fa) { box.style.setProperty('--fade-a', fa); box.style.setProperty('--fade-v', fv); box.style.setProperty('--fade-m', `${(4 + fd * 40).toFixed(1)}%`); }
      }
      // settings preview: no stream there, so show a made-up map in the chosen look and shape
      if (PREVIEW && box && window.MapFX && box.clientWidth > 0) { if (!demo) demo = MapFX.sample(1280, 720); crop = [0, 0]; msg(''); draw(demo); return; }
      if (!box || PREVIEW) { if (PREVIEW && box) msg('Google Maps shows here on the cluster'); if (ws && !box) { ws.onclose = null; ws.close(); ws = null; } return; }
      if (!ws) connect();
      const size = `${box.clientWidth}x${box.clientHeight}`;
      if (size !== sync.size && box.clientWidth > 0) { sync.size = size; sendCmd({ cmd: 'cluster_map_size', w: box.clientWidth, h: box.clientHeight }); }
      const a = (real && real.app) || {};
      live = a.stream === 'maps';
      if (!live) box.classList.remove('live');
      else if (!box.classList.contains('live') || performance.now() - frameAt > 3000) { needKey = true; askKey(); }
      msg(live ? (performance.now() - frameAt > 3000 ? 'Loading the map…' : '')
        : a.stream === 'music' ? 'The map comes back when YouTube Music closes'
          : real && real.companion && real.companion.connected ? 'Starting Google Maps…' : 'Google Maps shows here once your phone is linked');
    }
    setInterval(sync, 2000);
    return { sync };
  })();

  fetch('/static/themes.json').then((r) => r.json()).then((t) => { themes = t; if (real) applyLook(cfg()); }).catch(() => {});
  connect();
  requestAnimationFrame(tick);
})();
