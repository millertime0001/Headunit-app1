// Theme Studio: pick, make and fine-tune Looks for the whole dash (head unit, cluster, knob, startup).
// A Look = colors + an animated wallpaper (a Flow scene shared by every screen) + panel style + gauges + knob + map
// + startup (backend/looks.py has the format). Whatever you touch shows on the car live (POST /look/preview).
// Runs inside the Head Unit Link phone app (window.HUApp bridge: request/huReply, listen/huVoice) or in any browser
// that reaches the head unit (http://10.42.0.1:8080/theme, plain fetch).
'use strict';
const $ = (q, el = document) => el.querySelector(q);
const $$ = (q, el = document) => [...el.querySelectorAll(q)];
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const clone = (o) => (o == null ? o : JSON.parse(JSON.stringify(o)));
const APP = window.HUApp || null;
const frame = $('#frame'), splashFrame = $('#splashFrame'), panel = $('#panel');

// ================================================================ talking to the head unit
let reqId = 0;
const pend = {};
window.huReply = (id, status, text) => { const p = pend[id]; if (!p) return; delete pend[id]; p({ status, ok: status >= 200 && status < 300, text }); };
function api(method, path, body) {
  const data = body == null ? null : JSON.stringify(body);
  if (APP && APP.request) {
    return new Promise((res) => {
      const id = ++reqId;
      pend[id] = res;
      APP.request(id, method, path, data || '');
      setTimeout(() => { if (pend[id]) { delete pend[id]; res({ status: 0, ok: false, text: '' }); } }, 25000);
    });
  }
  return fetch(path, { method, headers: data ? { 'Content-Type': 'application/json' } : {}, body: data || undefined })
    .then(async (r) => ({ status: r.status, ok: r.ok, text: await r.text() }))
    .catch(() => ({ status: 0, ok: false, text: '' }));
}
async function apiJson(method, path, body) {
  const r = await api(method, path, body);
  try { r.json = JSON.parse(r.text); } catch (e) { r.json = null; }
  return r;
}
const cmd = (c, data = {}) => api('POST', '/cmd', Object.assign({ cmd: c }, data));
const NO_CAR = 'Can’t reach the head unit. Join the “Pi Head Unit” Wi-Fi or plug into the Pi.';

// ================================================================ colors
const hexRgb = (h) => { const n = parseInt(String(h || '#000000').slice(1), 16); return [n >> 16, (n >> 8) & 255, n & 255]; };
const rgbHex = (r, g, b) => '#' + [r, g, b].map((v) => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, '0')).join('').toUpperCase();
function rgbHsl(r, g, b) {
  r /= 255; g /= 255; b /= 255;
  const mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2;
  if (mx === mn) return [0, 0, l * 100];
  const d = mx - mn, s = l > 0.5 ? d / (2 - mx - mn) : d / (mx + mn);
  const h = mx === r ? (g - b) / d + (g < b ? 6 : 0) : mx === g ? (b - r) / d + 2 : (r - g) / d + 4;
  return [h * 60, s * 100, l * 100];
}
function hsl(h, s, l) {
  h = ((h % 360) + 360) % 360; s = Math.max(0, Math.min(100, s)) / 100; l = Math.max(0, Math.min(100, l)) / 100;
  const k = (n) => (n + h / 30) % 12, a = s * Math.min(l, 1 - l);
  const f = (n) => l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1)));
  return rgbHex(f(0) * 255, f(8) * 255, f(4) * 255);
}
const hexHsl = (h) => rgbHsl(...hexRgb(h));
const lum = (h) => { const [r, g, b] = hexRgb(h).map((v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4; }); return 0.2126 * r + 0.7152 * g + 0.0722 * b; };
const hueDist = (a, b) => { const d = Math.abs(a - b) % 360; return d > 180 ? 360 - d : d; };
const alpha = (hex, a) => hex + Math.round(a * 255).toString(16).padStart(2, '0');

// ================================================================ the Look format (backend/looks.py)
const SLOTS = [['base', 'Background'], ['b1', 'Glow 1'], ['b2', 'Glow 2'], ['b3', 'Glow 3'], ['accent', 'Accent']];
const LOOK_TOP = ['style', 'effect', 'motion', 'button_fx', 'clock_style', 'glow', 'ripple_style', 'knob_style', 'splash_style', 'map_style',
  'map_fx_amt', 'rain_glass', 'rain_amount', 'rain_over', 'transition'];
const LOOK_SUB = { glass: ['opacity', 'blur', 'depth', 'shine', 'tint', 'edge', 'textshadow', 'tilt'], flow: ['on', 'scene', 'amount', 'react', 'pulses'],
  cluster: ['look', 'face', 'needle', 'ticks', 'numerals', 'arc', 'glow', 'map_style'] };
const LOOK_DEFAULTS = {
  style: 'glass', effect: 'off', motion: 'lively', button_fx: 'glass', clock_style: 'thin', glow: true, ripple_style: 'waves', knob_style: 'aurora',
  splash_style: 'warp', map_style: 'theme', map_fx_amt: 100, rain_glass: false, rain_amount: 'steady', rain_over: true, transition: 'depth',
  glass: { opacity: 22, blur: 30, depth: 70, shine: 70, tint: 'theme', edge: true, textshadow: true, tilt: true },
  flow: { on: true, scene: 'liquid', amount: 75, react: true, pulses: 'on' },
  cluster: { look: 'scene', face: 'neon', needle: 'face', ticks: 'face', numerals: 'face', arc: 'face', glow: 60, map_style: 'same' },
};
const FALLBACK_COLORS = { base: '#05070B', b1: '#14B8A6', b2: '#7C3AED', b3: '#0EA5E9', accent: '#5EEAD4', light: false };
function merge(a, b) {
  const out = clone(a || {});
  for (const [k, v] of Object.entries(b || {})) out[k] = v && typeof v === 'object' && !Array.isArray(v) && out[k] && typeof out[k] === 'object' ? merge(out[k], v) : clone(v);
  return out;
}
function lookPart(s) {   // only the look settings out of a settings dict
  const out = {};
  for (const k of LOOK_TOP) if (s[k] !== undefined) out[k] = s[k];
  for (const [k, subs] of Object.entries(LOOK_SUB)) {
    if (!s[k] || typeof s[k] !== 'object') continue;
    const p = {};
    for (const x of subs) if (s[k][x] !== undefined) p[x] = s[k][x];
    if (Object.keys(p).length) out[k] = p;
  }
  return out;
}

// Studio extras (corner radius, border, accent glow, font, photo wallpaper, text color) are written into the Look's
// css after a small header, so they come back as sliders when the Look is opened again:
//   /*@studio{"radius":1.4,...}*/ <generated rules> /*@end*/ <your own css>
const RVARS = ['--r-xl', '--r-lg', '--r-md'];
function extrasCss(x) {
  const keep = Object.assign({}, x); delete keep.wall; delete keep.fontData;
  const css = [];
  if (x.fontData) css.push(`@font-face{font-family:StudioFont;src:url(${x.fontData})}`);
  if (x.font) css.push(`body,button,input{font-family:${x.font} !important}`);
  if (x.weight) css.push(`:is(h1,h2,.clock,.big-num,.nav-speed b,.label){font-weight:${x.weight} !important}`);
  if (x.border) css.push(`.glass{outline:${x.border}px solid ${x.borderColor || '#FFFFFF'};outline-offset:-${x.border}px}`);
  if (x.glow) css.push(`.glass{box-shadow:0 0 ${x.glow}px -${Math.round(x.glow / 3)}px var(--accent),0 1rem 2rem -1rem rgb(0 0 0/.6) !important}`);
  if (x.wall) {
    const dim = (x.wallDim ?? 35) / 100;
    css.push(`.bg{background:linear-gradient(rgb(0 0 0/${dim}),rgb(0 0 0/${dim})),url(${x.wall}) center/cover no-repeat !important}`,
      '.bg .blob,.bg #fx,.bg #flow{display:none !important}');
  }
  if (x.textColor) css.push(`:root{--text:${x.textColor} !important}`);
  if (!css.length && !Object.keys(keep).length) return '';
  return `/*@studio${JSON.stringify(keep)}*/\n${css.join('\n')}\n/*@end*/\n`;
}
function parseCss(css, vars) {
  vars = Object.assign({}, vars || {});
  let x = {}, custom = css || '';
  const m = /^\/\*@studio(\{[^\n]*?\})\*\/\n?/.exec(custom);
  if (m) {
    try { x = JSON.parse(m[1]); } catch (e) { x = {}; }
    const end = custom.indexOf('/*@end*/'), gen = custom.slice(0, end < 0 ? custom.length : end);
    custom = end < 0 ? '' : custom.slice(end + 8).replace(/^\n/, '');
    const w = /url\((data:image\/[^)]+)\) center\/cover/.exec(gen); if (w) x.wall = w[1];
    const f = /font-family:StudioFont;src:url\(([^)]+)\)/.exec(gen); if (f) x.fontData = f[1];
    if (x.radius != null) RVARS.forEach((k) => delete vars[k]);
  }
  return { x, custom, vars };
}

// A Look (or an old design file) into the thing the editor works on
function toDraft(lk, edits) {
  const ed = edits || {}, p = parseCss(lk.css, lk.vars);
  return { src: lk.id || '', mine: /^u-/.test(lk.id || ''), name: lk.name || 'My look', desc: lk.desc || '', author: lk.author || '',
    request: lk.request, colors: Object.assign({}, FALLBACK_COLORS, lk.colors || {}, ed.colors || {}),
    set: merge(LOOK_DEFAULTS, merge(lk.set || {}, ed.set || {})), knob: lk.knob ? clone(lk.knob) : null, vars: p.vars, x: p.x, custom: p.custom };
}
function fromDesign(f) {   // the older Theme Studio's "headunit-design" files
  const s = f.settings || {}, pal = PAL.find((t) => t.id === s.theme) || {};
  const colors = {};
  for (const [k] of SLOTS) if (pal[k]) colors[k] = pal[k];
  if (pal.light != null) colors.light = !!pal.light;
  const set = lookPart(s);
  if (!s.flow) set.flow = { on: false };   // old designs used the head unit's own background effects
  const d = toDraft({ name: f.name, desc: f.desc, author: f.author, colors: Object.assign(colors, f.colors || {}), set, knob: f.knob, vars: f.vars, css: f.studio ? '' : f.css });
  if (f.studio) { d.x = Object.assign({}, f.studio); d.custom = f.customCss || ''; }
  return d;
}
const fromAny = (o) => (o && o.format === 'headunit-design' ? fromDesign(o) : toDraft(o));
// The editor's draft back into a Look file
function compile(d) {
  const vars = Object.assign({}, d.vars);
  if (d.x.radius != null) { vars['--r-xl'] = `${d.x.radius}rem`; vars['--r-lg'] = `${(d.x.radius * 0.8).toFixed(2)}rem`; vars['--r-md'] = `${(d.x.radius * 0.55).toFixed(2)}rem`; }
  const out = { name: d.name, desc: d.desc, colors: d.colors, set: d.set, vars, css: extrasCss(d.x) + (d.custom || '') };
  if (d.mine) out.id = d.src;
  if (d.author) out.author = d.author;
  if (d.request) out.request = d.request;
  if (d.knob && d.knob.colors) out.knob = { colors: d.knob.colors };
  return out;
}
const knobColors = (d) => Object.assign({ accent: d.colors.accent, base: d.colors.base, text: d.colors.light ? '#0B1220' : '#F5F7FA', b1: d.colors.b1, b2: d.colors.b2, b3: d.colors.b3 }, (d.knob && d.knob.colors) || {});

// ================================================================ option lists (replaced by the preview page's own once it loads)
const T = {
  scenes: [['liquid', 'Liquid light', 'Glowing blobs of light drift from screen to screen'], ['ribbons', 'Silk ribbons', 'Ribbons of light flow across the dash'],
    ['aurora', 'Northern lights', 'Aurora curtains rippling across the whole dash'], ['vortex', 'Vortex', 'Spiral arms turning around the knob'],
    ['warp', 'Hyperspace', 'Stars streaming past, faster as you drive'], ['grid', 'Outrun', 'A neon sun and a racing grid floor'],
    ['plasma', 'Plasma', 'Slow waves of color'], ['rain', 'Rain storm', 'Rain sweeping across every screen'], ['ocean', 'Moonlit sea', 'A moon and rolling waves'],
    ['circuit', 'Circuit', 'Pulses racing along circuit traces'], ['embers', 'Embers', 'Sparks rising off the knob'], ['sonar', 'Sonar', 'Rings and a radar sweep']],
  styles: [['glass', 'Glass', 'Frosted panels'], ['carbon', 'Carbon Racing', 'Carbon weave, cut corners'], ['synth', 'Synthwave', 'Neon outlines'],
    ['minimal', 'Minimal', 'No boxes, thin type'], ['hud', 'Cyber HUD', 'Scanlines and brackets'], ['lux', 'Luxury', 'Gold hairlines, serif'],
    ['rally', 'Rally', 'Bold stripes'], ['soft', 'Soft 3D', 'Raised clay panels'], ['pop', 'Pop Art', 'Thick outlines'], ['sea', 'Deep Sea', 'Round and glowing'],
    ['paper', 'Paper', 'Ink on paper'], ['holo', 'Holographic', 'Iridescent rims'], ['slime', 'Slime', 'Glossy goo'], ['rainy', 'Rainy Window', 'Wet glass']],
  effects: [['blobs', 'Lava lamp'], ['liquid', 'Liquid glass'], ['aurora', 'Aurora'], ['nebula', 'Nebula'], ['road', 'Night highway'], ['warp', 'Warp speed'],
    ['grid', 'Synthwave'], ['window', 'Rainy window'], ['bokeh', 'City bokeh'], ['particles', 'Constellation'], ['fireflies', 'Fireflies'], ['waves', 'Waves'],
    ['matrix', 'Code rain'], ['plasma', 'Plasma'], ['embers', 'Embers'], ['snow', 'Snowfall'], ['storm', 'Thunderstorm'], ['galaxy', 'Galaxy'], ['smoke', 'Smoke'],
    ['petals', 'Falling petals'], ['underwater', 'Underwater'], ['off', 'Still']],
  buttons: [['glass', 'Glass'], ['neon', 'Neon glow'], ['holo', 'Holo ring'], ['liquid', 'Jelly'], ['chrome', 'Chrome sheen'], ['pulse', 'Pulse']],
  clocks: [['thin', 'Thin'], ['bold', 'Bold'], ['outline', 'Outline'], ['glow', 'Neon']],
  ripples: [['waves', 'Waves'], ['shock', 'Shockwave'], ['aurora', 'Aurora bloom'], ['sparks', 'Sparks'], ['edge', 'Edge only'], ['rain', 'Raindrops'],
    ['liquid', 'Liquid level'], ['curtain', 'Light curtain'], ['bars', 'Level bars']],
  splashes: [['warp', 'Warp ring', 'Light streaks and a glowing ring'], ['hyper', 'Hyperspace', 'Neon tunnel slams to a stop'], ['plasma', 'Plasma core', 'Energy orb charges and blasts'],
    ['ignition', 'Ignition', 'Gauge sweep to redline'], ['chrome', 'Liquid chrome', 'Metal drops merge into one'], ['dawn', 'Mountain dawn', 'Night turns to sunrise']],
  faces: [['real', 'Realistic'], ['luxe', 'Luxury watch'], ['tron', 'Tron'], ['lava', 'Lava'], ['crystal', 'Crystal'], ['retro', 'Retro VFD'], ['blueprint', 'Blueprint'],
    ['hologram', 'Hologram'], ['synthwave', 'Synthwave'], ['aurora', 'Aurora'], ['liquid', 'Liquid metal'], ['particles', 'Particles'], ['carbon', 'Carbon'],
    ['glass', 'Glass'], ['minimal', 'Minimal'], ['neon', 'Neon'], ['plasma', 'Plasma'], ['galaxy', 'Galaxy'], ['chrome', 'Chrome'], ['hud', 'HUD'], ['classic', 'Classic']],
  gopts: [['needle', 'Needle', [['face', 'Face default'], ['blade', 'Blade'], ['laser', 'Laser'], ['comet', 'Comet trail'], ['classic', 'Classic'], ['none', 'None']]],
    ['ticks', 'Tick marks', [['face', 'Face default'], ['fine', 'Fine'], ['bold', 'Bold'], ['minimal', 'Dots'], ['none', 'None']]],
    ['numerals', 'Numbers', [['face', 'Face default'], ['thin', 'Thin'], ['bold', 'Bold'], ['digital', 'Digital'], ['none', 'None']]],
    ['arc', 'Value arc', [['face', 'Face default'], ['gradient', 'Gradient'], ['solid', 'Solid'], ['segments', 'Segments'], ['none', 'None']]]],
  maps: [['original', 'Original', 'Google Maps as the phone draws it'], ['theme', 'Theme colors', 'Re-painted in the look’s colors'], ['night', 'Night', 'Dark mode'],
    ['neon', 'Neon', 'Roads traced in glowing lines'], ['blueprint', 'Blueprint', 'Navy drafting paper'], ['mono', 'Graphite', 'Quiet grayscale'],
    ['synthwave', 'Synthwave', 'Magenta roads, cyan route'], ['thermal', 'Thermal', 'Heat camera']],
  clLooks: [['scene', 'Wallpaper', 'The animated wallpaper behind the gauges'], ['glow', 'Glow', 'Soft color glow'], ['black', 'Black', 'Pure black'], ['carbon', 'Carbon', 'Carbon weave']],
};
const FONTS = [['', 'Style default'], ['system-ui, sans-serif', 'System'], ['"DejaVu Sans Condensed", sans-serif', 'Condensed'], ['"DejaVu Serif", serif', 'Serif'],
  ['"DejaVu Sans Mono", monospace', 'Monospace'], ['StudioFont', 'My uploaded font']];
const SCREENS = [['home', 'Home'], ['music', 'Music'], ['gauges', 'Gauges'], ['startup', 'Startup']];
function pullTables(w) {
  const get = (n) => { try { return w.eval(n); } catch (e) { return null; } };
  const ok = (a) => Array.isArray(a) && a.length && Array.isArray(a[0]) && typeof a[0][0] === 'string';
  const map = { scenes: 'FLOW_SCENES', styles: 'STYLES', effects: 'EFFECTS', buttons: 'BUTTONS', clocks: 'CLOCKS', ripples: 'RIPPLES', splashes: 'SPLASHES',
    faces: 'GAUGE_FACES', maps: 'MAP_STYLES' };
  for (const [k, n] of Object.entries(map)) { const v = get(n); if (ok(v)) T[k] = v.map((x) => [x[0], String(x[1]), typeof x[2] === 'string' ? x[2] : '']); }
  T.scenes = T.scenes.filter((s) => s[0] !== 'calibrate');
  const go = get('GAUGE_STYLE_OPTS');
  if (ok(go)) T.gopts = go.filter((o) => Array.isArray(o[2]));
}
const nameOf = (list, id) => ((T[list] || []).find((x) => x[0] === id) || [id, id])[1];
const has = (list, id) => (T[list] || []).some((x) => x[0] === id);

// ================================================================ state
let PAL = [], KFACES = [], CLAUDE = [];
let LK = { builtin: [], mine: [], current: null, edits: {}, look: null, schedule: null, schedule_now: null };
let palGroup = '';
const curPalGroup = (groups) => (groups[palGroup] ? palGroup : Object.keys(groups)[0] || '');
let D = null, sel = '', tab = localStorage.getItem('ts-tab') || 'looks', filter = 'all', screen = 'home';
let live = localStorage.getItem('ts-live') !== '0', carOk = null, ready = false, previewing = false;
let hist = [], fut = [], dirty = false, reqs = [], results = [], resultsFrom = '', photo = null, lib = [];

function saveDraft() {
  try { localStorage.setItem('ts-draft', JSON.stringify(D)); } catch (e) { try { localStorage.removeItem('ts-draft'); } catch (er) { /* full */ } }
}
function setDraft(d, opts = {}) {
  D = d; hist = []; fut = []; markDirty(!!opts.dirty); saveDraft(); undoState();
  showLocal();
  if (opts.live !== false) startPreview();
  if (tab === 'edit') render();
  $('#dname').value = D.name;
}

// ================================================================ editing + undo
let dragging = false;
function edit(fn, opts = {}) {
  if (opts.hist !== false && !(opts.drag && dragging)) { hist.push(JSON.stringify(D)); if (hist.length > 60) hist.shift(); fut = []; }
  if (opts.drag) dragging = true;
  fn(D);
  markDirty(); saveDraft(); showLocal(); startPreview(); undoState();
  if (opts.render) render();
}
function markDirty(v = true) { dirty = v; $('#saveBtn').classList.toggle('dirty', dirty); }
function undo() { if (!hist.length) return; fut.push(JSON.stringify(D)); D = JSON.parse(hist.pop()); afterUndo(); }
function redo() { if (!fut.length) return; hist.push(JSON.stringify(D)); D = JSON.parse(fut.pop()); afterUndo(); }
function afterUndo() { markDirty(); saveDraft(); showLocal(); startPreview(); render(); undoState(); }
function undoState() { $('#undoBtn').disabled = !hist.length; $('#redoBtn').disabled = !fut.length; }
const root = (r) => ({ set: D.set, x: D.x, c: D.colors, k: knobColors(D) }[r]);
function getP(path) {
  const [r, ...rest] = path.split('.');
  let o = root(r);
  if (!o) return D[path];
  for (const p of rest) o = o == null ? undefined : o[p];
  return o;
}
function setP(path, v) {
  const [r, ...rest] = path.split('.');
  if (r === 'k' && !(D.knob && D.knob.colors)) D.knob = { colors: knobColors(D) };
  let o = r === 'set' ? D.set : r === 'x' ? D.x : r === 'c' ? D.colors : r === 'k' ? D.knob.colors : null;
  if (!o) { D[path] = v; return; }
  for (const p of rest.slice(0, -1)) o = o[p] = o[p] || {};
  if (v === undefined) delete o[rest[rest.length - 1]]; else o[rest[rest.length - 1]] = v;
}

// ================================================================ live preview: on the car and in the phone's own preview
let pvTimer = 0, pvBusy = false, pvAgain = false, pvBeat = 0;
function startPreview() { previewing = true; queueCar(); }
function queueCar() {
  if (!live || !previewing || document.hidden) return;
  if (pvBusy) { pvAgain = true; return; }
  clearTimeout(pvTimer);
  pvTimer = setTimeout(sendCar, 220);   // about 4 updates a second while dragging
}
async function sendCar() {
  pvBusy = true;
  const r = await api('POST', '/look/preview', compile(D));
  pvBusy = false;
  setCarOk(r.ok);
  if (pvAgain) { pvAgain = false; queueCar(); }
  clearInterval(pvBeat);   // the car drops a preview 150 s after the last update: keep it alive while the Studio is open
  pvBeat = setInterval(() => { if (live && previewing && !document.hidden) api('POST', '/look/preview', compile(D)); }, 60000);
}
function stopPreview() {
  clearTimeout(pvTimer); clearInterval(pvBeat);
  if (previewing) api('POST', '/look/preview', {});
  previewing = false;
}
function setCarOk(ok) {
  carOk = ok;
  const b = $('#liveBtn');
  b.classList.toggle('off-car', !ok);
  b.querySelector('span').textContent = !live ? 'Live off' : ok ? 'Live' : 'No car';
}
function setLive(v) {
  live = v; localStorage.setItem('ts-live', v ? '1' : '0');
  $('#liveBtn').setAttribute('aria-pressed', String(v));
  if (v) { previewing = true; queueCar(); toast('Changes show on the car as you make them'); } else { stopPreview(); toast('The car shows its own look again'); }
  setCarOk(carOk !== false);
}
document.addEventListener('visibilitychange', () => {
  if (document.hidden) { if (previewing) { clearInterval(pvBeat); api('POST', '/look/preview', {}); } }
  else { if (previewing) queueCar(); refresh(); }
});
addEventListener('pagehide', () => { if (previewing) api('POST', '/look/preview', {}); });

let lT = 0;
function showLocal() {
  clearTimeout(lT);
  lT = setTimeout(() => {
    if (!D) return;
    if (ready) frame.contentWindow.postMessage({ type: 'look', look: compile(D), set: D.set }, '*');
    drawKnobPv();
    if (screen === 'startup') showSplash();
  }, 50);
}

// ================================================================ the phone's preview (the head unit page in a frame)
function fit() { const w = $('#bezel').clientWidth; for (const f of [frame, splashFrame]) f.style.transform = `scale(${w / 1024})`; }
new ResizeObserver(fit).observe($('#bezel'));
addEventListener('message', (e) => {
  if (!e.data || e.data.type !== 'preview-ready' || e.source !== frame.contentWindow) return;
  ready = true;
  pullTables(frame.contentWindow);
  showLocal(); render();
  setTimeout(() => goScreen(screen), 150);
});
function goScreen(s) {
  screen = s;
  $$('#screens .chip').forEach((c) => c.classList.toggle('on', c.dataset.screen === s));
  const sp = s === 'startup';
  splashFrame.classList.toggle('hidden', !sp);
  frame.classList.toggle('hidden', sp);
  if (sp) showSplash();
  else { splashFrame.removeAttribute('src'); if (ready) frame.contentWindow.postMessage({ type: 'go', screen: s }, '*'); }
}
let spN = 0, spKey = '';
function showSplash() {
  const c = D.colors;
  const key = JSON.stringify({ base: c.base, b1: c.b1, b2: c.b2, b3: c.b3, accent: c.accent, style: D.set.splash_style || 'warp', name: 'Pi Head Unit' });
  if (key === spKey && splashFrame.getAttribute('src')) return;
  spKey = key;
  splashFrame.src = `/static/splash.html?preview&v=${++spN}#${encodeURIComponent(key)}`;
}
$('#screens').innerHTML = SCREENS.map(([id, n]) => `<button class="chip ${screen === id ? 'on' : ''}" data-screen="${id}">${n}</button>`).join('');
$('#screens').addEventListener('click', (e) => { const b = e.target.closest('[data-screen]'); if (b) goScreen(b.dataset.screen); });

// knob faces drawn by the head unit page's own knob artwork (same as the real knob)
let kuid = 0;
const kCache = new Map();
function knobSvg(faceId) {
  const kc = knobColors(D), key = `${faceId}|${JSON.stringify(kc)}`;
  if (ready && kCache.has(key)) return kCache.get(key);
  const svg = knobSvgNow(faceId, kc);
  if (ready) { if (kCache.size > 300) kCache.clear(); kCache.set(key, svg); }
  return svg;
}
function knobSvgNow(faceId, kc) {
  const plain = `<svg viewBox="0 0 240 240"><circle cx="120" cy="120" r="120" fill="${kc.base}"/><circle cx="120" cy="120" r="100" fill="none" stroke="${kc.accent}" stroke-width="6"/></svg>`;
  if (!ready) return plain;
  try {
    const w = frame.contentWindow, S = w.eval('S'), faces = w.eval('FACES') || KFACES;
    const face = faces.find((f) => f.id === faceId) || faces[0];
    if (!face || !w.knobSVG) return plain;
    const saved = S.theme;
    S.theme = Object.assign({}, saved, { accent: kc.accent, base: kc.base, b1: kc.b1, b2: kc.b2, b3: kc.b3, light: kc.text === '#0B1220' });
    const svg = w.knobSVG(face, `ts${++kuid}`);
    S.theme = saved;
    return svg || plain;
  } catch (e) { return plain; }
}
function drawKnobPv() {
  if (!D) return;
  $('#knobPv').innerHTML = knobSvgNow(D.set.knob_style, knobColors(D));
  const big = $('#knobBig');
  if (big) { big.innerHTML = knobSvgNow(D.set.knob_style, knobColors(D)); big.style.setProperty('--kglow', alpha(knobColors(D).accent, 0.4)); }
}
$('#knobPv').addEventListener('click', () => {
  if (ready) frame.contentWindow.postMessage({ type: 'knob', act: 'turn', vol: 30 + Math.random() * 50 }, '*');
  if (tab !== 'edit') setTab('edit');
  openSec('knob');
});

// ================================================================ cards: a little dash drawn in the Look's colors and wallpaper
function sceneArt(scene, c, on = true) {
  const { base, b1, b2, b3, accent: a } = c;
  if (!on) return `radial-gradient(60% 70% at 25% 30%,${alpha(b1, 0.55)},transparent 70%),radial-gradient(60% 70% at 80% 80%,${alpha(b2, 0.5)},transparent 70%),${base}`;
  const A = {
    ribbons: `linear-gradient(160deg,transparent 30%,${alpha(b1, 0.75)} 38%,transparent 46%),linear-gradient(150deg,transparent 48%,${alpha(b2, 0.7)} 56%,transparent 64%),linear-gradient(170deg,transparent 62%,${alpha(b3, 0.6)} 68%,transparent 75%),${base}`,
    aurora: `repeating-linear-gradient(95deg,transparent 0 9%,${alpha(b1, 0.35)} 12%,transparent 16%),linear-gradient(transparent 10%,${alpha(b1, 0.55)} 35%,${alpha(b2, 0.4)} 55%,transparent 75%),${base}`,
    vortex: `radial-gradient(circle at 70% 70%,${alpha(a, 0.6)},transparent 12%),conic-gradient(from 0deg at 70% 70%,${b1},${base},${b2},${base},${b3},${base},${b1})`,
    warp: `radial-gradient(circle at 50% 50%,${alpha(a, 0.6)},transparent 18%),repeating-conic-gradient(from 0deg at 50% 50%,${alpha(b3, 0.75)} 0 1deg,transparent 1deg 9deg),${base}`,
    grid: `linear-gradient(transparent 55%,${alpha(b1, 0.5)} 56%,transparent 57%),repeating-linear-gradient(90deg,transparent 0 11%,${alpha(b1, 0.6)} 11% 11.6%),radial-gradient(circle at 50% 52%,${a} 0 15%,transparent 16%),linear-gradient(${base} 30%,${alpha(b2, 0.7)} 55%,${base} 56%)`,
    plasma: `radial-gradient(70% 60% at 20% 30%,${alpha(b1, 0.85)},transparent),radial-gradient(70% 60% at 80% 40%,${alpha(b2, 0.8)},transparent),radial-gradient(70% 70% at 50% 100%,${alpha(b3, 0.8)},transparent),${base}`,
    rain: `repeating-linear-gradient(100deg,transparent 0 6px,${alpha(a, 0.28)} 6px 7px),radial-gradient(circle at 30% 60%,${alpha(b1, 0.45)},transparent 25%),radial-gradient(circle at 75% 40%,${alpha(b2, 0.4)},transparent 22%),${base}`,
    ocean: `radial-gradient(circle at 62% 26%,${a} 0 6%,${alpha(a, 0.25)} 7%,transparent 18%),repeating-linear-gradient(transparent 0 6px,${alpha(b1, 0.35)} 6px 8px) 0 62%/100% 40% no-repeat,linear-gradient(${base} 60%,${alpha(b2, 0.6)})`,
    circuit: `linear-gradient(90deg,transparent 30%,${alpha(a, 0.7)} 30% 31%,transparent 31%),linear-gradient(transparent 60%,${alpha(b1, 0.7)} 60% 61.5%,transparent 61.5%),repeating-linear-gradient(90deg,${alpha(b3, 0.15)} 0 1px,transparent 1px 14px),repeating-linear-gradient(${alpha(b3, 0.15)} 0 1px,transparent 1px 14px),${base}`,
    embers: `radial-gradient(circle at 20% 70%,${a} 0 1.5%,transparent 2%),radial-gradient(circle at 45% 40%,${b1} 0 1.2%,transparent 1.8%),radial-gradient(circle at 70% 60%,${a} 0 1%,transparent 1.6%),radial-gradient(circle at 85% 30%,${b2} 0 1.4%,transparent 2%),radial-gradient(90% 60% at 50% 110%,${alpha(b1, 0.8)},transparent),${base}`,
    sonar: `repeating-radial-gradient(circle at 80% 85%,transparent 0 14px,${alpha(a, 0.4)} 14px 15px),conic-gradient(from 300deg at 80% 85%,${alpha(b1, 0.6)},transparent 25%),${base}`,
  };
  // scenes without their own thumbnail borrow the closest one
  const LIKE = { rainwindow: 'rain', snow: 'embers', bokeh: 'embers', galaxy: 'vortex', matrix: 'rain', lava: 'plasma', fireflies: 'embers', petals: 'embers',
    topo: 'sonar', speedlines: 'warp', caustics: 'ocean', smoke: 'plasma', silk: 'ribbons', mountains: 'ocean', neon: 'circuit', neoncity: 'grid',
    dunes: 'ribbons', crystal: 'vortex', chrome: 'ribbons', kaleido: 'vortex', fireworks: 'warp' };
  return A[scene] || A[LIKE[scene]] || `radial-gradient(45% 55% at 25% 30%,${alpha(b1, 0.9)},transparent 70%),radial-gradient(50% 60% at 80% 75%,${alpha(b2, 0.85)},transparent 70%),radial-gradient(40% 45% at 70% 10%,${alpha(b3, 0.8)},transparent 70%),${base}`;
}
function mini(lk, edits) {
  const c = Object.assign({}, FALLBACK_COLORS, lk.colors || {}, (edits && edits.colors) || {});
  const st = merge(LOOK_DEFAULTS, merge(lk.set || {}, (edits && edits.set) || {}));
  const kc = Object.assign({ base: c.base, accent: c.accent }, (lk.knob && lk.knob.colors) || {});
  const g = st.glass, a = Math.max(0.06, Math.min(0.55, (g.opacity || 22) / 100));
  const glass = c.light ? `rgb(255 255 255 / ${a + 0.3})` : `rgb(255 255 255 / ${a * 0.55})`;
  const txt = c.light ? '#0B1220' : '#F5F7FA';
  const wall = /url\(data:image/.test(lk.css || '') ? ' photo' : '';
  return `<div class="mini${wall}" style="--base:${c.base};--art:${sceneArt(st.flow.scene, c, st.flow.on !== false)};--acc:${c.accent};--txt:${txt};--glass:${glass};--kbase:${kc.base};--kacc:${kc.accent}">
    <i class="nv"></i><i class="t t1"></i><i class="t t2"></i><i class="t t3"></i><i class="kn"></i></div>`;
}
function card(key, lk, opts = {}) {
  const st = merge(LOOK_DEFAULTS, lk.set || {});
  const sub = opts.sub || (st.flow.on !== false ? nameOf('scenes', st.flow.scene) : /url\(data:image/.test(lk.css || '') ? 'Photo' : nameOf('effects', st.effect));
  const badges = (opts.badges || []).map(([t, cls]) => `<span class="badge ${cls || ''}">${esc(t)}</span>`).join('');
  return `<button class="lcard ${sel === key ? 'sel' : ''} ${opts.on ? 'on' : ''}" data-pick="${esc(key)}">${mini(lk, opts.edits)}<div class="badges">${badges}</div>
    <div class="meta"><b>${esc(lk.name)}</b><span>${esc(sub)}</span></div></button>`;
}

// ================================================================ "Describe it": words into whole Looks
const COLOR_WORDS = { red: 0, crimson: 350, scarlet: 5, ruby: 350, orange: 25, copper: 22, bronze: 30, amber: 40, gold: 45, golden: 45, yellow: 55,
  lime: 85, green: 130, emerald: 150, mint: 160, jade: 155, teal: 175, aqua: 185, cyan: 188, turquoise: 178, sky: 200, blue: 220, cobalt: 215,
  navy: 225, indigo: 245, violet: 265, purple: 275, lavender: 265, magenta: 305, fuchsia: 310, pink: 330, rose: 345, coral: 12, peach: 22 };
// mood words -> hues, saturation and the parts of the Look (scene = Flow wallpaper, face = gauge face, knob = knob face)
const MOODS = [
  [/neon|cyber|vegas|arcade/, { hues: [315, 190], sat: 96, style: 'synth', scene: 'grid', button: 'neon', ripple: 'shock', knob: 'neon', splash: 'hyper', clock: 'glow', face: 'tron', map: 'neon' }],
  [/tokyo|city|night ?life|downtown|skyline|metro/, { hues: [320, 200], sat: 90, style: 'glass', scene: 'circuit', knob: 'nightdrive', splash: 'hyper', clock: 'glow', face: 'hologram', map: 'neon' }],
  [/synth|retro|80s|outrun|vapor/, { hues: [300, 190, 30], sat: 95, style: 'synth', scene: 'grid', button: 'neon', knob: 'neon', splash: 'hyper', clock: 'glow', face: 'synthwave', map: 'synthwave' }],
  [/sunset|dusk|evening|golden hour/, { hues: [18, 330, 45], sat: 88, scene: 'liquid', style: 'glass', splash: 'dawn', knob: 'bloom', face: 'crystal' }],
  [/sunrise|dawn|morning/, { hues: [35, 200, 340], sat: 75, scene: 'aurora', splash: 'dawn', knob: 'sunburst', face: 'glass' }],
  [/ocean|sea|beach|wave|surf|tropic|island|lagoon|moon/, { hues: [190, 170, 210], sat: 80, style: 'sea', scene: 'ocean', ripple: 'liquid', knob: 'liquid', splash: 'plasma', face: 'liquid' }],
  [/forest|wood|cabin|pine|moss|jungle|nature/, { hues: [130, 95, 45], sat: 55, style: 'soft', scene: 'liquid', amount: 55, knob: 'halo', splash: 'dawn', face: 'glass', motion: 'calm' }],
  [/fire|lava|ember|flame|inferno|volcan|hell/, { hues: [12, 35, 350], sat: 95, scene: 'embers', style: 'carbon', knob: 'pulse', splash: 'ignition', ripple: 'sparks', face: 'lava' }],
  [/ice|arctic|frost|frozen|glacier|winter|snow/, { hues: [195, 210, 180], sat: 45, scene: 'aurora', style: 'glass', knob: 'ice', splash: 'chrome', face: 'crystal', glass: { opacity: 30, blur: 40 } }],
  [/space|galaxy|cosmic|star|nebula|astro|universe|hyper/, { hues: [265, 210, 310], sat: 80, scene: 'warp', style: 'holo', knob: 'starfield', splash: 'warp', face: 'galaxy' }],
  [/rally|subaru|wrc|wrx|sti|race|racing|track|motorsport/, { hues: [222, 48], sat: 90, style: 'rally', scene: 'ribbons', knob: 'rally', splash: 'ignition', button: 'chrome', clock: 'bold', face: 'real' }],
  [/carbon|stealth|murdered|black ?out|dark ?mode/, { hues: [210], sat: 8, style: 'carbon', scene: 'circuit', amount: 40, knob: 'carbonfibre', splash: 'ignition', button: 'chrome', mono: true, face: 'carbon', map: 'mono' }],
  [/matrix|hacker|terminal|code/, { hues: [130], sat: 90, scene: 'circuit', style: 'hud', knob: 'dotmatrix', splash: 'warp', font: '"DejaVu Sans Mono", monospace', mono: true, face: 'retro' }],
  [/rain|storm|thunder|wet|drizzle/, { hues: [215, 200, 260], sat: 45, style: 'rainy', scene: 'rain', knob: 'rainy', ripple: 'rain', splash: 'plasma', rain: true, face: 'glass', map: 'night' }],
  [/lux|luxury|gold|royal|elegant|premium|classy/, { hues: [42, 30], sat: 70, style: 'lux', scene: 'liquid', amount: 50, knob: 'classic', splash: 'chrome', button: 'chrome', clock: 'thin', face: 'luxe' }],
  [/cherry|sakura|blossom|spring|flower|petal/, { hues: [335, 350, 120], sat: 70, scene: 'ribbons', style: 'soft', knob: 'bloom', splash: 'dawn', face: 'glass' }],
  [/minimal|clean|simple|calm|zen/, { hues: [210], sat: 25, style: 'minimal', scene: 'plasma', amount: 30, knob: 'minimal', splash: 'chrome', motion: 'calm', face: 'minimal' }],
  [/paper|daylight|bright|light mode|white/, { hues: [215], sat: 40, style: 'paper', scene: 'plasma', amount: 30, light: true, knob: 'minimal', splash: 'dawn', face: 'minimal', map: 'original' }],
  [/chrome|metal|steel|silver|titanium/, { hues: [210, 200], sat: 12, style: 'chrome', scene: 'liquid', knob: 'chrono', splash: 'chrome', button: 'chrome', face: 'chrome' }],
  [/toxic|slime|radioactive|acid/, { hues: [95, 280], sat: 95, style: 'slime', scene: 'plasma', knob: 'liquid', splash: 'plasma', face: 'neon' }],
  [/aurora|northern lights|borealis/, { hues: [160, 280, 200], sat: 80, scene: 'aurora', style: 'glass', knob: 'auroraclock', splash: 'warp', face: 'aurora' }],
  [/desert|sand|canyon|dune|western|cowboy/, { hues: [28, 15, 200], sat: 60, scene: 'liquid', style: 'soft', knob: 'amber', splash: 'dawn', face: 'retro' }],
  [/hud|fighter|jet|military|cockpit|tactical|radar/, { hues: [150, 45], sat: 70, style: 'hud', scene: 'sonar', knob: 'hud', splash: 'ignition', mono: true, face: 'hud', map: 'blueprint' }],
  [/blueprint|technical|engineer/, { hues: [215], sat: 70, style: 'blueprint', scene: 'circuit', face: 'blueprint', map: 'blueprint', knob: 'minimal' }],
  [/halloween|spooky|ghost|horror/, { hues: [28, 275], sat: 90, scene: 'embers', style: 'carbon', knob: 'pulse', splash: 'plasma', face: 'lava' }],
  [/christmas|holiday|festive/, { hues: [355, 140, 45], sat: 80, scene: 'embers', style: 'soft', knob: 'halo', splash: 'warp', face: 'crystal' }],
  [/party|rave|club|disco|edm/, { hues: [290, 180, 50], sat: 98, scene: 'vortex', style: 'pop', button: 'pulse', ripple: 'bars', knob: 'equalizer', splash: 'hyper', face: 'particles' }],
  [/vortex|spiral|hypno|swirl/, { scene: 'vortex', face: 'hologram' }],
];
const SCENE_POOL = ['liquid', 'ribbons', 'aurora', 'plasma', 'vortex', 'ocean', 'warp'];
const FACE_POOL = ['neon', 'glass', 'aurora', 'crystal', 'hologram', 'particles', 'plasma'];
const titleCase = (s) => s.replace(/\s+/g, ' ').trim().split(' ').slice(0, 4).map((w) => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
const pick = (list, id, fb) => (has(list, id) ? id : fb);
function describe(text) {
  const q = ` ${text.toLowerCase()} `;
  const P = { hues: [], sat: null };
  const named = PAL.find((t) => q.includes(` ${t.name.toLowerCase()} `));
  for (const [re, p] of MOODS) {
    if (!re.test(q)) continue;
    for (const k in p) { if (k === 'hues') P.hues.push(...p.hues); else if (P[k] == null) P[k] = p[k]; }
  }
  // a scene you name by its own name wins ("silk ribbons", "plasma", "sonar")
  const sc = T.scenes.find(([id, n]) => q.includes(` ${id} `) || q.includes(n.toLowerCase()));
  if (sc) P.scene = sc[0];
  const colorHues = [];
  for (const [w, h] of Object.entries(COLOR_WORDS)) if (new RegExp(`\\b${w}\\b`).test(q)) colorHues.push(h);
  if (colorHues.length) P.hues = colorHues.concat(P.hues);
  if (/\b(black|dark|night|midnight|moody)\b/.test(q)) P.dark = true;
  if (/\b(pastel|soft|muted|gentle)\b/.test(q)) P.sat = Math.min(P.sat ?? 50, 45);
  if (/\b(bright|vivid|loud|bold|electric)\b/.test(q)) P.sat = 98;
  if (/\b(calm|chill|relax)\b/.test(q)) P.motion = 'calm';
  if (/\b(wild|crazy|intense|energetic)\b/.test(q)) P.motion = 'wild';
  const name = titleCase(text.replace(/[^\w\s'-]/g, '')) || 'New look';
  const seed = P.hues.length ? P.hues[0] : Math.random() * 360;
  return [0, 1, 2].map((v) => build(P, v, seed, named, name, text));
}
function build(P, v, seed, named, name, text) {
  const sat = P.sat ?? 80, h = P.hues.length ? P.hues : [seed];
  const off = [35, 180, 120][v];
  const h1 = h[0] + (v === 2 && h.length < 2 ? 10 : 0), h2 = h[1] ?? h1 + off, h3 = h[2] ?? (h1 + (h2 - h1) / 2 + (v === 1 ? 200 : 25));
  const s = v === 2 ? Math.min(100, sat + 10) : v === 1 ? sat * 0.85 : sat;
  let c;
  if (named && v === 0) c = { base: named.base, b1: named.b1, b2: named.b2, b3: named.b3, accent: named.accent, light: !!named.light };
  else if (P.mono) c = { base: hsl(h1, 12, 4), b1: hsl(h1, s * 0.6, 22), b2: hsl(h1, s * 0.4, 14), b3: hsl(h1 + 10, s * 0.5, 30), accent: hsl(h[1] ?? h1, Math.max(60, s), 60), light: false };
  else if (P.light) c = { base: hsl(h1, 30, 95), b1: hsl(h1, s, 70), b2: hsl(h2, s * 0.9, 74), b3: hsl(h3, s * 0.8, 78), accent: hsl(h1, Math.min(100, s + 10), 40), light: true };
  else {
    const dl = v === 1 || P.dark ? 3 : 5;
    c = { base: hsl(h1, Math.min(45, s * 0.45), dl), b1: hsl(h1, s, v === 1 ? 34 : 45), b2: hsl(h2, s, v === 1 ? 30 : 46), b3: hsl(h3, s * 0.9, 50),
      accent: hsl(v === 2 ? h2 : h1, Math.min(100, s + 6), 68), light: false };
  }
  const r = Math.round(seed) + v;
  const scene = v === 0 && P.scene ? P.scene : SCENE_POOL[(r + (v === 1 ? 3 : 0)) % SCENE_POOL.length];
  const face = v === 0 && P.face ? P.face : v === 2 && P.face ? P.face : FACE_POOL[r % FACE_POOL.length];
  const styles = ['glass', 'holo', 'soft', 'lux', 'synth'];
  const set = {
    style: pick('styles', P.style, styles[r % styles.length]), effect: 'off', motion: P.motion || 'lively',
    button_fx: P.button || ['glass', 'holo', 'neon'][v], ripple_style: P.ripple || ['waves', 'aurora', 'shock'][v], clock_style: P.clock || ['thin', 'outline', 'bold'][v],
    knob_style: P.knob || ['aurora', 'halo', 'neon'][v], splash_style: P.splash || ['warp', 'plasma', 'hyper'][v], map_style: P.map || 'theme',
    rain_glass: !!P.rain, flow: { on: true, scene: pick('scenes', scene, 'liquid'), amount: P.amount || [75, 60, 90][v] },
    cluster: { look: 'scene', face: pick('faces', face, 'neon') },
  };
  if (P.glass) set.glass = P.glass;
  if (v === 1) set.glass = Object.assign({}, set.glass, { opacity: 34, blur: 44 });
  const d = toDraft({ name: v === 0 ? name : `${name} · ${['', 'Deep', 'Bold'][v]}`, desc: `Made from “${text}”`, colors: c, set });
  if (P.font) d.x.font = P.font;
  return d;
}

// ================================================================ "From a photo": colors (and a wallpaper) out of a picture
function loadImage(file) {
  return new Promise((res, rej) => { const img = new Image(); img.onload = () => res(img); img.onerror = rej; img.src = URL.createObjectURL(file); });
}
function wallpaperOf(img) {   // cropped to the screen's shape, small enough to send
  const W = 1280, H = 750, cv = document.createElement('canvas');
  cv.width = W; cv.height = H;
  const s = Math.max(W / img.width, H / img.height), w = img.width * s, h = img.height * s;
  cv.getContext('2d').drawImage(img, (W - w) / 2, (H - h) / 2, w, h);
  return cv.toDataURL('image/jpeg', 0.8);
}
function paletteOf(img) {   // k-means, 7 groups, on a 72 x 72 copy
  const N = 72, cv = document.createElement('canvas');
  cv.width = N; cv.height = N;
  const x = cv.getContext('2d');
  x.drawImage(img, 0, 0, N, N);
  const px = x.getImageData(0, 0, N, N).data, pts = [];
  for (let i = 0; i < px.length; i += 4) if (px[i + 3] > 200) pts.push([px[i], px[i + 1], px[i + 2]]);
  const K = 7;
  let cen = Array.from({ length: K }, (_, i) => pts[Math.floor((i + 0.5) * pts.length / K)].slice()), n = [];
  for (let it = 0; it < 10; it++) {
    const sum = cen.map(() => [0, 0, 0, 0]);
    for (const p of pts) {
      let b = 0, bd = 1e9;
      cen.forEach((c, k) => { const d = (p[0] - c[0]) ** 2 + (p[1] - c[1]) ** 2 + (p[2] - c[2]) ** 2; if (d < bd) { bd = d; b = k; } });
      const s = sum[b]; s[0] += p[0]; s[1] += p[1]; s[2] += p[2]; s[3]++;
    }
    cen = sum.map((s, k) => (s[3] ? [s[0] / s[3], s[1] / s[3], s[2] / s[3]] : cen[k]));
    n = sum.map((s) => s[3]);
  }
  return cen.map((c, k) => ({ hex: rgbHex(...c), n: n[k] / pts.length, hsl: rgbHsl(...c) })).filter((c) => c.n > 0.01).sort((a, b) => b.n - a.n);
}
function fromPhoto(pal, wall) {
  const score = (c) => c.hsl[1] * Math.sqrt(c.n) * (c.hsl[2] > 12 && c.hsl[2] < 90 ? 1 : 0.2);
  const colorful = pal.slice().sort((a, b) => score(b) - score(a)), picks = [];
  for (const c of colorful) if (picks.every((p) => hueDist(p.hsl[0], c.hsl[0]) > 22)) picks.push(c);
  while (picks.length < 3) picks.push(colorful[picks.length % colorful.length] || pal[0]);
  const dark = pal.slice().sort((a, b) => a.hsl[2] - b.hsl[2])[0];
  const [h1, s1] = picks[0].hsl, [h2, s2] = picks[1].hsl, [h3, s3] = picks[2].hsl;
  const vivid = (s) => Math.max(55, Math.min(100, s * 1.25));
  const base = hsl(dark.hsl[0], Math.min(40, dark.hsl[1] * 0.7), 4);
  const make = (name, desc, c, set) => toDraft({ name, desc, colors: c, set: Object.assign({ effect: 'off' }, set) });
  const a = make('Photo colors', 'Your photo’s colors flowing across the dash', { base, b1: hsl(h1, vivid(s1), 45), b2: hsl(h2, vivid(s2), 45), b3: hsl(h3, vivid(s3), 50), accent: hsl(h1, vivid(s1), 68), light: false },
    { style: 'glass', knob_style: 'aurora', splash_style: 'plasma', flow: { on: true, scene: 'liquid', amount: 75 }, cluster: { face: 'glass' } });
  const b = make('Photo wallpaper', 'Your photo behind the head unit', { base, b1: hsl(h1, vivid(s1), 45), b2: hsl(h2, vivid(s2), 45), b3: hsl(h3, vivid(s3), 50), accent: hsl(h1, vivid(s1), 70), light: false },
    { style: 'glass', knob_style: 'minimal', splash_style: 'warp', flow: { on: false }, glass: { opacity: 26, blur: 36 }, cluster: { look: 'glow', face: 'glass' } });
  b.x = { wall, wallDim: 35 };
  const m = make('Photo moody', 'The photo’s colors, darker, with northern lights', { base: hsl(dark.hsl[0], Math.min(30, dark.hsl[1]), 3), b1: hsl(h2, s2 * 0.8, 28), b2: hsl(h3, s3 * 0.8, 24), b3: hsl(h1, s1 * 0.8, 32), accent: hsl(h2, vivid(s2), 64), light: false },
    { style: 'lux', knob_style: 'nightdrive', splash_style: 'chrome', flow: { on: true, scene: 'aurora', amount: 60 }, cluster: { face: 'luxe' } });
  return [a, b, m];
}

// ================================================================ voice ("Describe it" by talking)
const canTalk = () => !!(APP && APP.listen) || !!(window.SpeechRecognition || window.webkitSpeechRecognition);
window.huVoice = (text) => {
  $$('.mic').forEach((m) => m.classList.remove('on'));
  if (!text) return;
  const t = $('#descIn');
  if (t) { t.value = text; makeFromWords(); }
};
function listen() {
  $$('.mic').forEach((m) => m.classList.add('on'));
  if (APP && APP.listen) { APP.listen(); return; }
  const R = window.SpeechRecognition || window.webkitSpeechRecognition, rec = new R();
  rec.lang = 'en-US'; rec.interimResults = false;
  rec.onresult = (e) => window.huVoice(e.results[0][0].transcript);
  rec.onend = () => $$('.mic').forEach((m) => m.classList.remove('on'));
  rec.start();
}

// ================================================================ small builders
const svgI = (p, s = 22) => `<svg viewBox="0 0 24 24" style="width:${s}px;height:${s}px">${p}</svg>`;
const I = {
  looks: '<rect x="3" y="3" width="7" height="7" rx="2"/><rect x="14" y="3" width="7" height="7" rx="2"/><rect x="3" y="14" width="7" height="7" rx="2"/><rect x="14" y="14" width="7" height="7" rx="2"/>',
  create: '<path d="M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9z"/><path d="M19 15l.8 2.2L22 18l-2.2.8L19 21l-.8-2.2L16 18l2.2-.8z"/>',
  edit: '<path d="M4 6h10M18 6h2M4 12h4M12 12h8M4 18h12"/><circle cx="16" cy="6" r="2"/><circle cx="10" cy="12" r="2"/><circle cx="18" cy="18" r="2"/>',
  auto: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  photo: '<rect x="3" y="5" width="18" height="14" rx="3"/><circle cx="9" cy="10" r="2"/><path d="m21 16-5-5-8 8"/>',
  dice: '<rect x="3" y="3" width="18" height="18" rx="4"/><circle cx="8" cy="8" r="1.2" fill="currentColor"/><circle cx="16" cy="16" r="1.2" fill="currentColor"/><circle cx="12" cy="12" r="1.2" fill="currentColor"/>',
  claude: '<path d="M12 2v6M12 16v6M2 12h6M16 12h6M5 5l4 4M15 15l4 4M19 5l-4 4M9 15l-4 4"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  mic: '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/>',
  send: '<path d="M5 12h14M13 6l6 6-6 6"/>',
  palette: '<circle cx="12" cy="12" r="9"/><circle cx="8" cy="10" r="1.3" fill="currentColor"/><circle cx="12" cy="7.5" r="1.3" fill="currentColor"/><circle cx="16" cy="10" r="1.3" fill="currentColor"/><path d="M12 21a3 3 0 0 1 0-6h2"/>',
  wave: '<path d="M2 12c3-6 5-6 8 0s5 6 8 0 4-4 4-4"/>',
  panel: '<rect x="3" y="4" width="18" height="16" rx="3"/><path d="M3 10h18"/>',
  gauge: '<path d="M4.5 18.5a9 9 0 1 1 15 0"/><path d="M12 13l4-5"/><circle cx="12" cy="13.5" r="1.6"/>',
  knob: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="4"/><path d="M12 3v3"/>',
  map: '<path d="M9 4 3 6v14l6-2 6 2 6-2V4l-6 2z"/><path d="M9 4v14M15 6v14"/>',
  rocket: '<path d="M5 15c-1.5 1.5-2 5-2 5s3.5-.5 5-2M9 15l-3-3c1-4 4-8 9-9 1 0 2 1 2 2-1 5-5 8-9 9z"/><circle cx="14" cy="9" r="1.5"/>',
  code: '<path d="m8 8-5 4 5 4M16 8l5 4-5 4M14 4l-4 16"/>',
  file: '<path d="M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/><path d="M14 3v6h6"/>',
  trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
  share: '<circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="m8.6 13.5 6.8 4M15.4 6.5l-6.8 4"/>',
  play: '<path d="M7 4v16l13-8z"/>',
  car: '<path d="M5 17h14v-5l-2-5H7l-2 5zM3 12h18"/><circle cx="7.5" cy="17" r="1.5"/><circle cx="16.5" cy="17" r="1.5"/>',
  check: '<path d="m5 12 5 5L20 7"/>',
  more: '<circle cx="5" cy="12" r="1.4" fill="currentColor"/><circle cx="12" cy="12" r="1.4" fill="currentColor"/><circle cx="19" cy="12" r="1.4" fill="currentColor"/>',
};
const tog = (on, path) => `<button class="tog ${on ? 'on' : ''}" data-tog="${path}" aria-pressed="${!!on}"></button>`;
const swRow = (title, sub, on, path) => `<div class="sw-row"><div><b>${title}</b>${sub ? `<span>${sub}</span>` : ''}</div>${tog(on, path)}</div>`;
const range = (label, path, val, min, max, step = 1, unit = '') =>
  `<div class="field"><label>${label}<output>${val}${unit}</output></label><input type="range" min="${min}" max="${max}" step="${step}" value="${val}" data-range="${path}" data-unit="${unit}"></div>`;
const acc = (sec, icon, title, sub, body) =>
  `<details class="acc" data-sec="${sec}"><summary><span class="ai">${svgI(I[icon] || '', 20)}</span><div><b>${title}</b><span>${sub}</span></div></summary><div class="body">${body}</div></details>`;
const opts = (path, list, val, cls = '') =>
  `<div class="opts ${cls}">${list.map(([id, n, desc]) => `<button class="opt ${val === id ? 'on' : ''}" data-set="${path}" data-val="${esc(id)}"><b>${esc(n)}</b>${desc ? `<span>${esc(desc)}</span>` : ''}</button>`).join('')}</div>`;
const pills = (path, list, val) =>
  `<div class="pills">${list.map(([id, n]) => `<button class="pill ${val === id ? 'on' : ''}" data-set="${path}" data-val="${esc(id)}">${esc(n)}</button>`).join('')}</div>`;
const colorPick = (label, path, hex) =>
  `<label class="cpick"><div class="sw2" style="background:${hex}"></div><b>${label}</b><span>${hex}</span><input type="color" value="${hex}" data-color="${path}"></label>`;

// ================================================================ tabs
const TABS = [['looks', 'Looks'], ['create', 'Create'], ['edit', 'Edit'], ['auto', 'Auto-switch']];
function renderTabs() {
  $('#tabs').innerHTML = TABS.map(([id, n]) => `<button class="tab ${tab === id ? 'on' : ''}" data-tab="${id}">${svgI(I[id])}${n}</button>`).join('');
}
$('#tabs').addEventListener('click', (e) => { const b = e.target.closest('[data-tab]'); if (b) setTab(b.dataset.tab); });
function setTab(t) {
  tab = t; localStorage.setItem('ts-tab', t);
  renderTabs(); render(); panel.scrollTop = 0;
  if (t === 'looks' || t === 'auto') refresh();
  if (t === 'create') refreshRequests();
}
function openSec(sec) { const el = $(`details.acc[data-sec="${sec}"]`); if (el) { el.open = true; setTimeout(() => el.scrollIntoView({ behavior: 'smooth', block: 'start' }), 50); } }

function render() {
  if (!D) return;
  const open = $$('details.acc[open]').map((x) => x.dataset.sec), top = panel.scrollTop;
  panel.innerHTML = (VIEWS[tab] || VIEWS.looks)();
  if (tab === 'edit') {
    $$('details.acc').forEach((x) => { if (open.includes(x.dataset.sec)) x.open = true; });
    if (!open.length && !render.once) { const f = $('details.acc'); if (f) f.open = true; render.once = true; }
  }
  panel.scrollTop = top;
  $$('input[type=range]', panel).forEach(paintRange);
  renderBar();
  drawKnobPv();
}
const paintRange = (r) => r.style.setProperty('--p', `${((r.value - r.min) / (r.max - r.min)) * 100}%`);

// ---------------------------------------------------------------- where a card comes from
function source(key) {
  const [k, id] = [key.slice(0, 1), key.slice(2)];
  if (k === 'b') { const lk = LK.builtin.find((x) => x.id === id); return lk && { lk, kind: 'builtin', edits: LK.edits[id] }; }
  if (k === 'm') { const lk = LK.mine.find((x) => x.id === id); return lk && { lk, kind: 'mine' }; }
  if (k === 'c') { const lk = CLAUDE[+id]; return lk && { lk, kind: 'claude' }; }
  if (k === 'r') { const d = results[+id]; return d && { draft: d, lk: compile(d), kind: 'new' }; }
  if (k === 'p') { const d = lib[+id] && fromDesign(lib[+id]); return d && { draft: d, lk: compile(d), kind: 'phone' }; }
  return null;
}
const onCar = (id) => LK.current === id;

// ================================================================ the screens
const SUGGEST = ['Neon Tokyo night', 'Subaru rally blue and gold', 'Sunset beach', 'Arctic glass', 'Stealth carbon', 'Forest cabin',
  'Synthwave', 'Rain storm', 'Deep space', 'Cherry blossom', 'Black and gold luxury', 'Toxic green', 'Moonlit sea', 'Fighter jet HUD'];
const VIEWS = {
  looks() {
    const groups = [...new Set(LK.builtin.map((x) => x.group || 'More'))];
    const segs = [['all', 'All'], ['mine', 'Yours'], ['claude', 'From Claude'], ...groups.map((g) => [`g:${g}`, g])];
    const show = (f) => filter === 'all' || filter === f;
    let out = '';
    if (show('mine')) {
      out += `<h3>Yours</h3>${LK.mine.length ? `<div class="grid">${LK.mine.map((x) => card(`m:${x.id}`, x, { on: onCar(x.id), badges: [onCar(x.id) && ['On now', 'live'], x.author === 'Claude' && ['Claude', 'claude']].filter(Boolean) })).join('')}</div>`
        : `<p class="muted pad">${carOk === false ? NO_CAR : 'Looks you make or save land here.'}</p>`}`;
    }
    if (show('claude') && CLAUDE.length) {
      out += `<h3>From Claude</h3><div class="grid">${CLAUDE.map((x, i) => card(`c:${i}`, x, { sub: x.desc, badges: [[x.request ? 'For you' : 'Claude', 'claude']] })).join('')}</div>`;
    }
    for (const g of groups) {
      if (!show(`g:${g}`)) continue;
      const list = LK.builtin.filter((x) => (x.group || 'More') === g);
      out += `<h3>${esc(g)}</h3><div class="grid">${list.map((x) => card(`b:${x.id}`, x, { on: onCar(x.id), edits: LK.edits[x.id],
        badges: [onCar(x.id) && ['On now', 'live'], LK.edits[x.id] && ['Tweaked', '']].filter(Boolean) })).join('')}</div>`;
    }
    if (filter === 'all' && lib.length) {
      out += `<h3>Older designs on this phone</h3><p class="muted pad">Tap one, then Use it to move it to the car as a Look.</p><div class="grid">${lib.map((x, i) => card(`p:${i}`, compile(fromDesign(x)))).join('')}</div>`;
    }
    if (!LK.builtin.length && !LK.mine.length && carOk !== false) out += '<div class="empty"><b>Loading looks…</b></div>';
    if (carOk === false && !LK.builtin.length) out = `<div class="empty"><b>Not connected</b>${NO_CAR}</div>` + out;
    return `<h2>Looks</h2><p class="lead">Tap a look to see it on the car. Everything changes together: colors, the wallpaper across all screens, gauges, knob and startup.</p>
      <div class="seg">${segs.map(([id, n]) => `<button class="${filter === id ? 'on' : ''}" data-act="filter" data-val="${esc(id)}">${esc(n)}</button>`).join('')}</div>${out}`;
  },
  create() {
    const res = results.length ? `<h3>${esc(resultsFrom)}</h3><div class="grid">${results.map((d, i) => card(`r:${i}`, compile(d), { sub: nameOf('scenes', d.set.flow.scene) })).join('')}</div>
      <p class="muted pad">Tap one to see it on the car. Change anything in Edit, then Save.</p>` : '';
    const ph = photo ? `<div class="card photo-box"><img src="${photo.wall}" alt=""><div><b>Colors in your photo</b><div class="pal">${photo.pal.slice(0, 7).map((c) => `<i style="background:${c.hex}"></i>`).join('')}</div></div></div>` : '';
    return `<h2>Make a look</h2><p class="lead">From a few words, a photo, or ask Claude. You get the whole thing: colors, wallpaper, gauges, knob, startup.</p>
      <div class="hero"><h4>${svgI(I.create, 20)} Describe it</h4><p>A mood, a place, colors, a car. You get three takes on it.</p>
        <div class="ask"><textarea id="descIn" rows="1" placeholder="e.g. moody blue rally">${esc(localStorage.getItem('ts-desc') || '')}</textarea>
        ${canTalk() ? `<button class="mic" data-act="listen" aria-label="Talk">${svgI(I.mic)}</button>` : ''}<button class="go" data-act="describe" aria-label="Make it">${svgI(I.send)}</button></div>
        <div class="sugg">${SUGGEST.map((s) => `<button class="chip" data-act="sugg" data-val="${esc(s)}">${esc(s)}</button>`).join('')}</div></div>
      <div class="duo">
        <button class="tile photo" data-act="photo"><span class="ti">${svgI(I.photo)}</span><div><b>From a photo</b><br><span>A sunset, your car, a wallpaper</span></div></button>
        <button class="tile dice" data-act="surprise"><span class="ti">${svgI(I.dice)}</span><div><b>Surprise me</b><br><span>Three random looks</span></div></button>
        <button class="tile claude" data-act="claude"><span class="ti">${svgI(I.claude)}</span><div><b>Ask Claude</b><br><span>Claude designs it for you</span></div></button>
        <button class="tile blank" data-act="fromcar"><span class="ti">${svgI(I.car)}</span><div><b>Start from the car</b><br><span>What’s on now, to tweak</span></div></button>
      </div>${ph}${res}${reqs.length ? `<h3>Your requests to Claude</h3><div class="card">${reqList()}</div>` : ''}`;
  },
  edit() {
    const s = D.set, x = D.x, g = s.glass, f = s.flow, cl = s.cluster, c = D.colors;
    const wmode = x.wall ? 'photo' : f.on !== false ? 'flow' : 'effect';
    const kc = knobColors(D), ownKnob = !!(D.knob && D.knob.colors);
    const palGroups = {};
    PAL.forEach((t) => { (palGroups[t.group || 'More'] = palGroups[t.group || 'More'] || []).push(t); });
    const from = D.mine ? 'One of yours: Save writes over it' : D.src ? `Based on “${esc((LK.builtin.find((b) => b.id === D.src) || {}).name || D.name)}”: Save makes it one of yours` : 'New: Save puts it on the car';
    return `<h2>Edit</h2><div class="card"><input class="txt name" data-text="name" value="${esc(D.name)}" maxlength="60" aria-label="Name">
      <input class="txt" data-text="desc" value="${esc(D.desc)}" maxlength="200" placeholder="A line about it (optional)" style="margin-top:8px"><p class="muted" style="margin:8px 2px 0">${from}</p></div>
    ${acc('colors', 'palette', 'Colors', 'Pick a palette or set each color', `
      <div class="colors">${SLOTS.map(([k, n]) => colorPick(n, `c.${k}`, c[k])).join('')}${colorPick('Text', 'x.textColor', x.textColor || (c.light ? '#0B1220' : '#F5F7FA'))}</div>
      <div class="field"><label>Spin all colors around the color wheel</label><input type="range" class="hue" min="-180" max="180" value="0" data-act-range="hue"></div>
      <div class="pills"><button class="pill" data-act="harm" data-val="analog">Neighbors</button><button class="pill" data-act="harm" data-val="comp">Opposites</button><button class="pill" data-act="harm" data-val="triad">Triad</button><button class="pill" data-act="harm" data-val="mono">One color</button><button class="pill" data-act="harm" data-val="shuffle">Shuffle</button></div>
      ${swRow('Light mode', 'Bright background, dark text', c.light, 'c.light')}
      <h3>Palettes</h3><div class="sugg pgroups">${Object.keys(palGroups).map((gn) => `<button class="chip ${gn === curPalGroup(palGroups) ? 'on' : ''}" data-act="palgroup" data-val="${esc(gn)}">${esc(gn)}</button>`).join('')}</div>
      ${[[curPalGroup(palGroups), palGroups[curPalGroup(palGroups)] || []]].map(([gn, ts]) => `<div class="pgroup"><div class="palrow">${ts.map((t) => `<button class="pal5" data-act="pal" data-val="${t.id}" title="${esc(t.name)}"><i style="background:${t.base}"></i><i style="background:${t.b1}"></i><i style="background:${t.b2}"></i><i style="background:${t.b3}"></i><i style="background:${t.accent}"></i><b>${esc(t.name)}</b></button>`).join('')}</div></div>`).join('')}`)}
    ${acc('wall', 'wave', 'Wallpaper', 'The animation across all screens', `
      <div class="seg">${[['flow', 'All screens'], ['effect', 'Head unit'], ['photo', 'Photo']].map(([id, n]) => `<button class="${wmode === id ? 'on' : ''}" data-act="wmode" data-val="${id}">${n}</button>`).join('')}</div>
      ${wmode === 'flow' ? `<div class="scenes">${T.scenes.map(([id, n, desc]) => `<button class="scene ${f.scene === id ? 'on' : ''}" data-set="set.flow.scene" data-val="${id}"><i style="background:${sceneArt(id, c)}"></i><b>${esc(n)}</b><span>${esc(desc)}</span></button>`).join('')}</div>
        ${range('Strength', 'set.flow.amount', f.amount ?? 75, 10, 100, 5, '%')}
        ${swRow('Faster as you drive', 'The wallpaper speeds up with the car', f.react !== false, 'set.flow.react')}
        <div class="sw-row"><div><b>Ripples</b><span>Taps, knob presses and new songs send a ripple through it</span></div>${pills('set.flow.pulses', [['on', 'On'], ['off', 'Off']], f.pulses || 'on')}</div>` : ''}
      ${wmode === 'effect' ? `${opts('set.effect', T.effects, s.effect)}<h3>Motion</h3>${pills('set.motion', [['calm', 'Calm'], ['lively', 'Lively'], ['wild', 'Wild']], s.motion)}` : ''}
      ${wmode === 'photo' ? `${x.wall ? `<div class="wallpv" style="background-image:url('${x.wall}')"></div>${range('Darken', 'x.wallDim', x.wallDim ?? 35, 0, 85, 1, '%')}` : ''}
        <div class="btns"><button class="btn" data-act="wall">${svgI(I.photo, 18)}${x.wall ? 'Change photo' : 'Pick a photo'}</button></div>` : ''}
      <h3>Rain on the glass</h3>${swRow('Raindrops over the screen', 'Works with any wallpaper', !!s.rain_glass, 'set.rain_glass')}
      ${s.rain_glass ? pills('set.rain_amount', [['light', 'Light'], ['steady', 'Steady'], ['heavy', 'Heavy']], s.rain_amount) : ''}`)}
    ${acc('panels', 'panel', 'Panels', 'Style, glass, corners, buttons, font', `
      <div class="opts wide">${T.styles.map(([id, n, desc]) => `<button class="opt ${s.style === id ? 'on' : ''}" data-set="set.style" data-val="${id}"><b>${esc(n)}</b><span>${esc(desc)}</span></button>`).join('')}</div>
      <h3>Glass</h3>${range('Strength', 'set.glass.opacity', g.opacity, 0, 100, 1, '%')}${range('Blur', 'set.glass.blur', g.blur, 0, 60, 1, 'px')}
      ${range('Depth', 'set.glass.depth', g.depth, 0, 100, 1, '%')}${range('Shine', 'set.glass.shine', g.shine, 0, 100, 1, '%')}
      ${pills('set.glass.tint', [['theme', 'Tinted'], ['clear', 'Clear'], ['smoke', 'Smoke']], g.tint)}
      ${swRow('Shiny edges', '', g.edge !== false, 'set.glass.edge')}${swRow('Tilt when touched', '', g.tilt !== false, 'set.glass.tilt')}
      ${swRow('Text shadow', 'Easier to read over bright wallpaper', g.textshadow !== false, 'set.glass.textshadow')}${swRow('Glow', 'Soft light around lit-up things', s.glow !== false, 'set.glow')}
      <h3>Shape</h3>${range('Corner roundness', 'x.radius', x.radius ?? 1.4, 0, 3, 0.1, '')}
      ${range('Border', 'x.border', x.border ?? 0, 0, 4, 1, 'px')}${x.border ? `<div class="colors c1">${colorPick('Border color', 'x.borderColor', x.borderColor || '#FFFFFF')}</div>` : ''}
      ${range('Accent glow around panels', 'x.glow', x.glow ?? 0, 0, 60, 1, 'px')}
      <h3>Buttons</h3>${pills('set.button_fx', T.buttons, s.button_fx)}
      <h3>Clock</h3>${pills('set.clock_style', T.clocks, s.clock_style)}
      <h3>Changing screens</h3>${pills('set.transition', [['depth', 'Depth'], ['slide', 'Slide'], ['flip', 'Flip'], ['fade', 'Fade'], ['none', 'None']], s.transition)}
      <h3>Font</h3><div class="opts">${FONTS.map(([fv, n]) => `<button class="opt ${(x.font || '') === fv ? 'on' : ''}" data-set="x.font" data-val="${esc(fv)}" style="font-family:${fv === 'StudioFont' || !fv ? 'inherit' : esc(fv)}"><b>${esc(n)}</b><span>Aa 12:45</span></button>`).join('')}</div>
      <div class="btns"><button class="btn ghost" data-act="fontup">${svgI(I.file, 18)}${x.fontData ? 'Replace my font' : 'Upload a font'}</button></div>
      ${range('Heading weight', 'x.weight', x.weight || 400, 100, 900, 100, '')}`)}
    ${acc('gauges', 'gauge', 'Gauges', 'Cluster and Gauges screen dials', `
      <div class="opts wide">${T.faces.map(([id, n, desc]) => `<button class="opt ${cl.face === id ? 'on' : ''}" data-set="set.cluster.face" data-val="${id}"><b>${esc(n)}</b>${desc ? `<span>${esc(desc)}</span>` : ''}</button>`).join('')}</div>
      ${T.gopts.map(([k, n, list]) => `<h3>${esc(n)}</h3>${pills(`set.cluster.${k}`, list, cl[k] || 'face')}`).join('')}
      ${range('Glow', 'set.cluster.glow', cl.glow ?? 60, 0, 100, 5, '%')}
      <h3>Behind the cluster gauges</h3>${opts('set.cluster.look', T.clLooks, cl.look)}`)}
    ${acc('knob', 'knob', 'Knob', 'Face, colors, ripple', `<div class="knob-big"><div class="k" id="knobBig"></div></div>
      <div class="btns"><button class="btn" data-act="kturn">Try a turn</button></div>
      <h3>Face</h3><div class="faces">${KFACES.map((k) => `<button class="face ${k.id === s.knob_style ? 'on' : ''}" data-set="set.knob_style" data-val="${k.id}"><div class="fc">${knobSvg(k.id)}</div>${esc(k.name)}</button>`).join('')}</div>
      <h3>Colors</h3>${swRow('Same as the screen', 'Turn off to give the knob its own colors', !ownKnob, 'kmatch')}
      ${ownKnob ? `<div class="colors">${colorPick('Background', 'k.base', kc.base)}${colorPick('Accent', 'k.accent', kc.accent)}${colorPick('Text', 'k.text', kc.text)}${colorPick('Glow 1', 'k.b1', kc.b1)}${colorPick('Glow 2', 'k.b2', kc.b2)}${colorPick('Glow 3', 'k.b3', kc.b3)}</div>` : ''}
      <h3>Ripple when you turn it</h3>${pills('set.ripple_style', T.ripples, s.ripple_style)}`)}
    ${acc('map', 'map', 'Map', 'How Google Maps is painted', `${opts('set.map_style', T.maps, s.map_style)}
      ${range('Strength', 'set.map_fx_amt', s.map_fx_amt ?? 100, 0, 100, 5, '%')}
      <h3>On the cluster</h3>${pills('set.cluster.map_style', [['same', 'Same as head unit'], ...T.maps.map(([id, n]) => [id, n])], cl.map_style || 'same')}`)}
    ${acc('startup', 'rocket', 'Startup', 'The animation when the car turns on', `${opts('set.splash_style', T.splashes, s.splash_style, 'wide')}
      <div class="btns"><button class="btn" data-act="splashpv">${svgI(I.play, 18)}Preview</button><button class="btn" data-act="splashcar">${svgI(I.car, 18)}Play on car</button></div>
      <p class="muted">Play on car shows the look that’s saved on the car.</p>`)}
    ${acc('css', 'code', 'Advanced', 'Your own CSS, file, delete', `<textarea class="txt code" data-text="custom" spellcheck="false" placeholder=".glass { border-radius: 0 }">${esc(D.custom || '')}</textarea>
      <div class="btns"><button class="btn" data-act="share">${svgI(I.share, 18)}Share file</button><button class="btn ghost" data-act="import">${svgI(I.file, 18)}Import file</button></div>
      ${D.mine ? `<div class="btns"><button class="btn ghost danger" data-act="del">${svgI(I.trash, 18)}Delete from the car</button></div>` : ''}`)}`;
  },
  auto() {
    const sc = LK.schedule;
    if (!sc) return `<h2>Auto-switch</h2><div class="empty"><b>${carOk === false ? 'Not connected' : 'Loading…'}</b>${carOk === false ? NO_CAR : ''}</div>`;
    const hm = (m) => `${String(Math.floor(m / 60)).padStart(2, '0')}:${String(m % 60).padStart(2, '0')}`;
    const lookOpts = (cur) => {
      const o = (x) => `<option value="${esc(x.id)}" ${x.id === cur ? 'selected' : ''}>${esc(x.name)}</option>`;
      const groups = [...new Set(LK.builtin.map((x) => x.group || 'More'))];
      const known = LK.mine.some((x) => x.id === cur) || LK.builtin.some((x) => x.id === cur);
      return `${known ? '' : `<option value="${esc(cur || '')}" selected>${cur ? 'A look that’s gone' : 'Pick a look'}</option>`}
        ${LK.mine.length ? `<optgroup label="Yours">${LK.mine.map(o).join('')}</optgroup>` : ''}
        ${groups.map((gn) => `<optgroup label="${esc(gn)}">${LK.builtin.filter((x) => (x.group || 'More') === gn).map(o).join('')}</optgroup>`).join('')}`;
    };
    const rules = sc.rules.map((r, i) => {
      const w = WHEN.find((x) => x[0] === r.when) || WHEN[0], now = sc.on && LK.schedule_now === r.look && nowRule() === i;
      return `<div class="rule ${now ? 'now' : ''}"><div class="when"><i>${w[2]}</i><select data-rule="${i}" data-f="when">${WHEN.map((x) => `<option value="${x[0]}" ${x[0] === r.when ? 'selected' : ''}>${x[1]}</option>`).join('')}</select>${now ? '<span class="now-tag">NOW</span>' : ''}</div>
        <button class="ib" data-act="rdel" data-val="${i}" aria-label="Remove">${svgI(I.trash, 18)}</button>
        ${r.when === 'time' ? `<div class="look"><input type="time" value="${hm(r.from || 0)}" data-rule="${i}" data-f="from"> to <input type="time" value="${hm(r.to || 0)}" data-rule="${i}" data-f="to"></div>` : ''}
        <div class="look"><select data-rule="${i}" data-f="look">${lookOpts(r.look)}</select></div></div>`;
    }).join('');
    const nowName = (LK.mine.concat(LK.builtin).find((x) => x.id === LK.schedule_now) || {}).name;
    return `<h2>Auto-switch</h2><p class="lead">Let the dash change its look by itself: with the weather, day and night, or the time. The first rule that fits wins; a look you pick by hand stays until the next rule starts.</p>
      <div class="card">${swRow('Switch looks automatically', sc.on ? `Now: ${esc(nowName || 'no rule fits right now')}` : 'Off', sc.on, 'son')}</div>
      <div class="presets"><button class="preset" data-act="preset" data-val="weather"><b>🌦️ Follow the weather</b><span>Rain, storms, snow, fog, clear and cloudy skies, and night each get a look</span></button>
        <div class="duo"><button class="preset" data-act="preset" data-val="daynight"><b>🌓 Day + night</b><span>One look by day, one at night</span></button>
        <button class="preset" data-act="preset" data-val="commute"><b>🕒 Commute</b><span>Mornings, evenings, night</span></button></div></div>
      <h3>Rules</h3>${rules || '<p class="muted pad">No rules yet. Tap a preset above or add one.</p>'}
      <div class="btns"><button class="btn" data-act="radd">${svgI(I.plus, 18)}Add a rule</button></div>`;
  },
};
const WHEN = [['day', 'Daytime', '☀️'], ['night', 'Night', '🌙'], ['rain', 'Rain', '🌧️'], ['snow', 'Snow', '❄️'], ['storm', 'Thunderstorm', '⛈️'],
  ['fog', 'Fog', '🌫️'], ['clear', 'Clear sky', '🌤️'], ['cloudy', 'Cloudy', '☁️'], ['time', 'Between times', '🕒']];
function nowRule() { const sc = LK.schedule; return sc ? sc.rules.findIndex((r) => r.look === LK.schedule_now) : -1; }
function reqList() {
  return reqs.slice().reverse().map((r) => `<div class="req"><span class="st ${r.status === 'done' ? 'done' : ''}">${r.status === 'done' ? 'Ready' : 'Waiting'}</span><div class="grow">${esc(r.text)}<div class="muted">${r.status === 'done' ? 'In Looks › From Claude · ' : ''}${new Date(r.at * 1000).toLocaleDateString()}</div></div></div>`).join('');
}

// ---------------------------------------------------------------- the bar over the tabs: what's selected, and what to do with it
function renderBar() {
  const bar = $('#abar');
  const src = (tab === 'looks' || tab === 'create') && sel ? source(sel) : null;
  if (!src) { bar.classList.add('hidden'); return; }
  const lk = src.lk, isOn = (src.kind === 'builtin' || src.kind === 'mine') && onCar(lk.id);
  bar.innerHTML = `<div class="grow"><b>${esc(lk.name)}</b><span>${esc(lk.desc || (isOn ? 'On the car now' : 'Showing on the car'))}</span></div>
    ${src.kind === 'mine' ? `<button class="ib" data-bar="more" aria-label="More">${svgI(I.more)}</button>` : ''}
    <button class="btn ghost" data-bar="edit">Edit</button><button class="btn primary" data-bar="use" ${isOn ? 'disabled' : ''}>${isOn ? 'On now' : 'Use it'}</button>`;
  bar.classList.remove('hidden');
}
$('#abar').addEventListener('click', async (e) => {
  const b = e.target.closest('[data-bar]'); if (!b) return;
  const src = source(sel); if (!src) return;
  const a = b.dataset.bar;
  if (a === 'edit') { setTab('edit'); return; }
  if (a === 'use') return useSel(src);
  if (a === 'more') return mineSheet(src.lk);
});
async function useSel(src) {
  if (dirty && (src.kind === 'builtin' || src.kind === 'mine')) return save();   // tweaked: keep the tweaks
  let r;
  if (src.kind === 'builtin' || src.kind === 'mine') r = await cmd('look_use', { id: src.lk.id });
  else r = await api('POST', '/look', compile(D));   // new ones are saved as yours on the way
  if (!r.ok) { toast(r.status ? r.text || 'The car said no' : NO_CAR); return; }
  previewing = false; clearInterval(pvBeat);
  if (src.kind === 'builtin' || src.kind === 'mine') api('POST', '/look/preview', {});
  markDirty(false);
  toast(`“${src.lk.name}” is on the car`);
  await refresh();
  if (src.kind !== 'builtin' && src.kind !== 'mine') { const m = LK.mine.find((x) => x.id === LK.current); if (m) { sel = `m:${m.id}`; D.mine = true; D.src = m.id; saveDraft(); } }
  render();
}
function mineSheet(lk) {
  sheet(`<h2 style="margin-top:0">${esc(lk.name)}</h2><div class="field"><label>Name</label><input class="txt" id="renIn" value="${esc(lk.name)}" maxlength="60"></div>
    <div class="btns"><button class="btn primary" data-sheet="rename">Rename</button></div>
    <div class="btns"><button class="btn ghost danger" data-sheet="del">${svgI(I.trash, 18)}Delete</button></div>`);
  $('#sheet').onclick = async (e) => {
    const b = e.target.closest('[data-sheet]'); if (!b) return;
    if (b.dataset.sheet === 'rename') {
      const name = $('#renIn').value.trim(); if (!name) return;
      const r = await cmd('look_rename', { id: lk.id, name }); closeSheet(); toast(r.ok ? 'Renamed' : NO_CAR);
      if (D.src === lk.id) { D.name = name; $('#dname').value = name; saveDraft(); }
    } else {
      if (!confirm(`Delete “${lk.name}” from the car?`)) return;
      const r = await cmd('look_delete', { id: lk.id }); closeSheet(); toast(r.ok ? 'Deleted' : NO_CAR);
      if (D.src === lk.id) { D.mine = false; D.src = ''; saveDraft(); }
      sel = '';
    }
    await refresh(); render();
  };
}

// ================================================================ actions
function pickCard(key) {
  const src = source(key); if (!src) return;
  sel = key;
  if (src.draft) setDraft(clone(src.draft), { dirty: true });
  else setDraft(toDraft(src.lk, src.edits));
  if (src.kind === 'claude') D.author = 'Claude';
  render();
}
function shiftHue(deg, base) {
  const c = { light: base.light };
  for (const [k] of SLOTS) { const [h, s, l] = hexHsl(base[k]); c[k] = hsl(h + deg, s, l); }
  return c;
}
function harmony(kind) {
  const c = D.colors, [h, s] = hexHsl(c.accent), sat = Math.max(55, s), dl = c.light ? 72 : 45;
  const hs = { analog: [h - 30, h + 30, h + 60], comp: [h, h + 180, h + 200], triad: [h, h + 120, h + 240], mono: [h, h, h],
    shuffle: [Math.random() * 360, Math.random() * 360, Math.random() * 360] }[kind];
  edit((d) => {
    const nc = { base: c.base, b1: hsl(hs[0], sat, kind === 'mono' ? dl - 12 : dl), b2: hsl(hs[1], sat, kind === 'mono' ? dl - 22 : dl), b3: hsl(hs[2], sat * 0.9, dl + 5), accent: c.accent, light: c.light };
    if (kind === 'shuffle') { nc.accent = hsl(hs[0], 90, c.light ? 40 : 68); nc.base = c.light ? hsl(hs[0], 30, 95) : hsl(hs[0], 35, 4); }
    d.colors = nc;
  }, { render: true });
}
function showResults(list, from) {
  results = list; resultsFrom = from;
  pickCard('r:0');
  setTimeout(() => { const r = $('[data-pick="r:0"]'); if (r) r.scrollIntoView({ behavior: 'smooth', block: 'center' }); }, 60);
}
function makeFromWords() {
  const t = $('#descIn'), text = (t && t.value.trim()) || '';
  if (!text) { toast('Type or say what you want first'); return; }
  localStorage.setItem('ts-desc', text);
  showResults(describe(text), `“${text}”`);
}
function surprise() {
  const words = [0, 1, 2].map(() => SUGGEST[Math.floor(Math.random() * SUGGEST.length)]);
  showResults(words.map((w, i) => { const r = describe(w)[i]; r.name = titleCase(w); return r; }), 'Surprise');
}
async function onPhoto(file) {
  try {
    toast('Reading the colors…');
    const img = await loadImage(file), pal = paletteOf(img), wall = wallpaperOf(img);
    photo = { pal, wall };
    if (tab !== 'create') setTab('create');
    showResults(fromPhoto(pal, wall), 'From your photo');
  } catch (e) { toast('Couldn’t read that picture'); }
}
function claudeSheet() {
  sheet(`<h2 style="margin-top:0">Ask Claude</h2><p class="lead">Describe the look you want. Claude designs all of it (colors, wallpaper, gauges, knob, startup) and it shows up in Looks › From Claude.</p>
    <textarea class="txt" id="claudeIn" rows="4" placeholder="e.g. Match my car: Azurite blue paint, black interior, a little gold. Calm at night."></textarea>
    <button class="btn primary wide" style="margin-top:14px" id="claudeSend">${svgI(I.send, 18)}Send to Claude</button>
    <p class="muted">Claude works on it the next time Claude Code is open on the head unit (Settings › Tools › Start Claude Code). Tell it “do my design requests”.</p>`);
  $('#claudeSend').addEventListener('click', async () => {
    const text = $('#claudeIn').value.trim();
    if (!text) { toast('Say what you want first'); return; }
    const r = await apiJson('POST', '/design/request', { text, part: 'both' });
    if (!r.ok) { toast(r.status ? r.text : NO_CAR); return; }
    reqs = r.json.requests || []; closeSheet(); toast('Sent. Claude will design it.'); if (tab === 'create') render();
  });
}
async function saveSchedule(fn) {
  const sc = clone(LK.schedule || { on: false, rules: [] });
  fn(sc);
  LK.schedule = sc;
  render();
  const r = await cmd('settings', { patch: { look_schedule: sc } });
  if (!r.ok) toast(r.status ? r.text : NO_CAR);
  setTimeout(refresh, 800);
}
// "Follow the weather" and friends: the best built-in Look for each kind of weather, by name, then by wallpaper
// the built-in Looks made for it first (web/looks.json ids), else one whose name fits, else one with a fitting wallpaper
function findLook(ids, re, scenes, used) {
  const all = LK.builtin.concat(LK.mine), sceneOf = (x) => ((x.set || {}).flow || {}).scene, ok = (x) => !used.has(x.id);
  const hit = ids.map((id) => all.find((x) => x.id === id && ok(x))).find(Boolean) || all.find((x) => ok(x) && re.test(x.name))
    || all.find((x) => ok(x) && scenes.includes(sceneOf(x))) || all.find(ok) || all[0];
  if (hit) used.add(hit.id);
  return hit ? hit.id : '';
}
const NIGHT = [['northern-lights', 'moonlit-sea', 'midnight-run'], /night|midnight|moon|star/i, ['aurora', 'ocean', 'warp']];
const DAY = [['sunny-day', 'cloud'], /sun|day|bright|cloud/i, ['ocean', 'liquid']];
const PRESETS = {
  weather: () => {
    const u = new Set();
    return [['storm', ['thunderstorm'], /storm|thunder/i, ['rain']], ['rain', ['rainy-window'], /rain|wet/i, ['rain']],
      ['snow', ['snowfall', 'arctic'], /snow|arctic|ice|frost/i, ['aurora']], ['fog', ['fog'], /fog|mist|haze/i, ['plasma']],
      ['night', ...NIGHT], ['clear', ...DAY], ['cloudy', ['cloud', 'plasma'], /cloud|grey|gray|calm/i, ['plasma', 'liquid']]]
      .map(([when, ids, re, sc]) => ({ when, look: findLook(ids, re, sc, u) }));
  },
  daynight: () => { const u = new Set(); return [{ when: 'night', look: findLook(...NIGHT, u) }, { when: 'day', look: findLook(...DAY, u) }]; },
  commute: () => {
    const u = new Set();
    return [{ when: 'time', from: 360, to: 600, look: findLook(['sunny-day', 'cloud'], /sun|morning|dawn/i, ['ocean'], u) },
      { when: 'time', from: 960, to: 1140, look: findLook(['sunset-drive', 'desert-dunes'], /sunset|dusk|evening/i, ['aurora'], u) },
      { when: 'night', look: findLook(...NIGHT, u) }];
  },
};

function asVal(el) {   // data-val is a string: true/false/numbers back to what they were
  const v = el.dataset.val;
  return v === 'true' ? true : v === 'false' ? false : v;
}
panel.addEventListener('click', async (e) => {
  const pk = e.target.closest('[data-pick]');
  if (pk) return pickCard(pk.dataset.pick);
  const set = e.target.closest('[data-set]');
  if (set) {
    const path = set.dataset.set, v = asVal(set);
    edit(() => {
      setP(path, path === 'x.font' && !v ? undefined : v);
      if (path === 'set.style') applyStyleBundle(v);
    }, { render: true });
    return;
  }
  const t = e.target.closest('[data-tog]');
  if (t) {
    const p = t.dataset.tog;
    if (p === 'son') return saveSchedule((sc) => { sc.on = !sc.on; if (sc.on && !sc.rules.length) sc.rules = PRESETS.weather(); });
    if (p === 'kmatch') return edit((d) => { if (d.knob && d.knob.colors) d.knob = null; else d.knob = { colors: knobColors(d) }; }, { render: true });
    if (p === 'c.light') return edit((d) => { const c = d.colors; c.light = !c.light; const [h] = hexHsl(c.base); if (c.light && lum(c.base) < 0.4) c.base = hsl(h, 30, 95); else if (!c.light && lum(c.base) > 0.4) c.base = hsl(h, 35, 5); }, { render: true });
    const cur = getP(p);
    edit(() => setP(p, cur === false ? true : cur === true ? false : !(cur ?? true)), { render: true });
    return;
  }
  const b = e.target.closest('[data-act]');
  if (!b) return;
  const v = b.dataset.val;
  switch (b.dataset.act) {
    case 'filter': filter = v; render(); return;
    case 'describe': return makeFromWords();
    case 'sugg': $('#descIn').value = v; return makeFromWords();
    case 'listen': return listen();
    case 'photo': return $('#photoIn').click();
    case 'surprise': return surprise();
    case 'claude': return claudeSheet();
    case 'fromcar': if (LK.current) { sel = ''; const src = source(`${LK.mine.some((x) => x.id === LK.current) ? 'm' : 'b'}:${LK.current}`); if (src) { setDraft(toDraft(src.lk, src.edits)); setTab('edit'); } } else toast(NO_CAR); return;
    case 'pal': { const p = PAL.find((x) => x.id === v); if (p) edit((d) => { d.colors = { base: p.base, b1: p.b1, b2: p.b2, b3: p.b3, accent: p.accent, light: !!p.light }; }, { render: true }); return; }
    case 'harm': return harmony(v);
    case 'palgroup': palGroup = v; render(); return;
    case 'wmode':
      edit((d) => {
        if (v !== 'photo') delete d.x.wall;
        d.set.flow.on = v === 'flow';
        if (v === 'effect' && d.set.effect === 'off') d.set.effect = 'blobs';
        if (v !== 'effect') d.set.effect = 'off';
      }, { render: true });
      if (v === 'photo' && !D.x.wall) $('#wallIn').click();
      return;
    case 'wall': return $('#wallIn').click();
    case 'fontup': return $('#fontIn').click();
    case 'kturn':
      if (ready) frame.contentWindow.postMessage({ type: 'knob', act: 'turn', vol: 30 + Math.random() * 50 }, '*');
      { const k = $('#knobBig'); k.classList.remove('spin'); void k.offsetWidth; k.classList.add('spin'); }
      return;
    case 'splashpv': return goScreen('startup');
    case 'splashcar': { const r = await cmd('splash_play'); toast(r.ok ? 'Playing on the car' : NO_CAR); return; }
    case 'share': return shareLook();
    case 'import': return $('#fileIn').click();
    case 'del': {
      if (!confirm(`Delete “${D.name}” from the car?`)) return;
      const r = await cmd('look_delete', { id: D.src }); toast(r.ok ? 'Deleted' : NO_CAR);
      if (r.ok) { D.mine = false; D.src = ''; markDirty(); saveDraft(); await refresh(); render(); }
      return;
    }
    case 'radd': return saveSchedule((sc) => { sc.rules.push({ when: 'night', look: LK.current || (LK.builtin[0] || {}).id || '' }); });
    case 'rdel': return saveSchedule((sc) => { sc.rules.splice(+v, 1); });
    case 'preset': return saveSchedule((sc) => { sc.rules = PRESETS[v](); sc.on = true; });
    default:
  }
});
// picking a panel style also brings that style's own button/clock/ripple choices (STYLES[i][3] on the head unit page)
function applyStyleBundle(id) {
  if (!ready) return;
  try {
    const st = (frame.contentWindow.eval('STYLES') || []).find((x) => x[0] === id), b = st && st[3];
    if (!b || typeof b !== 'object') return;
    for (const k of ['button_fx', 'ripple_style', 'clock_style', 'rain_over']) if (b[k] !== undefined) D.set[k] = b[k];
    if (b.glass) D.set.glass = Object.assign({}, D.set.glass, b.glass);
  } catch (e) { /* the page's style list has another shape: just the style then */ }
}
let hueBase = null;
panel.addEventListener('input', (e) => {
  const el = e.target;
  if (el.dataset.range) {
    const v = +el.value; paintRange(el);
    const o = el.parentElement.querySelector('output'); if (o) o.textContent = `${v}${el.dataset.unit || ''}`;
    edit(() => setP(el.dataset.range, v), { drag: true });
  } else if (el.dataset.actRange === 'hue') {
    if (!hueBase) { hist.push(JSON.stringify(D)); hueBase = clone(D.colors); }
    edit((d) => { d.colors = shiftHue(+el.value, hueBase); }, { hist: false });
  } else if (el.dataset.color) {
    edit(() => setP(el.dataset.color, el.value.toUpperCase()), { drag: true });
    const cp = el.closest('.cpick'); cp.querySelector('.sw2').style.background = el.value; cp.querySelector('span').textContent = el.value.toUpperCase();
  } else if (el.dataset.text) {
    edit((d) => { d[el.dataset.text] = el.dataset.text === 'name' ? el.value.slice(0, 60) : el.value; }, { drag: true });
    if (el.dataset.text === 'name') $('#dname').value = el.value;
  } else if (el.id === 'descIn') {
    el.style.height = 'auto'; el.style.height = `${Math.min(120, el.scrollHeight)}px`;
  }
});
panel.addEventListener('change', (e) => {
  const el = e.target;
  dragging = false;
  if (el.dataset.actRange === 'hue') { hueBase = null; render(); }
  if (el.dataset.color) render();
  if (el.dataset.rule) {
    const i = +el.dataset.rule, f = el.dataset.f;
    saveSchedule((sc) => {
      const r = sc.rules[i]; if (!r) return;
      if (f === 'from' || f === 'to') { const [h, m] = el.value.split(':').map(Number); r[f] = h * 60 + m; }
      else { r[f] = el.value; if (f === 'when' && el.value === 'time') { r.from = r.from ?? 420; r.to = r.to ?? 1140; } }
    });
  }
});
panel.addEventListener('keydown', (e) => { if (e.target.id === 'descIn' && e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); makeFromWords(); } });

// ---------------------------------------------------------------- files
$('#photoIn').addEventListener('change', (e) => { const f = e.target.files[0]; e.target.value = ''; if (f) onPhoto(f); });
$('#wallIn').addEventListener('change', async (e) => {
  const f = e.target.files[0]; e.target.value = ''; if (!f) return;
  try {
    const w = wallpaperOf(await loadImage(f));
    edit((d) => { d.x.wall = w; d.x.wallDim = d.x.wallDim ?? 35; d.set.flow.on = false; d.set.effect = 'off'; }, { render: true });
  } catch (er) { toast('Couldn’t read that picture'); }
});
$('#fontIn').addEventListener('change', (e) => {
  const f = e.target.files[0]; e.target.value = ''; if (!f) return;
  if (f.size > 1.5e6) { toast('That font is too big (over 1.5 MB)'); return; }
  const r = new FileReader();
  r.onload = () => edit((d) => { d.x.fontData = r.result; d.x.font = 'StudioFont'; }, { render: true });
  r.readAsDataURL(f);
});
$('#fileIn').addEventListener('change', (e) => {
  const f = e.target.files[0]; e.target.value = ''; if (!f) return;
  const r = new FileReader();
  r.onload = () => window.studioImport(r.result);
  r.readAsText(f);
});
window.studioImport = (text) => {   // also called by the phone app when a look file is opened with it
  try {
    const f = JSON.parse(text);
    if (!f || typeof f !== 'object' || !(f.format === 'headunit-design' || f.colors || f.set)) throw new Error('format');
    const d = fromAny(f); d.mine = false; d.src = '';
    sel = ''; setDraft(d, { dirty: true }); setTab('edit'); toast(`Opened “${d.name}”. Save puts it on the car.`);
  } catch (e) { toast('That isn’t a head unit look file'); }
};
function shareLook() {
  const lk = compile(D); delete lk.id;
  const json = JSON.stringify(lk, null, 1), name = `${D.name.replace(/[^\w-]+/g, '_')}.headunit.json`;
  if (APP && APP.share) { APP.share(name, json); return; }
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([json], { type: 'application/json' })); a.download = name; a.click();
}

// ---------------------------------------------------------------- save
async function save() {
  const slugOf = (n) => `u-${String(n).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 40) || 'look'}`;
  if (!D.mine) {
    const clash = LK.mine.find((x) => x.id === slugOf(D.name));
    if (clash && !confirm(`You already have a look called “${clash.name}”. Replace it?`)) return;
  }
  const btn = $('#saveBtn');
  btn.disabled = true; btn.innerHTML = '<span class="spin-dot"></span>';
  const r = await api('POST', '/look', compile(D));
  btn.disabled = false; btn.textContent = 'Save';
  if (!r.ok) { toast(r.status ? r.text : NO_CAR); return; }
  previewing = false; clearInterval(pvBeat);   // saving puts it on the car for real and ends the preview
  markDirty(false); toast(r.text || 'Saved');
  await refresh();
  const m = LK.mine.find((x) => x.id === LK.current);
  if (m) { D.mine = true; D.src = m.id; sel = `m:${m.id}`; saveDraft(); }
  render();
}

// ---------------------------------------------------------------- refreshing from the car
async function refresh() {
  const r = await apiJson('GET', '/looks');
  setCarOk(r.ok);
  if (r.ok && r.json) {
    const j = r.json;
    LK = { builtin: j.builtin || [], mine: j.mine || [], current: j.current, edits: j.edits || {}, look: j.look, schedule: j.schedule || null, schedule_now: j.schedule_now };
    if (!LK.schedule) {   // a head unit without the schedule in /looks yet
      const o = await apiJson('GET', '/designs/full');
      if (o.ok && o.json && o.json.settings) { LK.schedule = o.json.settings.look_schedule || { on: false, rules: [] }; LK.schedule_now = o.json.schedule_now; }
    }
  }
  if (tab === 'looks' || tab === 'auto' || (tab === 'edit' && !D)) render();
  return r.ok;
}
async function refreshRequests() {
  const r = await apiJson('GET', '/design/request');
  if (r.ok && r.json) { const had = JSON.stringify(reqs); reqs = r.json.requests || []; if (tab === 'create' && JSON.stringify(reqs) !== had) render(); }
}

// ---------------------------------------------------------------- sheet + toast
function sheet(html) { $('#sheet').innerHTML = html; $('#sheet').onclick = null; $('#sheet').classList.remove('hidden'); $('#sheetBg').classList.remove('hidden'); }
function closeSheet() { $('#sheet').classList.add('hidden'); $('#sheetBg').classList.add('hidden'); }
$('#sheetBg').addEventListener('click', closeSheet);
let toastT;
function toast(t) { const el = $('#toast'); el.textContent = t; el.classList.add('show'); clearTimeout(toastT); toastT = setTimeout(() => el.classList.remove('show'), 2800); }
window.studioSent = (m) => toast(m);   // older app builds call this

// ---------------------------------------------------------------- header
$('#dname').addEventListener('input', (e) => edit((d) => { d.name = e.target.value.slice(0, 60) || 'Untitled'; }, { drag: true }));
$('#dname').addEventListener('change', () => { dragging = false; if (tab === 'edit') render(); });
$('#undoBtn').addEventListener('click', undo);
$('#redoBtn').addEventListener('click', redo);
$('#liveBtn').addEventListener('click', () => setLive(!live));
$('#saveBtn').addEventListener('click', save);

// ================================================================ start
(async function start() {
  const load = (f) => fetch(`/static/${f}`).then((r) => (r.ok ? r.json() : [])).catch(() => []);
  [PAL, KFACES, CLAUDE] = await Promise.all([load('themes.json'), load('knob_faces.json'), load('gallery.json')]);
  if (!Array.isArray(CLAUDE)) CLAUDE = [];
  try { lib = JSON.parse((APP && APP.loadLib ? APP.loadLib() : localStorage.getItem('hu-designs')) || '[]'); } catch (e) { lib = []; }
  if (!Array.isArray(lib)) lib = [];
  lib = lib.filter((x) => x && x.format === 'headunit-design');
  $('#liveBtn').setAttribute('aria-pressed', String(live));
  setCarOk(true);
  renderTabs();
  try { D = JSON.parse(localStorage.getItem('ts-draft') || 'null'); } catch (e) { D = null; }
  await refresh();
  if (!D || !D.set || !D.colors) {   // first time: start from what's on the car
    const cur = LK.mine.find((x) => x.id === LK.current) || LK.builtin.find((x) => x.id === LK.current) || LK.builtin[0];
    D = toDraft(cur || { name: 'My look' }, cur && LK.edits[cur.id]);
  }
  D.x = D.x || {}; D.set = merge(LOOK_DEFAULTS, D.set);
  $('#dname').value = D.name;
  undoState(); render(); fit(); showLocal();
  refreshRequests();
})();
