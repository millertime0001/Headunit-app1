// Instrument cluster (second screen) layouts, shared by the cluster page and Settings > Cluster on the head unit.
// [id, name, description, slot names, has a middle panel, which of the 6 gauge slots each name uses]
'use strict';
window.CLUSTER_LAYOUTS = [
  ['classic', 'Classic', 'Two big dials, info in the middle', ['Left dial', 'Right dial', 'Middle, top', 'Middle, bottom'], true, [0, 1, 2, 3]],
  ['sport', 'Sport', 'One big dial in the middle, readouts either side', ['Big dial', 'Left, top', 'Left, bottom', 'Right, top', 'Right, bottom'], false, [0, 1, 2, 3, 4]],
  ['digital', 'Digital', 'Huge speed number, rev bar across the top', ['Left, top', 'Left, bottom', 'Right, top', 'Right, bottom'], true, [2, 3, 4, 5]],
  ['trio', 'Three dials', 'Three dials side by side', ['Left', 'Middle', 'Right'], false, [0, 1, 2]],
  ['six', 'Six', 'Six gauges in two rows', ['1', '2', '3', '4', '5', '6'], false, [0, 1, 2, 3, 4, 5]],
  ['minimal', 'Minimal', 'Just your speed, the time and what’s next', [], true, []],
  ['map', 'Map', 'Google Maps between two dials', ['Left dial', 'Right dial'], false, [0, 1]],
  ['mapfull', 'Big map', 'Maps fills the screen, readouts along the bottom', ['Bottom left', 'Bottom middle', 'Bottom right'], false, [0, 1, 2]],
  ['quad', 'Four dials', 'Four dials in a row', ['1', '2', '3', '4'], false, [0, 1, 2, 3]],
  ['race', 'Race', 'Shift lights across the top, big tach, readouts around it', ['Big dial', 'Left, top', 'Left, bottom', 'Right, top', 'Right, bottom'], false, [0, 2, 3, 4, 5]],
  ['real', 'Realistic', 'Like a real car: two big analog dials with fuel and temp, info screen in the middle', ['Left dial', 'Right dial'], true, [1, 0]],
  ['pods', 'Pods', 'Each gauge in its own deep 3D pod with a chrome ring and a hood, two huge ones either side', ['Left pod', 'Right pod', 'Middle top', 'Middle bottom'], false, [1, 0, 2, 3]],
  ['grand', 'Grand', 'Huge speedometer and tach, now playing with album art, sloshing fuel and coolant', ['Left dial', 'Right dial', 'Middle left', 'Middle right'], false, [1, 0, 2, 3]],
  ['cockpit3d', '3D Cockpit', 'Dials wrapped around you in 3D, mirror floor, neon grid that races with your speed', ['Left dial', 'Center', 'Far left', 'Far right', 'Right dial'], false, [0, 1, 2, 3, 4]],
  ['eight', 'Eight', 'Eight gauges in two rows', ['1', '2', '3', '4', '5', '6', '7', '8'], false, [0, 1, 2, 3, 4, 5, 6, 7]],
  ['arcs', 'Arcs + map', 'Two tall sweeping arcs hugging the ends, Google Maps curving between them', ['Left arc', 'Right arc', 'Map, bottom left', 'Map, bottom right'], false, [1, 0, 2, 3]],
  ['scope', 'Scope', 'Two dials around a big live trace (try Rpm history), two gauges under it', ['Left dial', 'Right dial', 'Middle, wide', 'Middle left', 'Middle right'], false, [0, 1, 2, 3, 4]],
  ['strip', 'Digital strip', 'A huge digital speed between two rows of four readouts', ['Top 1', 'Top 2', 'Top 3', 'Top 4', 'Bottom 1', 'Bottom 2', 'Bottom 3', 'Bottom 4'], false, [0, 1, 2, 3, 4, 5, 6, 7]],
  ['hero', 'Center stage', 'One huge dial in the middle, three readouts stacked on each side', ['Big dial', 'Left 1', 'Left 2', 'Left 3', 'Right 1', 'Right 2', 'Right 3'], false, [0, 1, 2, 3, 4, 5, 6]],
  ['twinplus', 'Two big + six', 'Two big dials side by side, three readouts down each end', ['Left dial', 'Right dial', 'Left 1', 'Left 2', 'Left 3', 'Right 1', 'Right 2', 'Right 3'], false, [0, 1, 2, 3, 4, 5, 6, 7]],
  ['orbit', 'Orbit', 'A big dial with six round gauges circling it on a glowing ring', ['Center dial', 'Left top', 'Left', 'Left bottom', 'Right top', 'Right', 'Right bottom'], false, [0, 1, 2, 3, 4, 5, 6]],
  ['wings', 'Wings', 'Huge digital speed, readouts angled toward you on both sides like wings', ['Left 1', 'Left 2', 'Left 3', 'Right 1', 'Right 2', 'Right 3', 'Under the speed'], false, [0, 1, 2, 3, 4, 5, 6]],
  ['dash80', '80s digital', 'Rev bar across the top, big italic digital speed, readouts round it', ['Across the top (try Rev bar)', 'Left, top', 'Left, bottom', 'Right, top', 'Right, bottom', 'Bottom 1', 'Bottom 2', 'Bottom 3'], false, [0, 1, 2, 3, 4, 5, 6, 7]],
  ['bars', 'Bar graphs', 'Eight readouts with long bars, two columns: easiest to read at a glance', ['Left 1', 'Left 2', 'Left 3', 'Left 4', 'Right 1', 'Right 2', 'Right 3', 'Right 4'], false, [0, 1, 2, 3, 4, 5, 6, 7]],
  ['mapside', 'Map + four', 'Google Maps on the left half, four gauges on the right', ['Top left', 'Top right', 'Bottom left', 'Bottom right'], false, [0, 1, 2, 3]],
  ['navigator', 'Navigator', 'Google Maps in the middle melting into the background, next turn and speed limit over it, a dial each side', ['Left dial', 'Right dial'], false, [0, 1]],
  ['custom', 'Custom', 'Your own: put anything anywhere, any size (tap Edit layout)', [], false, []],
];
// Custom layout: pieces on a 24 x 9 grid over the whole screen (80 px squares on the 1920 x 720 bar).
// t = a gauge type (GAUGE_LIST) or one of these; o = options (map: its shape; others: "box" = panel behind it).
window.CLUSTER_GRID = [24, 9];
window.CLUSTER_PIECES = [
  ['@map', 'Google Maps', 'The live map from your phone (one per cluster)'],
  ['@nav', 'Directions', 'Next turn arrow, distance, street, arrival time and the speed limit'],
  ['@limit', 'Speed limit', 'The road’s speed limit sign; glows red when you’re over'],
  ['@speed', 'Digital speed', 'Your speed in big numbers'],
  ['@music', 'Now playing', 'Album art, song and progress'],
  ['@info', 'Auto info', 'Directions while navigating, else music, else this drive'],
  ['@trip', 'This drive', 'Distance, time, economy, outside temperature'],
  ['@time', 'Clock', 'Time and date'],
  ['@weather', 'Weather', 'Outside temperature and conditions'],
];
// starting points for the custom editor; 'A'/'B' = the first two cluster gauge slots
window.CLUSTER_PRESETS = [
  ['navigator', 'Navigator', [{ t: '@map', x: 6, y: 0, w: 12, h: 9, o: 'fade' }, { t: 'A', x: 0, y: 0, w: 8, h: 9 }, { t: 'B', x: 16, y: 0, w: 8, h: 9 },
    { t: '@nav', x: 7, y: 0, w: 10, h: 2, o: 'box' }]],
  ['mapwide', 'Big map', [{ t: '@map', x: 0, y: 0, w: 24, h: 9, o: 'fade' }, { t: '@nav', x: 0, y: 0, w: 9, h: 2, o: 'box' },
    { t: '@speed', x: 0, y: 6, w: 4, h: 3 }, { t: '@limit', x: 4, y: 7, w: 2, h: 2 }, { t: '@music', x: 16, y: 7, w: 8, h: 2, o: 'box' }]],
  ['dials', 'Two dials', [{ t: 'A', x: 0, y: 0, w: 9, h: 9 }, { t: 'B', x: 15, y: 0, w: 9, h: 9 }, { t: '@info', x: 9, y: 1, w: 6, h: 5, o: 'box' },
    { t: '@limit', x: 11, y: 6, w: 2, h: 3 }]],
  ['blank', 'Empty', []],
];
// a custom/navigator layout as pieces with the slot letters filled in
window.clusterPieces = (c) => {
  const s = c.slots || [];
  const fill = (list) => list.map((p) => Object.assign({}, p, { t: p.t === 'A' ? s[0] || 'tach' : p.t === 'B' ? s[1] || 'speed' : p.t }));
  if (c.layout === 'navigator') return fill(window.CLUSTER_PRESETS[0][2]);
  return Array.isArray(c.custom) ? c.custom : fill(window.CLUSTER_PRESETS[0][2]);
};
window.CLUSTER_CENTER = [['auto', 'Auto', 'Directions while navigating, else music'], ['nav', 'Directions'], ['music', 'Music'],
  ['trip', 'Trip'], ['clock', 'Clock'], ['map', 'Google Maps'], ['off', 'Nothing']];
window.CLUSTER_LOOKS = [['scene', 'Same as head unit', 'Your head unit’s animated background'], ['glow', 'Glow', 'Theme colors glowing behind glass'], ['black', 'Black', 'Pure black, numbers only'],
  ['carbon', 'Carbon', 'Carbon fiber with chrome rings']];
window.CLUSTER_DEFAULT = { on: true, screen: 'auto', layout: 'classic', slots: ['tach', 'speed', 'fuel', 'coolant', 'volts', 'mpg', 'oil', 'boost'],
  center: 'auto', look: 'scene', theme: '', bright: 100, night_dim: true, night: 40, shift: 6000, warn: true, bar: true,
  sweep: true, mirror: false, rotate: 'normal', mode: '', map_trim: 190, face: 'neon',
  needle: 'face', ticks: 'face', numerals: 'face', arc: 'face', glow: 60, redline: 6000, map_style: 'same', map_shape: 'rect', custom: null };
