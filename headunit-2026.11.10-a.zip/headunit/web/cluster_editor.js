// Custom cluster layout editor (Settings > Cluster > Layout > Edit layout). The cluster has no touch, so it's
// laid out here: a live preview of the cluster with a box over every piece.
// - Drag a box to move it; drag its corner to resize. Everything snaps to the cluster's 24 x 9 grid.
// - Pieces may overlap (later ones are on top): e.g. the directions panel over the map.
// - The chips under the preview select any piece, also one hidden under another.
// Every change is saved at once as settings.cluster.custom (+ layout "custom"), so the real cluster follows live.
'use strict';
const CE = { items: [], sel: -1, undo: [], drag: null, pick: null };
const ceClone = (a) => JSON.parse(JSON.stringify(a));
// default size (in grid squares) for a new piece
const CE_SIZE = { '@map': [12, 9], '@nav': [10, 2], '@limit': [2, 3], '@speed': [5, 3], '@music': [8, 3], '@info': [7, 5],
  '@trip': [6, 4], '@time': [5, 3], '@weather': [4, 2] };
const CE_X = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"><path d="M20 10v10H10M20 20L11 11"/></svg>';

function ceName(t) {
  const p = (window.CLUSTER_PIECES || []).find(([k]) => k === t) || (window.GAUGE_LIST || []).find(([k]) => k === t);
  return p ? p[1] : t;
}
function ceGrid() { return window.CLUSTER_GRID || [24, 9]; }

function ceOpen() {
  const c = clusterSet();
  CE.items = ceClone(window.clusterPieces(Object.assign({}, c, { layout: Array.isArray(c.custom) ? 'custom' : 'navigator' })));
  CE.sel = -1; CE.undo = []; CE.pick = null;
  const [w, h] = typeof clusterSize === 'function' ? clusterSize() : [1920, 720];
  const el = document.createElement('div');
  el.className = 'ce'; el.id = 'ce';
  el.innerHTML = `<div class="ce-top"><b>Cluster layout</b>
      <div class="ce-pre"><span>Start from</span>${(window.CLUSTER_PRESETS || []).map(([k, l]) => `<button class="sink" data-ce="preset:${k}">${l}</button>`).join('')}</div>
      <button class="btn small sink" data-ce="undo">Undo</button><button class="btn small primary sink" data-ce="done">Done</button></div>
    <div class="ce-stage" id="ceStage" style="aspect-ratio:${w} / ${h}">
      <iframe src="/static/cluster.html?preview&layout=custom" tabindex="-1" title="Cluster preview" style="width:${w}px;height:${h}px"></iframe>
      <div class="ce-boxes" id="ceBoxes"></div></div>
    <div class="ce-bar" id="ceBar"></div>
    <div class="ce-pick hidden" id="cePick"></div>`;
  document.body.appendChild(el);
  // the Settings page's own preview isn't needed while this one is open
  const pv = $('#clPrev iframe'); if (pv) pv.style.visibility = 'hidden';
  ceFit(); ceDraw();
}
function ceClose() {
  const el = $('#ce'); if (el) el.remove();
  const pv = $('#clPrev iframe'); if (pv) pv.style.visibility = '';
  render(true);
}
function ceFit() {
  const st = $('#ceStage'); if (!st) return;
  const f = st.querySelector('iframe');
  f.style.transform = `scale(${st.clientWidth / parseFloat(f.style.width)})`;
}
addEventListener('resize', () => { if ($('#ce')) ceFit(); });

function ceSave() {
  setCluster({ layout: 'custom', custom: CE.items });
}
function ceCommit(before) {
  CE.undo.push(before);
  if (CE.undo.length > 40) CE.undo.shift();
  ceSave(); ceDraw();
}

const cePct = (v, n) => `${((v / n) * 100).toFixed(3)}%`;
function ceBoxStyle(p) {
  const [GW, GH] = ceGrid();
  return `left:${cePct(p.x, GW)};top:${cePct(p.y, GH)};width:${cePct(p.w, GW)};height:${cePct(p.h, GH)}`;
}
function ceDraw() {
  const boxes = $('#ceBoxes'); if (!boxes) return;
  boxes.innerHTML = CE.items.map((p, i) => `<div class="ce-box${i === CE.sel ? ' on' : ''}${p.t === '@map' ? ' map' : ''}" data-ci="${i}" style="${ceBoxStyle(p)}">
    <span>${esc(ceName(p.t))}</span>${i === CE.sel ? `<i class="ce-h" data-ch>${CE_X}</i>` : ''}</div>`).join('');
  const p = CE.items[CE.sel];
  const opts = p ? String(p.o || '').split(',').filter(Boolean) : [];
  const chips = `<div class="ce-chips">${CE.items.map((q, i) => `<button class="sink${i === CE.sel ? ' on' : ''}" data-ce="sel:${i}">${esc(ceName(q.t))}</button>`).join('')}
    <button class="sink add" data-ce="add">+ Add</button></div>`;
  let tools = '<div class="ce-tools"><span class="note">Drag a piece to move it, drag its corner to resize. Tap a name above to pick one that’s underneath another.</span></div>';
  if (p) {
    const shapes = (window.MAP_SHAPES || []).map(([k, l]) => `<button class="${(opts.find((o) => o !== 'box') || 'rect') === k ? 'on' : ''}" data-ce="shape:${k}">${l}</button>`).join('');
    tools = `<div class="ce-tools">
      <button class="sink" data-ce="change">Change</button>
      <div class="seg"><button data-ce="size:-1:0">Narrower</button><button data-ce="size:1:0">Wider</button><button data-ce="size:0:-1">Shorter</button><button data-ce="size:0:1">Taller</button></div>
      ${p.t === '@map' ? `<div class="seg">${shapes}</div>` : `<button class="sink${opts.includes('box') ? ' on' : ''}" data-ce="box">Panel behind</button>`}
      <button class="sink" data-ce="front">To front</button><button class="sink" data-ce="back">To back</button>
      <button class="sink danger" data-ce="del">Remove</button></div>`;
  }
  $('#ceBar').innerHTML = chips + tools;
}

// ---- picker: what a piece shows (add a new one, or change the selected one)
function cePickOpen(mode) {
  CE.pick = mode;
  const cur = mode === 'change' && CE.items[CE.sel] ? CE.items[CE.sel].t : '';
  const btn = ([k, l, d]) => `<button class="sink${k === cur ? ' on' : ''}" data-ce="pick:${k}"><b>${esc(l)}</b><small>${esc(d || '')}</small></button>`;
  const el = $('#cePick');
  el.innerHTML = `<div class="ce-pick-head"><b>${mode === 'add' ? 'Add to the cluster' : `Change ${esc(ceName(cur))}`}</b><button class="btn small sink" data-ce="pickclose">Close</button></div>
    <div class="ce-pick-list"><div class="sect-t">Maps, directions and info</div><div class="gopts">${(window.CLUSTER_PIECES || []).map(btn).join('')}</div>
    <div class="sect-t">Gauges</div><div class="gopts">${(window.GAUGE_LIST || []).map(btn).join('')}</div></div>`;
  el.classList.remove('hidden');
}
function cePicked(t) {
  const before = ceClone(CE.items);
  const [GW, GH] = ceGrid();
  if (t === '@map') {
    const j = CE.items.findIndex((q, i) => q.t === '@map' && !(CE.pick === 'change' && i === CE.sel));
    if (j >= 0) { toast('The cluster has one map: here it is'); CE.sel = j; CE.pick = null; $('#cePick').classList.add('hidden'); return ceDraw(); }
  }
  if (CE.pick === 'change' && CE.items[CE.sel]) {
    const p = CE.items[CE.sel];
    p.t = t;
    if (t === '@map' && !p.o) p.o = 'fade';
  } else {
    const [w, h] = CE_SIZE[t] || [6, 6];
    const p = { t, w, h, x: Math.round((GW - w) / 2), y: Math.round((GH - h) / 2), o: t === '@map' ? 'fade' : t === '@nav' ? 'box' : '' };
    if (t === '@map') { CE.items.unshift(p); CE.sel = 0; } else { CE.items.push(p); CE.sel = CE.items.length - 1; }   // the map goes underneath
  }
  CE.pick = null;
  $('#cePick').classList.add('hidden');
  ceCommit(before);
}

// ---- taps on the editor's buttons
document.addEventListener('click', (e) => {
  const b = e.target.closest('[data-ce]');
  if (!b || !b.closest('#ce')) return;
  e.stopPropagation();
  const [a, ...r] = b.dataset.ce.split(':');
  const before = ceClone(CE.items), p = CE.items[CE.sel], [GW, GH] = ceGrid();
  switch (a) {
    case 'done': return ceClose();
    case 'undo':
      if (!CE.undo.length) return toast('Nothing to undo');
      CE.items = CE.undo.pop(); CE.sel = -1; ceSave(); return ceDraw();
    case 'preset': {
      const pr = (window.CLUSTER_PRESETS || []).find(([k]) => k === r[0]);
      if (!pr) return;
      const s = clusterSet().slots;
      CE.items = pr[2].map((q) => Object.assign({}, q, { t: q.t === 'A' ? s[0] : q.t === 'B' ? s[1] : q.t }));
      CE.sel = -1; return ceCommit(before);
    }
    case 'sel': CE.sel = +r[0] === CE.sel ? -1 : +r[0]; return ceDraw();
    case 'add': return cePickOpen('add');
    case 'change': return p && cePickOpen('change');
    case 'pick': return cePicked(r.join(':'));
    case 'pickclose': CE.pick = null; return $('#cePick').classList.add('hidden');
  }
  if (!p) return;
  if (a === 'size') {
    p.w = Math.max(1, Math.min(GW - p.x, p.w + +r[0]));
    p.h = Math.max(1, Math.min(GH - p.y, p.h + +r[1]));
  } else if (a === 'box') {
    const o = String(p.o || '').split(',').filter(Boolean);
    p.o = (o.includes('box') ? o.filter((x) => x !== 'box') : o.concat('box')).join(',');
  } else if (a === 'shape') {
    p.o = r[0];
  } else if (a === 'front') {
    CE.items.splice(CE.sel, 1); CE.items.push(p); CE.sel = CE.items.length - 1;
  } else if (a === 'back') {
    CE.items.splice(CE.sel, 1); CE.items.unshift(p); CE.sel = 0;
  } else if (a === 'del') {
    CE.items.splice(CE.sel, 1); CE.sel = -1;
  } else return;
  ceCommit(before);
}, true);

// ---- drag to move, corner to resize (snapped to the grid)
document.addEventListener('pointerdown', (e) => {
  const box = e.target.closest('#ceBoxes .ce-box');
  if (!box) return;
  const i = +box.dataset.ci, r = $('#ceBoxes').getBoundingClientRect(), [GW, GH] = ceGrid();
  CE.drag = { i, box, size: !!e.target.closest('[data-ch]'), sx: e.clientX, sy: e.clientY, p0: Object.assign({}, CE.items[i]),
    before: ceClone(CE.items), cw: r.width / GW, ch: r.height / GH, moved: false };
  box.setPointerCapture(e.pointerId);
  e.preventDefault();
});
document.addEventListener('pointermove', (e) => {
  const d = CE.drag;
  if (!d) return;
  const px = e.clientX - d.sx, py = e.clientY - d.sy;
  if (!d.moved && Math.hypot(px, py) < 10) return;   // a small wobble is still a tap
  d.moved = true;
  const [GW, GH] = ceGrid(), p0 = d.p0, p = CE.items[d.i];
  if (d.size) {
    p.w = Math.max(1, Math.min(GW - p0.x, p0.w + Math.round(px / d.cw)));
    p.h = Math.max(1, Math.min(GH - p0.y, p0.h + Math.round(py / d.ch)));
  } else {
    p.x = Math.max(0, Math.min(GW - p0.w, p0.x + Math.round(px / d.cw)));
    p.y = Math.max(0, Math.min(GH - p0.h, p0.y + Math.round(py / d.ch)));
  }
  d.box.style.cssText = ceBoxStyle(p);
  d.box.classList.add('dragging');
});
const ceEnd = () => {
  const d = CE.drag;
  if (!d) return;
  CE.drag = null;
  if (!d.moved) { CE.sel = d.i === CE.sel ? -1 : d.i; return ceDraw(); }   // a tap selects
  CE.sel = d.i;
  if (JSON.stringify(d.p0) !== JSON.stringify(CE.items[d.i])) ceCommit(d.before); else ceDraw();
};
document.addEventListener('pointerup', ceEnd);
document.addEventListener('pointercancel', ceEnd);
