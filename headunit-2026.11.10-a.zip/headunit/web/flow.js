/* Flow: one animation that runs across the whole dash: the instrument cluster, the head unit and the knob.
   Every screen draws its own slice of the same scene, placed by where it really sits in the dash (millimetres,
   settings.dash), at the same moment (state.flow_clock: a phase shared by every screen, sped up by driving).
   Taps on the head unit, knob presses, new songs and the shift point send a ripple through all of it
   (state.flow_pulses). The knob runs the same scenes in its firmware (BG_FLOW) from the fields Knob.push() sends.
   Used by index.html (window.FLOW_SCREEN = 'hu', the default) and cluster.html ('cluster').
   Needs the page globals settings(), S (S.state, S.theme) and, on the head unit, send(). */
'use strict';

window.FLOW_SCENES = [
  ['liquid', 'Liquid light', 'Glowing blobs of light drift from screen to screen, melting into each other'],
  ['ribbons', 'Silk ribbons', 'Ribbons of light flow from the cluster across the head unit'],
  ['aurora', 'Northern lights', 'Aurora curtains rippling across the whole dash'],
  ['vortex', 'Vortex', 'Spiral arms turning around the knob, reaching out to every screen'],
  ['warp', 'Hyperspace', 'Stars streaming past, faster as you drive'],
  ['grid', 'Outrun', 'A neon sun and a racing grid floor that spans every screen'],
  ['plasma', 'Plasma', 'Slow waves of color rolling across the dash'],
  ['rain', 'Rain storm', 'Rain sweeping across every screen, lightning flickering behind it'],
  ['ocean', 'Moonlit sea', 'A moon over the head unit, waves rolling under the whole dash'],
  ['circuit', 'Circuit', 'Pulses of light racing along circuit traces from screen to screen'],
  ['embers', 'Embers', 'Sparks rising off the knob and drifting up across the dash'],
  ['sonar', 'Sonar', 'Rings and a radar sweep spreading out from the knob'],
  ['rainwindow', 'Rainy window', 'A night city out of focus behind wet glass, drops running down'],
  ['snow', 'Snowfall', 'Snow drifting down across every screen, the near flakes out of focus'],
  ['bokeh', 'City lights', 'Out-of-focus city lights drifting slowly past'],
  ['galaxy', 'Galaxy', 'A spiral galaxy slowly turning between the cluster and the head unit'],
  ['matrix', 'Code rain', 'Columns of glowing glyphs falling down the dash'],
  ['lava', 'Lava lamp', 'Glossy blobs rising and sinking from screen to screen'],
  ['fireflies', 'Fireflies', 'Soft lights wandering and blinking in the dark'],
  ['petals', 'Sakura', 'Petals tumbling down and across the dash'],
  ['topo', 'Topographic', 'Contour lines of a slowly shifting landscape'],
  ['speedlines', 'Speed lines', 'Streaks rushing past, longer the faster you drive'],
  ['caustics', 'Underwater', 'Rippling light from the surface dancing over everything'],
  ['smoke', 'Smoke', 'Slow wisps of mist curling up across the dash'],
  ['silk', 'Silk', 'Soft satin folds with a slow sheen'],
  ['mountains', 'Starry mountains', 'Mountain ridges and a lake under a turning starry sky'],
  ['neon', 'Neon tubes', 'Glowing glass tubes bending across the dash'],
  ['neoncity', 'Neon city', 'Neon signs and city lights through a rainy windshield'],
  ['dunes', 'Desert dusk', 'Dunes rolling under a sunset sky'],
  ['crystal', 'Crystal', 'Cut-gem facets catching a slowly moving light'],
  ['chrome', 'Liquid chrome', 'A molten mirror surface reflecting strips of light'],
  ['kaleido', 'Kaleidoscope', 'A mirrored pattern turning around the knob'],
  ['fireworks', 'Fireworks', 'Bursts blooming over every screen'],
  ['calibrate', 'Line up the screens', 'Sweeping lines to check where your screens sit'],
];
// Where the screens sit, in millimetres from the top-left of the cluster, measured off a photo of the dash.
// cluster/hu: [x, y, width, height] of the visible picture; knob: [center x, center y, diameter].
window.FLOW_DASH = { cluster: [0, 0, 292, 110], hu: [397, 29, 222, 130], knob: [554, 218, 32] };
window.FLOW_DEFAULT = { on: false, scene: 'liquid', amount: 75, react: true, pulses: 'on', hu: true, cluster: true, knob: true };

const FLOW = { gl: null, canvas: null, progs: {}, scene: null, raf: 0, last: 0, scale: 0.5, slow: 0, fast: 0, frameMs: 33,
  pulses: [], seen: new Set(), lastTap: 0, buf: null };

const FLOW_PRE = `#version 300 es
precision highp float;
uniform vec2 R, uOrg, uSz, uKnob; uniform float P, uSpeed, uInt, uLight;
uniform vec3 uBase, uC1, uC2, uC3, uAcc; uniform vec4 uPulse[4];
out vec4 outColor;
#define PI 3.14159265
float h11(float p){ p = fract(p * .1031); p *= p + 33.33; p *= p + p; return fract(p); }
float h21(vec2 p){ vec3 p3 = fract(vec3(p.xyx) * .1031); p3 += dot(p3, p3.yzx + 33.33); return fract((p3.x + p3.y) * p3.z); }
vec2 h22(vec2 p){ vec3 p3 = fract(vec3(p.xyx) * vec3(.1031, .1030, .0973)); p3 += dot(p3, p3.yzx + 33.33); return fract((p3.xx + p3.yz) * p3.zy); }
vec3 hue(vec3 c){ return c / max(max(c.r, max(c.g, c.b)), 1e-3); }
float vn(vec2 p){ vec2 i = floor(p), f = fract(p); f = f * f * (3. - 2. * f);
  return mix(mix(h21(i), h21(i + vec2(1., 0.)), f.x), mix(h21(i + vec2(0., 1.)), h21(i + vec2(1., 1.)), f.x), f.y); }
float vn1(float x){ float i = floor(x), f = fract(x); return mix(h11(i), h11(i + 1.), f * f * (3. - 2. * f)); }
float fbm(vec2 p, int o){ float s = 0., a = .5; for (int i = 0; i < 4; i++) { if (i >= o) break; s += a * vn(p); p = p * 2.03 + vec2(1.7, 9.2); a *= .5; } return s; }
float cmp(float d, float r){ float k = clamp(1. - d / r, 0., 1.); return k * k; }   // a glow that ends at r (no seams at cell edges)
vec3 stars(vec2 p, float G, float dens){       // twinkling stars, one per G mm cell at most
  vec2 id = floor(p / G), rn = h22(id); float h = h21(id + 3.7);
  if (h < dens) return vec3(0.);
  float d = length(p - (id + .25 + .5 * rn) * G);
  return mix(vec3(1.), hue(uC3), rn.x * .5) * smoothstep(.55, 0., d) * (.55 + .45 * sin(P * (1.3 + rn.x * 2.) + rn.y * 50.)) * (.25 + (h - dens) / (1. - dens) * .9);
}
`;

// Each scene: vec3 scene(vec2 p), p in millimetres (x right, y down). Returns linear light; base color included.
const FLOW_GLSL = {
  // metaballs on slow Lissajous paths spanning the whole dash, so they literally travel between the screens
  liquid: `
vec3 scene(vec2 p){
  float f = 0.; vec3 col = vec3(0.); float wsum = 0.;
  for (int i = 0; i < 7; i++) {
    float fi = float(i);
    vec2 b = vec2(300. + 330. * sin(P * (.045 + fi * .011) + fi * 1.9), 115. + 120. * sin(P * (.06 + fi * .013) + fi * 2.7));
    float r = 48. + 14. * sin(P * .2 + fi);
    vec2 d = p - b; float k = r * r / (dot(d, d) + 1.);
    f += k;
    vec3 c = i % 3 == 0 ? hue(uC1) : i % 3 == 1 ? hue(uC2) : hue(uC3);
    if (i == 6) c = hue(uAcc);
    col += c * k; wsum += k;
  }
  col /= max(wsum, 1e-3);
  float inside = smoothstep(.85, 1.25, f);
  float rim = smoothstep(.7, 1., f) * (1. - smoothstep(1., 1.5, f));
  vec3 c = uBase * .9 + col * (.003 + .035 * smoothstep(.25, .95, f));   // soft halo
  c += col * inside * (.2 + .3 * smoothstep(1.2, 4., f));            // the glowing body
  c += mix(col, vec3(1.), .55) * rim * .3;                             // a bright skin at the edge
  vec3 lc = uBase * mix(vec3(1.), col * .85, clamp(inside * .5 + rim * .3 + .12 * smoothstep(.25, .95, f), 0., 1.));
  return mix(c, lc, uLight);   // light themes: tinted glass blobs on the paper
}`,
  ribbons: `
vec3 scene(vec2 p){
  vec2 u = p / 100.;
  vec3 c = uBase * .85 + hue(uC2) * .005;
  for (int i = 0; i < 7; i++) {
    float fi = float(i);
    float y = .3 + fi * .26 + .22 * sin(u.x * (.9 + fi * .13) - P * (.5 + fi * .07) + fi * 1.7) + .1 * sin(u.x * 2.1 + P * .31 + fi * 4.);
    float d = abs(u.y - y);
    float th = .01 + .025 * (.5 + .5 * sin(u.x * 1.3 + fi + P * .4));
    vec3 col = i % 3 == 0 ? hue(uC1) : i % 3 == 1 ? hue(uC2) : hue(uC3);
    if (i == 3) col = hue(uAcc);
    c += col * (exp(-d * d / (th * th)) * .5 + exp(-d * 9.) * .012);
  }
  return c;
}`,
  aurora: `
vec3 scene(vec2 p){
  vec2 u = p / 100.;
  float x = u.x - P * .12;
  vec3 c = uBase * .8 + hue(uC3) * .007 * smoothstep(2.6, 0., u.y);
  for (int i = 0; i < 3; i++) {
    float fi = float(i);
    float y0 = .75 + fi * .45 + .28 * sin(x * .7 + fi * 2.1 + P * .11) + .1 * sin(x * 2.3 - P * .37 + fi);
    float d = u.y - y0;
    float rays = (.55 + .45 * sin(x * 9. + sin(x * 3. + P * .5) * 2. + fi * 7.)) * (.65 + .35 * sin(x * 23. + P * 1.1 + fi));
    float body = d < 0. ? exp(d * 2.4) * rays : exp(-d * d * 140.);
    vec3 col = i == 0 ? hue(uC1) : i == 1 ? hue(uC3) : hue(uC2);
    c += col * body * .3;
  }
  return c;
}`,
  vortex: `
vec3 scene(vec2 p){
  vec2 d = (p - uKnob) / 100.;
  float r = length(d), a = atan(d.y, d.x), lr = log(r + .12);
  float s1 = sin(a * 3. + lr * 5. - P * 1.1), s2 = sin(a * 5. - lr * 7. + P * .75);
  float arms = smoothstep(.2, 1., s1) * .8 + smoothstep(.55, 1., s2) * .35;
  float fall = 1. / (1. + r * 1.2);
  vec3 col = mix(hue(uC1), hue(uC2), .5 + .5 * sin(lr * 2. - P * .3));
  col = mix(col, hue(uC3), (.5 + .5 * s2) * .4);
  return uBase * .85 + col * arms * arms * (.03 + .35 * fall) + hue(uAcc) * exp(-r * r * 30.) * .8;
}`,
  warp: `
vec3 scene(vec2 p){
  vec2 d = (p - vec2(345., 70.)) / 100.;
  float r = length(d), a = atan(d.y, d.x);
  vec3 c = uBase * .85 + hue(uC2) * .02 * exp(-r * .8);
  for (int l = 0; l < 2; l++) {
    float n = l == 0 ? 160. : 260., sec = (a + PI) / (2. * PI) * n, id = floor(sec);
    float rnd = h11(id * 1.37 + float(l) * 7.1), sp = .14 * (.5 + rnd);
    float s = fract(rnd * 3.1 + P * sp);
    float rs = .05 * exp(s * 4.2), len = rs * (.12 + .5 * uSpeed);
    float on = step(rs - len, r) * step(r, rs) * smoothstep(rs - len, rs, r);
    float w = abs(fract(sec) - .5) * 2.;
    float line = on * smoothstep(1., .3, w) * smoothstep(0., .25, s) * step(.35, rnd);
    vec3 col = rnd > .8 ? hue(uAcc) : rnd > .55 ? hue(uC1) : mix(hue(uC3), vec3(1.), .5);
    c += col * line * (.7 + .8 * s);
  }
  return c;
}`,
  grid: `
vec3 scene(vec2 p){
  float H = 78.;                                          // the horizon, in mm from the top of the cluster
  vec3 c;
  if (p.y < H) {
    float k = (H - p.y) / 120.;
    c = mix(hue(uC2) * .12, uBase * .9, smoothstep(0., 1., k)) + hue(uAcc) * .05 * exp(-k * 6.);
    vec2 sd = p - vec2(205., H - 6.); float sr = 58.;   // the sun sits behind the cluster
    float sun = smoothstep(sr, sr - 2., length(sd));
    float cut = p.y > H - 38. ? smoothstep(.34, .42, fract((p.y + P * 5.) / 9.)) : 1.;   // the classic stripes across its lower half
    vec3 sc = mix(hue(uAcc), hue(uC2), smoothstep(H - 70., H, p.y));
    c = mix(c, sc * 1.1, sun * cut);
    c += sc * .35 * exp(-max(length(sd) - sr, 0.) * .05) * (1. - sun);
  } else {
    float dy = (p.y - H) / 100. + .015, z = 1. / dy;
    float gx = (p.x - 345.) / 100. * z * .55, gz = z * .9 + P * 1.2;
    vec2 g = abs(fract(vec2(gx, gz)) - .5), fw = fwidth(vec2(gx, gz)) * 1.5 + .02;
    float line = max(smoothstep(fw.x, 0., .5 - g.x), smoothstep(fw.y, 0., .5 - g.y));
    float fade = exp(-z * .12);
    c = uBase * .7 + hue(uC2) * .006 + hue(uAcc) * line * fade * .9 + hue(uC2) * .12 * exp(-(p.y - H) * .06);
  }
  return c;
}`,
  plasma: `
vec3 scene(vec2 p){
  vec2 u = p / 100.; float t = P * .3;
  float v = sin(u.x * 1.6 + t) + sin(u.y * 2.1 - t * 1.3) + sin((u.x + u.y) * 1.2 + t * .7)
          + sin(length(u - vec2(3.5 + sin(t * .3) * 2., 1.)) * 2.4 - t);
  v *= .25;
  vec3 col = mix(mix(hue(uC1), hue(uC2), .5 + .5 * sin(v * PI)), hue(uC3), .5 + .5 * cos(v * 4. + t));
  return uBase * .75 + col * (.01 + .22 * pow(.5 + .5 * sin(v * 6.2832 + t * 2.), 3.));
}`,
  rain: `
vec3 scene(vec2 p){
  vec3 c = uBase * .85 + hue(uC3) * .006;
  float flash = pow(max(0., sin(P * .71) * sin(P * 1.33) * sin(P * .57)), 14.) * 6.;     // lightning, now and then
  c += hue(uC2) * flash * .05 * smoothstep(260., 0., p.y);
  vec2 q = p; q.x += q.y * .2;                                                           // wind slant
  for (int l = 0; l < 3; l++) {
    float fl = float(l), cw = 2.6 + fl * 1.7;
    float col = floor(q.x / cw), r = h11(col * 1.7 + fl * 13.);
    float sp = (190. + r * 150.) * 1.4 * (1. - fl * .22);
    float per = 90. + r * 110., t = fract((q.y - P * sp) / per + r * 7.);
    float len = .16 + .1 * r;
    float d = abs(fract(q.x / cw) - .5) * cw;
    float drop = step(t, len) * (t / len) * exp(-d * d / (.12 + fl * .1)) * step(.25, r);
    c += mix(hue(uC3), vec3(.9), .5) * drop * (.5 - fl * .12);
  }
  c += hue(uC1) * .02 * smoothstep(140., 260., p.y);                                       // mist low down
  return c;
}`,
  ocean: `
vec3 scene(vec2 p){
  float H = 72.;
  vec2 mo = vec2(470., 34.);
  if (p.y < H) {
    float k = (H - p.y) / 90.;
    vec3 c = mix(hue(uC3) * .05, uBase * .8, smoothstep(0., 1., k));
    float st = step(.996, h21(floor(p / 1.6))) * (.5 + .5 * sin(P * 2. + h21(floor(p / 1.6)) * 40.));
    c += vec3(.5) * st * smoothstep(0., .4, k);
    float dm = length(p - mo);
    c += mix(vec3(1.), hue(uAcc), .2) * smoothstep(13., 12., dm) * .9;                     // the moon
    c += hue(uAcc) * .12 * exp(-max(dm - 12., 0.) * .04);
    return c;
  }
  float dy = (p.y - H) / 100. + .01, z = 1. / dy;
  float gx = (p.x - mo.x) / 100. * z, gz = z * 1.4 + P * .6;
  float w = sin(gx * 2.1 + gz * 3.1) * .5 + sin(gx * -3.7 + gz * 5.3 + 1.3) * .3 + sin(gz * 9.1 - gx * 1.3) * .2;
  vec3 c = mix(hue(uC3) * .03, uBase * .9, smoothstep(0., 2.5, dy * 10.));
  float glint = pow(max(0., w), 6.) * exp(-abs(p.x - mo.x) / (25. + (p.y - H) * 1.2));
  c += mix(vec3(1.), hue(uAcc), .3) * glint * 1.4;
  c += hue(uC1) * pow(max(0., w), 3.) * .05 * exp(-z * .15);
  return c;
}`,
  circuit: `
vec3 scene(vec2 p){
  vec3 c = uBase * .85;
  float G = 16.;
  vec2 cell = floor(p / G), f = fract(p / G) - .5;
  // horizontal trace on this row segment?
  float hx = h21(vec2(floor(p.x / (G * 3.)), cell.y) + 3.1), hy = h21(vec2(cell.x, floor(p.y / (G * 3.))) + 7.7);
  float dh = abs(f.y) * G, dv = abs(f.x) * G;
  float th = step(.42, hx) * exp(-dh * dh * 1.6), tv = step(.55, hy) * exp(-dv * dv * 1.6);
  c += hue(uC3) * (th + tv) * .045;
  float pad = step(.42, hx) * step(.55, hy) * smoothstep(2.6, 2., length(f * G));
  c += hue(uC1) * pad * .25;
  // pulses running along the traces: right along rows, down along columns
  float rr = h11(cell.y * 3.3), sp = (60. + rr * 90.) * 1.6;
  float s = fract((p.x - P * sp) / (180. + rr * 220.) + rr);
  float ph = th * smoothstep(.0, .1, s) * smoothstep(.16, .1, s) * (s / .16);
  float rc = h11(cell.x * 5.1), spv = (40. + rc * 70.) * 1.6;
  float sv = fract((p.y - P * spv) / (120. + rc * 160.) + rc);
  float pv = tv * smoothstep(.0, .1, sv) * smoothstep(.16, .1, sv) * (sv / .16);
  c += hue(uAcc) * ph * 1.3 + hue(uC2) * pv * 1.1;
  return c;
}`,
  embers: `
vec3 scene(vec2 p){
  vec3 c = uBase * .85 + mix(hue(uAcc), hue(uC2), .4) * .05 * smoothstep(120., 260., p.y);  // glow from below
  for (int l = 0; l < 2; l++) {
    float fl = float(l), G = 14. + fl * 9.;
    vec2 q = p + vec2(P * (4. + fl * 3.), P * (20. + fl * 9.) * 1.3);      // the field drifts up and right
    vec2 id0 = floor(q / G);
    for (int j = -1; j <= 1; j++) for (int i = -1; i <= 1; i++) {
      vec2 id = id0 + vec2(i, j), rn = h22(id + fl * 17.);
      if (rn.x < .45) continue;
      vec2 ctr = (id + .5 + (rn - .5) * .7) * G + vec2(sin(P * (.8 + rn.y) + rn.x * 30.) * 3., 0.);
      float d = length(q - ctr), sz = .5 + rn.y * 1.1;
      float fl2 = .55 + .45 * sin(P * (5. + rn.x * 6.) + rn.y * 20.);
      vec3 col = mix(hue(uAcc), mix(hue(uC1), vec3(1., .85, .6), .4), rn.y);
      c += col * (exp(-d * d / (sz * sz)) * .9 + exp(-d * .5) * .03) * fl2 * (1. - fl * .35);
    }
  }
  return c;
}`,
  sonar: `
vec3 scene(vec2 p){
  vec2 d = p - uKnob;
  float r = length(d), a = atan(d.y, d.x);
  vec3 c = uBase * .85 + hue(uC3) * .01 * exp(-r * .004);
  float ring = exp(-pow((fract(r / 55. - P * .22) - .5) * 55. / 2.2, 2.));
  c += hue(uC3) * ring * .22 * exp(-r * .0035);
  float g2 = exp(-pow((fract(r / 11.) - .5) * 11. / .6, 2.)) * .025;
  c += hue(uC1) * g2;
  float sw = mod(P * 1.1, 2. * PI), da = mod(sw - a, 2. * PI);
  float wedge = exp(-da * 2.6);
  c += hue(uAcc) * wedge * .3 * exp(-r * .002);
  vec2 bc = floor(p / 30.), bp = (bc + .2 + .6 * h22(bc)) * 30.;
  float ba = atan(bp.y - uKnob.y, bp.x - uKnob.x), bd = mod(sw - ba, 2. * PI);
  float blip = step(.8, h21(bc + 9.)) * smoothstep(3., 1.5, length(p - bp)) * exp(-bd * 1.2);
  c += mix(hue(uAcc), vec3(1.), .4) * blip * 1.5;
  return c;
}`,
  // ---- added 2026-11-08: synced versions of the screen effects, and more. Velocities never multiply P by uSpeed
  // (the speed changes in steps and P is large, so that would make everything jump): driving speeds up P itself.
  // Out-of-focus city lights drifting past, three depths
  bokeh: `
vec3 bokehL(vec2 p, float fl){
  float G = 44. - fl * 12.;
  vec2 q = p + vec2(P * (6. - fl * 1.6), fl * 17.);
  float cx = floor(q.x / G); q.y += h11(cx * 1.9 + fl * 5.) * G;              // stagger the columns: no rows
  vec2 id = vec2(cx, floor(q.y / G)), rn = h22(id + fl * 31.);
  float pw = h21(id + fl * 7. + 3.);
  if (pw < .45) return vec3(0.);
  vec2 o = (id + .5 + (rn - .5) * .4) * G;
  float r = G * (.1 + .12 * rn.y), d = length(q - o), soft = 2.4 - fl * .7;
  pw = .35 + 1.4 * pow((pw - .45) / .55, 3.);
  float disk = smoothstep(r, r - soft, d), rim = smoothstep(r - 2.4, r - .4, d) * disk;
  float tw = .65 + .35 * sin(P * (.25 + rn.x * .5) + rn.y * 40.);
  vec3 col = rn.x < .3 ? hue(uC1) : rn.x < .55 ? hue(uC3) : rn.x < .8 ? hue(uAcc) : mix(hue(uAcc), vec3(1., .8, .55), .6);
  return col * tw * pw * (1. - fl * .2) * (disk * (.07 + fl * .03) + rim * .05 + cmp(d, r * 1.3) * .018);
}
vec3 scene(vec2 p){
  vec3 c = uBase * .82 + mix(hue(uC2), hue(uC3), clamp(p.y / 240., 0., 1.)) * .012;
  for (int l = 0; l < 3; l++) c += bokehL(p, float(l));
  return c;
}`,
  // Snow: four depths of flakes, swaying as they fall; the near ones out of focus
  snow: `
vec3 scene(vec2 p){
  vec3 c = uBase * .85 + hue(uC3) * .025 * smoothstep(60., 240., p.y);
  vec3 fc = mix(hue(uC3), vec3(1.), .8);
  for (int l = 0; l < 4; l++) {
    float fl = float(l), G = 8. + fl * 5.;
    vec2 q = p - P * vec2(3. + fl * 2., 8. + fl * 5.);
    vec2 id = floor(q / G), rn = h22(id + fl * 11.);
    if (rn.x < .35) continue;
    vec2 ctr = (id + .5) * G + vec2(sin(P * (.6 + rn.y * .8) + rn.x * 20.) * G * .2, (rn.y - .5) * G * .25);
    float d = length(q - ctr), sz = .3 + fl * .2 + rn.y * .25, bl = .25 + fl * .22;
    c += fc * (smoothstep(sz + bl, sz - bl * .5, d) * (.25 + fl * .08) + cmp(d, sz * 3.5) * .02);
  }
  return c;
}`,
  // Code rain: columns of glyphs falling, a bright head and a fading trail
  matrix: `
vec3 scene(vec2 p){
  vec2 cs = vec2(4.6, 5.8), cell = floor(p / cs), f = fract(p / cs);
  float rc = h11(cell.x * 1.31 + .7);
  vec3 c = uBase * .8;
  vec2 g = floor((f - vec2(.14, .1)) / vec2(.24, .16));
  float inG = step(0., g.x) * step(g.x, 2.) * step(0., g.y) * step(g.y, 4.);
  float fl = floor(P * (1.5 + rc * 3.) + h21(cell) * 9.);
  float gd = inG * step(.42, h21(cell * vec2(1.1, 1.7) + g * vec2(17., 31.) + fl * 3.3));
  vec3 gc = mix(hue(uC1), hue(uAcc), .3);
  c += gc * gd * (.012 + .02 * h21(cell + 5.));                       // faint idle glyphs
  if (rc < .12) return c;
  float sp = 22. + rc * 34., len = 50. + rc * 110., per = len + 60. + h11(cell.x * 7.3) * 180.;
  float dt = mod(P * sp + rc * 977. - (cell.y + .5) * cs.y, per);     // how far behind the head this cell is
  float tr = dt < len ? pow(1. - dt / len, 1.6) : 0.;
  float head = smoothstep(cs.y * 1.5, 0., dt);
  c += gc * (gd * tr * .5 + tr * .012) + mix(hue(uAcc), vec3(1.), .6) * gd * head * .9;
  return c;
}`,
  // A slow spiral galaxy turning between the cluster and the head unit
  galaxy: `
vec3 scene(vec2 p){
  vec2 d = (p - vec2(285., 62.)) / 110.; d.y *= 1.7;
  float rot = P * .03, cr = cos(rot), sr = sin(rot);
  vec2 dq = mat2(cr, -sr, sr, cr) * d;
  float r = length(d), a = atan(dq.y, dq.x);
  float arms = pow(.5 + .5 * cos(2. * (a + log(r + .05) * 2.4)), 2.5);
  float n = fbm(dq * 2.2 + 3., 3), disc = exp(-r * 1.1);
  vec3 col = mix(hue(uC2), hue(uC3), smoothstep(.2, 1.4, r));
  col = mix(col, hue(uC1), arms * .3);
  vec3 c = uBase * .8 + col * arms * (.35 + 1.4 * n * n) * disc * .45 + col * disc * .03;
  c *= 1. - .55 * smoothstep(.5, .75, n) * arms * disc;                  // dust lanes
  c += mix(hue(uAcc), vec3(1., .9, .75), .5) * (exp(-r * r * 30.) * .9 + exp(-r * 3.5) * .06);
  c += stars(p, 3.5, .93) * .8;
  return c;
}`,
  // Lava lamp: glossy blobs rising and sinking from screen to screen
  lava: `
vec3 scene(vec2 p){
  vec3 c = uBase * .8 + hue(uC2) * .03 * smoothstep(60., 240., p.y) + hue(uAcc) * .012 * smoothstep(120., 0., p.y);
  float f = 0.; vec2 g = vec2(0.);
  for (int i = 0; i < 8; i++) {
    float fi = float(i);
    vec2 b = vec2(40. + fi * 80. + 25. * sin(P * (.07 + fi * .01) + fi * 3.), 120. - 110. * sin(P * (.09 + fi * .017) + fi * 2.3));
    float r = 26. + 12. * h11(fi * 3.1);
    vec2 d = p - b; float R2 = r * r * 4., u = dot(d, d) / R2;
    if (u < 1.) { f += (1. - u) * (1. - u); g -= 4. * (1. - u) / R2 * d; }
  }
  float inside = smoothstep(.22, .27, f);
  vec3 n = normalize(vec3(g * 38. / sqrt(max(f - .2, .004)) * .15, 1.));
  vec3 L = normalize(vec3(-.4, -.6, .7));
  float dif = max(dot(n, L), 0.), spec = pow(max(dot(reflect(-L, n), vec3(0., 0., 1.)), 0.), 28.);
  vec3 col = mix(hue(uAcc), hue(uC1), smoothstep(20., 220., p.y));
  vec3 blob = col * (.04 + .22 * dif) * (.6 + .4 * smoothstep(.22, .6, f)) + mix(col, vec3(1.), .6) * spec * .35;
  c += col * (smoothstep(.02, .24, f) * .05 + smoothstep(.15, .24, f) * .05) * (1. - inside);
  return mix(c, blob, inside);
}`,
  // Fireflies: soft lights wandering and blinking in the dark
  fireflies: `
vec3 scene(vec2 p){
  vec3 c = uBase * .85 + hue(uC1) * .03 * smoothstep(80., 240., p.y) + hue(uC2) * .01;
  vec3 fc = mix(hue(uAcc), vec3(1., 1., .55), .35);
  for (int l = 0; l < 3; l++) {
    float fl = float(l), G = 40. - fl * 10.;
    vec2 q = p + vec2(P * (1.2 + fl), P * .6) + fl * 50.;
    vec2 id = floor(q / G), rn = h22(id + fl * 5.);
    if (rn.x < .3) continue;
    vec2 ctr = (id + .5) * G + G * .2 * vec2(sin(P * (.23 + rn.x * .25) + rn.y * 9.), sin(P * (.19 + rn.y * .2) + rn.x * 7.));
    float d = length(q - ctr), bl = smoothstep(.2, 1., sin(P * (.5 + rn.y * .7) + rn.x * 40.)), sz = .8 + rn.y * .5 - fl * .2;
    c += fc * bl * (smoothstep(sz, 0., d) * .9 + cmp(d, G * .28) * .12) * (1. - fl * .2);
  }
  return c;
}`,
  // Sakura: petals tumbling down and across the dash
  petals: `
vec3 scene(vec2 p){
  vec3 c = mix(uBase * .85 + hue(uC2) * .03, uBase * .9 + hue(uAcc) * .02, smoothstep(0., 240., p.y));
  for (int l = 0; l < 3; l++) {
    float fl = float(l), G = 30. + fl * 12.;
    vec2 q = p - P * vec2(9. + fl * 5., 6. + fl * 3.5);
    vec2 id = floor(q / G), rn = h22(id + fl * 3.7);
    if (rn.x < .45) continue;
    vec2 lp = q - (id + .5) * G - (rn - .5) * G * .25 - vec2(sin(P * .8 + rn.y * 30.) * G * .1, 0.);
    float an = P * (.6 + rn.x * 1.4) + rn.y * 6.28, ca = cos(an), sa = sin(an);
    lp = mat2(ca, sa, -sa, ca) * lp;
    float tum = .3 + .7 * abs(sin(P * (.9 + rn.y) + rn.x * 9.)), sz = 2.6 + fl * 1.3 + rn.y * 1.2;
    vec2 e = vec2(lp.x, lp.y / tum) / vec2(sz, sz * .62);
    float pet = smoothstep(1., .82, length(e)) * (1. - smoothstep(.34, .2, length(e - vec2(1.02, 0.))));
    vec3 pc = mix(hue(uAcc), vec3(1., .92, .95), .35 + .3 * clamp(-e.x, 0., 1.)) * (.12 + fl * .05) * (.7 + .3 * tum);
    c = mix(c, pc, pet);
  }
  return c;
}`,
  // Topographic map: contour lines of a slowly shifting landscape (also drawn as ink on light themes)
  topo: `
vec3 scene(vec2 p){
  vec2 u = p / 120.; float t = P * .02;
  float h = fbm(u + vec2(t, t * .6), 3) + .3 * vn(u * .6 - vec2(t * .5, -t * .3));
  float lv = h * 16., fw = fwidth(lv), d = .5 - abs(fract(lv) - .5);
  float major = mod(floor(lv + .5), 5.) == 0. ? 1. : 0.;
  float line = 1. - smoothstep(fw * (.6 + major), fw * (1.6 + major * 1.2), d);
  vec3 col = mix(hue(uC3), hue(uC1), smoothstep(.35, .7, h));
  col = mix(col, hue(uAcc), smoothstep(.7, .9, h));
  float sc = exp(-pow((p.x - mod(P * 40., 900.) + 100.) / 30., 2.));
  vec3 glow = uBase * .82 + col * (.012 + .02 * h) + col * line * ((major > .5 ? .34 : .13) + sc * .4);
  vec3 ink = uBase * (1. - .05 * h) * mix(vec3(1.), col * .35, clamp(line * ((major > .5 ? .75 : .45) + sc * .2), 0., 1.));
  return mix(glow, ink, uLight);
}`,
  // Speed lines: streaks rushing past, longer and faster the faster you drive
  speedlines: `
vec3 scene(vec2 p){
  vec3 c = uBase * .82 + hue(uC2) * .012;
  for (int l = 0; l < 3; l++) {
    float fl = float(l), lane = 2.4 + fl * 1.7;
    float row = floor(p.y / lane), rn = h11(row * 1.37 + fl * 11.);
    if (rn < .2) continue;
    float v = (70. + rn * 110.) * (1. + fl * .6), per = 150. + rn * 260.;
    float len = (14. + rn * 30.) * (.6 + 4. * uSpeed) * (1. + fl * .4);
    float x = mod(p.x + P * v + rn * 911., per);
    float s = x < len ? 1. - x / len : 0.;
    float dy = abs(fract(p.y / lane) - .5) * lane, th = .16 + fl * .1;
    vec3 col = rn > .85 ? hue(uAcc) : rn > .6 ? hue(uC1) : mix(hue(uC3), vec3(1.), .3);
    c += col * (pow(s, 1.5) * exp(-dy * dy / (th * th)) * (.3 + .15 * fl) + s * exp(-dy * .9) * .02) * (.8 + .6 * uSpeed);
  }
  return c;
}`,
  // Underwater: caustic light dancing over everything, sun shafts from above
  caustics: `
vec3 scene(vec2 p){
  float t = P * .35 + 23.;
  vec2 q = p / 36. - 250. + 2.2 * vec2(vn(p / 110.), vn(p / 110. + 7.3)), i = q; float s = 1.;
  for (int n = 0; n < 5; n++) {
    float tt = t * (1. - 3.5 / float(n + 1));
    i = q + vec2(cos(tt - i.x) + sin(tt + i.y), sin(tt - i.y) + cos(tt + i.x));
    s += 1. / length(vec2(q.x / (sin(i.x + tt) / .005), q.y / (cos(i.y + tt) / .005)));
  }
  s = 1.17 - pow(s / 5., 1.4);
  float caus = pow(abs(s), 8.);
  float rays = pow(.5 + .5 * sin((p.x + p.y * .45) * .05 + sin(p.x * .013 + P * .11) * 2.5), 4.) * smoothstep(230., 0., p.y);
  vec3 c = mix(hue(uC3) * .05 + uBase * .6, uBase * .75, smoothstep(0., 240., p.y));
  c += mix(hue(uC3), vec3(1.), .35) * caus * .4 * (.5 + .5 * smoothstep(240., 0., p.y)) + hue(uC1) * rays * .05;
  return c;
}`,
  // Smoke: slow wisps of mist curling up across the dash
  smoke: `
vec3 scene(vec2 p){
  vec2 u = p / 75.; float t = P * .05;
  float w = fbm(vec2(u.x * 1.3, u.y * .8 + t * 1.2), 2);
  float n = fbm(vec2(u.x + w * 1.6 - t * .2, u.y * .7 + t * 1.8), 4);
  float r = pow(clamp(1. - abs(n * 2. - .95), 0., 1.), 3.);
  vec3 col = mix(hue(uC3), hue(uC1), smoothstep(.3, .65, w));
  vec3 c = uBase * .82 + col * r * (.06 + .09 * smoothstep(240., 40., p.y)) + hue(uC2) * n * .025;
  return c + mix(col, vec3(1.), .5) * pow(r, 6.) * .05;
}`,
  // Silk: soft satin folds with a slow sheen
  silk: `
vec3 scene(vec2 p){
  vec2 u = p / 60.; float t = P * .1;
  float w = u.x * .8 + u.y * .45 + .9 * sin(u.y * .55 - u.x * .25 + t) + .45 * sin(u.x * .8 + u.y * .3 - t * .7);
  float a = w * 2.4, s1 = sin(a), s2 = sin(a * 2.1 + 1.3 + sin(u.y * .7 + t * .5));
  float slope = cos(a) * .75 + cos(a * 2.1 + 1.3) * .35;     // how the cloth tilts across the folds
  float dif = clamp(.5 + .5 * slope, 0., 1.);
  float sheen = pow(max(0., slope * .8 + .25 * s2), 10.);
  vec3 col = mix(hue(uC1), hue(uAcc), .5 + .5 * sin(w * .6 + t * .3));
  return uBase * .5 + col * (.006 + .11 * dif * dif * (.8 + .2 * s1)) + mix(col, vec3(1., .95, .88), .45) * sheen * .25;
}`,
  // Starry mountains: three ridges under a turning sky, a lake, the odd shooting star
  mountains: `
float ridge(float x, float s){ return vn1(x * .02 + s) * .55 + vn1(x * .05 + s * 3.) * .3 + vn1(x * .13 + s * 7.) * .15; }
vec3 scene(vec2 p){
  float lake = 196.;
  vec2 sp = p; if (p.y > lake) sp.y = 2. * lake - p.y + sin(p.y * .9 + P * 2.) * .7;
  vec3 c = mix(uBase * .7 + hue(uC2) * .02, hue(uC3) * .07 + uBase * .6, smoothstep(0., 180., sp.y));
  c += stars(sp + vec2(P * .3, 0.), 4., .95) * .8;
  float mw = fbm(vec2((sp.x + sp.y * .7) / 60., (sp.y - sp.x * .35) / 25.), 3);
  float band = exp(-pow((sp.y - 70. + (sp.x - 300.) * .25) / 35., 2.));
  c += mix(hue(uC2), hue(uC3), mw) * band * smoothstep(.35, .8, mw) * .12;
  float ts = P * .11, sk = floor(ts), sf = fract(ts);
  if (h11(sk * 3.3) > .4 && sf < .12) {            // a shooting star
    vec2 a0 = vec2(60. + h11(sk) * 500., 10. + h11(sk * 1.7) * 50.), dir = normalize(vec2(1., .35)), hp = a0 + dir * sf * 1500.;
    vec2 rel = sp - hp; float al = dot(rel, dir), pd = length(rel - dir * al);
    c += mix(hue(uAcc), vec3(1.), .7) * exp(-pd * pd * 2.) * smoothstep(-60., 0., al) * step(al, 0.) * (1. - sf / .12) * .9;
  }
  float x0 = sp.x + P * .3;
  for (int i = 0; i < 3; i++) {
    float fi = float(i);
    float y = 95. + fi * 50. - ridge(x0 * (1. + fi * .4) + fi * 300., fi * 17.) * (80. - fi * 20.);
    float inM = smoothstep(-.4, .4, sp.y - y), dd = sp.y - y;
    vec3 mc = mix(hue(uC3) * .045 + uBase * .5, uBase * .45, fi / 2.) + hue(uC3) * exp(-max(dd, 0.) * .5) * (.06 - fi * .015);
    mc += vec3(.06) * smoothstep(60., 30., y) * exp(-max(dd, 0.) * .15) * (1. - fi * .5);   // snow on the high peaks
    c = mix(c, mc, inM);
  }
  if (p.y > lake) c = c * .55 + hue(uC3) * .006;
  return c;
}`,
  // Neon tubes: glowing glass tubes bending across the dash, buzzing now and then
  neon: `
vec3 scene(vec2 p){
  vec3 c = uBase * .8 + hue(uC2) * .008;
  for (int i = 0; i < 5; i++) {
    float fi = float(i);
    float x = p.x * .008 + fi * 1.7, t = P * (.08 + fi * .015);
    float y = 25. + fi * 46. + 22. * sin(x + t + fi) + 12. * sin(x * 2.3 - t * 1.4 + fi * 3.);
    float dy = (p.y - y) / sqrt(1. + pow(22. * .008 * cos(x + t + fi) + 12. * .0184 * cos(x * 2.3 - t * 1.4 + fi * 3.), 2.));
    float d = abs(dy);
    float k = floor(P * 3. + fi * 7.), buzz = h11(k * 1.3 + fi) > .93 ? .35 : 1.;
    vec3 col = i == 0 ? hue(uAcc) : i == 1 ? hue(uC1) : i == 2 ? hue(uC2) : i == 3 ? hue(uC3) : hue(uAcc);
    c += (col * (smoothstep(1.6, .4, d) * .5 + exp(-d * .35) * .07 + exp(-d * .08) * .012) + mix(col, vec3(1.), .8) * smoothstep(.6, 0., d) * .4) * buzz;
  }
  return c;
}`,
  // Neon city: signs and blurred city lights through a wet windshield, streets shining underneath
  neoncity: `
vec3 nsign(vec2 q, float G, float s){
  vec2 id = floor(q / G), rn = h22(id + s); float kind = h21(id + s + 9.);
  if (rn.x < .5) return vec3(0.);
  vec2 lp = q - (id + .5 + (rn - .5) * .2) * G;
  float d;
  if (kind < .3) d = abs(length(lp) - (8. + rn.y * 6.));
  else if (kind < .65) { vec2 b = abs(lp) - vec2(8. + rn.x * 5., 3.5 + rn.y * 3.); d = abs(length(max(b, 0.)) + min(max(b.x, b.y), 0.) - 1.5); }
  else { vec2 b = vec2(mod(lp.x + 14., 5.) - 2.5, lp.y); d = max(length(max(abs(b) - vec2(1.1, 3.), 0.)), abs(lp.x) - 13.); }
  vec3 col = kind < .2 ? hue(uAcc) : kind < .45 ? hue(uC1) : kind < .7 ? hue(uC2) : kind < .85 ? hue(uC3) : hue(uAcc);
  float fl = h11(floor(P * 4. + rn.y * 9.) + rn.x * 7.) > .9 ? .3 : 1.;
  return (col * (smoothstep(1., .3, d) * .45 + cmp(d, 9.) * .12) + mix(col, vec3(1.), .7) * smoothstep(.45, 0., d) * .25) * fl;
}
vec3 scene(vec2 p){
  float H = 150.;
  vec2 q = p; float refl = 0.;
  if (p.y > H) { q = vec2(p.x + sin(p.y * .7 + P * 3.) * 1.4, 2. * H - p.y); refl = 1.; }
  q.x += P * 2.;
  vec3 c = uBase * .8 + mix(hue(uC2), hue(uC3), .5) * .02 * smoothstep(0., H, q.y);
  for (int l = 0; l < 2; l++) {                      // the city behind, out of focus
    float fl = float(l), G = 26. - fl * 8.; vec2 b = q * (1. - fl * .2) + vec2(0., fl * 9.);
    vec2 id = floor(b / G), rn = h22(id + fl * 3.); float on = step(.5, h21(id + 4. + fl));
    float d = length(b - (id + .5 + (rn - .5) * .3) * G), rr = G * (.1 + .1 * rn.y);
    c += (rn.x < .5 ? hue(uC3) : mix(hue(uAcc), vec3(1., .8, .5), .5)) * on * (smoothstep(rr, rr - 2., d) * .05 + cmp(d, rr * 1.4) * .012) * smoothstep(20., 140., b.y);
  }
  c += nsign(q, 70., 2.) + nsign(q + vec2(31., 21.), 52., 5.) * .8;
  if (refl > 0.) c = uBase * .7 + (c - uBase * .8) * .45 * smoothstep(240., H, p.y);
  vec2 r = p; r.x += r.y * .15; float cw = 3.2, col = floor(r.x / cw), rr = h11(col * 1.7);
  float tt = fract((r.y - P * (230. + rr * 120.)) / (70. + rr * 90.) + rr * 7.), dd = abs(fract(r.x / cw) - .5) * cw;
  c += mix(hue(uC3), vec3(.9), .5) * step(tt, .14) * (tt / .14) * exp(-dd * dd * 6.) * step(.35, rr) * .16;
  return c;
}`,
  // Rainy window: a night city out of focus behind wet glass, beads and drops running down (refracting it)
  rainwindow: `
vec3 cityL(vec2 p){
  vec3 c = uBase * .75 + mix(hue(uC2), hue(uAcc), smoothstep(40., 240., p.y)) * .02;
  for (int l = 0; l < 2; l++) {
    float fl = float(l), G = 34. - fl * 12.;
    vec2 q = p + vec2(P * (1.5 - fl * .5), fl * 13.);
    float cx = floor(q.x / G); q.y += h11(cx * 2.3 + fl) * G;
    vec2 id = vec2(cx, floor(q.y / G)), rn = h22(id + fl * 19.);
    float pw = h21(id + fl * 3. + 1.);
    if (pw < .4) continue;
    pw = .3 + 1.5 * pow((pw - .4) / .6, 3.);
    float r = G * (.13 + .12 * rn.y), d = length(q - (id + .5 + (rn - .5) * .35) * G);
    vec3 col = rn.x < .35 ? hue(uC1) : rn.x < .6 ? hue(uC3) : mix(hue(uAcc), vec3(1., .75, .45), .45 * rn.x);
    c += col * pw * (smoothstep(r, r - 3. + fl, d) * (.08 + fl * .04) + cmp(d, r * 1.3) * .02) * (.7 + .3 * sin(P * .3 + rn.y * 30.));
  }
  return c;
}
vec3 scene(vec2 p){
  vec2 n = vec2(0.); float m = 0.;
  float W = 15., cx = floor(p.x / W), r = h11(cx * 3.7 + 1.);
  float per = 300. + r * 200., yh = mod(P * (12. + r * 22.) + r * 400., per) - 20.;
  float xc = (cx + .5) * W + sin(p.y * .07 + r * 10.) * 2.5 + (r - .5) * 5.;
  float trail = step(p.y, yh) * smoothstep(yh - 90., yh - 10., p.y);
  float G = 6.5, bx = floor(p.x / G); vec2 bp = p + vec2(0., h11(bx * 1.7) * G); vec2 id = vec2(bx, floor(bp.y / G)), rn = h22(id + 1.3);
  if (rn.x > .3 && !(abs(p.x - xc) < 4. && p.y < yh && p.y > yh - 140.)) {   // still beads (wiped where a drop ran)
    float rad = .6 + 1.6 * rn.y * rn.y; vec2 dv = (bp - (id + .5 + (rn - .5) * .4) * G) / rad;
    float dd = dot(dv, dv); if (dd < 1.) { m = smoothstep(1., .7, dd); n = dv; }
  }
  { vec2 dv = vec2(p.x - xc, (p.y - yh) * .7) / 2.4; float dd = dot(dv, dv); if (dd < 1.) { m = smoothstep(1., .75, dd); n = dv; } }
  { float ty = floor(p.y / 3.2), rt = (.35 + .6 * h11(ty + cx * 7.)) * trail;     // the little beads it leaves behind
    vec2 dv = vec2(p.x - xc, fract(p.y / 3.2) * 3.2 - 1.6) / max(rt, .01); float dd = dot(dv, dv);
    if (rt > .2 && dd < 1. && m == 0.) { m = smoothstep(1., .7, dd); n = dv; } }
  vec3 bg = cityL(p - n * 12. * m);
  vec3 c = mix(bg * .8, bg * 1.6 + hue(uC3) * .006, m);
  c += vec3(1.) * m * pow(max(0., 1. - length(n - vec2(-.35, -.45)) * 2.2), 3.) * .35;   // the glint
  c += mix(hue(uC3), vec3(1.), .5) * m * smoothstep(.6, 1., dot(n, n)) * smoothstep(0., .8, n.y) * .06;  // lit lower rim
  c *= 1. - m * smoothstep(.6, 1., dot(n, n)) * smoothstep(.2, -.8, n.y) * .5;              // dark upper rim
  return c;
}`,
  // Desert dusk: dunes rolling under a sunset sky, the sun sitting low
  dunes: `
vec3 scene(vec2 p){
  float hz = 95.; vec2 sun = vec2(330., 86.);
  float ds = length(p - sun);
  vec3 warm = mix(hue(uAcc), vec3(1., .55, .25), .35);
  vec3 c = mix(hue(uC2) * .05 + uBase * .6, warm * .22, pow(smoothstep(0., hz, p.y), 2.));
  c += stars(p, 5., .965) * smoothstep(60., 0., p.y) * .6;
  c += mix(warm, vec3(1., .85, .6), .5) * (smoothstep(16., 15., ds) * .9 + exp(-ds * .025) * .12);
  for (int i = 0; i < 4; i++) {
    float fi = float(i), x = p.x + P * (.6 + fi * .7) + fi * 137., fr = .006 + fi * .0025, amp = 14. * (1. + fi * .35);
    float s = sin(x * fr + fi * 2.), s2 = sin(x * fr * 2.3 + fi * 5.);
    float y = hz - 6. + fi * 38. - amp * (.55 + .45 * s) - 5. * s2;
    float dydx = -amp * .45 * fr * cos(x * fr + fi * 2.) - 5. * fr * 2.3 * cos(x * fr * 2.3 + fi * 5.);
    float lit = .5 + .5 * clamp(dydx * 4. * clamp((p.x - sun.x) / 80., -1., 1.), -1., 1.);
    float dd = p.y - y, inD = smoothstep(-.4, .4, dd);
    vec3 dc = mix(warm, hue(uC2), fi / 3.) * (.025 + .09 * lit) * exp(-dd * .012) * (1. - fi * .12);
    dc = mix(dc, c, .45 * (1. - fi / 3.) * exp(-dd * .05));
    dc += warm * exp(-max(dd, 0.) * .6) * lit * .05;
    c = mix(c, dc, inD);
  }
  return c;
}`,
  // Crystal: cut-gem facets catching a slowly moving light, bright along their edges
  crystal: `
vec3 scene(vec2 p){
  vec2 q = p / 36.; vec2 id = floor(q), f = fract(q);
  float d1 = 9., d2 = 9.; vec2 cid = vec2(0.);
  for (int j = -1; j <= 1; j++) for (int i = -1; i <= 1; i++) {
    vec2 o = vec2(i, j), h = h22(id + o);
    vec2 pt = o + .5 + .4 * sin(h * 6.28 + P * .05 * (h.yx + .5));
    float d = dot(f - pt, f - pt);
    if (d < d1) { d2 = d1; d1 = d; cid = id + o; } else if (d < d2) d2 = d;
  }
  vec2 h = h22(cid + 7.);
  vec3 n = normalize(vec3((h - .5) * 1.4, 1.));
  vec3 L = normalize(vec3(sin(P * .13), cos(P * .1) * .7, .8));
  float lit = pow(max(dot(n, L), 0.), 6.), edge = sqrt(d2) - sqrt(d1);
  vec3 col = mix(hue(uC3), hue(uC1), h.x); col = mix(col, hue(uC2), h.y * .4);
  vec3 c = uBase * .75 + col * (.015 + lit * .2) + mix(col, vec3(1.), .5) * pow(lit, 4.) * .2;
  c += mix(hue(uAcc), vec3(1.), .4) * smoothstep(.04, .0, edge) * (.06 + lit * .4);
  return c;
}`,
  // Liquid chrome: a molten mirror surface reflecting a studio of light strips
  chrome: `
vec3 scene(vec2 p){
  vec2 u = p / 42.; float t = P * .35;
  u += .3 * vec2(sin(u.y * 1.3 + t * .4), sin(u.x * 1.1 - t * .3));
  vec2 k1 = vec2(.9, .4), k2 = vec2(-.5, 1.1), k3 = vec2(1.6, -.9), k4 = vec2(.3, 1.9);
  vec2 g = .5 * cos(dot(u, k1) + t) * k1 + .35 * cos(dot(u, k2) - t * .8) * k2 + .2 * cos(dot(u, k3) + t * 1.3) * k3 + .12 * cos(dot(u, k4) - t * 1.1) * k4;
  vec3 n = normalize(vec3(-g * 1.3, 1.));
  vec2 r = 2. * n.z * n.xy;
  float hz = r.y + .1;
  vec3 sky = mix(mix(hue(uC3), vec3(1.), .55) * .55, hue(uC3) * .12, smoothstep(-1.2, 0., hz));
  vec3 gnd = mix(hue(uC2) * .05, uBase * .3, smoothstep(0., 1., hz));
  vec3 env = mix(sky, gnd, smoothstep(-.015, .015, hz));
  env += vec3(1.) * exp(-hz * hz * 900.) * .5;
  env += mix(hue(uAcc), vec3(1.), .4) * smoothstep(.08, 0., abs(r.x - .45)) * .5 * step(hz, 0.) + hue(uC1) * smoothstep(.1, 0., abs(r.x + .5)) * .3;
  return uBase * .2 + env;
}`,
  // Kaleidoscope: a mirrored pattern turning around the knob
  kaleido: `
vec3 scene(vec2 p){
  vec2 d = (p - uKnob) / 70.;
  float r = length(d), a = atan(d.y, d.x) + P * .04, seg = PI / 6.;
  a = abs(mod(a, 2. * seg) - seg);
  vec2 k = r * vec2(cos(a), sin(a));
  float t = P * .25;
  float v3 = sin((k.x + k.y) * 5. + t * .7);
  float v = sin(k.x * 7. - t * 1.3) * sin(k.y * 9. + t) + sin(length(k - vec2(1.2 + .4 * sin(t * .3), .2)) * 10. - t * 2.) * .7 + v3 * .5;
  vec3 col = mix(hue(uC1), hue(uC2), .5 + .5 * sin(r * 3. - t + a * 2.));
  col = mix(col, hue(uC3), .3 + .3 * v3);
  return uBase * .82 + col * (exp(-abs(v) * 5.) * .3 + smoothstep(.2, 1.2, v) * .06) * (.35 + .65 * exp(-r * .25)) + hue(uAcc) * exp(-r * r * 4.) * .3;
}`,
  // Fireworks: bursts blooming over every screen, sparks falling and twinkling out
  fireworks: `
vec3 scene(vec2 p){
  vec3 c = mix(uBase * .8, uBase * .9 + hue(uC2) * .03, smoothstep(0., 240., p.y));
  c += stars(p, 6., .95) * .5;
  for (int b = 0; b < 4; b++) {
    float fb = float(b), T = 3.1 + fb * .6, tb = P / T + fb * .37, k = floor(tb), f = fract(tb);
    float s1 = h11(k * 1.31 + fb * 5.7), s2 = h11(k * 2.17 + fb * 1.3), s3 = h11(k * 4.71 + fb * 3.3);
    vec2 ctr = vec2(40. + s1 * 570., 25. + s2 * 170. + 22. * f * f);
    vec3 col = mix(s3 < .25 ? hue(uC1) : s3 < .5 ? hue(uC2) : s3 < .75 ? hue(uC3) : hue(uAcc), vec3(1.), .2);
    vec2 rel = p - ctr; float r = length(rel);
    c += col * exp(-r * .025) * exp(-f * 14.) * .3;
    float R = (45. + 35. * h11(k * 9.1 + fb)) * (1. - exp(-f * 5.));
    if (r > R + 12.) continue;
    float sec = (atan(rel.y, rel.x) + PI) / (2. * PI) * 26., sid = floor(sec);
    float rr = R * (.8 + .2 * h11(sid + k * 13.)), ds = abs(fract(sec) - .5) * 2. * PI / 26. * r, dr = r - rr;
    float spark = exp(-ds * ds * 2.) * (exp(-dr * dr * .6) + step(dr, 0.) * exp(dr * .18) * .3);
    float tw = f > .5 ? .5 + .5 * step(.5, fract(P * 9. + sid * .37)) : 1.;
    c += col * spark * (1. - f) * (1. - f) * tw * 1.4;
  }
  return c;
}`,
  calibrate: `
vec3 scene(vec2 p){
  vec3 c = uBase * .5;
  vec2 g = abs(fract(p / 50. + .5) - .5) * 50.;
  c += vec3(.12) * smoothstep(1.2, 0., min(g.x, g.y));
  vec2 g2 = abs(fract(p / 100. + .5) - .5) * 100.;
  c += vec3(.25) * smoothstep(1.4, 0., min(g2.x, g2.y));
  float bx = mod(P * 110., 700.) - 30., by = mod(P * 45., 280.) - 20.;
  c += hue(uAcc) * smoothstep(9., 0., abs(p.x - bx)) * 1.4;
  c += hue(uC2) * smoothstep(7., 0., abs(p.y - by)) * 1.1;
  c += vec3(1.) * smoothstep(6., 4., abs(length(p - uKnob) - 16.));
  return c;
}`,
};

const FLOW_MAIN = `
void main(){
  vec2 q = gl_FragCoord.xy / R;
  vec2 p = uOrg + vec2(q.x, 1. - q.y) * uSz;
  vec3 c = scene(p);
  c = mix(uBase, c, uInt);
  for (int i = 0; i < 4; i++) {             // ripples from taps, the knob, new songs, the shift point
    vec4 u = uPulse[i];
    if (u.w <= 0. || u.z < 0. || u.z > 2.6) continue;
    float r = length(p - u.xy), front = u.z * 430., w = 10. + u.z * 22.;
    float ring = exp(-pow((r - front) / w, 2.)) * pow(1. - u.z / 2.6, 1.5);
    vec3 pc = u.w > 1.5 ? vec3(1., .16, .1) : hue(uAcc);
    c += pc * ring * (u.w > 1.5 ? 1.1 : .8) + vec3(1.) * ring * ring * .15;
  }
  c = uLight > .5 ? clamp(c, 0., 1.) : 1. - exp(-c * 1.6);   // light themes keep their paper white
  c = pow(c, vec3(.4545));
  // the soft vignette (was a separate full-screen CSS layer over the canvas: one less layer to composite)
  c *= 1. - (.35 - .25 * uLight) * clamp((length((q - vec2(.5, .6)) / vec2(1.2, .9)) - .55) / .45, 0., 1.);
  c += (h21(gl_FragCoord.xy + fract(P)) + h21(gl_FragCoord.yx + 17.3 + fract(P * 1.7)) - 1.) / 200.;   // triangular dither: no banding
  outColor = vec4(c, 1.);
}`;
const FLOW_VERT = `#version 300 es
in vec2 p; void main(){ gl_Position = vec4(p, 0., 1.); }`;

const FLOW_TEST = (location.search.match(/[?&]flow=([a-z]+)/) || [])[1];   // testing: ?flow=<scene> forces it on
function flowCfg() {
  const s = (typeof settings === 'function' && settings()) || {};
  return Object.assign({}, window.FLOW_DEFAULT, s.flow || {}, FLOW_TEST ? { on: true, scene: FLOW_TEST, hu: true, cluster: true } : {});
}
function flowDash() {
  const d = ((typeof settings === 'function' && settings()) || {}).dash || {};
  const out = {};
  for (const k of ['cluster', 'hu', 'knob']) out[k] = Array.isArray(d[k]) && d[k].length >= (k === 'knob' ? 3 : 4) ? d[k] : window.FLOW_DASH[k];
  return out;
}
function flowScreen() { return window.FLOW_SCREEN || 'hu'; }
// The shared phase: the backend's clock, run forward on this screen's own clock (all screens share the Pi's clock).
function flowPhase() {
  const c = S.state && S.state.flow_clock, now = Date.now() / 1000;
  if (!c) return now % 10000;
  return c.p0 + c.rate * (now - c.t0);
}
function flowOn() {
  const s = (typeof settings === 'function' && settings()) || {}, c = flowCfg();
  if (s.animate === false || !c.on || c[flowScreen()] === false || !FLOW_GLSL[c.scene]) return false;
  return true;
}

function flowInit() {
  if (FLOW.gl) return true;
  let c = document.getElementById('flow');
  if (!c) {
    const host = document.querySelector('.bg') || document.querySelector('.cl-bg');
    if (!host) return false;
    c = document.createElement('canvas'); c.id = 'flow';
    host.insertBefore(c, host.querySelector('#mapBg') || null);
  }
  const gl = c.getContext('webgl2', { antialias: false, alpha: false, depth: false, powerPreference: 'high-performance' });
  if (!gl) { console.warn('flow: no WebGL2'); return false; }
  FLOW.gl = gl; FLOW.canvas = c;
  FLOW.buf = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, FLOW.buf);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
  c.addEventListener('webglcontextlost', (e) => { e.preventDefault(); FLOW.progs = {}; });
  c.addEventListener('webglcontextrestored', () => { FLOW.buf = null; FLOW.gl = null; flowApply(); });
  return true;
}

function flowProgram(id, ctx = FLOW) {
  const gl = ctx.gl;
  if (ctx.progs[id]) return ctx.progs[id];
  const mk = (type, src) => {
    const sh = gl.createShader(type); gl.shaderSource(sh, src); gl.compileShader(sh);
    if (!gl.getShaderParameter(sh, gl.COMPILE_STATUS)) { console.warn(`flow ${id}: ${gl.getShaderInfoLog(sh)}`); return null; }
    return sh;
  };
  const vs = mk(gl.VERTEX_SHADER, FLOW_VERT), fs = mk(gl.FRAGMENT_SHADER, FLOW_PRE + FLOW_GLSL[id] + FLOW_MAIN);
  if (!vs || !fs) { ctx.progs[id] = null; return null; }
  const p = gl.createProgram(); gl.attachShader(p, vs); gl.attachShader(p, fs); gl.linkProgram(p);
  if (!gl.getProgramParameter(p, gl.LINK_STATUS)) { console.warn(`flow ${id}: ${gl.getProgramInfoLog(p)}`); return null; }
  const u = {};
  ['R', 'uOrg', 'uSz', 'uKnob', 'P', 'uSpeed', 'uInt', 'uLight', 'uBase', 'uC1', 'uC2', 'uC3', 'uAcc', 'uPulse'].forEach((n) => { u[n] = gl.getUniformLocation(p, n); });
  ctx.progs[id] = { p, u, loc: gl.getAttribLocation(p, 'p') };
  return ctx.progs[id];
}

const flowLin = (h) => {
  const n = parseInt(String(h || '#000000').replace('#', '').slice(0, 6), 16) || 0;
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255].map((v) => { v /= 255; return v <= 0.04045 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4; });
};

// Ripples: the backend's list (state.flow_pulses) plus our own taps, shown at once without waiting for the echo.
function flowPulses() {
  const st = S.state || {}, now = Date.now();
  for (const p of st.flow_pulses || []) {
    if (FLOW.seen.has(p.id)) continue;
    FLOW.seen.add(p.id);
    FLOW.pulses.push({ x: p.x, y: p.y, at: p.at, k: p.k || 1 });
  }
  if (FLOW.seen.size > 200) FLOW.seen = new Set([...FLOW.seen].slice(-60));
  FLOW.pulses = FLOW.pulses.filter((p) => now - p.at < 2600).slice(-4);
  const out = new Float32Array(16);
  FLOW.pulses.forEach((p, i) => { out.set([p.x, p.y, (now - p.at) / 1000, p.k], i * 4); });
  return out;
}

// One shared 30 fps beat for every canvas loop on the page (Flow, gauges): they all redraw on the same frames,
// so the screen is recomposited 30 times a second instead of up to 60 (unaligned loops each forced their own frame).
window.halfRate = window.halfRate || (() => {
  let frame = -1, go = false, at = -1e9;
  return (now) => { if (now !== frame) { frame = now; go = now - at >= 31; if (go) at = now; } return go; };
})();
function flowFrame(now) {
  FLOW.raf = requestAnimationFrame(flowFrame);
  if (FLOW.paused || !FLOW.scene) return;
  if (!halfRate(now)) return;     // about 30 fps, on the same frames as the gauges
  const dt = FLOW.last ? Math.min(0.1, (now - FLOW.last) / 1000) : 0.033;
  FLOW.last = now;
  // adaptive resolution: keep a steady 30 fps (the cluster and the head unit share one graphics chip)
  FLOW.frameMs = FLOW.frameMs * 0.92 + dt * 1000 * 0.08;
  if (FLOW.frameMs > 40) { if (++FLOW.slow > 30) { FLOW.scale = Math.max(0.3, FLOW.scale * 0.88); FLOW.slow = 0; FLOW.frameMs = 33; } } else FLOW.slow = 0;
  if (FLOW.frameMs < 36) { if (++FLOW.fast > 150) { FLOW.scale = Math.min(0.6, FLOW.scale * 1.1); FLOW.fast = 0; } } else FLOW.fast = 0;
  const c = FLOW.canvas, cw = c.clientWidth || innerWidth, ch = c.clientHeight || innerHeight;
  const w = Math.max(64, Math.round(cw * FLOW.scale)), h = Math.max(36, Math.round(ch * FLOW.scale));
  if (c.width !== w || c.height !== h) { c.width = w; c.height = h; }
  const dash = flowDash();
  flowDraw(FLOW, FLOW.scene, dash[flowScreen()] || dash.hu, w, h);
}

// Draws one frame of a scene into ctx's canvas: r = the world rectangle [x, y, w, h] in mm that the canvas shows.
function flowDraw(ctx, scene, r, w, h, pulses = true) {
  const gl = ctx.gl, pr = flowProgram(scene, ctx);
  if (!pr) return;
  const t = (S && S.theme) || {}, cfg = flowCfg(), kn = flowDash().knob;
  gl.viewport(0, 0, w, h);
  gl.useProgram(pr.p);
  gl.bindBuffer(gl.ARRAY_BUFFER, ctx.buf);
  gl.enableVertexAttribArray(pr.loc); gl.vertexAttribPointer(pr.loc, 2, gl.FLOAT, false, 0, 0);
  const u = pr.u;
  gl.uniform2f(u.R, w, h);
  gl.uniform2f(u.uOrg, r[0], r[1]); gl.uniform2f(u.uSz, r[2], r[3]);
  gl.uniform2f(u.uKnob, kn[0], kn[1]);
  gl.uniform1f(u.P, flowPhase());
  const fc = (S.state && S.state.flow_clock) || {};
  gl.uniform1f(u.uSpeed, Math.max(0, Math.min(1, fc.speed || 0)));
  gl.uniform1f(u.uInt, Math.max(0.1, Math.min(1, (cfg.amount ?? 75) / 100)));
  gl.uniform1f(u.uLight, t.light ? 1 : 0);
  gl.uniform3fv(u.uBase, flowLin(t.base || '#05070B')); gl.uniform3fv(u.uC1, flowLin(t.b1 || '#14B8A6'));
  gl.uniform3fv(u.uC2, flowLin(t.b2 || '#7C3AED')); gl.uniform3fv(u.uC3, flowLin(t.b3 || '#0EA5E9'));
  gl.uniform3fv(u.uAcc, flowLin(t.accent || '#5EEAD4'));
  gl.uniform4fv(u.uPulse, cfg.pulses === 'off' || !pulses ? new Float32Array(16) : flowPulses());
  gl.drawArrays(gl.TRIANGLES, 0, 3);
}

// Called whenever settings or the screen change (app.js applyLook / render, cluster.js applyLook).
function flowApply() {
  const on = flowOn();
  document.body.classList.toggle('flowing', on);
  if (!on) { FLOW.scene = null; cancelAnimationFrame(FLOW.raf); FLOW.raf = 0; return; }
  if (!flowInit()) { document.body.classList.remove('flowing'); return; }
  FLOW.scene = flowCfg().scene;
  // the phone's video needs the graphics chip: rest while Maps or YouTube Music fills the touch screen
  const scr = typeof S !== 'undefined' ? S.screen : '';
  const g2 = (k) => ((typeof settings === 'function' && settings()) || {})[k];
  FLOW.paused = flowScreen() === 'hu' && (scr === 'maps' || scr === 'ytm' || (g2('map_bg') && (g2('map_opacity') ?? 100) >= 100 && scr === 'home'));
  if (!FLOW.raf) { FLOW.last = 0; FLOW.raf = requestAnimationFrame(flowFrame); }
}

// A tap on the head unit sends a ripple out from under your finger, across every screen and the knob.
function flowTap(e) {
  if (flowScreen() !== 'hu' || !FLOW.scene || flowCfg().pulses === 'off') return;
  const now = Date.now();
  if (now - FLOW.lastTap < 350) return;
  FLOW.lastTap = now;
  const r = flowDash().hu, x = r[0] + (e.clientX / innerWidth) * r[2], y = r[1] + (e.clientY / innerHeight) * r[3];
  const id = `t${now}${Math.random().toString(36).slice(2, 6)}`;
  FLOW.seen.add(id);
  FLOW.pulses.push({ x, y, at: now, k: 1 });
  try { if (typeof send === 'function') send('flow_pulse', { id, x: Math.round(x), y: Math.round(y) }); } catch (er) { /* offline */ }
}
addEventListener('pointerdown', flowTap, { capture: true, passive: true });

// ---------------------------------------------------------------- the dash preview (Look > Dash)
// The whole dash to scale: the animation runs across it, with the three screens cut out of a dark dashboard.
// Drag a screen to move it; its position is saved to settings.dash (millimetres).
const FLOWPV = { gl: null, progs: {}, buf: null, raf: 0, el: null, last: 0, box: null, drag: null };
function flowBox() {
  const d = flowDash(), k = d.knob, xs = [d.cluster[0], d.hu[0], k[0] - k[2] / 2], ys = [d.cluster[1], d.hu[1], k[1] - k[2] / 2];
  const xe = [d.cluster[0] + d.cluster[2], d.hu[0] + d.hu[2], k[0] + k[2] / 2], ye = [d.cluster[1] + d.cluster[3], d.hu[1] + d.hu[3], k[1] + k[2] / 2];
  const x0 = Math.min(...xs) - 25, y0 = Math.min(...ys) - 25, x1 = Math.max(...xe) + 25, y1 = Math.max(...ye) + 25;
  return [x0, y0, x1 - x0, y1 - y0];
}
function flowPreview(el) {
  cancelAnimationFrame(FLOWPV.raf); FLOWPV.raf = 0;
  FLOWPV.el = el;
  if (!el) return;
  const glc = el.querySelector('canvas.dpv-gl');
  if (FLOWPV.canvas !== glc) {
    FLOWPV.canvas = glc; FLOWPV.progs = {};
    FLOWPV.gl = glc.getContext('webgl2', { antialias: false, alpha: false, depth: false });
    if (!FLOWPV.gl) return;
    const gl = FLOWPV.gl;
    FLOWPV.buf = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, FLOWPV.buf);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
    flowPreviewDrag(el);
  }
  const tick = (now) => {
    if (!FLOWPV.el || !document.body.contains(FLOWPV.el)) { FLOWPV.raf = 0; FLOWPV.el = null; return; }
    FLOWPV.raf = requestAnimationFrame(tick);
    if (now - FLOWPV.last < 45) return;                 // about 20 fps is plenty for a preview
    FLOWPV.last = now;
    const cw = el.clientWidth, box = flowBox(), ch = Math.round(cw * box[3] / box[2]);
    if (el.style.height !== `${ch}px`) el.style.height = `${ch}px`;
    FLOWPV.box = box;
    const w = Math.round(cw * 0.6), h = Math.round(ch * 0.6), c = FLOWPV.canvas;
    if (c.width !== w || c.height !== h) { c.width = w; c.height = h; }
    flowDraw(FLOWPV, flowCfg().scene, box, w, h);
    flowPreviewOverlay(el, box, cw, ch);
  };
  FLOWPV.raf = requestAnimationFrame(tick);
}
function flowPreviewOverlay(el, box, cw, ch) {
  const ov = el.querySelector('canvas.dpv-ov'), dpr = Math.min(2, devicePixelRatio || 1);
  if (ov.width !== Math.round(cw * dpr)) { ov.width = Math.round(cw * dpr); ov.height = Math.round(ch * dpr); }
  const g = ov.getContext('2d'), k = cw / box[2], d = flowDash(), on = flowCfg();
  g.setTransform(dpr, 0, 0, dpr, 0, 0); g.clearRect(0, 0, cw, ch);
  const X = (x) => (x - box[0]) * k, Y = (y) => (y - box[1]) * k;
  // the dashboard: everything except the screens
  g.save(); g.fillStyle = 'rgba(14,15,18,.86)'; g.beginPath(); g.rect(0, 0, cw, ch);
  for (const n of ['cluster', 'hu']) { const r = d[n]; g.rect(X(r[0]) + r[2] * k, Y(r[1]), -r[2] * k, r[3] * k); }
  const kn = d.knob; g.moveTo(X(kn[0]) + kn[2] * k / 2, Y(kn[1])); g.arc(X(kn[0]), Y(kn[1]), kn[2] * k / 2, 0, Math.PI * 2, true);
  g.fill('evenodd'); g.restore();
  const sel = FLOWPV.sel || '';
  const label = (t, x, y) => { g.font = '600 11px system-ui, sans-serif'; g.fillStyle = 'rgba(255,255,255,.75)'; g.fillText(t, x, y); };
  for (const [n, t] of [['cluster', 'Cluster'], ['hu', 'Head unit']]) {
    const r = d[n], off = on[n] === false;
    if (off) { g.fillStyle = 'rgba(0,0,0,.6)'; g.fillRect(X(r[0]), Y(r[1]), r[2] * k, r[3] * k); }
    g.strokeStyle = sel === n ? '#fff' : 'rgba(255,255,255,.35)'; g.lineWidth = sel === n ? 2.5 : 1.2;
    g.strokeRect(X(r[0]), Y(r[1]), r[2] * k, r[3] * k);
    label(off ? `${t} (off)` : t, X(r[0]) + 6, Y(r[1]) + r[3] * k + 14);
  }
  g.strokeStyle = sel === 'knob' ? '#fff' : 'rgba(255,255,255,.5)'; g.lineWidth = sel === 'knob' ? 2.5 : 1.5;
  g.beginPath(); g.arc(X(kn[0]), Y(kn[1]), kn[2] * k / 2 + 1, 0, Math.PI * 2); g.stroke();
  label(on.knob === false ? 'Knob (off)' : 'Knob', X(kn[0]) + kn[2] * k / 2 + 6, Y(kn[1]) + 4);
}
function flowPreviewDrag(el) {
  const toMm = (e) => { const r = el.getBoundingClientRect(), b = FLOWPV.box || flowBox(), k = b[2] / r.width; return [b[0] + (e.clientX - r.left) * k, b[1] + (e.clientY - r.top) * k]; };
  const hit = ([x, y]) => {
    const d = flowDash(), kn = d.knob;
    if (Math.hypot(x - kn[0], y - kn[1]) < kn[2] / 2 + 12) return 'knob';
    for (const n of ['hu', 'cluster']) { const r = d[n]; if (x > r[0] - 6 && x < r[0] + r[2] + 6 && y > r[1] - 6 && y < r[1] + r[3] + 6) return n; }
    return null;
  };
  el.addEventListener('pointerdown', (e) => {
    if (!el.hasAttribute('data-drag')) return;   // only the "Where your screens sit" picture moves screens
    const p = toMm(e), n = hit(p);
    if (!n) return;
    e.preventDefault(); e.stopPropagation();
    try { el.setPointerCapture(e.pointerId); } catch (er) { /* fine */ }
    FLOWPV.sel = n;
    FLOWPV.drag = { n, p, orig: flowDash()[n].slice(), box: FLOWPV.box };
    document.dispatchEvent(new CustomEvent('flowdash-select', { detail: n }));
  });
  el.addEventListener('pointermove', (e) => {
    const dr = FLOWPV.drag;
    if (!dr) return;
    const p = toMm(e), dx = p[0] - dr.p[0], dy = p[1] - dr.p[1];
    const v = dr.orig.slice(); v[0] = Math.round(dr.orig[0] + dx); v[1] = Math.round(dr.orig[1] + dy);
    const s = settings(); s.dash = Object.assign({}, flowDash(), { [dr.n]: v });
  });
  const end = (e) => {
    const dr = FLOWPV.drag;
    if (!dr) return;
    FLOWPV.drag = null;
    if (e && e.type === 'pointercancel') {   // the page scrolled instead: put the screen back, save nothing
      const st = settings(); st.dash = Object.assign({}, flowDash(), { [dr.n]: dr.orig });
      return;
    }
    try { if (typeof send === 'function') send('settings', { patch: { dash: { [dr.n]: flowDash()[dr.n] } } }); } catch (er) { /* offline */ }
  };
  el.addEventListener('pointerup', end); el.addEventListener('pointercancel', end);
}
