// In-page phone stream: the Pi relays Google Maps' video over /appws and it's decoded here
// (WebCodecs) onto a canvas inside #appArea, so it can have rounded corners, be cropped to just the
// map, and later sit under glass tiles. Touches on the canvas go back to the phone.
// If this screen can't decode the video, it tells the Pi, which falls back to the classic window.
(function () {
  let ws = null, dec = null, box = null, cv = null, ctx = null, fx = null, cfg = null, needKey = true, ts = 0;
  let vw = 0, vh = 0, crop = [0, 0], failed = false, retry = null;
  const ids = new Map(); // browser pointer id -> small finger number

  const app = () => (S.state && S.state.app) || {};
  const wanted = () => {
    const a = app();
    return !failed && !window.HU_PREVIEW && a.view === 'page' && a.current &&
      (a.status === 'starting' || a.status === 'running') && (window.streamArea ? streamArea() : document.getElementById('appArea'));
  };

  function fail(why) {
    if (failed) return;
    failed = true;
    console.warn('in-page stream:', why);
    send('app_view_fail', { why: String(why) });
    teardown();
  }

  function teardown() {
    if (ws) { ws.onclose = null; ws.close(); ws = null; }
    if (dec) { try { dec.close(); } catch (e) { /* already closed */ } dec = null; }
    if (fx) { fx.destroy(); fx = null; }
    if (box) { box.remove(); box = null; cv = null; ctx = null; }
    cfg = null; needKey = true; clearTimeout(retry);
  }

  function build() {
    box = document.createElement('div');
    box.className = 'appview';
    cv = document.createElement('canvas');
    box.appendChild(cv);
    // map looks (mapfx.js) draw through WebGL; it may swap in a fresh canvas when the look changes, so the
    // touch handlers sit on the box and always measure the current canvas
    if (window.MapFX) fx = MapFX.attach(cv, { style: MapFX.huStyle, amt: MapFX.huAmt, onswap: (n) => { cv = n; } });
    else ctx = cv.getContext('2d', { alpha: false, desynchronized: true });
    // touches go to the phone and nowhere else (no card tilt, no long-press menu)
    const pos = (e) => {
      const r = cv.getBoundingClientRect();
      return [Math.round(((e.clientX - r.left) / r.width) * vw), Math.round(((e.clientY - r.top) / r.height) * vh)];
    };
    const fwd = (a) => (e) => {
      e.stopPropagation(); e.preventDefault();
      if (!vw) return;
      if (a === 0) { try { box.setPointerCapture(e.pointerId); } catch (er) { /* fine */ } if (!ids.has(e.pointerId)) ids.set(e.pointerId, ids.size); }
      if (!ids.has(e.pointerId)) return;
      const [x, y] = pos(e);
      send('app_touch', { a, id: ids.get(e.pointerId), x: Math.max(0, Math.min(vw - 1, x)), y: Math.max(0, Math.min(vh - 1, y)), w: vw, h: vh });
      if (a === 1) ids.delete(e.pointerId);
    };
    box.addEventListener('pointerdown', fwd(0));
    box.addEventListener('pointermove', fwd(2));
    box.addEventListener('pointerup', fwd(1));
    box.addEventListener('pointercancel', fwd(1));
    ['click', 'contextmenu'].forEach((t) => box.addEventListener(t, (e) => { e.stopPropagation(); e.preventDefault(); }));
  }

  // the stream is taller than the frame when cropping: slide it up so only the map shows
  // When the stream isn't the box's shape (the Home card sharing the cluster's wide map) it fills the box and
  // the overflow is cut off, centered. Touches still land right: they're measured against the canvas itself.
  const puck = { at: 0, pos: null };
  const navFollow = () => S.screen === 'home' && !!(S.state && S.state.nav && S.state.nav.active);
  function layout() {
    if (!box || !vw) return;
    const bw = box.clientWidth, bh = box.clientHeight;
    // navigating on the Home card: keep the bottom (Google puts your position there) and follow the puck
    const follow = navFollow() && puck.pos;
    const low = follow && puck.pos.y > vh - crop[1] - 40;   // only un-trim the bottom when you're down there
    const sh = Math.max(1, vh - crop[0] - (low ? 0 : crop[1]));
    let k = bw / vw;
    if (bh && Math.abs(bw / bh - vw / sh) > 0.08) k = Math.max(bw / vw, bh / sh);
    let left = (bw - vw * k) / 2, top = -crop[0] * k + (bh ? (bh - sh * k) / 2 : 0);
    if (follow && bh) {
      const cl = (v, a, b) => Math.max(a, Math.min(b, v));
      left = cl(bw / 2 - puck.pos.x * k, bw - vw * k, 0);
      top = cl(bh * 0.62 - puck.pos.y * k, bh - (vh - (low ? 0 : crop[1])) * k, -crop[0] * k);
    }
    cv.classList.toggle('follow', !!follow);
    cv.style.width = `${vw * k}px`;
    cv.style.left = `${left}px`;
    cv.style.top = `${top}px`;
    cv.style.height = `${vh * k}px`;
  }

  function codecFrom(c) {
    for (let i = 0; i + 4 < c.length; i++) {
      if (c[i] === 0 && c[i + 1] === 0 && c[i + 2] === 1 && (c[i + 3] & 0x1f) === 7) {
        const h = (n) => n.toString(16).padStart(2, '0');
        return `avc1.${h(c[i + 4])}${h(c[i + 5])}${h(c[i + 6])}`;
      }
    }
    return 'avc1.42e01f';
  }

  async function configure(c) {
    cfg = c;
    if (!('VideoDecoder' in window)) return fail('no WebCodecs');
    const codec = codecFrom(c);
    try {
      const sup = await VideoDecoder.isConfigSupported({ codec, optimizeForLatency: true });
      if (!sup.supported) return fail(`codec ${codec} not supported`);
    } catch (e) { return fail(e); }
    if (dec) { try { dec.close(); } catch (e) { /* ignore */ } }
    dec = new VideoDecoder({
      output: (frame) => {
        if (cv) {
          if (cv.width !== frame.displayWidth || cv.height !== frame.displayHeight) {
            cv.width = frame.displayWidth; cv.height = frame.displayHeight;
            vw = frame.displayWidth; vh = frame.displayHeight; layout();
          }
          if (fx) fx.draw(frame); else ctx.drawImage(frame, 0, 0);
          if (navFollow() && window.MapFX && MapFX.findPuck && performance.now() - puck.at > 1500) {
            puck.at = performance.now();
            const p = MapFX.findPuck(frame);
            if (p) { puck.pos = p; puck.seen = puck.at; } else if (puck.at - (puck.seen || 0) > 10000) puck.pos = null;
            layout();
          } else if (!navFollow() && puck.pos) { puck.pos = null; layout(); }
          if (fx && fx.last) {
            const l = fx.last, sig = `${S.screen} ${l.st} ${l.mode} dark=${l.dark} land=${l.land} broken=${l.broken} r=${l.retries} ${l.w}x${l.h}`;
            if (sig !== window._mapfxSig) { window._mapfxSig = sig; send('mapfx_log', { sig }); }
          }
          box.classList.add('live');
        }
        frame.close();
      },
      error: (e) => { console.warn('decoder', e); needKey = true; },
    });
    dec.configure({ codec, optimizeForLatency: true });
    needKey = true;
  }

  function onPacket(buf) {
    const u = new Uint8Array(buf), kind = u[0], data = u.subarray(1);
    if (kind === 1) { configure(data.slice()); return; }
    if (!dec || dec.state !== 'configured') return;
    if (kind === 3 && needKey) return;
    if (dec.decodeQueueSize > 20) { needKey = true; if (kind === 3) return; } // falling behind: skip to the next key frame
    let chunk = data;
    if (kind === 2 && cfg) { chunk = new Uint8Array(cfg.length + data.length); chunk.set(cfg); chunk.set(data, cfg.length); }
    try {
      dec.decode(new EncodedVideoChunk({ type: kind === 2 ? 'key' : 'delta', timestamp: (ts += 16667), data: chunk }));
      if (kind === 2) needKey = false;
    } catch (e) { needKey = true; }
  }

  function connect() {
    ws = new WebSocket(`ws://${location.host}/appws`);
    ws.binaryType = 'arraybuffer';
    ws.onmessage = (m) => {
      if (typeof m.data === 'string') {
        const meta = JSON.parse(m.data);
        if (meta.type === 'meta') { vw = meta.w; vh = meta.h; crop = meta.crop || [0, 0]; layout(); }
        return;
      }
      onPacket(m.data);
    };
    ws.onclose = () => { ws = null; retry = setTimeout(sync, 1000); };
  }

  // called after every render and state update
  function sync() {
    const a = wanted();
    if (!a) { if (box || ws) teardown(); return; }
    if (!box) build();
    if (box.parentNode !== a) { a.appendChild(box); requestAnimationFrame(layout); }
    // Maps screen frame shape (map_shape_hu): only the frame changes, the canvas (and so touch mapping) doesn't
    const shp = a.id === 'appArea' && a.classList.contains('area') ? (settings().map_shape_hu || 'rect') : 'rect';
    if (box.dataset.shape !== shp) box.dataset.shape = shp;
    if (!ws) connect();
  }
  addEventListener('resize', () => requestAnimationFrame(layout));
  window.appView = { sync, back: () => send('app_key', { key: 'back' }) };
})();
