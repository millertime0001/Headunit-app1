// Preview mode (index.html?preview): the Theme Studio (web/theme) shows this page in a frame. There's no head
// unit behind it, so it gets made-up sample data instead of a connection, and the Studio sends it
// Looks to show. Does nothing on the real head unit.
(function () {
  if (!new URLSearchParams(location.search).has('preview')) return;
  window.HU_PREVIEW = true;
  document.addEventListener('DOMContentLoaded', () => document.body.classList.add('hu-preview'));
  const sample = {
    version: 'preview', phone: { connected: true, name: 'Galaxy Z Fold7' },
    media: { available: true, status: 'playing', title: 'This Cowboy\u2019s Hat', artist: 'Chris LeDoux', album: '', position: 64, duration: 214, at: Date.now() / 1000 },
    call: { available: true, state: null, name: '', number: '' },
    weather: { temp: 61, text: 'Sunny', hi: 66, lo: 45, day: true, place: 'Preview' },
    speed: { mps: 20, at: 9e12 }, app: { current: null, status: 'idle', message: '' },
    nav: { active: false }, adb: {}, companion: { connected: true }, knob: { connected: true },
    audio: { ready: true, volume: 40 }, bt: {}, look: null, look_preview: null,
    settings: { favorites: [{ name: 'Mom', number: '1' }, { name: 'Work', number: '2' }, { name: 'Home', number: '3' }], recents: [] },
  };
  let base = JSON.parse(JSON.stringify(sample.settings));
  window.WebSocket = class {
    constructor() {
      this.readyState = 1;
      setTimeout(() => { this.onopen && this.onopen(); this.onmessage && this.onmessage({ data: JSON.stringify({ type: 'state', state: sample }) }); }, 30);
    }
    send(text) { // taps inside the preview: keep setting changes local, ignore everything else
      try { const m = JSON.parse(text); if (m.cmd === 'settings') Object.assign(sample.settings, m.patch); } catch (e) { /* ignore */ }
    }
    close() {}
  };
  // the Theme Studio posts { type: 'look', look, set } whenever something changes (look = colors/vars/css/knob,
  // set = the look settings), and { type: 'go', screen }. The page gets it the way the car does: state.look_preview.
  addEventListener('message', (e) => {
    const m = e.data || {};
    if (m.type === 'look') {
      const lk = m.look || {}, set = m.set || {};
      const s = JSON.parse(JSON.stringify(base));
      for (const k in set) s[k] = set[k] && typeof set[k] === 'object' && !Array.isArray(set[k]) ? Object.assign({}, s[k] || {}, set[k]) : set[k];
      sample.settings = s;
      const pv = { id: 'preview', name: lk.name || 'Preview', colors: lk.colors || {}, vars: lk.vars || {}, css: lk.css || '', knob: lk.knob || null, set };
      sample.look_preview = pv;
      sample.look = { id: 'preview', name: pv.name, colors: pv.colors, vars: pv.vars, css_rev: 0, knob: pv.knob };
      if (typeof onState === 'function') onState(JSON.parse(JSON.stringify(sample)));
      if (typeof render === 'function') render(true); // a new style can change the markup
    } else if (m.type === 'go' && typeof go === 'function') {
      if (m.tab) S.lookTab = m.tab;
      go(m.screen);
    } else if (m.type === 'knob' && window.knobFx) {
      window.knobFx({ act: m.act || 'turn', dir: 1, vol: m.vol ?? 55 });
    }
  });
  addEventListener('load', () => { try { parent.postMessage({ type: 'preview-ready' }, '*'); } catch (e) { /* ignore */ } });
})();
