// Map looks: re-colors the Google Maps stream from the phone (a VideoFrame per decoded frame) on the GPU.
// One textured quad per frame through a small color-grading shader (WebGL2, else WebGL1); "Original" and
// intensity 0 use plain 2D drawImage, the cheapest path. If WebGL is missing or its context is lost it falls
// back to 2D too. A canvas can only ever have one kind of context, so switching between 2D and WebGL swaps in
// a fresh canvas (same class/style/size) and tells the owner through onswap.
//   const r = MapFX.attach(canvas, { style: () => id, amt: () => 0..100, onswap: (cv) => {} });
//   r.draw(frame, sx, sy, sw, sh, dx, dy, dw, dh);  r.clear(css);  r.destroy();
// Every style keeps Google's route visible: saturated blue (and vivid traffic colors) in the source are kept
// and boosted, and white pixels right next to the route (the turn arrow) stay white.
(function () {
  window.MAP_STYLES = [
    ['original', 'Original', 'Google Maps exactly as the phone draws it'],
    ['theme', 'Theme colors', 'The map re-painted in your theme: land, water and parks in its glow colors'],
    ['night', 'Night', 'Dark mode for a daytime map: inverted, colors kept'],
    ['neon', 'Neon', 'Black map, roads traced in glowing accent lines'],
    ['blueprint', 'Blueprint', 'Navy drafting paper, white line work, cyan route'],
    ['mono', 'Graphite', 'Quiet grayscale with the route in your accent color'],
    ['synthwave', 'Synthwave', 'Magenta roads, cyan route, faint scanlines'],
    ['thermal', 'Thermal', 'Heat camera: the route runs white-hot'],
  ];
  window.MAP_SHAPES = [
    ['rect', 'Panel', 'A plain rounded panel'],
    ['round', 'Soft', 'Big rounded corners, soft inner shadow'],
    ['circle', 'Porthole', 'A round map with a chrome, glowing ring'],
    ['fade', 'Melt', 'Edges fade into the animated background'],
    ['tilt', '3D tilt', 'Tilted back like a navigation view, fading at the horizon'],
  ];

  const S_IDS = new Set(window.MAP_STYLES.map((s) => s[0]));
  const cfg = () => { try { return (typeof settings === 'function' && settings()) || {}; } catch (e) { return {}; } };
  const huStyle = () => { const s = cfg().map_style; return S_IDS.has(s) ? s : 'original'; };
  const clusterStyle = () => { const s = (cfg().cluster || {}).map_style; return S_IDS.has(s) ? s : huStyle(); };
  const amtOf = (v) => (typeof v === 'number' && isFinite(v) ? Math.max(0, Math.min(100, v)) : 100);
  const huAmt = () => amtOf(cfg().map_fx_amt);
  const clusterAmt = () => { const c = cfg().cluster || {}; return amtOf(typeof c.map_fx_amt === 'number' ? c.map_fx_amt : cfg().map_fx_amt); };

  // ---------------------------------------------------------------- theme colors (CSS vars, re-read ~1/s)
  let colors = null, colorsAt = 0;
  function parseColor(s, def) {
    s = (s || '').trim();
    let m = /^#([0-9a-f]{3})$/i.exec(s);
    if (m) return [...m[1]].map((h) => parseInt(h + h, 16) / 255);
    m = /^#([0-9a-f]{6})/i.exec(s);
    if (m) return [0, 2, 4].map((i) => parseInt(m[1].substr(i, 2), 16) / 255);
    m = /rgba?\(\s*([\d.]+)[\s,]+([\d.]+)[\s,]+([\d.]+)/i.exec(s);
    if (m) return [m[1], m[2], m[3]].map((x) => +x / 255);
    return def;
  }
  function themeColors() {
    const now = performance.now();
    if (colors && now - colorsAt < 1000) return colors;
    colorsAt = now;
    const cs = getComputedStyle(document.documentElement), v = (k, d) => parseColor(cs.getPropertyValue(`--${k}`), d);
    colors = { A: v('accent', [0.37, 0.92, 0.83]), B1: v('b1', [0.08, 0.72, 0.65]), B2: v('b2', [0.49, 0.23, 0.93]),
      B3: v('b3', [0.05, 0.65, 0.91]), BASE: v('base', [0.02, 0.03, 0.04]) };
    return colors;
  }

  // ---------------------------------------------------------------- shaders
  const VS = `attribute vec2 p; uniform vec4 dst; uniform vec4 src; varying vec2 v;
void main(){ v = src.xy + p * src.zw; vec2 q = dst.xy + p * dst.zw; gl_Position = vec4(q.x * 2. - 1., 1. - q.y * 2., 0., 1.); }`;

  const PRE = `#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;   // uv offsets of a texel or two need it on the Pi's GPU
#else
precision mediump float;
#endif
varying vec2 v;
uniform sampler2D T;
uniform vec2 px;            // one source texel in uv
uniform float amt, dark, land;
uniform vec3 A, B1, B2, B3, BASE;
uniform sampler2D M;        // route mask, 1/4 size (max of each 4x4 block), so thin route outlines are never missed
uniform vec2 mpx;           // one mask texel in uv
uniform sampler2D G;        // the mask blurred at 1/16 size: route glow
float msk(vec2 o){ return texture2D(M, v + o * mpx).r; }
float lum(vec3 c){ return dot(c, vec3(.299, .587, .114)); }
float mx3(vec3 c){ return max(c.r, max(c.g, c.b)); }
float mn3(vec3 c){ return min(c.r, min(c.g, c.b)); }
vec3 tex(vec2 o){ return texture2D(T, v + o * px).rgb; }
// Google's route: saturated blue (day #1A73E8/#4285F4, night #669DF6) plus vivid traffic colors on it
float routeOf(vec3 c){
  float m = mx3(c), ch = m - mn3(c);
  return max(smoothstep(.17, .3, c.b - max(c.r, c.g)) * smoothstep(.3, .45, m) * smoothstep(.35, .5, ch),
             smoothstep(.58, .75, ch) * smoothstep(.45, .6, m));
}
vec3 boost(vec3 c){ return clamp(mix(vec3(lum(c)), c, 1.45) * 1.12 + .03, 0., 1.); }
float edge(){
  vec2 d = vec2(1.5, 0.);
  float a = lum(tex(d)), b = lum(tex(-d)), e = lum(tex(d.yx)), f = lum(tex(-d.yx));
  float g = length(vec2(a - b, e - f));
  // road/land edges glow; label edges don't (they'd smear the text): skip hard edges and anything next to text
  float near = mix(smoothstep(.72, .5, min(min(a, b), min(e, f))), smoothstep(.62, .8, max(max(a, b), max(e, f))), dark);
  return g * (1. - smoothstep(.16, .32, g)) * (1. - near);
}
vec3 c; float L, Ld, rt, wat, grn, yel, road, ink, bld;
// paint the map's parts in a palette: land, buildings, parks, water, highways, roads, labels
vec3 paint(vec3 bg, vec3 bd, vec3 park, vec3 water, vec3 hwy, vec3 rd, vec3 txt){
  vec3 o = mix(bg, bd, bld);
  o = mix(o, park, grn); o = mix(o, water, wat); o = mix(o, hwy, yel); o = mix(o, rd, road); o = mix(o, txt, ink);
  return o;
}
`;
  const MAIN = (body) => `
void main(){
  c = texture2D(T, v).rgb;
  L = lum(c); Ld = mix(L, 1. - L, dark);
  rt = routeOf(c);
  wat = smoothstep(.05, .12, c.b - max(c.r, c.g)) * (1. - rt);
  grn = smoothstep(.025, .07, c.g - max(c.r, c.b)) * (1. - rt);
  yel = smoothstep(.1, .22, min(c.r, c.g) - c.b) * (1. - rt);
  float chr = mx3(c) - mn3(c);
  // day map: roads are whiter than the land, labels dark; night map: roads a bit lighter, labels light
  float rDay = smoothstep(land + .006, min(land + .03, .996), L);
  float rNight = smoothstep(land + .04, land + .12, L) * smoothstep(.8, .66, L);
  road = mix(rDay, rNight, dark) * (1. - yel) * (1. - smoothstep(.08, .2, chr));
  ink = mix(smoothstep(.78, .42, L), smoothstep(.62, .82, L), dark) * (1. - rt);
  bld = smoothstep(land - .012, land - .035, L) * (1. - dark) * (1. - ink);
  // the white turn arrow (and the you-are-here puck) sit on the route: a white pixel with route on BOTH sides of
  // it along some direction stays white. Roads that merely touch the route don't (they only hit it on one side).
  float arrow = 0.;
  float wh = mix(smoothstep(land + .012, land + .035, L), smoothstep(.8, .9, L), dark) * (1. - smoothstep(.06, .14, chr));
  if (wh > .01) {
    float sw = 0.;
    for (int i = 0; i < 4; i++) {
      vec2 d = i == 0 ? vec2(1., 0.) : i == 1 ? vec2(0., 1.) : i == 2 ? vec2(.7, .7) : vec2(.7, -.7);
      float a = max(max(msk(d * 1.5), msk(d * 3.5)), max(msk(d * 6.), msk(d * 10.)));
      float b = max(max(msk(-d * 1.5), msk(-d * 3.5)), max(msk(-d * 6.), msk(-d * 10.)));
      sw = max(sw, min(a, b));
    }
    arrow = wh * smoothstep(.12, .4, sw);
  }
  // soft glow around the route, for the styles that want one
  float halo = texture2D(G, v).r;
  vec3 g, rc, gc = vec3(0.);
  ${body}
  g += gc * halo * (1. - rt);
  g = mix(g, rc, rt);
  g = mix(g, vec3(1.), arrow);
  gl_FragColor = vec4(mix(c, g, amt), 1.);
}`;

  const BODY = {
    theme: `
  vec3 bg = mix(BASE, B1, .12) + .035;
  g = paint(bg, bg * .8, mix(bg, B2, .3), mix(BASE * .5, B3, .34), mix(bg, mix(B2, A, .4), .6), mix(bg, B1, .42) + .1, mix(vec3(1.), A, .25));
  rc = boost(c);
  gc = A * .35;`,
    night: `
  float f = .07 + (1. - L) * .85;          // light land -> dark, dark labels -> light, hue kept
  f = mix(f, .21, road);                    // roads a touch lighter than the land, like Google's own night map
  g = clamp(vec3(f) + (c - vec3(L)) * 1.3, 0., 1.);
  // already a night map (Google's own navy one, e.g. on the small Home map): re-paint it in the same palette
  // a day map gets above, so Night looks the same on every screen
  // (its navy land would read as water, so go by brightness: land -> the same gray, roads/labels keep their lift)
  vec3 gd = clamp(vec3(.087 + max(L - .17, 0.) * 1.05) + (c - vec3(L)) * .3, 0., 1.);
  gd = mix(gd, vec3(.03, .2, .06), grn * .8);
  gd = mix(gd, vec3(.31, .19, .03), yel * .8);
  g = mix(g, gd, dark);
  rc = boost(c);`,
    neon: `
  float e = smoothstep(.015, .07, edge()) * (1. - ink);
  vec3 bg = BASE * .45 + .012;
  g = paint(bg, bg * .6 + .008, mix(bg, B2, .13), mix(bg, B3, .16) * .8, mix(bg, B2, .32), mix(bg, A, .16), vec3(.93));
  g += A * e * 1.15;
  rc = boost(c) * 1.1 + vec3(.04, .08, .2);
  gc = vec3(.15, .45, 1.) * .9;`,
    blueprint: `
  float e = smoothstep(.015, .07, edge()) * (1. - ink);
  vec2 q = gl_FragCoord.xy;
  vec3 bg = vec3(.035, .16, .36) + (step(mod(q.x, 48.), 1.) + step(mod(q.y, 48.), 1.)) * .05
          + (step(mod(q.x, 12.), .7) + step(mod(q.y, 12.), .7)) * .015;
  g = paint(bg, bg * .86, bg + vec3(0., .035, .02), vec3(.02, .1, .24), bg + vec3(.13, .15, .16), bg + vec3(.05, .09, .13), vec3(.93, .97, 1.));
  g += vec3(.72, .87, 1.) * e * .85;
  rc = mix(vec3(.45, 1., 1.), vec3(1.), .12) * (.62 + .45 * mx3(c));
  gc = vec3(.3, .9, 1.) * .5;`,
    mono: `
  g = paint(vec3(.115), vec3(.09), vec3(.145), vec3(.06), vec3(.33), vec3(.25), vec3(.9));
  vec3 a = mix(vec3(lum(A)), A, 1.25);
  if (lum(a) < .32) a = mix(a, vec3(1.), .45);   // a very dark accent would vanish on graphite
  rc = clamp(a * (.55 + .6 * mx3(c)), 0., 1.);`,
    synthwave: `
  float e = smoothstep(.015, .07, edge()) * (1. - ink);
  vec3 bg = mix(vec3(.07, .0, .14), vec3(.18, .02, .2), v.y);
  g = paint(bg, bg * .8, bg + vec3(.0, .04, .05), vec3(.03, .02, .14), vec3(.0, .72, .85) * .85, vec3(1., .2, .74) * .6, vec3(1., .9, 1.));
  g += vec3(1., .24, .78) * e * .6;
  rc = vec3(.18, .95, 1.) * (.6 + .5 * mx3(c));
  gc = vec3(.1, .8, 1.) * .8;
  g *= .84 + .16 * step(1., mod(gl_FragCoord.y, 3.));`,
    thermal: `
  float t = paint(vec3(.17), vec3(.12), vec3(.3), vec3(.05), vec3(.6), vec3(.45), vec3(.76)).x;
  t += smoothstep(.015, .07, edge()) * (1. - ink) * .08;
  vec3 h = mix(vec3(0.), vec3(.12, .0, .38), smoothstep(.0, .2, t));
  h = mix(h, vec3(.55, .0, .6), smoothstep(.2, .4, t));
  h = mix(h, vec3(.95, .13, .15), smoothstep(.4, .6, t));
  h = mix(h, vec3(1., .6, .0), smoothstep(.6, .8, t));
  g = mix(h, vec3(1., 1., .82), smoothstep(.8, 1., t));
  rc = mix(vec3(1., .85, .3), vec3(1.), smoothstep(.4, .9, mx3(c)));
  gc = vec3(1., .45, .05) * .8;`,
  };
  // pass 1: the route mask at 1/4 size
  const MASK = `void main(){
  float m = 0.;
  for (int i = 0; i < 4; i++) for (int j = 0; j < 4; j++) m = max(m, routeOf(tex(vec2(float(i), float(j)) - 1.5)));
  gl_FragColor = vec4(m);
}`;
  const BLUR = `void main(){
  float m = 0.;
  for (int i = 0; i < 4; i++) for (int j = 0; j < 4; j++) m += texture2D(T, v + (vec2(float(i), float(j)) - 1.5) * px).r;
  gl_FragColor = vec4(min(1., m / 8.));
}`;
  const PASS = 'void main(){ gl_FragColor = vec4(texture2D(T, v).rgb, 1.); }';

  // ---------------------------------------------------------------- renderer
  function attach(canvas, opts = {}) {
    const r = { canvas, style: 'original', amt: 100, mode: '', gl: null, ctx: null, progs: {}, tex: null, buf: null,
      dark: 0, land: 0.95, probeAt: -1e9, glBroken: false, destroyed: false };
    const want = () => {
      const st = opts.style ? opts.style() : r.style, am = opts.amt ? opts.amt() : r.amt;
      return { st: S_IDS.has(st) ? st : 'original', am: amtOf(am) / 100 };
    };

    function swap(mode) {
      const old = r.canvas;
      if (r.mode) {   // a canvas keeps its first context forever: start over on a fresh one
        const n = document.createElement('canvas');
        n.className = old.className; n.style.cssText = old.style.cssText; n.width = old.width; n.height = old.height;
        if (old.id) { n.id = old.id; old.removeAttribute('id'); }
        old.replaceWith(n);
        if (r.gl) { try { const x = r.gl.getExtension('WEBGL_lose_context'); if (x) x.loseContext(); } catch (e) { /* gone */ } }
        r.canvas = n;
      }
      r.gl = null; r.ctx = null; r.progs = {}; r.tex = null; r.buf = null; r.mt = null; r.gt = null; r.mw = 0; r.mh = 0;
      if (mode === 'gl') {
        const o = { alpha: false, antialias: false, depth: false, stencil: false, desynchronized: !opts.sync, premultipliedAlpha: false,
          preserveDrawingBuffer: false, powerPreference: 'low-power' };
        r.gl = r.canvas.getContext('webgl2', o) || r.canvas.getContext('webgl', o);
        if (!r.gl) { r.glBroken = true; mode = '2d'; }
        else {
          r.canvas.addEventListener('webglcontextlost', (e) => { e.preventDefault(); r.glBroken = true; }, { once: true });
          if (!setupGL()) { r.glBroken = true; mode = '2d'; swapTo2d(); }
        }
      }
      if (mode === '2d' && !r.ctx) r.ctx = r.canvas.getContext('2d', { alpha: false, desynchronized: !opts.sync });
      r.mode = mode;
      if (r.canvas !== old && opts.onswap) opts.onswap(r.canvas);
    }
    function swapTo2d() {   // the GL context came up but is useless: a new canvas for 2D
      const old = r.canvas, n = document.createElement('canvas');
      n.className = old.className; n.style.cssText = old.style.cssText; n.width = old.width; n.height = old.height;
      if (old.id) { n.id = old.id; old.removeAttribute('id'); }
      old.replaceWith(n); r.canvas = n; r.gl = null;
    }

    function setupGL() {
      const gl = r.gl;
      r.buf = gl.createBuffer();
      gl.bindBuffer(gl.ARRAY_BUFFER, r.buf);
      gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([0, 0, 1, 0, 0, 1, 1, 1]), gl.STATIC_DRAW);
      r.tex = gl.createTexture();
      gl.bindTexture(gl.TEXTURE_2D, r.tex);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
      gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false);
      gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, false);
      return !!prog('original');
    }
    function prog(id) {
      if (r.progs[id] !== undefined) return r.progs[id];
      const gl = r.gl, sh = (type, src) => {
        const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s);
        if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) { console.warn('mapfx shader', id, gl.getShaderInfoLog(s)); return null; }
        return s;
      };
      const fs = PRE + (id === 'original' ? PASS : id === 'mask' ? MASK : id === 'blur' ? BLUR : MAIN(BODY[id]));
      const v = sh(gl.VERTEX_SHADER, VS), f = sh(gl.FRAGMENT_SHADER, fs);
      let p = null;
      if (v && f) {
        p = gl.createProgram(); gl.attachShader(p, v); gl.attachShader(p, f);
        gl.bindAttribLocation(p, 0, 'p'); gl.linkProgram(p);
        if (!gl.getProgramParameter(p, gl.LINK_STATUS)) { console.warn('mapfx link', id, gl.getProgramInfoLog(p)); p = null; }
      }
      if (p) {
        const u = {};
        ['dst', 'src', 'px', 'amt', 'dark', 'land', 'A', 'B1', 'B2', 'B3', 'BASE', 'T', 'M', 'mpx', 'G'].forEach((k) => { u[k] = gl.getUniformLocation(p, k); });
        p.u = u;
      }
      r.progs[id] = p;
      return p;
    }

    // a render target texture on its own texture unit
    function target(key, unit, w, h) {
      const gl = r.gl;
      let t = r[key];
      if (!t) {
        t = r[key] = { tex: gl.createTexture(), fbo: gl.createFramebuffer(), w: 0, h: 0 };
        gl.activeTexture(gl.TEXTURE0 + unit); gl.bindTexture(gl.TEXTURE_2D, t.tex);
        [[gl.TEXTURE_MIN_FILTER, gl.LINEAR], [gl.TEXTURE_MAG_FILTER, gl.LINEAR], [gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE], [gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE]]
          .forEach(([k, v]) => gl.texParameteri(gl.TEXTURE_2D, k, v));
      }
      gl.activeTexture(gl.TEXTURE0 + unit); gl.bindTexture(gl.TEXTURE_2D, t.tex);
      if (t.w !== w || t.h !== h) {
        t.w = w; t.h = h;
        gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, w, h, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
        gl.bindFramebuffer(gl.FRAMEBUFFER, t.fbo);
        gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, t.tex, 0);
      }
      gl.bindFramebuffer(gl.FRAMEBUFFER, t.fbo);
      gl.viewport(0, 0, w, h);
      return t;
    }
    function pass(p, fromUnit, w, h) {
      const gl = r.gl;
      gl.useProgram(p);
      gl.uniform4f(p.u.dst, 0, 1, 1, -1);   // row 0 = top of the picture, so it shares the frame's uv
      gl.uniform4f(p.u.src, 0, 0, 1, 1);
      gl.uniform2f(p.u.px, 1 / w, 1 / h);
      gl.uniform1i(p.u.T, fromUnit);
      gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
    }
    // pass 1: route mask (max of each 4x4 block), 1/4 size, unit 1. pass 2: its 4x4 average, 1/16 size, unit 2:
    // bilinear-stretched back up, that's a soft glow around the route for almost nothing
    function maskPass(fw, fh) {
      const gl = r.gl, mp = prog('mask'), bp = prog('blur');
      if (!mp || !bp) return;
      const m = target('mt', 1, Math.ceil(fw / 4), Math.ceil(fh / 4));
      pass(mp, 0, fw, fh);
      target('gt', 2, Math.ceil(m.w / 4), Math.ceil(m.h / 4));
      pass(bp, 1, m.w, m.h);
      gl.bindFramebuffer(gl.FRAMEBUFFER, null);
      gl.activeTexture(gl.TEXTURE0);
      r.mw = m.w; r.mh = m.h;
    }

    // every 2 s: is the phone's map a day or a night map, and how light is its land (a 32x18 peek, not per frame)
    let pc = null;
    function probe(src, sx, sy, sw, sh) {
      const now = performance.now();
      if (now - r.probeAt < 2000) return;
      r.probeAt = now;
      try {
        if (!pc) { pc = document.createElement('canvas'); pc.width = 32; pc.height = 18; pc.g = pc.getContext('2d', { willReadFrequently: true }); }
        pc.g.drawImage(src, sx, sy, sw, sh, 0, 0, 32, 18);
        const d = pc.g.getImageData(0, 0, 32, 18).data, ls = [];
        for (let i = 0; i < d.length; i += 4) {
          const R = d[i] / 255, G = d[i + 1] / 255, B = d[i + 2] / 255;
          if (Math.max(R, G, B) - Math.min(R, G, B) < 0.12) ls.push(0.299 * R + 0.587 * G + 0.114 * B);
        }
        if (ls.length < 40) return;
        ls.sort((a, b) => a - b);
        const med = ls[ls.length >> 1];
        r.dark = med < 0.45 ? 1 : 0;
        r.land = med;
      } catch (e) { /* tainted or not ready: keep the last guess */ }
    }

    r.draw = (frame, sx, sy, sw, sh, dx, dy, dw, dh) => {
      if (r.destroyed) return;
      const { st, am } = want();
      const fw = frame.displayWidth || frame.videoWidth || frame.width, fh = frame.displayHeight || frame.videoHeight || frame.height;
      if (sw === undefined) { sx = 0; sy = 0; sw = fw; sh = fh; }
      if (dw === undefined) { dx = 0; dy = 0; dw = r.canvas.width; dh = r.canvas.height; }
      if (r.glBroken && performance.now() - (r.brokeAt || (r.brokeAt = performance.now())) > 5000) { r.glBroken = false; r.brokeAt = 0; r.retries = (r.retries || 0) + 1; }
      r.last = { st, am, dark: r.dark, land: +r.land.toFixed(2), mode: r.mode, broken: r.glBroken, retries: r.retries || 0, w: fw, h: fh };
      const fx = st !== 'original' && am > 0.004 && !r.glBroken;
      const mode = fx ? 'gl' : '2d';
      if (r.mode !== mode || (r.mode === 'gl' && r.glBroken)) swap(r.glBroken ? '2d' : mode);
      if (r.mode === '2d') { r.ctx.drawImage(frame, sx, sy, sw, sh, dx, dy, dw, dh); return; }
      const gl = r.gl, p = prog(st) || prog('original');
      if (!p) { r.glBroken = true; return; }
      probe(frame, sx, sy, sw, sh);
      const W = r.canvas.width, H = r.canvas.height;
      gl.bindBuffer(gl.ARRAY_BUFFER, r.buf);
      gl.enableVertexAttribArray(0);
      gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);
      gl.activeTexture(gl.TEXTURE0);
      gl.bindTexture(gl.TEXTURE_2D, r.tex);
      try { gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, frame); } catch (e) { r.glBroken = true; return; }
      if (st !== 'original') maskPass(fw, fh);
      gl.viewport(0, 0, W, H);
      gl.useProgram(p);
      const u = p.u, k = themeColors();
      gl.uniform4f(u.dst, dx / W, dy / H, dw / W, dh / H);
      gl.uniform4f(u.src, sx / fw, sy / fh, sw / fw, sh / fh);
      if (u.px) gl.uniform2f(u.px, 1 / fw, 1 / fh);
      if (u.amt) gl.uniform1f(u.amt, am);
      if (u.dark) gl.uniform1f(u.dark, r.dark);
      if (u.land) gl.uniform1f(u.land, r.dark ? r.land : Math.max(0.86, Math.min(0.975, r.land)));
      for (const n of ['A', 'B1', 'B2', 'B3', 'BASE']) if (u[n]) gl.uniform3fv(u[n], k[n]);
      gl.uniform1i(u.T, 0);
      if (u.M) gl.uniform1i(u.M, 1);
      if (u.G) gl.uniform1i(u.G, 2);
      if (u.mpx) gl.uniform2f(u.mpx, 1 / r.mw, 1 / r.mh);
      gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
    };
    // fill the whole canvas with one color (letterboxing)
    r.clear = (css = '#0b0d10') => {
      if (r.destroyed || !r.mode) return;
      if (r.mode === '2d') { r.ctx.fillStyle = css; r.ctx.fillRect(0, 0, r.canvas.width, r.canvas.height); return; }
      const c = parseColor(css, [0.04, 0.05, 0.06]);
      r.gl.viewport(0, 0, r.canvas.width, r.canvas.height);
      r.gl.clearColor(c[0], c[1], c[2], 1); r.gl.clear(r.gl.COLOR_BUFFER_BIT);
    };
    r.destroy = () => {
      r.destroyed = true;
      if (r.gl) { try { const x = r.gl.getExtension('WEBGL_lose_context'); if (x) x.loseContext(); } catch (e) { /* gone */ } }
      r.gl = null; r.ctx = null;
    };
    return r;
  }

  // ---------------------------------------------------------------- a made-up Google-Maps-like picture
  // Used by the cluster's settings preview (no phone stream there) and for thumbnails of the styles.
  function sample(w = 640, h = 360, night = false) {
    const cv = document.createElement('canvas'); cv.width = w; cv.height = h;
    const g = cv.getContext('2d'), s = Math.min(w, h) / 360;
    const P = night ? { land: '#1f2835', bld: '#273141', park: '#1d3a2c', water: '#0e1a2e', road: '#3c4a60', casing: '#2a3446',
      hwy: '#7a6a3a', text: '#c8d0dc', halo: '#1f2835', route: '#669df6', rcase: '#3367d6' }
      : { land: '#f1f3f4', bld: '#e3e5e8', park: '#c8e6c9', water: '#aadaff', road: '#ffffff', casing: '#dadce0',
        hwy: '#fde293', text: '#3c4043', halo: '#ffffff', route: '#4285f4', rcase: '#1967d2' };
    g.fillStyle = P.land; g.fillRect(0, 0, w, h);
    g.fillStyle = P.water; g.beginPath(); g.moveTo(w * 0.7, 0); g.bezierCurveTo(w * 0.62, h * 0.3, w * 0.9, h * 0.45, w * 0.82, h); g.lineTo(w, h); g.lineTo(w, 0); g.fill();
    g.fillStyle = P.park; g.beginPath(); g.ellipse(w * 0.2, h * 0.28, w * 0.12, h * 0.14, 0.3, 0, 7); g.fill();
    g.fillRect(w * 0.48, h * 0.62, w * 0.1, h * 0.2);
    g.fillStyle = P.bld;
    for (let i = 0; i < 26; i++) { const x = ((i * 97) % 61) / 61 * w * 0.65, y = ((i * 53) % 47) / 47 * h; g.fillRect(x, y, 14 * s, 10 * s); }
    const line = (pts, wd, col) => { g.strokeStyle = col; g.lineWidth = wd * s; g.lineCap = 'round'; g.lineJoin = 'round'; g.beginPath(); pts.forEach(([x, y], i) => (i ? g.lineTo(x * w, y * h) : g.moveTo(x * w, y * h))); g.stroke(); };
    const roads = [[[0, 0.5], [1, 0.42]], [[0.35, 0], [0.4, 1]], [[0, 0.82], [0.7, 0.75]], [[0.12, 0], [0.18, 1]], [[0.55, 0], [0.6, 0.6], [0.66, 1]], [[0, 0.16], [0.68, 0.2]]];
    roads.forEach((r) => line(r, 9, P.casing)); roads.forEach((r) => line(r, 7, P.road));
    const hw = [[0, 0.66], [0.3, 0.6], [0.62, 0.3], [1, 0.25]];
    line(hw, 13, night ? '#5c5030' : '#f0c75e'); line(hw, 10, P.hwy);
    const route = [[0.37, 1], [0.375, 0.47], [0.6, 0.44], [0.62, 0.3], [0.8, 0.27], [1, 0.25]];
    line(route, 12, P.rcase); line(route, 9, P.route);
    line([[0.6, 0.44], [0.62, 0.3]], 9, '#f29900');                    // a bit of traffic
    // the white turn arrow at the next turn
    g.save(); g.translate(0.375 * w, 0.5 * h); g.fillStyle = '#fff'; g.strokeStyle = P.rcase; g.lineWidth = 2 * s;
    g.beginPath(); g.moveTo(-5 * s, 34 * s); g.lineTo(-5 * s, 4 * s); g.lineTo(22 * s, 4 * s); g.lineTo(22 * s, -6 * s); g.lineTo(40 * s, 9 * s);
    g.lineTo(22 * s, 24 * s); g.lineTo(22 * s, 14 * s); g.lineTo(5 * s, 14 * s); g.lineTo(5 * s, 34 * s); g.closePath(); g.fill(); g.stroke(); g.restore();
    // you-are-here puck
    g.fillStyle = P.rcase; g.beginPath(); g.arc(0.375 * w, 0.88 * h, 11 * s, 0, 7); g.fill();
    g.fillStyle = '#fff'; g.beginPath(); g.arc(0.375 * w, 0.88 * h, 7 * s, 0, 7); g.fill();
    g.fillStyle = P.route; g.beginPath(); g.arc(0.375 * w, 0.88 * h, 5 * s, 0, 7); g.fill();
    g.font = `500 ${13 * s}px Roboto, Arial, sans-serif`; g.lineWidth = 3 * s; g.strokeStyle = P.halo; g.fillStyle = P.text;
    [['Main St', 0.06, 0.48], ['Oak Ave', 0.41, 0.95], ['Riverside Park', 0.1, 0.3], ['I-5', 0.22, 0.6]].forEach(([t, x, y]) => { g.strokeText(t, x * w, y * h); g.fillText(t, x * w, y * h); });
    g.fillStyle = night ? '#7aa7d6' : '#1a73e8'; g.font = `italic ${13 * s}px Roboto, Arial, sans-serif`; g.fillText('Lake Union', 0.84 * w, 0.62 * h);
    return cv;
  }

  // ---------------------------------------------------------------- where you are on the map
  // While navigating, Google puts your position (a big blue dot with a halo, or the blue arrow) low in the picture,
  // and the panels that trim the map would cut it off. findPuck() looks for it: the most solidly blue patch the size
  // of the puck (the route line is blue too, but thin). Checked on a quarter-size copy. Returns {x, y} in frame
  // pixels, or null.
  let pk = null;
  function findPuck(frame) {
    const fw = frame.displayWidth || frame.width, fh = frame.displayHeight || frame.height;
    if (!fw || !fh) return null;
    const w = Math.max(32, Math.round(fw / 4)), h = Math.max(32, Math.round(fh / 4));
    if (!pk) { pk = document.createElement('canvas'); pk.g = pk.getContext('2d', { willReadFrequently: true }); }
    if (pk.width !== w || pk.height !== h) { pk.width = w; pk.height = h; }
    try { pk.g.drawImage(frame, 0, 0, w, h); } catch (e) { return null; }
    const d = pk.g.getImageData(0, 0, w, h).data, W1 = w + 1;
    const I = new Int32Array(W1 * (h + 1)), Wt = new Int32Array(W1 * (h + 1));   // running sums: blue, white
    for (let y = 0; y < h; y++) {
      let row = 0, roww = 0;
      for (let x = 0; x < w; x++) {
        const i = (y * w + x) * 4, r = d[i], g = d[i + 1], b = d[i + 2];
        row += b > 150 && b - Math.max(r, g) > 45 && b - r > 70 ? 1 : 0;      // Google's puck blue, not cyan routes
        roww += r > 215 && g > 215 && b > 215 ? 1 : 0;
        I[(y + 1) * W1 + x + 1] = I[y * W1 + x + 1] + row;
        Wt[(y + 1) * W1 + x + 1] = Wt[y * W1 + x + 1] + roww;
      }
    }
    const box = (A, x, y, r) => A[(y + r + 1) * W1 + x + r + 1] - A[(y - r) * W1 + x + r + 1] - A[(y + r + 1) * W1 + x - r] + A[(y - r) * W1 + x - r];
    const R = Math.max(4, Math.round(Math.min(fw, fh) / 4 / 50));          // puck halo radius at this scale
    // the puck: a solid white dot (center 3x3 nearly all white) inside a solidly blue ring; text in blue
    // bubbles is too thin to make a solid white 3x3, and route lines are too thin to fill the ring
    let best = 0, bx = 0, by = 0;
    for (let y = R; y < h - R; y++) for (let x = R; x < w - R; x++) {
      if (box(Wt, x, y, 1) < 8) continue;
      const n = box(I, x, y, R);
      if (n > best) { best = n; bx = x; by = y; }
    }
    return best >= (2 * R + 1) * (2 * R + 1) * 0.3 ? { x: bx * fw / w, y: by * fh / h } : null;
  }

  window.MapFX = { attach, sample, huStyle, clusterStyle, huAmt, clusterAmt, themeColors, findPuck };
})();
