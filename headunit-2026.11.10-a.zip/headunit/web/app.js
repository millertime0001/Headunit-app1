/* Pi Head Unit UI. Talks to the backend over a WebSocket at /ws. */
'use strict';

// ================================================================ tables
let THEMES = [];      // web/themes.json
let FACES = [];       // web/knob_faces.json (same order as the knob firmware)
const EFFECTS = [
  ['blobs', 'Lava lamp', 'Soft color blobs'], ['liquid', 'Liquid glass', 'Melting color under glass'],
  ['aurora', 'Aurora', 'Ribbons of light'], ['nebula', 'Nebula', 'Drifting space clouds'],
  ['road', 'Night highway', 'Lane lines rushing by'], ['warp', 'Warp speed', 'Stars stream past'],
  ['grid', 'Synthwave', 'Retro sun and grid'], ['tunnel', 'Tunnel', 'Flying through rings'],
  ['window', 'Rainy window', 'City lights through wet glass; drops run over the tiles too'], ['rain', 'Rain on glass', 'Drops sliding down'], ['bokeh', 'City bokeh', 'Blurry lights at night'],
  ['particles', 'Constellation', 'Linked floating dots'], ['fireflies', 'Fireflies', 'Glowing specks'],
  ['waves', 'Waves', 'Layered rolling waves'], ['hex', 'Hex pulse', 'Honeycomb that breathes'],
  ['matrix', 'Code rain', 'Falling green symbols'],
  ['slime', 'Oozing slime', 'Goo drips from the top and splats into a pool'], ['goo', 'Goo lamp', 'Blobs that stretch, merge and split'],
  ['plasma', 'Plasma', 'Swirling liquid color'], ['embers', 'Embers', 'Sparks rising from a fire'],
  ['snow', 'Snowfall', 'Flakes drifting in the wind'], ['storm', 'Thunderstorm', 'Rain with lightning flashes'],
  ['pond', 'Rain on a pond', 'Rings spreading on water'], ['circuit', 'Circuit board', 'Pulses racing along traces'],
  ['galaxy', 'Galaxy', 'A slowly turning spiral'], ['smoke', 'Smoke', 'Soft colored haze rising'],
  ['petals', 'Falling petals', 'Leaves tumbling down'], ['lasers', 'Laser show', 'Beams sweeping to the beat'],
  ['skyline', 'City skyline', 'Buildings that light up with music'], ['dna', 'Double helix', 'A spinning DNA strand'],
  ['radar', 'Radar', 'A sweep that finds blips'], ['kaleido', 'Kaleidoscope', 'Mirrored shapes turning'],
  ['fireworks', 'Fireworks', 'Rockets bursting overhead'], ['underwater', 'Underwater', 'Light rays and rising bubbles'],
  ['off', 'Still', 'No movement'],
];
const LAYOUTS = {
  dashboard: { name: 'Dashboard', slots: 2, wire: ['h h', 'a b'], rows: '1fr 2fr' },
  cockpit: { name: 'Cockpit', slots: 3, wire: ['a b c'], rows: '1fr' },
  focus: { name: 'Focus', slots: 3, wire: ['a b', 'a c'], rows: '1fr 1fr' },
  grid: { name: 'Grid', slots: 4, wire: ['a b', 'c d'], rows: '1fr 1fr' },
  duo: { name: 'Duo', slots: 2, wire: ['a b'], rows: '1fr' },
  minimal: { name: 'Minimal', slots: 0, wire: ['h'], rows: '1fr' },
  free: { name: 'Freeform (edit it yourself)', slots: 0, wire: ['a a b', 'c d e'], rows: '1.4fr 1fr' },
  // Built from their wireframe: each letter is a spot, in order (a = spot 1). cols/rows size the grid.
  wide: { name: 'Widescreen', gen: true, slots: 3, wire: ['a a b', 'a a c'], cols: '1.25fr 1.25fr 1fr', rows: '1fr 1fr' },
  strip: { name: 'Hero strip', gen: true, slots: 4, wire: ['a a a', 'b c d'], cols: '1fr 1fr 1fr', rows: '1.7fr 1fr' },
  sidebar: { name: 'Sidebar', gen: true, slots: 4, wire: ['b a a', 'c a a', 'd a a'], cols: '1fr 1.3fr 1.3fr', rows: '1fr 1fr 1fr' },
  bento: { name: 'Bento box', gen: true, slots: 4, wire: ['a b b', 'a c d'], cols: '1.2fr 1fr 1fr', rows: '1fr 1fr' },
  mosaic: { name: 'Mosaic', gen: true, slots: 5, wire: ['a a b', 'a a c', 'd e c'], cols: '1fr 1fr 1fr', rows: '1fr 1fr 1fr' },
  cinema: { name: 'Cinema', gen: true, slots: 3, wire: ['a a a', 'b c c'], cols: '1fr 1fr 1fr', rows: '2.6fr 1fr' },
  cluster: { name: 'Gauge cluster', gen: true, slots: 3, wire: ['a b c'], cols: '1fr 1.25fr 1fr', rows: '1fr', fancy: 'Round dials like a dashboard' },
  orbit: { name: 'Orbit', gen: true, slots: 5, wire: ['b a c', 'd a e'], cols: '1fr 1.3fr 1fr', rows: '1fr 1fr', fancy: 'A big round center with four around it' },
  hive: { name: 'Honeycomb', gen: true, slots: 5, wire: ['a a b b c c', '. d d e e .'], cols: 'repeat(6, 1fr)', rows: '1fr 1fr', fancy: 'Hexagon tiles' },
  wall: { name: '3D wall', gen: true, slots: 3, wire: ['a b c'], cols: '1fr 1.35fr 1fr', rows: '1fr', fancy: 'Side panels angle toward you' },
  scatter: { name: 'Scattered', gen: true, slots: 4, wire: ['a a b', 'c d d'], cols: '1fr 1fr 1fr', rows: '1fr 1fr', fancy: 'Tilted cards, like photos on a table' },
  angled: { name: 'Speed lines', gen: true, slots: 3, wire: ['a b c'], cols: '1fr 1.2fr 1fr', rows: '1fr', fancy: 'Slanted race-style panels' },
  split: { name: 'Diagonal split', gen: true, slots: 2, wire: ['a b'], cols: '1.15fr 1fr', rows: '1fr', fancy: 'Two panels cut on an angle' },
};
const CARD_NAMES = { music: 'Now playing', nav: 'Navigation', speed: 'Speedometer', weather: 'Weather', clock: 'Clock',
  favs: 'Favorites', controls: 'Quick controls', viz: 'Visualizer', art: 'Album art', maps: 'Live Google Maps', engine: 'Engine (OBD)',
  g_tach: 'Tachometer gauge', g_speed: 'Speed gauge', g_fuel: 'Fuel gauge', g_coolant: 'Coolant gauge', g_volts: 'Battery gauge',
  g_mpg: 'Fuel economy gauge', g_intake: 'Intake air gauge', g_load: 'Engine load gauge', g_throttle: 'Throttle gauge' };
const SPEEDOS = [['sport', 'Sport'], ['arc', 'Arc'], ['hud', 'LED bar'], ['ring', 'Comet ring']];
const BUTTONS = [['glass', 'Glass'], ['neon', 'Neon glow'], ['holo', 'Holo ring'], ['liquid', 'Jelly'], ['chrome', 'Chrome sheen'], ['pulse', 'Pulse']];
// Complete looks: [id, name, what it's like, settings it switches on, thumbnail]
const STYLES = [
  ['glass', 'Glass', 'Frosted panels over flowing color', { theme: 'aurora', effect: 'blobs', button_fx: 'glass', ripple_style: 'waves', clock_style: 'thin' },
    ['radial-gradient(circle at 20% 20%,#14B8A6,transparent 55%),radial-gradient(circle at 85% 90%,#7C3AED,transparent 55%),#05070B', 'background:#ffffff1f;box-shadow:inset 0 0 0 1px #ffffff45;border-radius:.5rem', 'font-weight:200']],
  ['carbon', 'Carbon Racing', 'Carbon weave, cut corners, race stripes', { theme: 'redline', effect: 'road', nav: 'dock', button_fx: 'chrome', ripple_style: 'shock', clock_style: 'bold' },
    ['repeating-linear-gradient(45deg,#111 0 4px,#1b1b1b 4px 8px)', 'background:#0b0b0b;box-shadow:inset 3px 0 0 #E10600;clip-path:polygon(10% 0,100% 0,100% 85%,90% 100%,0 100%,0 15%)', 'font-style:italic;font-weight:900']],
  ['synth', 'Synthwave', 'Neon outlines over a rolling grid', { theme: 'outrun', effect: 'aurora', button_fx: 'neon', ripple_style: 'waves', clock_style: 'glow' },
    ['linear-gradient(#0D0221 55%,#2A0845)', 'box-shadow:0 0 0 1.5px #05D9E8,0 0 8px #05D9E8;border-radius:.3rem', 'font-style:italic;font-weight:900;color:#05D9E8']],
  ['minimal', 'Minimal', 'No boxes, giant thin type, hairlines', { theme: 'obsidian', effect: 'off', button_fx: 'glass', ripple_style: 'edge', clock_style: 'thin' },
    ['#000', 'border-top:1px solid #ffffff40', 'font-weight:100;font-size:1.8rem']],
  ['hud', 'Cyber HUD', 'Scanlines, bracket corners, terminal type', { theme: 'matrix', effect: 'matrix', button_fx: 'neon', ripple_style: 'sparks', clock_style: 'glow' },
    ['repeating-linear-gradient(#000a06 0 3px,#0b2a10 3px 4px)', 'box-shadow:inset 0 0 0 1px #39FF1460', 'font-family:monospace;color:#39FF14']],
  ['lux', 'Luxury', 'Gold hairlines and serif type', { theme: 'champagne', effect: 'bokeh', button_fx: 'chrome', ripple_style: 'aurora', clock_style: 'thin' },
    ['radial-gradient(circle at 50% 0,#2a2118,#0a0806 70%)', 'box-shadow:inset 0 0 0 1px #CBA35C;border-radius:.15rem', 'font-family:Georgia,serif;color:#E8D3A6']],
  ['rally', 'Rally', 'Bold stripes, chunky outlined panels', { theme: 'rally-blue', effect: 'road', nav: 'dock', button_fx: 'liquid', ripple_style: 'shock', clock_style: 'bold' },
    ['linear-gradient(105deg,#020818 62%,#FACC15 62% 64%,#020818 64% 66%,#FACC15 66% 67%,#020818 67%)', 'background:#0b1a40;box-shadow:inset 0 0 0 2px #fff;border-top:4px solid #FACC15;border-radius:.4rem', 'font-style:italic;font-weight:900']],
  ['soft', 'Soft 3D', 'Raised clay panels, no glass', { theme: 'clay', effect: 'off', button_fx: 'liquid', ripple_style: 'aurora', clock_style: 'bold' },
    ['#2A2630', 'background:#2A2630;box-shadow:4px 4px 8px #0008,-3px -3px 7px #ffffff12;border-radius:.7rem', 'font-weight:700;color:#F9A8D4']],
  ['pop', 'Pop Art', 'Thick outlines, hard shadows, halftone', { theme: 'comic', effect: 'off', button_fx: 'liquid', ripple_style: 'sparks', clock_style: 'bold' },
    ['radial-gradient(#ffffff22 22%,transparent 24%) 0 0/7px 7px,#101010', 'background:#101010;box-shadow:0 0 0 2px #000,4px 4px 0 2px #FFEA00;border-radius:.4rem', 'font-weight:900;color:#FFEA00']],
  ['sea', 'Deep Sea', 'Glowing, very round, drifting bubbles', { theme: 'abyss', effect: 'fireflies', button_fx: 'pulse', ripple_style: 'aurora', clock_style: 'glow' },
    ['radial-gradient(circle at 30% 80%,#0B3B5C,transparent 60%),#000510', 'box-shadow:0 0 12px #22D3EE60,inset 0 0 8px #22D3EE30;border-radius:1rem', 'font-weight:200;color:#A5F3FC']],
  ['paper', 'Paper', 'Ink on paper, crisp and bright', { theme: 'paper-ink', effect: 'off', button_fx: 'glass', ripple_style: 'edge', clock_style: 'thin' },
    ['#F4F1EA', 'background:#fffdf8;box-shadow:0 0 0 1px #1F2937,3px 3px 0 1px #1F2937;border-radius:.2rem', 'font-family:Georgia,serif;color:#1F2937']],
  ['holo', 'Holographic', 'Iridescent rims, rainbow type', { theme: 'prism', effect: 'liquid', button_fx: 'holo', ripple_style: 'sparks', clock_style: 'thin' },
    ['radial-gradient(circle at 20% 30%,#A855F7,transparent 55%),radial-gradient(circle at 80% 80%,#06B6D4,transparent 55%),#07060E', 'border:2px solid;border-image:linear-gradient(135deg,#ff6ec7,#7df9ff,#a0ff9f,#b388ff) 1', 'background:linear-gradient(90deg,#ff6ec7,#7df9ff,#a0ff9f);-webkit-background-clip:text;color:transparent']],
  ['slime', 'Slime', 'Glossy goo panels that drip, oozing background', { theme: 'toxic-slime', effect: 'slime', button_fx: 'liquid', ripple_style: 'aurora', clock_style: 'bold' },
    ['radial-gradient(ellipse 30% 22% at 20% 0,#39FF14 60%,transparent 62%),radial-gradient(ellipse 12% 34% at 62% 0,#39FF14 60%,transparent 62%),radial-gradient(ellipse 60% 20% at 50% 100%,#1f7a0f 60%,transparent 62%),#020801', 'background:#0d3a07cc;box-shadow:inset 0 .25rem .3rem #b6ff9c80,inset 0 -.3rem .5rem #00000080;border-radius:1rem 1rem 1.4rem 1.4rem', 'font-weight:900;color:#7CFF4F;text-shadow:0 2px 0 #0d5c07']],
];
STYLES.push(['rainy', 'Rainy Window', 'Night city through wet glass, drops run over the tiles', { theme: 'rainy-night', effect: 'window', rain_over: true, ripple_style: 'rain', glass: { opacity: 16, blur: 14, depth: 60, shine: 80, tint: 'theme', edge: true, textshadow: true, tilt: true }, button_fx: 'glass', clock_style: 'thin' },
  ['radial-gradient(circle at 25% 45%,#FFB34766,transparent 18%),radial-gradient(circle at 70% 60%,#38BDF855,transparent 16%),radial-gradient(circle at 50% 75%,#FF2A2A44,transparent 12%),radial-gradient(circle at 62% 30%,#ffffff55 2px,transparent 3px),radial-gradient(circle at 30% 70%,#ffffff44 3px,transparent 4px),linear-gradient(#060A12,#152238 60%,#060A12)',
   'background:#9fb7d81a;box-shadow:inset 0 1px 0 #ffffff40,inset 0 0 0 1px #ffffff22;border-radius:.5rem;backdrop-filter:blur(2px)', 'font-weight:200;color:#DCEBFF']]);
// Panel styles added with Looks (styles.css); [3] is unused now (a Look sets everything), kept for the shape
STYLES.push(
  ['neon', 'Neon edge', 'Crisp lit outlines on dark glass', {}, ['radial-gradient(circle at 30% 30%,#7C3AED55,transparent 60%),#05030c', 'box-shadow:0 0 0 1.5px #22D3EE,0 0 8px #22D3EE;border-radius:.4rem', 'color:#fff;text-shadow:0 0 6px #22D3EE']],
  ['chrome', 'Chrome', 'Polished metal rims, heavy type', {}, ['linear-gradient(#1a1c20,#0b0c0e)', 'background:#111;box-shadow:inset 0 0 0 2px #c9ced6;border-radius:.35rem', 'font-weight:800;color:#e5e7eb']],
  ['aero', 'Aero', 'Very round, airy frosted glass', {}, ['radial-gradient(circle at 70% 20%,#38BDF8,transparent 60%),#0b1730', 'background:#ffffff24;box-shadow:inset 0 1px 0 #ffffff90;border-radius:1rem', 'font-weight:200']],
  ['tech', 'Tech', 'Precise lines, one cut corner', {}, ['#06080c', 'background:#0b0f16;box-shadow:inset 0 -1px 0 #ffffff30;clip-path:polygon(0 0,80% 0,100% 30%,100% 100%,0 100%);border-top:2px solid #22D3EE', 'font-weight:300;font-family:monospace']],
  ['oled', 'OLED black', 'True black, only the accent lights up', {}, ['#000', 'background:#000;box-shadow:inset 0 0 0 1px #ffffff14;border-radius:.4rem', 'color:#5EEAD4;font-weight:300']],
  ['jdm', 'JDM', '80s racer: italic type, tri-color stripe', {}, ['#0b0b0e', 'background:#111;border-top:4px solid;border-image:linear-gradient(90deg,#EF4444 33%,#F59E0B 33% 66%,#3B82F6 66%) 1', 'font-style:italic;font-weight:900']],
  ['retro', 'Retro 70s', 'Round panels and sunset stripes', {}, ['linear-gradient(transparent 70%,#F97316 70% 76%,transparent 76% 80%,#FACC15 80% 86%,transparent 86% 90%,#EF4444 90%),#1c1410', 'background:#2a1d14;box-shadow:0 3px 0 #b45309;border-radius:.8rem', 'font-family:Georgia,serif;font-weight:700;color:#FDBA74']],
  ['blueprint', 'Blueprint', 'Drawing grid and dashed outlines', {}, ['linear-gradient(#ffffff18 1px,transparent 1px) 0 0/10px 10px,linear-gradient(90deg,#ffffff18 1px,transparent 1px) 0 0/10px 10px,#0b3a6e', 'background:#0b3a6e;outline:1px dashed #ffffffa0;outline-offset:-4px;box-shadow:inset 0 0 0 1px #fff', 'font-family:monospace;color:#fff']],
);
const RIPPLES = [['rain', 'Raindrops', 'Drops splash into rings'], ['liquid', 'Liquid level', 'Glowing water that sloshes'], ['curtain', 'Light curtain', 'Rays rise from the knob'], ['bars', 'Level bars', 'A meter across the bottom'],
  ['waves', 'Waves', 'Rings roll across'], ['shock', 'Shockwave', 'One fast blast'], ['aurora', 'Aurora bloom', 'Color swells up'],
  ['sparks', 'Sparks', 'Embers fly out'], ['edge', 'Edge only', 'Just the border']];
const SPLASHES = [['warp', 'Warp ring', 'Light streaks and a glowing ring'], ['hyper', 'Hyperspace', 'Neon tunnel slams to a stop'],
  ['plasma', 'Plasma core', 'Energy orb charges and blasts'], ['ignition', 'Ignition', 'Gauge sweep to redline'],
  ['chrome', 'Liquid chrome', 'Metal drops merge into one'], ['dawn', 'Mountain dawn', 'Night turns to sunrise']];
const CLOCKS = [['thin', 'Thin'], ['bold', 'Bold'], ['outline', 'Outline'], ['glow', 'Neon']];
const DIM_STEPS = [100, 85, 70, 55, 40, 30, 20, 12, 6, 3];
// One "Clarity" slider stands for opacity and frost together: 0 = clear glass, 100 = solid panels.
const glassClarity = (gl) => Math.round(glassClamp((gl.opacity / 88 + gl.blur / 40) / 2) * 100);
const glassClamp = (v) => Math.max(0, Math.min(1, v));
const clarityGlass = (v) => ({ opacity: Math.round(4 + (v / 100) * 70), blur: Math.round(6 + (v / 100) * 30) });
const GLASS_PRESETS = {
  crystal: ['Crystal', { opacity: 4, blur: 8, depth: 85, shine: 100, tint: 'clear' }],
  frosted: ['Frosted', { opacity: 22, blur: 30, depth: 70, shine: 70, tint: 'theme' }],
  liquid: ['Liquid', { opacity: 10, blur: 44, depth: 100, shine: 90, tint: 'clear' }],
  smoked: ['Smoked', { opacity: 48, blur: 22, depth: 75, shine: 45, tint: 'smoke' }],
  solid: ['Solid', { opacity: 88, blur: 10, depth: 45, shine: 30, tint: 'theme' }],
};
const KNOB_PAL = {
  classic: ['#FFFFFF', '#101214', '#FFFFFF', '#3F3F46', '#27272A', '#52525B'],
  racing: ['#EF4444', '#0A0A0A', '#FFFFFF', '#B91C1C', '#1F2937', '#DC2626'],
  amber: ['#FFB000', '#120A00', '#FFD27A', '#B45309', '#78350F', '#F59E0B'],
  ice: ['#7DD3FC', '#020A12', '#E0F2FE', '#38BDF8', '#1E3A8A', '#A5F3FC'],
  led: ['#39FF14', '#000800', '#B6FF5C', '#14532D', '#16A34A', '#052E16'],
};
// What new settings look like until the backend has stored them
const DEF = {
  glass: { opacity: 22, blur: 30, depth: 70, shine: 70, tint: 'theme', edge: true, textshadow: true, tilt: true },
  ui_scale: 100, nav: 'left', home_layout: 'dashboard', header: true, quick: true, maps_panel: true, map_only: true, app_view: 'page', map_bg: false, map_dim: 25, map_opacity: 100, map_glass: 'frost', rain_over: true, rain_glass: false, rain_amount: 'steady', tank: 185,
  gauges: { layout: 'quad', slots: ['tach', 'speed', 'fuel', 'coolant', 'volts', 'mpg'] },
  home_cards: { dashboard: ['music', 'nav'], cockpit: ['nav', 'speed', 'music'], focus: ['music', 'speed', 'weather'],
    grid: ['music', 'nav', 'speed', 'clock'], duo: ['art', 'speed'],
    wide: ['music', 'speed', 'weather'], strip: ['music', 'clock', 'speed', 'weather'], sidebar: ['music', 'clock', 'weather', 'speed'],
    bento: ['art', 'music', 'speed', 'clock'], mosaic: ['music', 'speed', 'viz', 'clock', 'weather'], cinema: ['viz', 'clock', 'music'],
    cluster: ['clock', 'speed', 'weather'], orbit: ['speed', 'clock', 'weather', 'music', 'favs'], hive: ['clock', 'speed', 'weather', 'music', 'controls'],
    wall: ['weather', 'music', 'speed'], scatter: ['music', 'clock', 'speed', 'art'], angled: ['clock', 'speed', 'music'], split: ['music', 'speed'] },
  transition: 'depth', speedo: 'sport', clock_style: 'thin', button_fx: 'glass', style: 'glass', knob_ripple: true, ripple_from: 'bottom', knob_x: 50, ripple_style: 'waves', ripple_power: 60, ripple_edge: true, ripple_hud: true,
  splash_style: 'warp', splash_knob: true, splash_text: 'Pi Head Unit', effect: 'blobs', motion: 'lively',
  night_dim: false, night_level: 25, dim_by: 'time', clock_24h: false, app_size: 'medium', knob_style: 'aurora', knob_top: 'clock',
};

// ================================================================ icons
const sv = (inner, size = 28, extra = '') =>
  `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" ${extra}>${inner}</svg>`;
const fill = (inner, size = 28) => `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">${inner}</svg>`;
const P = {
  gauges: '<path d="M4.5 18.5a9 9 0 1 1 15 0"/><path d="M12 13l4-5"/><circle cx="12" cy="13.5" r="1.6"/><path d="M6 13h1.5M16.5 13H18M12 6.5V8"/>',
  gauge: '<path d="M4.5 18.5a9 9 0 1 1 15 0"/><path d="M12 13l4-5"/><circle cx="12" cy="13.5" r="1.6"/><path d="M6 13h1.5M16.5 13H18M12 6.5V8"/>',
  down: '<polyline points="6 9 12 15 18 9"/>',
  car: '<path d="M5 17h14M3 17v-4l2.2-5.2A2 2 0 0 1 7 6.5h10a2 2 0 0 1 1.8 1.3L21 13v4"/><path d="M3 13h18"/><circle cx="7" cy="17" r="2"/><circle cx="17" cy="17" r="2"/>',
  engine: '<path d="M4 10h2V8h3V6h6v2h2l2 3h2v5h-2l-2 2H9l-2-2H4z"/><path d="M12 10v4"/>',
  home: '<path d="M3 11l9-7 9 7v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>',
  maps: '<path d="M3 11l18-8-8 18-2-8z"/>',
  music: '<path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/>',
  phone: '<path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1.9.4 1.8.7 2.7a2 2 0 0 1-.5 2.1L8 9.8a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.7.7a2 2 0 0 1 1.7 2z"/>',
  audio: '<line x1="4" y1="21" x2="4" y2="14"/><line x1="4" y1="10" x2="4" y2="3"/><line x1="12" y1="21" x2="12" y2="12"/><line x1="12" y1="8" x2="12" y2="3"/><line x1="20" y1="21" x2="20" y2="16"/><line x1="20" y1="12" x2="20" y2="3"/><line x1="1" y1="14" x2="7" y2="14"/><line x1="9" y1="8" x2="15" y2="8"/><line x1="17" y1="16" x2="23" y2="16"/>',
  look: '<path d="M12 22a10 10 0 1 1 10-10c0 2.8-2.2 4-4 4h-2a2 2 0 0 0-1.5 3.3A1.6 1.6 0 0 1 12 22z"/><circle cx="7.5" cy="11" r="1.2"/><circle cx="11" cy="7" r="1.2"/><circle cx="16" cy="8.5" r="1.2"/>',
  settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>',
  moon: '<path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/>',
  mic: '<rect x="9" y="2" width="6" height="12" rx="3"/><path d="M5 10a7 7 0 0 0 14 0"/><line x1="12" y1="17" x2="12" y2="22"/>',
  micOff: '<line x1="2" y1="2" x2="22" y2="22"/><path d="M15 9.3V5a3 3 0 0 0-5.7-1.3"/><path d="M9 9v3a3 3 0 0 0 5.1 2.1"/><path d="M19 10a7 7 0 0 1-1.2 3.9M5 10a7 7 0 0 0 11.6 5.3"/><line x1="12" y1="17" x2="12" y2="22"/>',
  back: '<path d="M21 4H8l-7 8 7 8h13a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2z"/><line x1="18" y1="9" x2="12" y2="15"/><line x1="12" y1="9" x2="18" y2="15"/>',
  turn: '<path d="M8 21V11a3 3 0 0 1 3-3h8"/><polyline points="15 4 19 8 15 12"/>',
  bt: '<polyline points="6.5 6.5 17.5 17.5 12 23 12 1 17.5 6.5 6.5 17.5"/>',
  vol: '<polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M15.5 8.5a5 5 0 0 1 0 7"/><path d="M19 5a10 10 0 0 1 0 14"/>',
  sun: '<circle cx="12" cy="12" r="4.5"/><line x1="12" y1="1.5" x2="12" y2="3.5"/><line x1="12" y1="20.5" x2="12" y2="22.5"/><line x1="1.5" y1="12" x2="3.5" y2="12"/><line x1="20.5" y1="12" x2="22.5" y2="12"/><line x1="4.6" y1="4.6" x2="6" y2="6"/><line x1="18" y1="18" x2="19.4" y2="19.4"/><line x1="4.6" y1="19.4" x2="6" y2="18"/><line x1="18" y1="6" x2="19.4" y2="4.6"/>',
  cloudSun: '<circle cx="8" cy="8" r="3"/><line x1="8" y1="1.5" x2="8" y2="2.5"/><line x1="2.5" y1="8" x2="1.5" y2="8"/><line x1="4" y1="4" x2="3.3" y2="3.3"/><path d="M18 20H10a5 5 0 1 1 4.8-6.4H16a3.2 3.2 0 1 1 2 6.4z"/>',
  cloud: '<path d="M17.5 19H9a7 7 0 1 1 6.7-9h1.8a4.5 4.5 0 1 1 0 9z"/>',
  rain: '<path d="M20 15.6A4.5 4.5 0 0 0 17.5 7h-1.8A7 7 0 1 0 4 14.9"/><line x1="8" y1="17" x2="7" y2="21"/><line x1="12" y1="17" x2="11" y2="21"/><line x1="16" y1="17" x2="15" y2="21"/>',
  snow: '<path d="M20 15.6A4.5 4.5 0 0 0 17.5 7h-1.8A7 7 0 1 0 4 14.9"/><line x1="8" y1="18" x2="8.01" y2="18"/><line x1="12" y1="20" x2="12" y2="20.01"/><line x1="16" y1="18" x2="16.01" y2="18"/>',
  storm: '<path d="M19 16.9A5 5 0 0 0 18 7h-1.3A8 8 0 1 0 4 15.2"/><polyline points="13 11 9 17 15 17 11 23"/>',
  glass: '<rect x="3" y="3" width="13" height="13" rx="3"/><rect x="8" y="8" width="13" height="13" rx="3"/>',
  motion: '<path d="M2 12c3-6 6-6 9 0s6 6 9 0"/><path d="M2 18c3-6 6-6 9 0" opacity=".5"/>',
  layout: '<rect x="3" y="3" width="18" height="18" rx="3"/><line x1="3" y1="9" x2="21" y2="9"/><line x1="12" y1="9" x2="12" y2="21"/>',
  knob: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  display: '<rect x="2" y="4" width="20" height="13" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/>',
  info: '<circle cx="12" cy="12" r="10"/><line x1="12" y1="11" x2="12" y2="16"/><line x1="12" y1="8" x2="12.01" y2="8"/>',
  speed: '<path d="M12 14l4-6"/><path d="M3.5 18a10 10 0 1 1 17 0"/>',
  clock: '<circle cx="12" cy="12" r="9"/><polyline points="12 7 12 12 15 14"/>',
  star: '<polygon points="12 2 15 9 22 9.3 16.6 14 18.5 21 12 17 5.5 21 7.4 14 2 9.3 9 9"/>',
  list: '<line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><circle cx="4" cy="6" r="1"/><circle cx="4" cy="12" r="1"/><circle cx="4" cy="18" r="1"/>',
  library: '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
  search: '<circle cx="11" cy="11" r="7"/><line x1="21" y1="21" x2="16.5" y2="16.5"/>',
  pin: '<path d="M12 17v5"/><path d="M9 10.8V5h6v5.8l3 3.2H6z"/>',
  chevron: '<polyline points="9 6 15 12 9 18"/>',
  left: '<polyline points="15 6 9 12 15 18"/>',
  x: '<line x1="6" y1="6" x2="18" y2="18"/><line x1="18" y1="6" x2="6" y2="18"/>',
  wrench: '<path d="M14.7 6.3a4 4 0 0 0 5.4 5.4L21 21l-9.3-.9a4 4 0 0 0-5.4-5.4L3 3l3.3 3.3a4 4 0 0 0 5.4 5.4"/>',
  sliders: '<line x1="4" y1="6" x2="20" y2="6"/><circle cx="9" cy="6" r="2"/><line x1="4" y1="18" x2="20" y2="18"/><circle cx="15" cy="18" r="2"/>',
  wave: '<line x1="4" y1="10" x2="4" y2="14"/><line x1="8" y1="6" x2="8" y2="18"/><line x1="12" y1="3" x2="12" y2="21"/><line x1="16" y1="7" x2="16" y2="17"/><line x1="20" y1="10" x2="20" y2="14"/>',
  image: '<rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="9" cy="9" r="2"/><path d="M21 15l-5-5L5 21"/>',
  shuffle: '<polyline points="16 3 21 3 21 8"/><line x1="4" y1="20" x2="21" y2="3"/><polyline points="21 16 21 21 16 21"/><line x1="15" y1="15" x2="21" y2="21"/><line x1="4" y1="4" x2="9" y2="9"/>',
};
const ICON = {
  play: fill('<path d="M7 4.5v15a1 1 0 0 0 1.5.9l12-7.5a1 1 0 0 0 0-1.8l-12-7.5A1 1 0 0 0 7 4.5z"/>', 32),
  pause: fill('<rect x="6" y="4" width="4" height="16" rx="1"/><rect x="14" y="4" width="4" height="16" rx="1"/>', 32),
  prev: fill('<polygon points="19 4 9 12 19 20"/><rect x="5" y="5" width="2" height="14"/>', 34),
  next: fill('<polygon points="5 4 15 12 5 20"/><rect x="17" y="5" width="2" height="14"/>', 34),
  hangup: fill('<path d="M12 9c-3.4 0-6.6.9-9.4 2.6a1.7 1.7 0 0 0-.8 1.5v2.3a1.5 1.5 0 0 0 1.9 1.5l3.3-.9a1.5 1.5 0 0 0 1.1-1.4v-1.8a12 12 0 0 1 7.8 0v1.8a1.5 1.5 0 0 0 1.1 1.4l3.3.9a1.5 1.5 0 0 0 1.9-1.5v-2.3a1.7 1.7 0 0 0-.8-1.5A18 18 0 0 0 12 9z"/>', 34),
  phone: sv(P.phone, 32),
};
const ico = (name, size) => sv(P[name], size);
const CARD_ICONS = { music: 'music', nav: 'maps', speed: 'speed', weather: 'cloudSun', clock: 'clock', favs: 'star', controls: 'sliders', viz: 'wave', art: 'image', maps: 'maps', engine: 'engine', g_tach: 'gauge', g_speed: 'gauge', g_fuel: 'gauge', g_coolant: 'gauge', g_volts: 'gauge', g_mpg: 'gauge',
  g_intake: 'gauge', g_load: 'gauge', g_throttle: 'gauge' };

// ================================================================ state
const S = { state: null, screen: 'home', dial: '', tab: 'favorites', lookTab: 'looks', setTab: 'phone', group: 'All',
  recentsSig: '', theme: null, editSlot: null, lastRect: '',
  mtab: 'queue', queue: null, library: null, libStack: [], search: '', recentSearches: [], pinEdit: false };
const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const settings = () => (S.state && S.state.settings) || {};
const g = (k) => { const v = settings()[k]; return v === undefined || v === null ? DEF[k] : v; };
const glassSet = () => Object.assign({}, DEF.glass, settings().glass || {});
const cardsFor = (layout) => {
  const saved = (settings().home_cards || {})[layout];
  const def = DEF.home_cards[layout] || [];
  const n = (LAYOUTS[layout] || {}).slots || 0;
  return Array.from({ length: n }, (_, i) => (saved && CARD_NAMES[saved[i]] ? saved[i] : def[i] || 'music'));
};

// album art comes once per song ("art" message); states carry only art.rev
let ART = null;
const withArt = (st) => { if (st && st.art && !st.art.data && ART && ART.rev === st.art.rev) st.art = ART; return st; };
let ws = null;
function connect() {
  ws = new WebSocket(`ws://${location.host}/ws`);
  ws.onopen = () => { $('#offline').classList.add('hidden'); S.lastRect = ''; };
  ws.onclose = () => { $('#offline').classList.remove('hidden'); setTimeout(connect, 1000); };
  ws.onmessage = (e) => {
    const m = JSON.parse(e.data);
    if (m.type === 'state') {
      // after an update the backend comes back with a new version: load the new screen files
      if (m.state.version && S.version && m.state.version !== S.version) return location.reload();
      S.version = m.state.version;
      onState(withArt(m.state));
    }
    else if (m.type === 'art') { ART = m.art; if (S.state && S.state.art && S.state.art.rev === ART.rev) onState(withArt(Object.assign({}, S.state))); }
    else if (m.type === 'reload') location.reload();
    else if (m.type === 'splash') location.href = '/static/splash.html?replay';
    else if (m.type === 'knob' && window.knobFx) window.knobFx(m);
    else if (m.type === 'tool_result') {
      const name = (TOOL_BTNS.find((t) => t[0] === m.tool) || [, m.tool])[1];
      S.toolOut = m.running ? `${name}…` : `${name}: ${m.ok ? 'done' : 'failed'}\n\n${m.out || ''}`;
      const o = $('#toolOut'); if (o) o.textContent = S.toolOut;
      $$('[data-tool]').forEach((b) => b.classList.toggle('busy', !!m.running && b.dataset.tool === m.tool));
      if (!m.running) toast(m.ok ? `${name}: done` : `${name}: didn’t work`);
    }
    else if (m.type === 'obd') onObd(m.data);
    else if (m.type === 'can') onCan(m.can);
    else if (m.type === 'toast') toast(m.text);
    else if (m.type === 'queue') { S.queue = m.queue; if (S.screen === 'music' && S.mtab === 'queue') renderMusicPanel(); update(); }
    else if (m.type === 'queue_active') { if (S.queue) { S.queue.active = m.id; markQueueActive(); } update(); }
    else if (m.type === 'library') { S.library = m.library; if (S.screen === 'music' && S.mtab === 'library') renderMusicPanel(); }
  };
}
function send(cmd, data = {}) {
  if (ws && ws.readyState === 1) ws.send(JSON.stringify(Object.assign({ cmd }, data)));
  else toast('Not connected to the head unit yet.');
}
let toastTimer;
function toast(text) {
  const t = $('#toast');
  t.textContent = text;
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('show'), 3200);
}

// ================================================================ look
const hexRgb = (h) => { const n = parseInt(h.slice(1), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; };
const lum = (h) => { const [r, gg, b] = hexRgb(h).map((v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4; }); return 0.2126 * r + 0.7152 * gg + 0.0722 * b; };
function themeById(id) { return THEMES.find((x) => x.id === id) || THEMES[0] || { id: 'aurora', base: '#05070B', b1: '#14B8A6', b2: '#7C3AED', b3: '#0EA5E9', accent: '#5EEAD4' }; }

function fitScale() {
  const fit = Math.min(innerWidth / 1280, innerHeight / 800);
  return 16 * fit * (g('ui_scale') / 100);
}

function effectiveBrightness() {
  const s = settings();
  const b = s.brightness ?? 100;
  if (b > 0 && g('night_dim') && isDark()) return Math.min(b, g('night_level'));
  return b;
}
// Night = time of day only (sunset from the weather, else 7 pm - 7 am), same as the backend's is_night().
// Headlight detection was removed in 2026.11.05-c.
function isDark() {
  const w = S.state && S.state.weather;
  if (w && typeof w.day === 'boolean') return !w.day;
  const h = new Date().getHours();
  return h >= 19 || h < 7;
}
const isNight = isDark;
const carLights = () => null;
// Dash-style indicators: blue high beam, green turn arrows (arrows only when the car reports signals).
function renderCarLights() {
  const l = carLights() || {};
  const el = $('#carLights');
  if (!el) return;
  el.classList.toggle('hb', !!l.high);
  el.classList.toggle('tl', !!l.left);
  el.classList.toggle('tr', !!l.right);
}

// ---- Looks (backend/looks.py). A Look is the whole dash's look: colors, panels, the synced wallpaper (Flow),
// gauge faces, knob, map colors and startup. state.look is the finished one every screen draws with; any look
// setting you change is saved with the Look you're on. Built-in Looks: web/looks.json.
let LOOKS = [];       // web/looks.json
const LOOK_GROUPS = ['Night drive', 'Neon', 'Racing', 'Weather', 'Warm', 'Nature', 'Luxury', 'Calm', 'Bright', 'Fun'];
const LC_SLOTS = [['base', 'Background'], ['b1', 'Glow 1'], ['b2', 'Glow 2'], ['b3', 'Glow 3'], ['accent', 'Accent']];
const LC_QUICK = ['#000000', '#0B1020', '#334155', '#FFFFFF', '#EF4444', '#F97316', '#FACC15', '#84CC16', '#22C55E', '#14B8A6',
  '#06B6D4', '#3B82F6', '#6366F1', '#7C3AED', '#D946EF', '#EC4899'];
const LOOK_FALLBACK = { base: '#05070B', b1: '#14B8A6', b2: '#7C3AED', b3: '#0EA5E9', accent: '#5EEAD4', light: false };
const curLook = () => (S.state && (S.state.look_preview || S.state.look)) || {};
const lookColors = () => Object.assign({}, LOOK_FALLBACK, curLook().colors || {});
const lookById = (id) => LOOKS.find((x) => x.id === id) || ((S.state && S.state.my_looks) || []).find((x) => x.id === id);
const sceneName = (id) => ((window.FLOW_SCENES || []).find((x) => x[0] === id) || [])[1] || '';
// A little picture of a Look: its glows on its background, two panels, and its accent.
function lookSwatch(c) {
  c = Object.assign({}, LOOK_FALLBACK, c || {});
  return `<div class="lk-sw" style="--lb:${c.base};--l1:${c.b1};--l2:${c.b2};--l3:${c.b3};--la:${c.accent}"><i class="p"></i><i class="p q"></i><i class="a"></i></div>`;
}
function hexHsv(hex) {
  const [r, gg, b] = hexRgb(hex).map((v) => v / 255);
  const mx = Math.max(r, gg, b), d = mx - Math.min(r, gg, b);
  let h = 0;
  if (d) { h = mx === r ? ((gg - b) / d) % 6 : mx === gg ? (b - r) / d + 2 : (r - gg) / d + 4; h *= 60; if (h < 0) h += 360; }
  return [Math.round(h), Math.round(mx ? (d / mx) * 100 : 0), Math.round(mx * 100)];
}
function hsvHex(h, sat, v) {
  sat /= 100; v /= 100;
  const f = (n) => { const k = (n + h / 60) % 6; return v - v * sat * Math.max(0, Math.min(k, 4 - k, 1)); };
  return `#${[f(5), f(3), f(1)].map((x) => Math.round(x * 255).toString(16).padStart(2, '0')).join('').toUpperCase()}`;
}
function lookColorsCard() {
  const cur = lookColors();
  const slot = LC_SLOTS.some(([k]) => k === S.lcSlot) ? S.lcSlot : 'accent';
  const [h, sat, v] = hexHsv(cur[slot]);
  return `<div class="lcard glass">
    <div class="lc-head"><div><b>Colors</b><small>Tap a color, then slide. Saved with this Look.</small></div>
      <button class="btn small sink" data-act="lcreset">${ico('back', 18)}Original</button></div>
    <div class="lc-slots">${LC_SLOTS.map(([k, l]) => `<button class="lc-slot sink ${k === slot ? 'on' : ''}" data-act="lcslot:${k}">
      <i data-lc="${k}" style="background:${cur[k]}"></i><span>${l}</span></button>`).join('')}</div>
    <div class="lc-pick" data-lcpick="${slot}">
      <label><span>Color</span><input type="range" class="lc-hue" min="0" max="359" step="1" value="${h}" data-lch="h"></label>
      <label><span>Richness</span><input type="range" min="0" max="100" step="1" value="${sat}" data-lch="s" style="--a:${hsvHex(h, 0, Math.max(v, 30))};--b:${hsvHex(h, 100, Math.max(v, 30))}"></label>
      <label><span>Brightness</span><input type="range" min="0" max="100" step="1" value="${v}" data-lch="v" style="--a:#000;--b:${hsvHex(h, sat, 100)}"></label>
    </div>
    <div class="lc-quick">${LC_QUICK.map((c) => `<button class="sink" data-act="lcq:${c}" style="background:${c}" aria-label="${c}"></button>`).join('')}</div>
  </div>`;
}
// Colors change on screen at once; the backend hears about it at most ~8 times a second.
function setLookColors(cols) {
  const lk = S.state.look;
  if (!lk) return;
  lk.colors = Object.assign({}, lk.colors, cols);
  lk.edited = true;
  applyLook();
  Object.entries(cols).forEach(([k, hex]) => $$(`[data-lc="${k}"]`).forEach((i) => { i.style.background = hex; }));
  S.lcPending = Object.assign(S.lcPending || {}, cols);
  if (!S.lcTimer) S.lcTimer = setTimeout(() => { send('look_colors', { colors: S.lcPending }); S.lcPending = null; S.lcTimer = 0; }, 120);
}
function lookColorFromSliders() {
  const box = $('[data-lcpick]');
  if (!box) return;
  const val = (c) => +$(`[data-lch="${c}"]`, box).value;
  const h = val('h'), sat = val('s'), v = val('v');
  const hex = hsvHex(h, sat, v);
  $('[data-lch="s"]', box).style.cssText = `--a:${hsvHex(h, 0, Math.max(v, 30))};--b:${hsvHex(h, 100, Math.max(v, 30))}`;
  $('[data-lch="v"]', box).style.cssText = `--a:#000;--b:${hsvHex(h, sat, 100)}`;
  setLookColors({ [box.dataset.lcpick]: hex });
}
function usePalette(t) {
  setLookColors({ base: t.base, b1: t.b1, b2: t.b2, b3: t.b3, accent: t.accent, light: !!t.light });
}
const lookSig = () => { const l = (S.state && S.state.look) || {}, f = settings().flow || {}; return `${l.id}|${l.edited}|${l.mine}|${f.on}|${f.scene}|${((S.state && S.state.my_looks) || []).length}|${JSON.stringify((settings().look_schedule || {}))}`; };
function useLook(id, e) {
  const lk = lookById(id);
  themeWipe(() => {
    if (lk && S.state.look) S.state.look = Object.assign({}, S.state.look, { id, name: lk.name, desc: lk.desc || '', colors: lk.colors, edited: false });
    send('look_use', { id });
    applyLook();
    S.lastRect = '';
    render(true);
    requestAnimationFrame(() => { movePill(); if (isStage(S.screen)) reportRect(); });
    if (typeof flowTap === 'function' && e) { FLOW.lastTap = 0; const x = e.clientX, y = e.clientY; setTimeout(() => flowTap({ clientX: x, clientY: y }), 80); }
  }, e ? e.clientX : 512, e ? e.clientY : 300);
  if (lk) toast(`${lk.name}: all three screens`);
}

function applyLook() {
  const s = settings();
  const lk = curLook(), c = lookColors();
  const t = Object.assign({}, c, { id: `${lk.id || 'look'}~${c.base}${c.b1}${c.b2}${c.b3}${c.accent}`, name: lk.name || '' }); // new id: effects redraw in the new colors
  applyDesignCss(lk);
  const gl = glassSet();
  // write a CSS variable only when it changes (each write makes the browser re-check styles; this runs on every state)
  const st0 = document.documentElement.style, VAR = applyLook.vars || (applyLook.vars = {});
  const r = { setProperty: (k, v) => { if (VAR[k] !== v) { VAR[k] = v; st0.setProperty(k, v); } } };
  const light = !!t.light;
  const fs = `${fitScale().toFixed(3)}px`;
  if (st0.fontSize !== fs) st0.fontSize = fs;
  const vars = { base: t.base, b1: t.b1, b2: t.b2, b3: t.b3, accent: t.accent,
    'on-accent': lum(t.accent) > 0.42 ? '#06080C' : '#FFFFFF',
    text: light ? '#0B1220' : '#F5F7FA', sub: light ? 'rgb(15 23 42 / .68)' : 'rgb(245 247 250 / .72)' };
  Object.entries(vars).forEach(([k, v]) => r.setProperty(`--${k}`, v));
  const tint = gl.tint === 'smoke' ? '0 0 0' : gl.tint === 'clear' || light ? '255 255 255' : hexRgb(t.base).join(' ');
  r.setProperty('--tint', tint);
  r.setProperty('--ga', String(Math.max(0, Math.min(100, gl.opacity)) / 100 * 0.94));
  r.setProperty('--blur', `${Math.max(0, gl.blur)}px`);
  r.setProperty('--depth', String(gl.depth / 100));
  r.setProperty('--shine', String(gl.shine / 100));
  r.setProperty('--blobT', `${{ calm: 30, lively: 18, wild: 9 }[g('motion')] || 18}s`);
  const b = document.body;
  b.classList.toggle('light', light);
  b.classList.toggle('anim', s.animate !== false);
  b.classList.toggle('glow', s.glow !== false);
  b.classList.toggle('edge', gl.edge !== false);
  b.classList.toggle('shadowtext', gl.textshadow !== false && !light);
  b.classList.toggle('flat', gl.tilt === false || s.animate === false);
  ['nav-left', 'nav-right', 'nav-dock'].forEach((x) => b.classList.remove(x));
  b.classList.add(`nav-${g('nav') === 'dock' ? 'dock' : g('nav') === 'right' ? 'right' : 'left'}`);
  CLOCKS.forEach(([x]) => b.classList.toggle(`clock-${x}`, g('clock_style') === x));
  if (b.dataset.style !== (g('style') || 'glass')) b.dataset.style = g('style') || 'glass';
  BUTTONS.forEach(([x]) => b.classList.toggle(`bfx-${x}`, g('button_fx') === x));
  S.theme = t;
  const br = effectiveBrightness();
  const dim = $('#dim');
  dim.classList.toggle('off', br === 0);
  dim.style.opacity = br === 0 ? '' : String(((100 - br) / 100) * 0.97);
  const db = $('#dimBtn');
  if (db) db.classList.toggle('lowered', br < 100);
  if (typeof fxApply === 'function') fxApply();
  if (typeof flowApply === 'function') flowApply();
  applyMapBg();
  // panels skip the live frosted blur while anything behind them moves (style.css body.bg-moving)
  const fxKind = b.dataset.effect || 'off';
  b.classList.toggle('bg-moving', b.classList.contains('flowing') || b.classList.contains('mapbg-home') ||
    (s.animate !== false && fxKind !== 'off'));
}
// A Look's own CSS: its variables first, then its free-form rules. A saved Look's CSS can be big (wallpaper
// pictures), so it's fetched once per change (look.css_rev) instead of riding along with every state.
function applyDesignCss(lk) {
  const el = document.getElementById('designCss');
  if (!el) return;
  const vars = Object.entries(lk.vars || {}).map(([k, v]) => `${k}:${v};`).join('');
  let css = vars ? `:root{${vars}}\n` : '';
  if (lk.id === 'preview') css += lk.css || '';
  else if (lk.css_rev) {
    if (S.cssRev !== lk.css_rev) {
      S.cssRev = lk.css_rev;
      fetch('/look/css').then((r) => r.text()).then((t) => { S.lookCss = t; applyDesignCss(curLook()); }).catch(() => { S.cssRev = 0; });
    }
    css += S.lookCss || '';
  } else { S.cssRev = 0; S.lookCss = ''; }
  if (el.textContent !== css) el.textContent = css;
}
function setSetting(patch, rerender) {
  Object.assign(S.state.settings, patch); // instant feedback
  applyLook();
  send('settings', { patch });
  if (rerender) render(true);
}
function flowSet() { return Object.assign({}, window.FLOW_DEFAULT || {}, settings().flow || {}); }
function setFlow(patch) { setSetting({ flow: Object.assign(flowSet(), patch) }); }
// A ripple from your finger through all three screens (the backend passes it to the cluster and the knob).
function flowSplash(e) {
  if (typeof flowTap === 'function' && e) { FLOW.lastTap = 0; const x = e.clientX, y = e.clientY; setTimeout(() => flowTap({ clientX: x, clientY: y }), 80); }
}
function setGlass(patch) { setSetting({ glass: Object.assign(glassSet(), patch) }); }
function cycleDim() {
  const b = settings().brightness ?? 100;
  const i = DIM_STEPS.findIndex((x) => x < b);
  const next = i === -1 ? DIM_STEPS[0] : DIM_STEPS[i];
  setSetting({ brightness: next });
  toast(next === 100 ? 'Full brightness' : `Brightness ${next}%`);
}
function screenOff() { setSetting({ brightness: 0 }); }
function screenOn() { setSetting({ brightness: settings().brightness_last || 100 }); }

// ================================================================ helpers
const fmtTime = (ms) => { const s = Math.max(0, Math.floor(ms / 1000)); return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`; };
function mediaPos(m) {
  if (!m) return 0;
  let p = m.position || 0;
  if (m.status === 'playing') p += (Date.now() / 1000 - (m.at || 0)) * 1000;
  return m.duration ? Math.min(p, m.duration) : p;
}
function weatherIcon(w, size) {
  if (!w) return ico('cloud', size);
  const c = w.code;
  if (c === 0 || c === 1) return w.day ? ico('sun', size) : ico('moon', size);
  if (c === 2) return ico('cloudSun', size);
  if (c >= 95) return ico('storm', size);
  if ((c >= 71 && c <= 77) || c === 85 || c === 86) return ico('snow', size);
  if ((c >= 51 && c <= 67) || (c >= 80 && c <= 82)) return ico('rain', size);
  return ico('cloud', size);
}
function ago(t) {
  const d = Date.now() / 1000 - t;
  if (d < 60) return 'Just now';
  if (d < 3600) return `${Math.floor(d / 60)} min ago`;
  if (d < 86400) return `${Math.floor(d / 3600)} hr ago`;
  return new Date(t * 1000).toLocaleDateString([], { weekday: 'long' });
}
const initial = (n) => (String(n || '?').trim()[0] || '?').toUpperCase();
function speedUnits(st) {
  const u = (st.settings || {}).speed_units || 'auto';
  if (u !== 'auto') return u;
  return (((st.settings || {}).location || {}).units === 'celsius') ? 'kmh' : 'mph';
}
function speedValue(st) {
  if (!st.speed) return null;
  return Math.round(speedUnits(st) === 'kmh' ? st.speed.mps * 3.6 : st.speed.mps * 2.23694);
}
function artHtml(st, iconSize) {
  const a = st.art, m = st.media || {};
  if (a && a.data && a.title && a.title === m.title) return `<img class="art-img" src="data:image/jpeg;base64,${a.data}" alt="">`;
  // the notification's art can lag a song behind: the phone's queue has the same song's art too
  const qa = m.title && ((S.queue && S.queue.items) || []).find((q) => q.art && q.title === m.title);
  if (qa) return `<img class="art-img" src="data:image/jpeg;base64,${qa.art}" alt="">`;
  return ico('music', iconSize);
}

function nextInQueue() {
  const q = S.queue;
  if (!q || !q.items) return null;
  const i = q.items.findIndex((x) => x.id === q.active);
  return i >= 0 ? q.items[i + 1] || null : null;
}

// Values bound into the page: data-k (text), data-k-html (markup), data-show (visibility), data-w (width)
function binds() {
  const st = S.state || {};
  const m = st.media || {};
  const c = st.call || {};
  const w = st.weather;
  const now = new Date();
  const playing = m.status === 'playing';
  const callState = c.state;
  const statusText = { incoming: 'Incoming call', waiting: 'Call waiting', dialing: 'Calling…', alerting: 'Ringing…',
    active: c.since ? fmtTime((Date.now() / 1000 - c.since) * 1000) : 'Connected', held: 'On hold' }[callState] || '';
  const phone = st.phone || {};
  const a = st.audio || {};
  const app = st.app || {};
  const nav = st.nav || {};
  const sp = speedValue(st);
  return {
    clock: g('clock_24h')
      ? now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false })
      : now.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true }).replace(/\s?[AP]M$/i, ''),
    date: now.toLocaleDateString([], { weekday: 'long', month: 'long', day: 'numeric' }),
    wtemp: w ? `${w.temp}°` : '--°',
    wdesc: w ? `${w.text}, high ${w.hi}°, low ${w.lo}°` : 'Weather comes from the phone app',
    wicon: weatherIcon(w, 60),
    title: m.title || (m.available ? 'Nothing playing' : 'Connect your phone'),
    artist: m.artist || (m.available ? 'Start music on your phone' : 'Pair it in Settings to play music'),
    npLine: m.title ? `${m.title}${m.artist ? ` — ${m.artist}` : ''}` : '',
    pos: fmtTime(mediaPos(m)), dur: m.duration ? fmtTime(m.duration) : '',
    progress: m.duration ? `${(mediaPos(m) / m.duration) * 100}%` : '0%',
    playIcon: playing ? ICON.pause : ICON.play,
    phoneStatus: phone.connected ? `${phone.name} connected` : 'No phone connected',
    btStatus: phone.connected ? `Connected to ${phone.name}` : (st.bt && st.bt.discoverable ? 'Visible as “Pi Head Unit”. Pair from your phone now.' : 'Not connected'),
    callAvail: c.available ? 'Calls and voice assistant are ready' : 'Not ready. Pair your phone and allow call access.',
    callStatus: statusText, callName: c.name || '', callNumber: c.name && c.number && c.name !== c.number ? c.number : '',
    callIncoming: callState === 'incoming' || callState === 'waiting',
    callOngoing: ['active', 'dialing', 'alerting', 'held'].includes(callState),
    muteIcon: sv(c.muted ? P.micOff : P.mic, 32),
    dial: S.dial || ' ',
    audioFix: (() => { const f = ((st.audio || {}).fixes || [])[0]; if (!f) return '';
      const when = f.voice ? ` (during ${f.voice === 'call' ? 'a call' : 'the assistant'})` : f.after ? ` (after a ${f.after})` : '';
      return `Last fixed automatically at ${new Date(f.at * 1000).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}${when}: ${f.what}.`; })(),
    audioMsg: a.ready ? (a.testing ? `Playing: ${a.testing}` : 'Outputs: DAC channel 1 front left, 2 front right, 3 rear left, 4 rear right, 5 subwoofer.') : (a.message || ''),
    appTitle: { maps: 'Google Maps', music: 'YouTube Music' }[app.current] || (S.screen === 'ytm' ? 'YouTube Music' : 'Google Maps'),
    appStarting: app.status === 'starting' || (app.status === 'idle' && isStage(S.screen)),
    appRunning: app.status === 'running',
    appError: app.status === 'error',
    appMsg: app.message || '',
    updInfo: `Version ${st.version || '?'}. To update, open Head Unit Link on your phone, tap “Send an update to the head unit” and pick headunit.zip.`,
    adbStatus: !st.adb || !st.adb.mode ? 'Not connected. Join the Pi’s Wi-Fi, or plug in by USB once after the phone restarts.'
      : st.adb.mode === 'usb' ? 'Connected by USB (charging). Wireless is switched on for next time.' : 'Connected wirelessly',
    wifi: st.hotspot ? `Network “${st.hotspot.ssid}”, password ${st.hotspot.password}` : 'Not set up. Run scripts/setup-hotspot.sh on the Pi.',
    speed: sp ?? '--',
    speedUnit: speedUnits(st) === 'kmh' ? 'km/h' : 'mph',
    hasSpeed: sp !== null,
    noSpeed: sp === null,
    weatherBig: weatherIcon(w, 96),
    wtempOnly: w ? `${w.temp}°` : '--°',
    wtext: w ? w.text : 'Waiting for the phone app',
    whilo: w ? `High ${w.hi}°, low ${w.lo}°` : '',
    navActive: !!nav.active, navIdle: !nav.active,
    navTitle: nav.title || '', navText: nav.text || '', navSub: nav.sub || '',
    navIcon: nav.icon ? `<img src="data:image/png;base64,${nav.icon}" alt="">` : ico('turn', 60),
    artSmall: artHtml(st, 46), artBig: artHtml(st, 110),
    companion: st.companion && st.companion.connected ? `Connected to ${st.companion.name}` : 'Not connected. The Pi installs and sets it up when the phone is plugged in.',
    knob: st.knob && st.knob.connected ? 'Connected' : 'Not connected',
    city: w && w.city ? `Weather for ${w.city}` : 'Weather',
    bright: `${settings().brightness ?? 100}%`,
    nightLevel: `${g('night_level')}%`,
    uiScale: `${g('ui_scale')}%`,
    upNext: nextInQueue() ? `Up next: ${nextInQueue().title}` : '',
    hasUpNext: !!nextInQueue(),
    assistantOn: st.voice === 'assistant',
    callVolume: `${(st.settings.audio || {}).call_volume ?? 70}`,
    obdOn: (st.obd || {}).status === 'connected',
    obdOff: (st.obd || {}).status !== 'connected',
    obdStatus: (() => { const o = st.obd || {}; const has = !!(settings().obd || {}).addr;
      if (o.status === 'connected') return `${o.message || 'Connected'}${o.hz ? `, ${Math.round(o.hz)} readings a second` : ''}`;
      if (o.status === 'connecting') return o.message || 'Connecting…';
      if (o.status === 'error') return `${o.message || 'Not connected'} Trying again by itself.`;
      return has ? 'Not connected' : 'None set up. Plug one in, turn the ignition on and tap Find adapters.'; })(),
    obdShort: (() => { const o = st.obd || {}; return o.status === 'connecting' ? 'Connecting to the car…' : (settings().obd || {}).addr ? 'Car not connected' : 'Add a Bluetooth OBD adapter'; })(),
    displayNow: st.display && st.display.current ? `${st.display.current.replace('@', ' at ')} Hz` : 'Unknown',
  };
}

// ================================================================ speedometers (SVG, 200 x 200)
const polar = (r, deg) => { const a = (deg * Math.PI) / 180; return [100 + r * Math.cos(a), 100 + r * Math.sin(a)]; };
function arcPath(r, a0, a1) {
  const [x0, y0] = polar(r, a0), [x1, y1] = polar(r, a1);
  return `M${x0.toFixed(2)} ${y0.toFixed(2)}A${r} ${r} 0 ${a1 - a0 > 180 ? 1 : 0} 1 ${x1.toFixed(2)} ${y1.toFixed(2)}`;
}
const speedMax = (units) => (units === 'kmh' ? 200 : 120);
let gradId = 0;
function speedoSVG(style) {
  const units = speedUnits(S.state || {});
  const max = speedMax(units);
  const id = `sg${gradId++}`;
  let inner = '';
  if (style === 'arc') {
    let ticks = '';
    for (let i = 0; i <= 40; i++) { const a = 135 + i * 6.75; const [x0, y0] = polar(97, a), [x1, y1] = polar(i % 5 ? 94 : 91, a);
      ticks += `<line class="tick" x1="${x0.toFixed(1)}" y1="${y0.toFixed(1)}" x2="${x1.toFixed(1)}" y2="${y1.toFixed(1)}" stroke-width="${i % 5 ? 1 : 2}" opacity="${i % 5 ? .5 : .9}"/>`; }
    inner = `<defs><linearGradient id="${id}" x1="0" y1="1" x2="1" y2="0"><stop offset="0" stop-color="var(--b1)"/><stop offset="1" stop-color="var(--accent)"/></linearGradient></defs>
      ${ticks}<path class="trk" d="${arcPath(80, 135, 405)}" stroke-width="15" stroke-linecap="round"/>
      <path class="val" d="${arcPath(80, 135, 405)}" stroke="url(#${id})" stroke-width="15" pathLength="100" stroke-dasharray="100 200" stroke-dashoffset="100" style="filter:drop-shadow(0 0 6px var(--accent))"/>
      <text class="num" x="100" y="96" font-size="58">0</text><text class="unit" x="100" y="136">${units === 'kmh' ? 'km/h' : 'mph'}</text>`;
  } else if (style === 'hud') {
    const N = 30;
    let segs = '';
    for (let i = 0; i < N; i++) {
      const a = 135 + (i + 0.5) * (270 / N);
      const col = i >= N - 5 ? '#EF4444' : i >= N - 11 ? '#FBBF24' : 'var(--accent)';
      const [x, y] = polar(84, a);
      segs += `<rect class="seg" data-i="${i}" x="${(x - 4).toFixed(1)}" y="${(y - 9).toFixed(1)}" width="8" height="18" rx="2" fill="${col}" opacity=".14" transform="rotate(${(a + 90).toFixed(1)} ${x.toFixed(1)} ${y.toFixed(1)})"/>`;
    }
    inner = `${segs}<text class="num" x="100" y="98" font-size="62" style="font-family:'DejaVu Sans Mono',monospace;letter-spacing:-4px">0</text>
      <text class="unit" x="100" y="140">${units === 'kmh' ? 'km/h' : 'mph'}</text><line x1="62" y1="152" x2="138" y2="152" stroke="var(--faint)" stroke-width="2"/>`;
  } else if (style === 'ring') {
    let tail = '';
    for (let k = 0; k < 14; k++) tail += `<path d="${arcPath(84, -90 - (k + 1) * 4.5, -90 - k * 4.5)}" stroke="var(--accent)" stroke-width="${7 - k * 0.4}" fill="none" stroke-linecap="round" opacity="${(1 - k / 14).toFixed(2)}"/>`;
    inner = `<circle cx="100" cy="100" r="84" class="trk" stroke-width="3"/><circle cx="100" cy="100" r="70" fill="none" stroke="var(--faint)" stroke-dasharray="1 5"/>
      <g class="comet">${tail}<circle cx="100" cy="16" r="6" fill="#fff" style="filter:drop-shadow(0 0 6px var(--accent))"/></g>
      <text class="num" x="100" y="96" font-size="64">0</text><text class="unit" x="100" y="134">${units === 'kmh' ? 'km/h' : 'mph'}</text>`;
  } else { // sport: needle dial with redline
    const step = units === 'kmh' ? 10 : 5, major = units === 'kmh' ? 40 : 20, red = max * 0.83;
    let ticks = '';
    for (let v = 0; v <= max; v += step) {
      const a = 135 + (v / max) * 270;
      const isMaj = v % major === 0;
      const [x0, y0] = polar(90, a), [x1, y1] = polar(isMaj ? 78 : 84, a);
      const redc = v >= red ? ' red' : '';
      ticks += `<line class="tick${isMaj ? ' major' : ''}${redc}" x1="${x0.toFixed(1)}" y1="${y0.toFixed(1)}" x2="${x1.toFixed(1)}" y2="${y1.toFixed(1)}" stroke-width="${isMaj ? 2.6 : 1.2}"/>`;
      if (isMaj) { const [lx, ly] = polar(65, a); ticks += `<text class="lbl${redc}" x="${lx.toFixed(1)}" y="${ly.toFixed(1)}" style="stroke:none">${v}</text>`; }
    }
    inner = `<defs><radialGradient id="${id}"><stop offset=".55" stop-color="var(--accent)" stop-opacity="0"/><stop offset="1" stop-color="var(--accent)" stop-opacity=".18"/></radialGradient></defs>
      <circle cx="100" cy="100" r="96" fill="url(#${id})"/>
      <path d="${arcPath(94, 135 + 270 * 0.83, 405)}" fill="none" class="red" stroke-width="4" opacity=".85"/>
      <path class="trk" d="${arcPath(94, 135, 405)}" stroke-width="3"/>
      <path class="val" d="${arcPath(94, 135, 405)}" stroke-width="4" pathLength="100" stroke-dasharray="100 200" stroke-dashoffset="100" style="filter:drop-shadow(0 0 5px var(--accent))"/>
      ${ticks}
      <g class="needle" style="transform:rotate(135deg)"><polygon points="100,96.5 186,100 100,103.5 86,100" fill="var(--accent)" style="filter:drop-shadow(0 0 5px var(--accent))"/></g>
      <circle cx="100" cy="100" r="10" fill="var(--accent)"/><circle cx="100" cy="100" r="5" fill="var(--base)"/>
      <text class="num" x="100" y="146" font-size="30">0</text><text class="unit" x="100" y="166">${units === 'kmh' ? 'km/h' : 'mph'}</text>`;
  }
  return `<svg class="speedo" data-speedo="${style}" viewBox="0 0 200 200" aria-label="Speed">${inner}</svg>`;
}
function updateSpeedos() {
  const st = S.state || {};
  const v = speedValue(st);
  const max = speedMax(speedUnits(st));
  const frac = Math.max(0, Math.min(1, (v || 0) / max));
  $$('svg.speedo').forEach((el) => {
    if (el._v === v) return;
    el._v = v;
    const num = el.querySelector('.num');
    if (num) num.textContent = v === null ? '--' : String(v);
    const val = el.querySelector('.val');
    if (val) val.style.strokeDashoffset = String(100 - frac * 100);
    const needle = el.querySelector('.needle');
    if (needle) needle.style.transform = `rotate(${135 + frac * 270}deg)`;
    const comet = el.querySelector('.comet');
    if (comet) comet.style.transform = `rotate(${frac * 360}deg)`;
    el.querySelectorAll('.seg').forEach((s) => { s.setAttribute('opacity', (+s.dataset.i + 0.5) / 30 <= frac ? '1' : '.14'); });
  });
}

// ================================================================ home cards
const CARDS = {
  music: () => `<div class="label">Now playing</div>
      <div class="np"><div class="art" data-k-html="artSmall"></div>
        <div class="np-text"><div class="np-title" data-k="title"></div><div class="np-artist sub" data-k="artist"></div>
        <div class="np-next" data-show="hasUpNext" data-k="upNext"></div></div></div>
      <div class="bar"><i data-w="progress"></i></div>
      <div class="controls">
        <button class="icon-btn sink" data-act="media:previous" aria-label="Previous">${ICON.prev}</button>
        <button class="round accent glowable sink" data-act="playpause" aria-label="Play or pause" data-k-html="playIcon"></button>
        <button class="icon-btn sink" data-act="media:next" aria-label="Next">${ICON.next}</button>
      </div>`,
  nav: () => `<div class="label">Navigation</div>
      <div class="turn" data-k-html="navIcon"></div>
      <div data-show="navActive"><h2 data-k="navTitle"></h2><div class="nav-text" data-k="navText"></div><div class="sub" data-k="navSub"></div></div>
      <div data-show="navIdle"><h2>Google Maps</h2><div class="sub">Tap to open it here, or press the mic and say “Navigate to…”</div></div>`,
  speed: () => speedoSVG(g('speedo')),
  weather: () => `<div class="label" data-k="city"></div>
      <div class="wx-row"><span data-k-html="weatherBig"></span><div class="big-num" data-k="wtempOnly"></div></div>
      <div class="w1" data-k="wtext"></div><div class="w2 sub" data-k="whilo"></div>`,
  clock: () => `<div class="clock big-num" data-k="clock"></div><div class="date sub" data-k="date"></div>`,
  favs: () => {
    const favs = (settings().favorites || []).filter((f) => f.number);
    return `<div class="label">Favorites</div><div class="favs">${favs.length ? favs.map((f) =>
      `<button class="fav sink" data-dial="${esc(f.number)}"><span class="avatar">${esc(initial(f.name))}</span><span>${esc(f.name)}</span></button>`).join('')
      : '<div class="empty">Star contacts on your phone and they show up here.</div>'}</div>`;
  },
  controls: () => {
    const a = settings().audio || {};
    return `<div class="label">Quick controls</div>
      <label class="qrow">${ico('vol', 26)}<input type="range" min="0" max="100" value="${a.volume ?? 40}" data-audio="volume" aria-label="Volume"></label>
      <label class="qrow">${ico('sun', 26)}<input type="range" min="1" max="100" step="1" value="${Math.max(1, settings().brightness || 1)}" data-bright aria-label="Brightness"></label>
      <div class="row" style="justify-content:space-between">
        <button class="btn small sink" data-act="assistant">${ico('mic', 20)}Assistant</button>
        <button class="btn small sink" data-act="screen_off">${ico('moon', 20)}Screen off</button>
      </div>`;
  },
  viz: () => `<div class="label">Visualizer</div><canvas class="viz-canvas"></canvas>`,
  art: () => `<div class="art" data-k-html="artBig"></div><div class="cap"><b data-k="title"></b><span data-k="artist"></span></div>`,
  maps: () => `<div class="map-hole" id="appArea"><div class="status">
      <div data-show="appStarting" class="spinner"></div>
      <b>Google Maps</b>
      <p class="sub" data-show="appError" data-k="appMsg"></p>
      <button class="btn small sink" data-show="appError" data-act="open:maps">Try again</button>
    </div></div>`,
};
CARDS.engine = () => `<div class="label">Engine</div>
      <div class="eng" data-show="obdOn">
        <div class="eng-rpm"><svg viewBox="0 0 200 120" aria-hidden="true"><path class="trk" d="M20 110A80 80 0 0 1 180 110" stroke-width="14" fill="none" stroke-linecap="round"/>
          <path class="val" data-obd-arc="rpm" d="M20 110A80 80 0 0 1 180 110" stroke-width="14" fill="none" stroke-linecap="round" pathLength="100" stroke-dasharray="100 200" stroke-dashoffset="100"/></svg>
          <div class="eng-num"><b data-obd="rpm">--</b><span>rpm</span></div></div>
        <div class="eng-row"><div><b data-obd="coolant">--</b><span>Coolant</span></div><div><b data-obd="volts">--</b><span>Battery</span></div><div><b data-obd="load">--</b><span>Load</span></div></div>
      </div>
      <div class="eng-off" data-show="obdOff"><b data-k="obdShort"></b><button class="btn small sink" data-act="car_settings">${ico('car', 20)}Set up</button></div>`;
// Every gauge (gauges.js GAUGE_LIST, loaded after this file) can also be a Home tile; tap one to open Gauges.
const CARD_TAP = { music: 'music', nav: 'maps', art: 'music' };
function addGaugeCards() {
  for (const [type, label] of window.GAUGE_LIST || []) {
    if (!CARD_NAMES[`g_${type}`]) CARD_NAMES[`g_${type}`] = `${label} gauge`;
    CARDS[`g_${type}`] = () => `<div class="label">${label}</div><canvas class="gcard" data-gauge="${type}" aria-label="${label} gauge"></canvas>`;
    CARD_TAP[`g_${type}`] = 'gauges';
  }
}
function cardHtml(type, slot, area) {
  const go = CARD_TAP[type] ? ` data-go-card="${CARD_TAP[type]}"` : '';
  const pos = area ? ` style="grid-area:${area}"` : '';
  // the live Maps stream is a plain rectangle, so it never gets a round, hex or tilted shape
  const shape = area ? ` s-${type === 'maps' ? 'plain' : 'shaped'} n${slot + 1}` : '';
  return `<div class="card glass ${type === 'maps' ? '' : 'tilt '}c-${type}${shape}" data-hold="slot:${slot}"${go}${pos}>${(CARDS[type] || CARDS.music)()}</div>`;
}

// ================================================================ knob face previews (SVG, 240 x 240 like the knob)
function knobColors(face) {
  if (face.pal && KNOB_PAL[face.pal]) { const p = KNOB_PAL[face.pal]; return { accent: p[0], base: p[1], text: p[2], b: [p[3], p[4], p[5]] }; }
  const t = S.theme || themeById();
  return { accent: t.accent, base: t.base, text: t.light ? '#0B1220' : '#F5F7FA', b: [t.b1, t.b2, t.b3] };
}
function knobSVG(face, uid) {
  const c = knobColors(face);
  const id = `k${uid}`;
  const v = face.val === 'speed' ? 0.52 : 0.62;
  const P2 = (r, deg) => { const a = (deg * Math.PI) / 180; return [120 + r * Math.cos(a), 120 + r * Math.sin(a)]; };
  const arc = (r, a0, a1) => { const [x0, y0] = P2(r, a0), [x1, y1] = P2(r, a1); return `M${x0.toFixed(1)} ${y0.toFixed(1)}A${r} ${r} 0 ${a1 - a0 > 180 ? 1 : 0} 1 ${x1.toFixed(1)} ${y1.toFixed(1)}`; };
  const end = 135 + 270 * v;
  let bg = `<rect width="240" height="240" fill="${c.base}"/>`;
  let defs = '';
  if (face.bg === 'aurora') {
    defs += `<filter id="${id}f"><feGaussianBlur stdDeviation="22"/></filter>`;
    bg += `<g filter="url(#${id}f)" opacity=".85"><circle cx="70" cy="75" r="70" fill="${c.b[0]}"/><circle cx="175" cy="170" r="70" fill="${c.b[1]}"/><circle cx="150" cy="80" r="60" fill="${c.b[2]}"/></g><circle cx="120" cy="120" r="97" fill="${c.base}" opacity=".5"/>`;
  } else if (face.bg === 'radial') {
    defs += `<radialGradient id="${id}r"><stop offset="0" stop-color="${c.accent}" stop-opacity=".38"/><stop offset="1" stop-color="${c.base}" stop-opacity="0"/></radialGradient>`;
    bg += `<circle cx="120" cy="120" r="120" fill="url(#${id}r)"/>`;
  } else if (face.bg === 'stars' || face.bg === 'nightdrive') {
    let s = 0;
    for (let i = 0; i < 40; i++) { const x = (i * 97) % 240, y = (i * 61 + 17) % 240; s += 1; bg += `<circle cx="${x}" cy="${y}" r="${(i % 3) * 0.6 + 0.6}" fill="${c.text}" opacity="${0.3 + (i % 4) * 0.18}"/>`; }
  } else if (face.bg === 'carbon') {
    defs += `<pattern id="${id}p" width="12" height="12" patternUnits="userSpaceOnUse"><rect width="12" height="12" fill="${c.base}"/><rect width="6" height="6" fill="#ffffff" opacity=".06"/><rect x="6" y="6" width="6" height="6" fill="#ffffff" opacity=".06"/></pattern>`;
    bg += `<rect width="240" height="240" fill="url(#${id}p)"/>`;
  } else if (face.bg === 'sunburst') {
    for (let i = 0; i < 24; i += 2) { const [x0, y0] = P2(170, i * 15), [x1, y1] = P2(170, (i + 1) * 15); bg += `<path d="M120 120L${x0.toFixed(1)} ${y0.toFixed(1)}L${x1.toFixed(1)} ${y1.toFixed(1)}Z" fill="${c.accent}" opacity=".09"/>`; }
  } else if (face.bg === 'rings' || face.bg === 'radar') {
    for (let r = 20; r < 120; r += 18) bg += `<circle cx="120" cy="120" r="${r}" fill="none" stroke="${c.text}" opacity=".12"/>`;
    if (face.bg === 'radar') bg += `<path d="M120 120L${P2(118, -90).join(' ')}A118 118 0 0 1 ${P2(118, -40).map((n) => n.toFixed(1)).join(' ')}Z" fill="${c.accent}" opacity=".3"/>`;
  } else if (face.bg === 'rain') {
    defs += `<filter id="${id}f"><feGaussianBlur stdDeviation="9"/></filter>`;
    bg += `<g filter="url(#${id}f)" opacity=".75"><circle cx="58" cy="150" r="30" fill="#FFB347"/><circle cx="170" cy="132" r="26" fill="#FFC870"/><circle cx="96" cy="200" r="18" fill="#FF2A2A"/><circle cx="196" cy="196" r="22" fill="${c.b[0]}"/><circle cx="140" cy="62" r="16" fill="${c.b[2]}"/></g>`;
    for (let i = 0; i < 34; i++) { const x = (i * 83 + 11) % 228 + 6, y = (i * 47 + 23) % 228 + 6, r = 1 + (i % 3) * 0.8; bg += `<circle cx="${x}" cy="${y}" r="${r}" fill="#0b0f16" opacity=".55"/><circle cx="${x - r * 0.3}" cy="${y - r * 0.4}" r="${r * 0.35}" fill="#fff"/>`; }
    bg += `<line x1="150" y1="40" x2="150" y2="88" stroke="${c.text}" stroke-opacity=".12" stroke-width="3"/><circle cx="150" cy="92" r="4.5" fill="#0b0f16" opacity=".6"/><circle cx="148.6" cy="90" r="1.5" fill="#fff"/>`;
  } else if (face.bg === 'liquid') {
    defs += `<linearGradient id="${id}l" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${c.accent}"/><stop offset="1" stop-color="${c.b[1]}"/></linearGradient>`;
    bg += `<path d="M0 104 Q60 92 120 102 T240 98 V240 H0Z" fill="url(#${id}l)"/><path d="M0 104 Q60 92 120 102 T240 98" stroke="#fff" stroke-opacity=".6" stroke-width="2" fill="none"/>`;
  } else if (face.bg === 'scan') {
    defs += `<pattern id="${id}s" width="4" height="4" patternUnits="userSpaceOnUse"><rect width="4" height="2" fill="#000" opacity=".35"/></pattern>`;
    bg += `<rect width="240" height="240" fill="url(#${id}s)"/>`;
  }
  const dim = `${c.text}`;
  let ring = '';
  const R = face.ring;
  if (R === 'glow' || R === 'thin') {
    const w = R === 'glow' ? 9 : 4;
    ring = `<path d="${arc(113, 135, 405)}" stroke="${dim}" stroke-opacity=".16" stroke-width="${w}" fill="none" stroke-linecap="round"/>
      <path d="${arc(113, 135, end)}" stroke="${c.accent}" stroke-width="${w}" fill="none" stroke-linecap="round" ${R === 'glow' ? `style="filter:drop-shadow(0 0 6px ${c.accent})"` : ''}/>
      <circle cx="${P2(113, end)[0]}" cy="${P2(113, end)[1]}" r="${R === 'glow' ? 7 : 5}" fill="${c.text}"/>`;
  } else if (R === 'segments') {
    for (let i = 0; i < 30; i++) { const a0 = 135 + i * 9, a1 = a0 + 6; const lit = (i + 0.5) / 30 <= v;
      ring += `<path d="${arc(110, a0, a1)}" stroke="${lit ? c.accent : dim}" stroke-opacity="${lit ? 1 : 0.16}" stroke-width="13" fill="none"/>`; }
  } else if (R === 'dots') {
    for (let i = 0; i <= 36; i++) { const a = 135 + i * 7.5; const [x, y] = P2(112, a); const lit = i / 36 <= v; ring += `<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="${lit ? 3.6 : 2.2}" fill="${lit ? c.accent : dim}" opacity="${lit ? 1 : 0.25}"/>`; }
  } else if (R === 'bars') {
    for (let i = 0; i < 48; i++) { const a = i * 7.5; const len = 6 + 14 * Math.abs(Math.sin(i * 1.7)) * (i / 48 <= v ? 1 : 0.3);
      const [x0, y0] = P2(116, a), [x1, y1] = P2(116 - len, a); ring += `<line x1="${x0.toFixed(1)}" y1="${y0.toFixed(1)}" x2="${x1.toFixed(1)}" y2="${y1.toFixed(1)}" stroke="${i / 48 <= v ? c.accent : dim}" stroke-opacity="${i / 48 <= v ? 1 : 0.25}" stroke-width="3.5" stroke-linecap="round"/>`; }
  } else if (R === 'double') {
    ring = `<circle cx="120" cy="120" r="114" stroke="${dim}" stroke-opacity=".15" stroke-width="5" fill="none"/>
      <path d="${arc(114, 135, end)}" stroke="${c.accent}" stroke-width="5" fill="none" stroke-linecap="round"/>
      <path d="${arc(102, 135, 135 + 270 * v * 0.8)}" stroke="${c.b[0]}" stroke-width="3" fill="none" stroke-linecap="round"/>`;
  } else if (R === 'gradient') {
    defs += `<linearGradient id="${id}g" x1="0" y1="1" x2="1" y2="0"><stop offset="0" stop-color="${c.b[0]}"/><stop offset="1" stop-color="${c.accent}"/></linearGradient>`;
    ring = `<path d="${arc(110, 135, 405)}" stroke="${dim}" stroke-opacity=".14" stroke-width="13" fill="none" stroke-linecap="round"/>
      <path d="${arc(110, 135, end)}" stroke="url(#${id}g)" stroke-width="13" fill="none" stroke-linecap="round"/>`;
  } else if (R === 'dial' || R === 'sport') {
    const N = R === 'sport' ? 24 : 40;
    for (let i = 0; i <= N; i++) { const a = 135 + (i / N) * 270; const major = i % (R === 'sport' ? 4 : 4) === 0; const red = R === 'sport' && i / N > 0.83;
      const [x0, y0] = P2(117, a), [x1, y1] = P2(major ? 102 : 110, a);
      ring += `<line x1="${x0.toFixed(1)}" y1="${y0.toFixed(1)}" x2="${x1.toFixed(1)}" y2="${y1.toFixed(1)}" stroke="${red ? '#EF4444' : i / N <= v && R === 'dial' ? c.accent : dim}" stroke-opacity="${red || (i / N <= v && R === 'dial') ? 1 : 0.6}" stroke-width="${major ? 3 : 1.5}"/>`; }
    if (R === 'sport') ring += `<path d="${arc(118, 135, end)}" stroke="${c.accent}" stroke-width="3" fill="none"/>`;
    const [nx, ny] = P2(100, end);
    ring += `<line x1="120" y1="120" x2="${nx.toFixed(1)}" y2="${ny.toFixed(1)}" stroke="${c.accent}" stroke-width="5" stroke-linecap="round"/><circle cx="120" cy="120" r="11" fill="${c.accent}"/><circle cx="120" cy="120" r="5" fill="${c.base}"/>`;
  } else if (R === 'comet' || R === 'clock') {
    ring = `<circle cx="120" cy="120" r="113" stroke="${dim}" stroke-opacity=".16" stroke-width="2" fill="none"/>`;
    if (R === 'comet') for (let k = 0; k < 10; k++) ring += `<path d="${arc(113, 200 - (k + 1) * 6, 200 - k * 6)}" stroke="${c.accent}" stroke-width="${6 - k * 0.45}" fill="none" opacity="${1 - k / 10}"/>`;
    else for (let i = 0; i < 60; i++) { const a = i * 6; const major = i % 5 === 0; const [x0, y0] = P2(117, a), [x1, y1] = P2(major ? 104 : 112, a);
      ring += `<line x1="${x0.toFixed(1)}" y1="${y0.toFixed(1)}" x2="${x1.toFixed(1)}" y2="${y1.toFixed(1)}" stroke="${major ? c.text : dim}" stroke-opacity="${major ? 1 : 0.45}" stroke-width="${major ? 3 : 1.2}"/>`; }
  }
  if (R === 'tach') {
    ring = `<path d="${arc(116, 135 + 270 * 6 / 7, 405)}" stroke="#EF4444" stroke-opacity=".85" stroke-width="8" fill="none"/>`;
    for (let i = 0; i <= 28; i++) { const a = 135 + (i / 28) * 270, major = i % 4 === 0, red = i / 28 >= 6 / 7;
      const [x0, y0] = P2(111, a), [x1, y1] = P2(major ? 95 : 104, a);
      ring += `<line x1="${x0.toFixed(1)}" y1="${y0.toFixed(1)}" x2="${x1.toFixed(1)}" y2="${y1.toFixed(1)}" stroke="${red ? '#EF4444' : c.text}" stroke-opacity="${major || red ? 1 : 0.6}" stroke-width="${major ? 3 : 1.4}"/>`;
      if (major) { const [lx, ly] = P2(79, a); ring += `<text x="${lx.toFixed(1)}" y="${ly.toFixed(1)}" font-size="14" fill="${red ? '#EF4444' : c.text}" text-anchor="middle" dominant-baseline="central" font-family="Inter,DejaVu Sans,sans-serif">${i / 4}</text>`; } }
    const [nx, ny] = P2(100, 135 + 270 * 0.42);
    ring += `<line x1="120" y1="120" x2="${nx.toFixed(1)}" y2="${ny.toFixed(1)}" stroke="${c.accent}" stroke-width="5" stroke-linecap="round"/><circle cx="120" cy="120" r="11" fill="${c.accent}"/><circle cx="120" cy="120" r="5" fill="${c.base}"/>`;
  } else if (R === 'orbit') {
    ring = `<circle cx="120" cy="120" r="104" stroke="${c.text}" stroke-opacity=".08" fill="none"/>`;
    [[58, 40, c.b[0]], [76, 200, c.b[1]], [44, 300, c.b[2]]].forEach(([r, a, col]) => { const [x, y] = P2(r, a); ring += `<circle cx="120" cy="120" r="${r}" stroke="${c.text}" stroke-opacity=".06" fill="none"/><circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="3" fill="${col}"/>`; });
    for (let k = 0; k < 24; k++) { const f = 1 - k / 24, [x, y] = P2(104, -30 - k * 6); ring += `<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="${(1 + 3.5 * f).toFixed(1)}" fill="${c.accent}" opacity="${(f * f).toFixed(2)}"/>`; }
    const [hx, hy] = P2(104, -30); ring += `<circle cx="${hx.toFixed(1)}" cy="${hy.toFixed(1)}" r="5" fill="#fff"/>`;
  }
  const T = (x, y, s, txt, col, w = 700) => `<text x="${x}" y="${y}" font-size="${s}" font-weight="${w}" fill="${col}" text-anchor="middle" dominant-baseline="central" font-family="Inter,DejaVu Sans,sans-serif">${txt}</text>`;
  let center = '';
  const C = face.center;
  if (C === 'music') center = T(120, 66, 15, '12:45', c.text, 500) + T(120, 106, 20, 'Song title', c.text) + T(120, 132, 14, 'Artist', c.text, 400) + `<circle cx="120" cy="176" r="22" fill="${c.accent}"/><path d="M114 166v20l16-10z" fill="${c.base}"/>`;
  else if (C === 'clock') center = T(120, 120, 62, '12:45', c.text, 800) + T(120, 168, 14, 'Song title', c.text, 400);
  else if (C === 'speed') center = T(120, 122, 74, '62', c.text, 800) + T(120, 172, 15, 'mph', c.text, 500);
  else if (C === 'speedlow') center = T(120, 172, 34, '62', c.text, 800) + T(120, 196, 12, 'mph', c.text, 500);
  else if (C === 'volume') center = T(120, 118, 76, '40', c.text, 800) + T(120, 170, 15, 'Volume', c.text, 500);
  else if (C === 'gaugeinfo') center = T(120, 66, 15, '12:45', c.text, 500) + T(120, 166, 20, '40', c.text) + T(120, 190, 13, 'Song', c.text, 400);
  else if (C === 'eqclock') { center = T(120, 104, 40, '12:45', c.text, 800) + T(120, 142, 14, 'Song title', c.text, 400);
    for (let i = 0; i < 5; i++) { const h = 6 + ((i * 7) % 16); center += `<rect x="${98 + i * 9}" y="${182 - h}" width="6" height="${h}" rx="2" fill="${c.accent}"/>`; } }
  else if (C === 'analog') {
    const hand = (deg, len, w, col) => { const [x, y] = P2(len, deg - 90); return `<line x1="120" y1="120" x2="${x.toFixed(1)}" y2="${y.toFixed(1)}" stroke="${col}" stroke-width="${w}" stroke-linecap="round"/>`; };
    center = hand(300, 55, 7, c.text) + hand(60, 85, 4.5, c.text) + hand(200, 95, 2, c.accent) + `<circle cx="120" cy="120" r="7" fill="${c.accent}"/>`;
  }
  return `<svg viewBox="0 0 240 240" aria-hidden="true"><defs>${defs}<clipPath id="${id}c"><circle cx="120" cy="120" r="120"/></clipPath></defs><g clip-path="url(#${id}c)">${bg}${ring}${center}</g></svg>`;
}

// ================================================================ screens
function navHtml() {
  const items = [['home', 'Home'], ['gauges', 'Gauges'], ['maps', 'Maps'], ['music', 'Music'], ['phone', 'Phone'], ['audio', 'Sound'], ['look', 'Look'], ['settings', 'Settings']];
  return `<div class="nav-pill" id="navPill"></div>
    <div class="nav-speed" data-show="hasSpeed"><b data-k="speed"></b><span data-k="speedUnit"></span></div>
    ${items.map(([id, l]) => `<button class="nav-btn" data-go="${id}" aria-label="${l}">${ico(id, 28)}</button>`).join('')}
    <div class="nav-gap"></div>
    <button class="nav-btn stage-only" data-act="fullmap" aria-label="Full screen">${S.full
      ? '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M9 4v5H4M15 4v5h5M9 20v-5H4M15 20v-5h5"/></svg>'
      : '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/></svg>'}</button>
    <button class="nav-btn" id="dimBtn" aria-label="Dim the screen (hold to turn it off)">${ico('moon', 26)}</button>
    <button class="nav-btn voice glowable" data-act="assistant" aria-label="Voice assistant">${ico('mic', 26)}</button>`;
}

const GAUGE_LAYOUTS = [['duo', 'Two', 2], ['trio', 'Three', 3], ['quad', 'Four', 4], ['six', 'Six', 6]];
const gaugeSet = () => Object.assign({}, DEF.gauges, settings().gauges || {});
const views = {
  gauges() {
    const gs = gaugeSet(), n = (GAUGE_LAYOUTS.find((l) => l[0] === gs.layout) || GAUGE_LAYOUTS[2])[2];
    const o = (S.state && S.state.obd) || {};
    const names = Object.fromEntries((window.GAUGE_LIST || []).map(([id, l]) => [id, l]));
    return `<section class="screen gauges-screen g-${gs.layout} ${S.gEdit ? 'editing' : ''}">
      <header class="g-head">
        <h1>Gauges</h1>
        ${o.status === 'connected' ? '' : `<button class="g-warn sink" data-act="car_settings">${ico('car', 20)}<span>${o.status === 'connecting' ? 'Connecting to your OBD adapter…' : 'Connect your OBD adapter to bring these to life'}</span></button>`}
        <div class="g-tools">
          ${S.gEdit ? seg('data-glayout', GAUGE_LAYOUTS.map(([k, l]) => [k, l]), gs.layout) : ''}
          <button class="btn ${S.gEdit ? 'primary' : ''} sink" data-act="gauges_edit">${S.gEdit ? 'Done' : `${ico('sliders', 20)}Change gauges`}</button>
          ${S.gEdit ? '' : `<button class="btn sink" data-act="cluster_settings">${ico('gauge', 20)}Cluster</button>`}
        </div>
      </header>
      <div class="g-grid">${gs.slots.slice(0, n).map((id, i) => `<div class="gslot glass g${i}" data-gslot="${i}">
          <canvas data-gauge="${id}" aria-label="${names[id] || id}"></canvas>
          ${S.gEdit ? `<div class="g-pick">${ico('sliders', 26)}<b>${names[id] || id}</b><span>Tap to change</span></div>` : ''}
        </div>`).join('')}</div>
    </section>`;
  },
  home() {
    const lay = LAYOUTS[g('home_layout')] ? g('home_layout') : 'dashboard';
    if (lay === 'free') return `<section class="screen home l-free ${S.edit ? 'editing' : ''}">${freeHtml()}</section>`;
    const favs = (settings().favorites || []).filter((f) => f.number).slice(0, 3);
    const header = lay === 'dashboard' && g('header') ? `<header class="home-top">
        <div><div class="clock big-num" data-k="clock"></div><div class="date sub" data-k="date"></div></div>
        <div class="wx"><div><div class="wtemp big-num" data-k="wtemp"></div><div class="wdesc sub" data-k="wdesc"></div></div><span data-k-html="wicon"></span></div>
      </header>` : '';
    const quick = lay !== 'grid' && g('quick') ? `<div class="quick">
        ${favs.map((f) => `<button class="chip glass sink" data-dial="${esc(f.number)}"><span class="avatar">${esc(initial(f.name))}</span><span>${esc(f.name)}</span></button>`).join('')}
        <div class="status-chip">${ico('bt', 22)}<span data-k="phoneStatus"></span></div>
      </div>` : '';
    let body;
    if (lay === 'minimal') {
      body = `<div class="minimal-hero"><div><div class="clock big-num" data-k="clock"></div><div class="date sub" data-k="date"></div><div class="np-line" data-k="npLine"></div></div></div>`;
    } else if (LAYOUTS[lay].gen) {
      const L = LAYOUTS[lay];
      const letters = [...new Set(L.wire.join(' ').split(' ').filter((x) => x !== '.'))].sort();
      body = `<div class="slots gen" style="grid-template-columns:${L.cols};grid-template-rows:${L.rows};grid-template-areas:${L.wire.map((r) => `'${r}'`).join(' ')}">${
        cardsFor(lay).map((c, i) => cardHtml(c, i, letters[i])).join('')}</div>`;
    } else {
      body = `<div class="slots">${cardsFor(lay).map((c, i) => cardHtml(c, i)).join('')}</div>`;
    }
    return `<section class="screen home l-${lay}">${header}${body}${quick}</section>`;
  },

  stage() {
    const name = S.screen === 'ytm' ? 'music' : 'maps';
    const panel = g('maps_panel');
    const side = panel ? `<aside class="side glass">
        ${speedoSVG(g('speedo'))}
        <div class="turn-row" data-show="navActive"><span class="ic" data-k-html="navIcon"></span><div style="min-width:0"><b data-k="navTitle"></b><span class="sub" data-k="navText"></span></div></div>
        <div class="np"><div class="art" data-k-html="artSmall"></div><div style="min-width:0;flex:1"><div class="np-title" data-k="title"></div><div class="np-artist sub" data-k="artist"></div></div></div>
        <div class="controls">
          <button class="icon-btn sink" data-act="media:previous" aria-label="Previous">${ICON.prev}</button>
          <button class="round accent sink" data-act="playpause" aria-label="Play or pause" data-k-html="playIcon"></button>
          <button class="icon-btn sink" data-act="media:next" aria-label="Next">${ICON.next}</button>
        </div>
      </aside>` : '';
    return `<section class="screen stage ${panel ? 'with-panel' : ''}">${side}
      <div class="area glass" id="appArea">
        <div class="status">
          <div data-show="appStarting" class="spinner"></div>
          <h1 data-k="appTitle"></h1>
          <p data-show="appStarting">Opening on your phone and streaming it here…</p>
          <p data-show="appRunning">Running. Use the buttons on the side to leave.</p>
          <p data-show="appError" data-k="appMsg"></p>
          <div class="row" data-show="appError" style="justify-content:center;margin-top:1rem"><button class="btn primary sink" data-act="open:${name}">Try again</button></div>
        </div>
      </div>
    </section>`;
  },

  music() {
    const a = settings().audio || {};
    const tabs = [['queue', 'Up next', 'list'], ['library', 'Library', 'library'], ['search', 'Search', 'search'], ['pins', 'Pinned', 'pin']];
    return `<section class="screen music2">
      <div class="now glass tilt">
        <div class="art-stage"><div class="art" data-k-html="artBig"></div></div>
        <div class="now-text"><h2 class="np-title" data-k="title"></h2><div class="sub np-artist" data-k="artist"></div></div>
        <div><div class="bar"><i data-w="progress"></i></div><div class="times"><span data-k="pos"></span><span data-k="dur"></span></div></div>
        <div class="controls">
          <button class="icon-btn sink" data-act="media:previous" aria-label="Previous">${ICON.prev}</button>
          <button class="round accent glowable sink" data-act="playpause" aria-label="Play or pause" data-k-html="playIcon"></button>
          <button class="icon-btn sink" data-act="media:next" aria-label="Next">${ICON.next}</button>
        </div>
        <label class="vol-row">${ico('vol', 24)}<input type="range" min="0" max="100" value="${a.volume ?? 40}" data-audio="volume" aria-label="Volume"></label>
        <button class="btn small sink" data-go="ytm">${ico('music', 18)}Open YouTube Music</button>
      </div>
      <div class="mpane glass">
        <div class="mtabs">${tabs.map(([k, l, i]) => `<button class="mtab sink ${S.mtab === k ? 'on' : ''}" data-act="mtab:${k}">${ico(i, 22)}<span>${l}</span></button>`).join('')}</div>
        <div class="mbody" id="mpanel"></div>
      </div>
    </section>`;
  },

  phone() {
    const keys = [['1', ''], ['2', 'ABC'], ['3', 'DEF'], ['4', 'GHI'], ['5', 'JKL'], ['6', 'MNO'], ['7', 'PQRS'], ['8', 'TUV'], ['9', 'WXYZ'], ['*', ''], ['0', '+'], ['#', '']];
    return `<section class="screen phone">
      <div class="glass list-panel">
        <div class="seg">
          <button data-act="tab:favorites" class="${S.tab === 'favorites' ? 'on' : ''}">Favorites</button>
          <button data-act="tab:recents" class="${S.tab === 'recents' ? 'on' : ''}">Recents</button>
        </div>
        <div class="plist" id="plist"></div>
      </div>
      <div class="glass keypad">
        <div class="dial-display"><span data-k="dial"></span><button class="icon-btn sink" data-act="backspace" aria-label="Delete">${ico('back', 28)}</button></div>
        <div class="keys">${keys.map(([d, l]) => `<button class="key sink" data-key="${d}"><b>${d}</b><small>${l}</small></button>`).join('')}</div>
        <button class="round ok sink" data-act="call" aria-label="Call">${ICON.phone}</button>
      </div>
    </section>`;
  },

  audio() {
    const rows = [
      ['volume', 'Volume', 0, 100, 1, (v) => `${v}`],
      ['sub', 'Subwoofer level', -12, 12, 1, (v) => `${v > 0 ? '+' : ''}${v} dB`],
      ['xover', 'Subwoofer crossover', 40, 160, 5, (v) => `${v} Hz`],
      ['bass', 'Bass', -10, 10, 1, (v) => `${v > 0 ? '+' : ''}${v}`],
      ['mid', 'Mid', -10, 10, 1, (v) => `${v > 0 ? '+' : ''}${v}`],
      ['treble', 'Treble', -10, 10, 1, (v) => `${v > 0 ? '+' : ''}${v}`],
      ['call_volume', 'Call volume', 0, 100, 1, (v) => `${v}`],
      ['assistant_volume', 'Voice assistant volume', 0, 100, 1, (v) => `${v}`],
    ];
    S.fmt = Object.fromEntries(rows.map((r) => [r[0], r[5]]));
    const a = Object.assign({ call_volume: 70, assistant_volume: 60 }, settings().audio || {});
    return `<section class="screen audio">
      <div class="glass pad-panel">
        <h2>Fader and balance</h2>
        <div class="pad" id="pad">
          <span class="spk" style="top:12%;left:6%">FL</span><span class="spk" style="top:12%;right:6%">FR</span>
          <span class="spk" style="top:72%;left:6%">RL</span><span class="spk" style="top:72%;right:6%">RR</span>
          <span class="spk" style="bottom:5%;left:50%;transform:translateX(-50%)">Sub</span>
          <div class="dot" id="dot"></div>
        </div>
        <div class="pad-read"><span>Fader <b id="faderVal"></b></span><span>Balance <b id="balVal"></b></span><button class="btn small sink" data-act="center">Center</button></div>
      </div>
      <div class="glass sliders">
        ${rows.map(([k, label, min, max, step, f]) => `<label class="slider-row"><div class="top"><span>${label}</span><b id="v_${k}">${f(a[k] ?? 0)}</b></div>
          <input type="range" min="${min}" max="${max}" step="${step}" value="${a[k] ?? 0}" data-audio="${k}" aria-label="${label}"></label>`).join('')}
        <div class="row">
          <button class="btn primary sink" data-act="speaker_test">Test speakers</button>
          <button class="btn sink" data-act="tone_reset">Flatten tone</button>
          <button class="btn sink" data-act="fix_audio">${ico('wrench', 20)}Fix sound</button>
        </div>
        <p class="note">Call and assistant volumes are separate from music. Turning the knob during a call or while the assistant talks changes only that volume.</p>
        <p class="note" data-k="audioMsg"></p>
        <p class="note" data-k="audioFix"></p>
      </div>
    </section>`;
  },

  look() {
    // Four places: pick a Look, customize it (saved with it), let it switch by itself, and the Home layout.
    const tabs = [['looks', 'Looks', 'star', 'Pick the whole dash'], ['custom', 'Customize', 'look', 'Make this one yours'],
      ['auto', 'Auto-switch', 'sun', 'Weather and time'], ['home', 'Home layout', 'layout', 'What goes where']];
    if (!LOOK[S.lookTab]) S.lookTab = 'looks';
    const pane = LOOK[S.lookTab]();
    requestAnimationFrame(() => { if (typeof flowPreview === 'function') flowPreview(document.getElementById('dashPv')); });
    return `<section class="screen panel-screen look-screen">
      <div class="tabs glass"><h1>Look</h1>${tabs.map(([k, l, i, d]) => `<button class="tab sink ${S.lookTab === k ? 'on' : ''}" data-act="looktab:${k}">${ico(i, 24)}<span>${l}<small>${d}</small></span></button>`).join('')}</div>
      <div class="pane glass"><div class="pane-scroll">${pane}</div></div>
    </section>`;
  },

  settings() {
    const tabs = [['phone', 'Phone', 'phone'], ['car', 'Car', 'car'], ['display', 'Display', 'display'], ['cluster', 'Cluster', 'gauge'], ['tools', 'Tools', 'wrench'], ['about', 'System', 'info']];
    const pane = SET[S.setTab] ? SET[S.setTab]() : SET.phone();
    return `<section class="screen panel-screen">
      <div class="tabs glass"><h1>Settings</h1>${tabs.map(([k, l, i]) => `<button class="tab sink ${S.setTab === k ? 'on' : ''}" data-act="settab:${k}">${ico(i, 24)}${l}</button>`).join('')}</div>
      <div class="pane glass"><div class="pane-scroll">${pane}</div></div>
    </section>`;
  },
};
views.maps = views.stage;
// ---- CAN listener (Settings > Car > CAN listener): every message on the car's bus, live. Bytes flash when they
// change. "Ignore what's changing" learns the background chatter; after that, only bytes that change when you do
// something light up and are listed under "Reacted". The backend sends {"type":"can"} ~4 times a second.
views.can = () => `<section class="screen panel-screen can-screen"><div class="pane glass"><div class="pane-scroll">
    <div class="ph"><h2>CAN listener</h2><button class="btn small sink" data-act="car_settings">${ico('back', 18)}Car settings</button></div>
    <div class="can-bar" id="canBar"></div>
    <div id="canHits"></div>
    <div class="can-head"><span>ID</span><span>Hz</span><span>Bytes (lit = just changed, dim = ignored)</span></div>
    <div id="canList"></div>
    <p class="note">How to use it: 1. Start. 2. With nothing touched, tap “Ignore what's changing” and wait 10 seconds (engine idling if you're testing with it on). 3. Do one thing (a button, the brake, a door) a few times. Whatever reacts shows up at the top. Tap Mark before each test so the saved log (logs folder) says what you did. Only messages on the OBD port's bus can be seen; some controls (like the turn signals on this car) aren't on it. The gauges pause while it listens.</p>
  </div></div></section>`;
const CAN = { data: null };
function onCan(c) {
  CAN.data = c;
  if (S.screen === 'can') renderCan();
}
function canBits(v) { return v.toString(2).padStart(8, '0').replace(/(....)/, '$1 '); }
function renderCan() {
  const bar = $('#canBar');
  if (!bar) return;
  const c = CAN.data || {}, on = !!(S.state && S.state.obd && S.state.obd.listening) || c.on;
  bar.innerHTML = `<button class="btn ${on ? '' : 'primary'} sink" data-act="can_listen:${on ? 0 : 1}">${on ? 'Stop' : 'Start listening'}</button>
    ${on ? `<button class="btn sink ${c.learning ? 'busy' : ''}" data-act="can_ignore">${c.learning ? `Learning… ${Math.ceil(c.learning)}s` : 'Ignore what\'s changing'}</button>
    ${c.learned ? '<button class="btn sink" data-act="can_clear">Forget ignored</button>' : ''}
    <button class="btn sink" data-act="can_mark">Mark ${(CAN.mark || 0) + 1}</button>` : ''}
    <span class="can-stat">${on && c.ids ? `${c.ids.length} IDs · ${c.fps || 0} frames/s${c.over ? ` · ${c.over} dropped` : ''} · ${c.secs || 0}s` : c.file ? `Saved ${esc(c.file)}${c.frames ? ` (${c.frames} frames)` : ''}` : 'Not listening'}</span>`;
  const ids = c.ids || [];
  const hits = [];
  for (const [id, , data, , , h] of ids) (h || []).forEach((n, i) => { if (n) hits.push([id, i, n, parseInt(data.substr(i * 2, 2), 16)]); });
  hits.sort((a, b) => b[2] - a[2]);
  $('#canHits').innerHTML = c.learned && !c.learning ? `<div class="sect-t">Reacted since ignoring</div>${hits.length
    ? `<div class="can-hits">${hits.slice(0, 12).map(([id, i, n, v]) => `<div class="can-hit"><b>${id}</b><span>byte ${i}</span><code>${v.toString(16).toUpperCase().padStart(2, '0')}</code><code>${canBits(v)}</code><small>${n} change${n > 1 ? 's' : ''}</small></div>`).join('')}</div>`
    : '<p class="note">Nothing yet. Do the thing you want to find, a few times.</p>'}` : '';
  const order = ids.slice().sort((a, b) => (c.learned ? b[5].reduce((x, y) => x + y, 0) - a[5].reduce((x, y) => x + y, 0) : 0) || (a[0] < b[0] ? -1 : 1));
  $('#canList').innerHTML = order.map(([id, hz, data, age, noise, h, nv]) => `<div class="can-row"><b>${id}</b><span>${hz}</span><div class="can-bytes">${
    [...Array(data.length / 2)].map((_, i) => {
      const cls = h[i] ? 'hit' : noise[i] === '1' ? 'noise' : age[i] >= 0 && age[i] < 400 ? 'lit' : age[i] >= 0 && age[i] < 2000 ? 'warm' : '';
      return `<i class="${cls}" title="${nv[i]} different values">${data.substr(i * 2, 2)}</i>`;
    }).join('')}</div></div>`).join('') || (on ? '<p class="note">Waiting for frames…</p>' : '');
}
views.ytm = views.stage;

const seg = (attr, opts, cur) => `<div class="seg">${opts.map(([v, l]) => `<button class="${cur === v ? 'on' : ''}" ${attr}="${v}">${l}</button>`).join('')}</div>`;
const sw = (attr, on, label) => `<button class="switch ${on ? 'on' : ''}" ${attr} aria-label="${label}"></button>`;
const outKey = (attr) => attr.replace(/["=]/g, '_');
const slider = (attr, label, val, min, max, step, shown) => `<label class="opt col"><div class="top"><span>${label}</span><b data-out="${outKey(attr)}">${shown}</b></div>
  <input type="range" min="${min}" max="${max}" step="${step}" value="${val}" ${attr}></label>`;

const optRow = (t, d, ctl) => `<div class="opt"><div><div class="t">${t}</div>${d ? `<div class="d">${d}</div>` : ''}</div>${ctl}</div>`;
const AUTO_WHEN = [['day', 'Daytime'], ['night', 'Night'], ['rain', 'Rain'], ['storm', 'Thunderstorm'], ['snow', 'Snow'], ['fog', 'Fog'],
  ['clear', 'Clear sky'], ['cloudy', 'Cloudy'], ['time', 'Between times']];
// "Follow the weather": first match wins, so the rarer weather comes first.
const AUTO_WEATHER = [['storm', 'thunderstorm'], ['snow', 'snowfall'], ['rain', 'rainy-window'], ['fog', 'fog'], ['night', 'midnight-run'],
  ['cloudy', 'arctic'], ['clear', 'sunny-day']];
const hhmm = (m) => `${String(Math.floor(m / 60) % 24).padStart(2, '0')}:${String(m % 60).padStart(2, '0')}`;

const LOOK = {
  // ---- Looks: every Look as a big card. One tap restyles the cluster, this screen and the knob together.
  looks() {
    const lk = S.state.look || {}, mine = S.state.my_looks || [];
    const groups = ['All', ...(mine.length ? ['Yours'] : []), ...LOOK_GROUPS];
    const grp = groups.includes(S.lookGroup) ? S.lookGroup : 'All';
    const list = grp === 'Yours' ? mine : grp === 'All' ? [...mine, ...LOOKS] : LOOKS.filter((x) => x.group === grp);
    const f = flowSet();
    const card = (x) => {
      const scene = x.scene !== undefined ? x.scene : ((x.set || {}).flow || {}).on === false ? null : ((x.set || {}).flow || {}).scene;
      return `<button class="lk-card sink ${lk.id === x.id ? 'on' : ''}" data-look="${esc(x.id)}">${lookSwatch(x.colors)}
        <b>${esc(x.name)}</b><small>${esc(x.desc || '')}</small>${scene ? `<em>${ico('motion', 14)}${esc(sceneName(scene))}</em>` : ''}</button>`;
    };
    const armed = S.armed === `lookdel:${lk.id}`;
    return `<div class="lk-hero">${lookSwatch(lk.colors)}
        <div class="lk-ht"><small>Now on all three screens</small><b>${esc(lk.name || '')}</b><p>${esc(lk.desc || '')}</p>
          <div class="lk-tags">${lk.mine ? '<i>Yours</i>' : ''}${lk.edited && !lk.mine ? '<i>With your tweaks</i>' : ''}${f.on ? `<i>${ico('motion', 14)} ${esc(sceneName(f.scene))}</i>` : ''}</div>
          <div class="lk-acts"><button class="btn primary sink" data-act="looktab:custom">${ico('look', 20)}Customize</button>
            <button class="btn sink" data-act="looksave">${ico('star', 20)}Save as mine</button>
            ${lk.edited && !lk.mine ? `<button class="btn sink" data-act="lookreset">${ico('back', 20)}Undo tweaks</button>` : ''}
            ${lk.mine ? `<button class="btn sink ${armed ? 'warn' : ''}" data-act="lookdel:${esc(lk.id)}">${ico('x', 20)}${armed ? 'Tap again to delete' : 'Delete'}</button>` : ''}</div></div></div>
      <div class="chips swipe lk-groups">${groups.map((x) => `<button class="sink ${grp === x ? 'on' : ''}" data-act="lookgroup:${x}">${x}</button>`).join('')}</div>
      <div class="lk-grid">${list.map(card).join('')}</div>
      <p class="note">Every Look changes the colors, panels, the moving wallpaper across all three screens, the gauges, the knob, the map colors and the startup screen. Your Home and cluster layouts stay as they are. Make your own in the Theme Studio on your phone, or tweak one here and tap Save as mine.</p>`;
  },

  // ---- Customize: the parts of the Look you're on. Everything here is saved with it.
  custom() {
    const parts = [['colors', 'Colors'], ['wallpaper', 'Wallpaper'], ['panels', 'Panels'], ['gauges', 'Gauges'], ['knob', 'Knob'], ['more', 'Map & startup']];
    const p = parts.some(([k]) => k === S.lookPart) ? S.lookPart : 'colors';
    const lk = S.state.look || {};
    return `<div class="ph"><h2>${esc(lk.name || 'This Look')}</h2><p class="sub">${lk.mine ? 'Saved straight into your Look' : 'Saved with this Look. Undo tweaks on the Looks tab brings back the original.'}</p></div>
      <div class="seg lk-parts">${parts.map(([k, l]) => `<button class="${p === k ? 'on' : ''}" data-act="lookpart:${k}">${l}</button>`).join('')}</div>
      ${LOOKPART[p]()}`;
  },

  // ---- Auto-switch: Looks that come on by themselves with the weather or the time. First match wins.
  auto() {
    const sc = Object.assign({ on: false, rules: [] }, settings().look_schedule || {});
    const now = S.state.schedule_now, nowLook = now && lookById(now);
    return `<div class="ph"><h2>Auto-switch</h2><p class="sub">The dash changes its Look by itself</p></div>
      <button class="wlook glass sink ${sc.on ? 'on' : ''}" data-act="auto_on">
        <span class="wl-icon">${ico(wxIconName(), 34)}</span>
        <span class="wl-text"><b>Switch Looks by themselves</b><small>${sc.on
          ? (nowLook ? `Now: ${esc(nowLook.name)}. Picking a Look yourself keeps it until the weather or time changes.` : 'Nothing matches right now, so your own pick stays.')
          : 'Rain outside? It rains on your dash. Snow, fog, night, sunshine: each can bring its own Look.'}</small></span>
        <span class="switch ${sc.on ? 'on' : ''}"></span></button>
      <div class="sect-t">Rules <small>(the first one that matches wins)</small></div>
      <div class="ar-list">${sc.rules.length ? sc.rules.map((r, i) => {
        const l = lookById(r.look);
        return `<div class="ar-row glass">
          <button class="ar-when sink" data-act="auto_when:${i}">${esc((AUTO_WHEN.find((w) => w[0] === r.when) || ['', r.when])[1])}</button>
          ${r.when === 'time' ? `<span class="ar-time"><button class="sink" data-act="auto_t:${i}:from:-30">−</button><b>${hhmm(r.from || 0)}</b><button class="sink" data-act="auto_t:${i}:from:30">+</button>
            to <button class="sink" data-act="auto_t:${i}:to:-30">−</button><b>${hhmm(r.to || 0)}</b><button class="sink" data-act="auto_t:${i}:to:30">+</button></span>` : ''}
          <button class="ar-look sink" data-act="auto_look:${i}">${l ? lookSwatch(l.colors) : ''}<span>${esc(l ? l.name : 'Pick a Look')}</span></button>
          <button class="round soft sink" data-act="auto_del:${i}" aria-label="Remove">${ico('x', 18)}</button></div>`;
      }).join('') : '<p class="note">No rules yet.</p>'}</div>
      <div class="row ar-add"><button class="btn primary sink" data-act="auto_weather">${ico('rain', 20)}Follow the weather</button>
        <button class="btn sink" data-act="auto_add">${ico('clock', 20)}Add a rule</button></div>
      <p class="note">Follow the weather fills in: storm, snow, rain, fog, night, cloudy and sunny, each with a Look made for it. Tap a rule's Look to change it.</p>`;
  },

  // ---- Home layout: the layout, what goes in each spot, and the side rail. (Setup, not part of a Look.)
  home() {
    const cur = g('home_layout');
    const wire = (L) => {
      const cols = L.wire[0].split(' ').length;
      const k = Object.keys(LAYOUTS).find((x) => LAYOUTS[x] === L);
      const areas = [...new Set(L.wire.join(' ').split(' '))].filter((a) => a !== '.').sort();
      return `<div class="wire wl-${k}" style="grid-template-columns:${L.cols || `repeat(${cols},1fr)`};grid-template-rows:${L.rows};grid-template-areas:${L.wire.map((r) => `'${r}'`).join(' ')}">${
        areas.map((a, i) => `<i class="${a === 'h' ? 'h' : ''} n${i + 1}" style="grid-area:${a}"></i>`).join('')}</div>`;
    };
    const slots = cardsFor(cur);
    return `<div class="ph"><h2>Home layout</h2><p class="sub">Hold any tile on Home to swap it</p></div>
      <div class="lgrid">${Object.entries(LAYOUTS).map(([k, L]) => `<button class="lcard sink ${cur === k ? 'on' : ''}" data-set="home_layout:${k}">${wire(L)}<span>${L.name}</span>${L.fancy ? `<small class="sub">${L.fancy}</small>` : ''}</button>`).join('')}</div>
      ${slots.length ? `<div class="sect-t">What goes in each spot</div>
      ${slots.map((c, i) => `<div class="slot-row"><b>Spot ${i + 1}</b><div class="chips swipe">${Object.entries(CARD_NAMES).map(([id, l]) =>
        `<button class="sink ${c === id ? 'on' : ''}" data-slot="${i}:${id}">${l}</button>`).join('')}</div></div>`).join('')}` : ''}
      <div class="sect-t">Around the edges</div>
      <div class="opt"><span>Side rail</span>${seg('data-set', [['nav:left', 'Left'], ['nav:right', 'Right'], ['nav:dock', 'Bottom']], `nav:${g('nav')}`)}</div>
      <div class="opt"><span>Clock and weather on top</span>${sw('data-toggle="header"', g('header'), 'Clock and weather')}</div>
      <div class="opt"><span>Favorites bar</span>${sw('data-toggle="quick"', g('quick'), 'Favorites bar')}</div>
      <div class="sect-t">Speedometer</div>
      <div class="lgrid">${SPEEDOS.map(([k, l]) => `<button class="lcard sink ${g('speedo') === k ? 'on' : ''}" data-set="speedo:${k}"><div style="height:7rem;display:grid;place-items:center">${speedoSVG(k).replace('class="speedo"', 'class="speedo" style="height:7rem;width:7rem"')}</div><span>${l}</span></button>`).join('')}</div>
      <div class="sect-t">Where your screens sit</div>
      <p class="note" style="margin:-.2rem 0 .6rem">The wallpaper runs across the cluster, this screen and the knob as one picture, so it needs to know where they are. Drag a screen in the picture, or pick one and nudge it. “Line them up” shows sweeping lines: move the screens until the lines run straight from one to the next.</p>
      <div class="dash-pv" id="dashPv" data-drag><canvas class="dpv-gl"></canvas><canvas class="dpv-ov"></canvas></div>
      <div class="opt"><span>Move</span>${seg('data-dashsel', [['cluster', 'Cluster'], ['hu', 'This screen'], ['knob', 'Knob']], S.dashSel || 'hu')}</div>
      <div class="dnudge">
        <button class="btn sink" data-dashnudge="-10,0">←</button><button class="btn sink" data-dashnudge="0,-10">↑</button>
        <button class="btn sink" data-dashnudge="0,10">↓</button><button class="btn sink" data-dashnudge="10,0">→</button>
        <button class="btn sink" data-act="flow_lineup">${flowSet().scene === 'calibrate' ? 'Done lining up' : 'Line them up'}</button>
        <button class="btn sink" data-act="dash_reset">Reset</button></div>
      <p class="note">Speed units, the 24-hour clock and the Maps options are in Settings › Display. The cluster's layout is in Settings › Cluster.</p>`;
  },
};

const LOOKPART = {
  colors() {
    const groups = ['All', ...new Set(THEMES.map((t) => t.group))];
    const list = S.group === 'All' ? THEMES : THEMES.filter((t) => t.group === S.group);
    return `${lookColorsCard()}
      <div class="ph"><div class="sect-t">Ready-made color sets</div><button class="btn small sink" data-act="shuffle">${ico('shuffle', 20)}Surprise me</button></div>
      <div class="chips swipe">${groups.map((x) => `<button class="sink ${S.group === x ? 'on' : ''}" data-act="group:${x}">${x}</button>`).join('')}</div>
      <div class="tgrid">${list.map((t) => `<button class="tcard sink" data-theme="${t.id}" aria-label="${t.name} colors">
        <div class="mini" style="background:${t.base}"><i style="background:${t.b1}"></i><i style="background:${t.b2}"></i><i style="background:${t.b3}"></i><u></u><em style="background:${t.accent};color:${t.accent}"></em></div>
        <span>${t.name}</span></button>`).join('')}</div>`;
  },
  // The wallpaper: one animation across all three screens (Flow), or an effect on this screen only.
  wallpaper() {
    const f = flowSet();
    const fpick = (key, opts) => `<div class="seg">${opts.map(([v, l]) => `<button class="${String(f[key]) === String(v) ? 'on' : ''}" data-flow="${key}:${v}">${l}</button>`).join('')}</div>`;
    const ftog = (k, label) => sw(`data-flowtoggle="${k}"`, f[k] !== false, label);
    const win = g('effect') === 'window', rainOn = win ? g('rain_over') !== false : !!g('rain_glass');
    return `<div class="dash-pv${f.on ? '' : ' off'}" id="dashPv"><canvas class="dpv-gl"></canvas><canvas class="dpv-ov"></canvas>
        ${f.on ? '' : '<div class="dpv-msg">The wallpaper is on this screen only. Pick one below to run it across all three screens.</div>'}</div>
      <div class="sect-t">Across all three screens</div>
      <div class="effects lk-scenes">${(window.FLOW_SCENES || []).filter(([id]) => id !== 'calibrate').map(([id, l, d]) => `<button class="sink ${f.on && f.scene === id ? 'on' : ''}" data-flow="scene:${id}">${l}<small>${d}</small></button>`).join('')}</div>
      ${f.on ? `${slider('data-flowint="amount"', 'Strength', f.amount ?? 75, 10, 100, 5, `${f.amount ?? 75}%`)}
      ${optRow('Speeds up as you drive', 'Up to 3½ times as fast on the highway', ftog('react', 'Speeds up as you drive'))}
      ${optRow('Ripples', 'From your taps, the knob, a new song and the shift point', fpick('pulses', [['on', 'On'], ['off', 'Off']]))}
      <details class="fine"><summary>Which screens${ico('down', 22)}</summary>
        ${optRow('Instrument cluster', '', ftog('cluster', 'Cluster'))}${optRow('This screen', '', ftog('hu', 'Head unit'))}${optRow('Knob', 'Its rings and readouts stay on top', ftog('knob', 'Knob'))}</details>` : ''}
      ${optRow('Rain on the glass', `${win ? 'Drops run down over your panels too' : 'Drops running down the screen over any wallpaper'}. Hidden on the full Maps screen.`, sw(`data-toggle="${win ? 'rain_over' : 'rain_glass'}"`, rainOn, 'Rain on the glass'))}
      ${rainOn ? `<div class="opt"><span>How hard it’s raining</span>${seg('data-set', [['rain_amount:light', 'Light'], ['rain_amount:steady', 'Steady'], ['rain_amount:heavy', 'Downpour']], `rain_amount:${g('rain_amount') || 'steady'}`)}</div>` : ''}
      <details class="fine" ${f.on ? '' : 'open'}><summary>This screen only (not synced)${ico('down', 22)}</summary>
        <div class="effects">${EFFECTS.map(([id, l, d]) => `<button class="sink ${!f.on && g('effect') === id ? 'on' : ''}" data-fxonly="${id}">${l}<small>${d}</small></button>`).join('')}</div></details>
      <div class="sect-t">Live Google Maps behind Home</div>
      ${optRow('Map wallpaper', 'The map fills the screen behind Home and your tiles float over it', sw('data-toggle="map_bg"', !!g('map_bg'), 'Live map background'))}
      ${g('map_bg') ? `${slider('data-intset="map_dim"', 'Darken the map', g('map_dim') ?? 25, 0, 90, 5, `${g('map_dim') ?? 25}%`)}
      <div class="opt"><div><div class="t">Tiles over the map</div><div class="d">Tinted is lighter work for the Pi if the map stutters</div></div>${seg('data-set', [['map_glass:frost', 'Frosted'], ['map_glass:tint', 'Tinted']], `map_glass:${g('map_glass') || 'frost'}`)}</div>` : ''}`;
  },
  panels() {
    const s = settings(), gl = glassSet(), st = g('style') || 'glass', clarity = glassClarity(gl);
    return `<div class="sect-t">Panel style</div>
      <div class="sgrid">${STYLES.map(([id, name, desc, , th]) => `<button class="scard sink ${st === id ? 'on' : ''}" data-style-pick="${id}">
        <div class="sp" style="background:${th[0]}"><i class="t" style="${th[2]}">4:20</i><i class="p1" style="${th[1]}"></i><i class="p2" style="${th[1]}"></i></div>
        <b>${name}</b><small>${desc}</small></button>`).join('')}</div>
      <div class="sect-t">Glass</div>
      ${slider('data-clarity', 'Clarity: clear to frosted', clarity, 0, 100, 1, clarity < 34 ? 'Clear' : clarity < 67 ? 'Frosted' : 'Solid')}
      ${slider('data-glass="shine"', 'Shine', gl.shine, 0, 100, 1, `${gl.shine}%`)}
      <div class="opt"><span>Clock</span>${seg('data-set', CLOCKS.map(([k, l]) => [`clock_style:${k}`, l]), `clock_style:${g('clock_style')}`)}</div>
      <div class="opt"><span>Buttons</span>${seg('data-set', BUTTONS.map(([k, l]) => [`button_fx:${k}`, l]), `button_fx:${g('button_fx')}`)}</div>
      <details class="fine" data-fine ${S.fineOpen ? 'open' : ''}><summary>Fine-tune${ico('down', 22)}</summary>
        <div class="chips">${Object.entries(GLASS_PRESETS).map(([k, [l]]) => `<button class="sink" data-act="gpreset:${k}">${l} glass</button>`).join('')}</div>
        ${slider('data-glass="opacity"', 'Glass opacity', gl.opacity, 0, 100, 1, `${gl.opacity}%`)}
        ${slider('data-glass="blur"', 'Frost', gl.blur, 0, 60, 1, `${gl.blur}`)}
        ${slider('data-glass="depth"', 'Depth and shadow', gl.depth, 0, 100, 1, `${gl.depth}%`)}
        <div class="opt"><span>Glass tint</span>${seg('data-gtint', [['theme', 'Look color'], ['clear', 'Clear'], ['smoke', 'Smoke']], gl.tint)}</div>
        <div class="opt"><span>Motion</span>${seg('data-set', [['motion:calm', 'Calm'], ['motion:lively', 'Lively'], ['motion:wild', 'Wild']], `motion:${g('motion')}`)}</div>
        <div class="opt"><span>Page change</span>${seg('data-set', [['transition:depth', 'Depth'], ['transition:slide', 'Slide'], ['transition:flip', 'Flip'], ['transition:fade', 'Fade'], ['transition:none', 'None']], `transition:${g('transition')}`)}</div>
        ${optRow('3D tilt', 'Panels lean toward your finger', sw('data-gtoggle="tilt"', gl.tilt !== false, '3D tilt'))}
        ${optRow('Edge glow', 'Active panels glow in your accent color', sw('data-gtoggle="edge"', gl.edge !== false, 'Edge glow'))}
        ${optRow('Text shadow', 'Keeps words readable on very clear glass', sw('data-gtoggle="textshadow"', gl.textshadow !== false, 'Text shadow'))}
        <div class="opt"><span>Glowing buttons</span>${sw('data-toggle="glow"', s.glow !== false, 'Glowing buttons')}</div>
        ${optRow('Animations', 'Turn off to make everything still (not saved with the Look)', sw('data-toggle="animate"', s.animate !== false, 'Animations'))}
        <p class="note">Frost blurs what's behind the panels when the wallpaper is still. Over a moving wallpaper the panels use a tint instead, so the screen stays smooth.</p>
      </details>`;
  },
  // Gauge faces are shared by the cluster, the Gauges screen and gauge tiles on Home.
  gauges() {
    const c = clusterSet();
    const pick = (k, opts) => `<div class="seg">${opts.map(([v, l]) => `<button class="${String(c[k]) === String(v) ? 'on' : ''}" data-cl="${k}:${v}">${l}</button>`).join('')}</div>`;
    return `<p class="note" style="margin:0 0 .6rem">For the cluster, the Gauges screen and gauge tiles on Home. Their colors come from this Look.</p>
      <div class="res-list cl-faces">${(window.GAUGE_FACES || []).map(([k, l, d]) => `<button class="sink ${(c.face || 'neon') === k ? 'on' : ''}" data-cl="face:${k}">${l}<small>${d}</small></button>`).join('')}</div>
      ${(window.GAUGE_STYLE_OPTS || []).filter((o) => o[0] !== 'redline').map((o) => o[2] === 'range'
        ? slider(`data-clint="${o[0]}"`, o[1], c[o[0]] ?? 60, o[3], o[4], o[5], `${c[o[0]] ?? 60}%`)
        : optRow(o[1], '', pick(o[0], o[2].map(([v, l]) => [v, l])))).join('')}
      ${optRow('Cluster background', 'Behind the cluster’s gauges when the wallpaper is off there', pick('look', (window.CLUSTER_LOOKS || []).map(([k, l]) => [k, l])))}`;
  },
  knob() {
    const cur = g('knob_style');
    return `<p class="note">Swipe up or down on the knob to flip through these too. <span data-k="knob"></span>.</p>
      <div class="kgrid">${FACES.map((f, i) => `<button class="kcard sink ${cur === f.id ? 'on' : ''}" data-knob="${f.id}">${knobSVG(f, i)}<b>${f.name}</b><small>${f.desc}</small></button>`).join('')}</div>
      <div class="opt"><span>Top line on the knob</span>${seg('data-set', [['knob_top:clock', 'Clock'], ['knob_top:speed', 'Speed']], `knob_top:${g('knob_top')}`)}</div>
      <div class="sect-t">Ripple when you turn it</div>
      ${optRow('Knob ripple', 'An effect flows across the screen from wherever your knob is mounted', sw('data-toggle="knob_ripple"', g('knob_ripple'), 'Knob ripple'))}
      <div class="lgrid">${RIPPLES.map(([k, l, d]) => `<button class="lcard sink ${g('ripple_style') === k ? 'on' : ''}" data-set="ripple_style:${k}"><div class="rprev rp-${k}"><i></i><i></i><i></i></div><span>${l}</span><small class="sub">${d}</small></button>`).join('')}</div>
      <details class="fine"><summary>Where it starts and how strong${ico('down', 22)}</summary>
        <div class="opt"><span>Knob is mounted</span>${seg('data-set', [['ripple_from:bottom', 'Below the screen'], ['ripple_from:right', 'Right'], ['ripple_from:left', 'Left'], ['ripple_from:center', 'Center']], `ripple_from:${g('ripple_from')}`)}</div>
        ${slider('data-intset="knob_x"', 'Where along the bottom (for “Below the screen”)', g('knob_x'), 0, 100, 1, `${g('knob_x')}%`)}
        ${slider('data-intset="ripple_power"', 'Strength', g('ripple_power'), 20, 100, 1, `${g('ripple_power')}%`)}
        <div class="opt"><span>Volume traced around the screen edge</span>${sw('data-toggle="ripple_edge"', g('ripple_edge'), 'Edge trace')}</div>
        <div class="opt"><span>Volume readout</span>${sw('data-toggle="ripple_hud"', g('ripple_hud'), 'Volume readout')}</div></details>
      <div class="opt"><span>Try it</span><button class="btn small sink" data-act="ripple_test">Play the ripple</button></div>`;
  },
  more() {
    return `<div class="sect-t">Google Maps colors</div>
      <p class="note" style="margin:-.2rem 0 .6rem">Recolors the map from your phone everywhere it shows. The route line always stays bright.</p>
      <div class="effects">${(window.MAP_STYLES || []).map(([id, l, d]) => `<button class="sink ${(g('map_style') || 'original') === id ? 'on' : ''}" data-set="map_style:${id}">${l}<small>${d}</small></button>`).join('')}</div>
      ${(g('map_style') || 'original') !== 'original' ? slider('data-intset="map_fx_amt"', 'How strong', g('map_fx_amt') ?? 100, 10, 100, 5, `${g('map_fx_amt') ?? 100}%`) : ''}
      ${slider('data-intset="map_opacity"', 'Map opacity: see your wallpaper through it', g('map_opacity') ?? 100, 20, 100, 5, `${g('map_opacity') ?? 100}%`)}
      <div class="opt"><span>Maps screen corners</span>${seg('data-set', [['map_shape_hu:rect', 'Square'], ['map_shape_hu:round', 'Rounded'], ['map_shape_hu:fade', 'Faded edges']], `map_shape_hu:${g('map_shape_hu') || 'rect'}`)}</div>
      <div class="sect-t">When the car starts</div>
      <div class="lgrid">${SPLASHES.map(([k, l, d]) => `<button class="lcard sink ${(g('splash_style') || 'warp') === k ? 'on' : ''}" data-set="splash_style:${k}"><span>${l}</span><small class="sub">${d}</small></button>`).join('')}</div>
      <div class="opt"><span>See it now</span><button class="btn sink" data-act="splash_play">Play</button></div>`;
  },
};

const TOOL_BTNS = [
  ['claude_code', 'Start Claude Code', 'Opens SSH and the tunnel to your phone and starts Claude Code, all in one tap'],
  ['phone_update', 'Install update from phone', 'Takes the newest headunit zip from your phone’s Download folder'],
  ['usb_update', 'Install update from USB stick', 'Plug in the stick with headunit (or headunit.zip) on it'],
  ['clear_cache', 'Clear screen cache', 'If something new doesn’t show up after an update'],
  ['restart', 'Restart head unit', 'Restarts the app, not the whole Pi'],
  ['reboot', 'Reboot the Pi', 'Full restart'],
  ['wifi_check', 'Wi-Fi check', 'Is the phone-internet fix applied, which phones are connected'],
  ['fix_internet', 'Fix phone internet', 'Keeps the phone on mobile data for the internet'],
  ['fix_boot', 'Fix boot flashes', 'Hides the firmware screen at startup (needs a reboot)'],
  ['fix_splash', 'Reinstall boot logo', 'Takes a minute or two'],
  ['sound_report', 'Sound report', 'What’s connected to what, if the sound goes wrong'],
  ['logs', 'Show logs', 'Take a photo of these if something breaks'],
];
// ---- Instrument cluster on the second screen (web/cluster.html). The cluster has no touch, so it's set up here.
// Changes are sent as settings.cluster and the cluster redraws itself; a live preview of it sits at the top.
const clusterSet = () => {
  const d = window.CLUSTER_DEFAULT || {}, c = Object.assign({}, d, settings().cluster || {});
  c.slots = (c.slots || []).concat((d.slots || []).slice((c.slots || []).length)).slice(0, 8);   // older settings had 6
  return c;
};
function setCluster(patch) { setSetting({ cluster: Object.assign(clusterSet(), patch) }); }
// The cluster's shape as you see it in the car: a screen that stretches a smaller mode (1280x720 shown on a
// 1920x720 bar) is previewed at its real, wider shape.
function clusterSize() {
  const c = (S.state && S.state.cluster) || {};
  const [w, h] = String(c.size || '1920x720').split('x').map(Number);
  const k = +c.stretch || 1;
  return w > 0 && h > 0 ? [Math.round(w * k), h] : [1920, 720];
}
function clusterStatus() {
  const c = (S.state && S.state.cluster) || {};
  if (!c.connected) return 'Not plugged in. Plug it into the Pi’s other HDMI port and it starts by itself.';
  const on = clusterSet().on !== false;
  return `${esc(c.model || 'Screen')} on ${esc(c.output)}, ${esc((c.size || '').replace('x', ' × '))}. ${!on ? 'Switched off.' : c.running ? 'Showing the cluster.' : 'Starting…'}`;
}
function clusterSlotsHtml() {
  const c = clusterSet(), L = (window.CLUSTER_LAYOUTS || []).find((l) => l[0] === c.layout) || [];
  const names = Object.fromEntries((window.GAUGE_LIST || []).map(([id, l]) => [id, l]));
  const slots = L[3] || [], idx = L[5] || slots.map((_, i) => i);
  const edit = `<div class="opt"><div><div class="t">${c.layout === 'custom' ? 'Your layout' : 'Make your own'}</div><div class="d">${c.layout === 'custom'
    ? 'Put any gauge, Google Maps, directions, the speed limit, music or the clock anywhere, any size'
    : 'Move and resize everything yourself: starts from Navigator (or your last custom layout)'}</div></div>
    <button class="btn ${c.layout === 'custom' ? 'primary ' : ''}sink" data-act="cl_edit">Edit layout</button></div>`;
  if (c.layout === 'custom') return edit;
  if (!slots.length) return `<p class="note">This layout shows your speed in big numbers, no dials to pick.</p>${edit}`;
  return `<div class="cl-slots">${slots.map((n, i) => `<button class="sink" data-clslot="${idx[i]}"><small>${esc(n)}</small><b>${esc(names[c.slots[idx[i]]] || c.slots[idx[i]])}</b></button>`).join('')}</div>
    ${c.layout === 'digital' ? '<p class="note">The rev bar across the top is always the tachometer.</p>' : ''}${edit}`;
}
function fitClusterPreview() {
  const box = $('#clPrev');
  if (!box) return;
  const [w, h] = clusterSize(), f = box.querySelector('iframe');
  box.style.aspectRatio = `${w} / ${h}`;
  f.style.width = `${w}px`; f.style.height = `${h}px`;
  f.style.transform = `scale(${box.clientWidth / w})`;
}
function openClusterSheet(i) {
  const c = clusterSet(), cur = c.slots[i], L = (window.CLUSTER_LAYOUTS || []).find((l) => l[0] === c.layout) || [];
  $('#overlay').innerHTML = `<div class="sheet-wrap" data-act="sheet_close"><div class="sheet glass" data-stop>
    <div class="head"><h2>Cluster: ${esc((L[3] || [])[(L[5] || []).indexOf(i)] || `Gauge ${i + 1}`)}</h2><button class="btn small sink" data-act="sheet_close">Done</button></div>
    <div class="gopts">${(window.GAUGE_LIST || []).map(([id, l, d]) => `<button class="sink ${cur === id ? 'on' : ''}" data-clpick="${i}:${id}"><b>${l}</b><small>${d}</small></button>`).join('')}</div>
  </div></div>`;
}
function updateClusterPane() {
  const st = $('#clStatus');
  if (st) { const t = clusterStatus(); if (st._v !== t) { st.innerHTML = t; st._v = t; fitClusterPreview(); } }
}

const SET = {
  cluster() {
    const c = clusterSet(), info = (S.state && S.state.cluster) || {};
    const pick = (key, opts) => `<div class="seg">${opts.map(([v, l]) => `<button class="${String(c[key]) === String(v) ? 'on' : ''}" data-cl="${key}:${v}">${l}</button>`).join('')}</div>`;
    const row = (t, d, ctl) => `<div class="opt"><div><div class="t">${t}</div>${d ? `<div class="d">${d}</div>` : ''}</div>${ctl}</div>`;
    const tog = (k, label) => sw(`data-cltoggle="${k}"`, c[k] !== false && c[k] !== undefined && c[k] !== 0, label);
    const outs = (info.outputs || []).filter((n) => n !== info.main || c.screen === n);
    requestAnimationFrame(fitClusterPreview);
    // One place for everything about the cluster. The preview stays put; the tabs below switch in place
    // (no re-render, so the preview doesn't reload).
    const tab = S.clTab || 'layout';
    const tabs = [['layout', 'Layout'], ['gauges', 'Gauges'], ['map', 'Map'], ['look', 'Look'], ['screen', 'Screen']];
    const pane = (k, html) => `<div class="cl-pane${tab === k ? '' : ' hidden'}" data-clpane="${k}">${html}</div>`;
    const flowOnCl = (settings().flow || {}).on && (settings().flow || {}).cluster !== false;
    return `<h2>Instrument cluster</h2>
      <div class="opt"><div><div class="t">Second screen</div><div class="d" id="clStatus">${clusterStatus()}</div></div>
        <div class="row">${info.connected ? '<button class="btn sink" data-act="cluster_restart">Restart it</button>' : ''}${sw('data-cltoggle="on"', c.on !== false, 'Cluster on')}</div></div>
      <div class="cl-prev" id="clPrev"><iframe src="/static/cluster.html?preview" tabindex="-1" title="Cluster preview"></iframe></div>
      <div class="seg cl-tabs">${tabs.map(([k, l]) => `<button class="${tab === k ? 'on' : ''}" data-act="cltab:${k}">${l}</button>`).join('')}</div>
      ${pane('layout', `
        <div class="lgrid cl-lays">${(window.CLUSTER_LAYOUTS || []).map(([k, l, d]) => `<button class="lcard sink ${c.layout === k ? 'on' : ''}" data-cl="layout:${k}"><div class="clw clw-${k}"><i></i><i></i><i></i><i></i><i></i><i></i>${k === 'eight' ? '<i></i><i></i>' : k === 'strip' ? '<i></i><i></i><i></i>' : ''}</div><span>${l}</span><small class="sub">${d}</small></button>`).join('')}</div>
        <div class="sect-t">What each spot shows</div>
        <p class="note" style="margin:-.2rem 0 .6rem">Tap one to pick from ${(window.GAUGE_LIST || []).length} gauges.</p>
        <div id="clSlots">${clusterSlotsHtml()}</div>
        <div id="clMid" class="${((window.CLUSTER_LAYOUTS || []).find((l) => l[0] === c.layout) || [])[4] ? '' : 'hidden'}">
          ${row('In the middle', 'Directions, music, this drive, or a clock', pick('center', (window.CLUSTER_CENTER || []).map(([k, l]) => [k, l])))}</div>`)}
      ${pane('gauges', `
        <p class="note" style="margin:0 0 .6rem">For the cluster and the Gauges screen. They take their colors from your theme.</p>
        <div class="res-list cl-faces">${(window.GAUGE_FACES || []).map(([k, l, d]) => `<button class="sink ${(c.face || 'neon') === k ? 'on' : ''}" data-cl="face:${k}">${l}<small>${d}</small></button>`).join('')}</div>
        ${(window.GAUGE_STYLE_OPTS || []).map((o) => o[2] === 'range'
          ? slider(`data-clint="${o[0]}"`, o[1], c[o[0]] ?? (o[0] === 'redline' ? 6000 : 60), o[3], o[4], o[5], o[0] === 'redline' ? `${c[o[0]] ?? 6000} rpm` : `${c[o[0]] ?? 60}%`)
          : row(o[1], '', pick(o[0], o[2].map(([v, l]) => [v, l])))).join('')}
        ${row('Needle sweep', 'Every needle swings to full and back when it starts, like a real cluster', tog('sweep', 'Needle sweep'))}
        <div class="sect-t">Alerts</div>
        ${slider('data-clint="shift"', 'Shift light: the edges flash red at this rpm', c.shift, 0, 7000, 250, c.shift ? `${c.shift} rpm` : 'Off')}
        ${row('Warnings', 'Overheating, low fuel and charging problems pop up on the cluster', tog('warn', 'Warnings'))}`)}
      ${pane('map', `
        ${row('Map colors', 'Same as the head unit, or its own', pick('map_style', [['same', 'Same'], ...(window.MAP_STYLES || []).map(([k, l]) => [k, l])]))}
        ${row('Map shape', 'How the map sits in the cluster', pick('map_shape', (window.MAP_SHAPES || []).map(([k, l]) => [k, l])))}
        ${slider('data-clint="map_opacity"', 'See-through: lower lets the background show through the map', c.map_opacity ?? 100, 10, 100, 5, `${c.map_opacity ?? 100}%`)}
        ${slider('data-clint="map_fade"', 'Edge fade: how far the soft edges reach in (Arcs layout, Melt or 3D tilt shape)', c.map_fade ?? 35, 0, 100, 5, `${c.map_fade ?? 35}%`)}
        ${slider('data-clint="map_trim"', 'Hide this much of Google Maps’ bottom (the card that says “Local vibe”)', c.map_trim ?? 190, 0, 300, 10, `${c.map_trim ?? 190}`)}`)}
      ${pane('look', `
        ${flowOnCl ? '<p class="note" style="margin:0 0 .6rem">The wallpaper runs on the cluster too. Turn that off in Look › Customize › Wallpaper › Which screens.</p>' : ''}
        ${row('Style', '', pick('look', (window.CLUSTER_LOOKS || []).map(([k, l]) => [k, l])))}
        <p class="note">Colors, gauge faces and the wallpaper come from your Look (Look › Customize).</p>
        ${row('Top bar', 'Clock, lights and check-engine symbols, outside temperature', tog('bar', 'Top bar'))}`)}
      ${pane('screen', `
        ${row('Lock at 100%', 'Keeps the screen\'s backlight at full and ignores the settings below', tog('lock', 'Lock at 100%'))}
        ${slider('data-clint="bright"', `Brightness${info.ddc ? ' (its own backlight)' : ''}`, c.bright, 5, 100, 5, `${c.bright}%`)}
        ${row('Dim at night', 'After sunset (or 7 pm - 7 am)', tog('night_dim', 'Dim at night'))}
        ${slider('data-clint="night"', 'Night brightness', c.night, 5, 100, 5, `${c.night}%`)}
        <div class="sect-t">Mounting</div>
        ${row('Turn the picture', 'If the screen is mounted sideways or upside down', pick('rotate', [['normal', 'Normal'], ['90', '90°'], ['180', '180°'], ['270', '270°']]))}
        ${row('Mirror it', 'For a screen that reflects off the windshield (head-up display)', tog('mirror', 'Mirror'))}
        ${outs.length > 1 || c.screen !== 'auto' ? row('Which screen', 'Auto picks the one that isn’t the touch screen', pick('screen', [['auto', 'Auto'], ...outs.map((n) => [n, n])])) : ''}
        ${info.connected ? `<div class="opt col"><div class="top"><span>Screen mode</span></div>
          <p class="note" style="margin:0 0 .5rem">If the cluster says “No signal”, try another one. “Pi timing” keeps the screen’s own size with standard timing.</p>
          <div class="res-list">${[['', 'Screen’s own', 'what it asks for'],
            ...(() => { const p = (info.modes || []).find((m) => m.preferred); return p ? [['cvt', `${p.w} × ${p.h}`, 'Pi timing']] : []; })(),
            ...(info.modes || []).filter((m) => !m.preferred).slice(0, 8).map((m) => [m.id, `${m.w} × ${m.h}`, `${m.r} Hz`])]
            .map(([v, l, d]) => `<button class="sink ${(c.mode || '') === v ? 'on' : ''}" data-cl="mode:${v}">${l}<small>${d}</small></button>`).join('')}</div></div>` : ''}`)}`;
  },
  car() {
    const o = (S.state && S.state.obd) || {}, cfg = settings().obd || {};
    const on = o.status === 'connected';
    const found = (o.found || []).filter((f) => f.addr !== cfg.addr);
    const codes = o.codes;
    const codeRow = (c, pending) => `<div class="dtc"><b>${c}</b><span>${esc(DTC[c] || 'See a code lookup for this one')}</span>${pending ? '<small>Pending</small>' : ''}</div>`;
    return `<h2>Car</h2>
      <div class="opt"><div><div class="t">${cfg.addr ? esc(cfg.name || 'OBD adapter') : 'OBD adapter'}</div><div class="d" data-k="obdStatus"></div></div>
        <div class="row">${cfg.addr && o.status === 'error' ? '<button class="btn sink" data-act="obd_retry">Try again</button>' : ''}
        ${cfg.addr ? '<button class="btn sink" data-act="obd_forget">Forget</button>' : ''}
        <button class="btn ${cfg.addr ? '' : 'primary'} sink ${o.scanning ? 'busy' : ''}" data-act="obd_scan">${ico('search', 20)}${o.scanning ? 'Looking…' : 'Find adapters'}</button></div></div>
      ${found.length || o.scanning ? `<div class="obd-list">${found.map((f) => `<button class="obd-dev sink ${f.likely ? 'likely' : ''}" data-obd-use="${esc(f.addr)}|${esc(f.kind)}|${esc(f.name)}">
          ${ico(f.likely ? 'car' : 'bt', 24)}<span><b>${esc(f.name)}</b><small>${f.kind === 'usb' ? 'USB cable' : f.kind === 'ble' ? 'Bluetooth LE' : 'Bluetooth'}${f.likely && f.kind !== 'usb' ? ', looks like an OBD adapter' : ''}</small></span><em>Connect</em></button>`).join('')}
        ${o.scanning && !found.length ? '<div class="empty">Looking for Bluetooth devices…</div>' : ''}</div>` : ''}
      ${on ? `<h2>Live</h2><div class="obd-grid">${OBD_TILES.filter(([k]) => (o.pids || []).includes(k) || k === 'volts').map(([k, l]) =>
        `<div class="obd-tile"><b data-obd="${k}">--</b><span>${l}</span></div>`).join('')}</div>
      <h2>CAN bus</h2>
      <div class="opt"><div><div class="t">CAN listener</div><div class="d">See every message on the car's bus live and find which ones react to buttons, pedals and doors</div></div>
        <button class="btn sink" data-act="can_open">Open</button></div>
      <h2>Check engine light</h2>
      <div class="opt"><div><div class="t">Trouble codes</div><div class="d">${codes ? (codes.stored.length + codes.pending.length ? `Read ${new Date(codes.at * 1000).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}` : 'No codes. All clear.') : 'Reads what made the check engine light come on'}</div></div>
        <div class="row"><button class="btn sink" data-act="obd_codes">Read codes</button>${codes && (codes.stored.length || codes.pending.length) ? `<button class="btn sink ${S.clearArmed ? 'danger' : ''}" data-act="obd_clear">${S.clearArmed ? 'Tap again to clear' : 'Clear codes'}</button>` : ''}</div></div>
      ${codes ? `<div class="dtcs">${codes.stored.map((c) => codeRow(c)).join('')}${codes.pending.map((c) => codeRow(c, true)).join('')}</div>` : ''}` : ''}
      ${(o.events || []).length ? `<h2>What the adapter has been doing</h2><div class="obd-ev">${o.events.slice(0, 5).map((e) =>
        `<div><span>${new Date(e.at * 1000).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}</span>${esc(e.text)}</div>`).join('')}</div>` : ''}
      <h2>Fuel tank</h2>
      ${slider('data-tank', 'Tank size, for the range on the Fuel gauge', g('tank') || 185, 50, 400, 5, `${((g('tank') || 185) / 10).toFixed(1)} gal`)}
      <p class="note" style="margin-top:-.6rem">A 2011 Outback holds 18.5 gallons.</p>
      <p class="note">Plug the adapter into the port under the dash and turn the ignition on. Close OBD apps on your phone first: an adapter only talks to one thing at a time. Bluetooth adapters are paired automatically (PIN 1234 or 0000). While music plays, a Bluetooth adapter is read about 8 times a second so it doesn't crowd your music; a USB adapter (ELM327 or OBDLink on a cable) shares nothing with the music and can go full speed. Wi-Fi adapters can't be used, since the Pi's Wi-Fi is busy being the hotspot.</p>`;
  },
  tools() {
    return `<h2>Tools</h2>
      <p class="sub" style="margin:-.3rem 0 .8rem">One tap instead of typing. For a terminal on your phone, open <b>localhost:8080/term</b> in Chrome on the phone (works while the phone is linked for Maps).</p>
      <div class="tool-grid">${TOOL_BTNS.map(([k, l, d]) => `<button class="tool-btn sink" data-tool="${k}"><b>${l}</b><small>${d}</small></button>`).join('')}</div>
      <pre class="tool-out" id="toolOut">${esc(S.toolOut || '')}</pre>`;
  },
  phone() {
    const row = (t, k, btn = '') => `<div class="opt"><div><div class="t">${t}</div><div class="d" data-k="${k}"></div></div>${btn}</div>`;
    return `<h2>Phone</h2>
      ${row('Bluetooth', 'btStatus', '<button class="btn primary sink" data-act="pair">Pair a phone</button>')}
      ${row('Calls and voice', 'callAvail')}
      ${row('Wi-Fi for your phone', 'wifi')}
      ${row('Maps and YouTube Music', 'adbStatus', '<button class="btn sink" data-go="maps">Test</button>')}
      ${row('Updates', 'updInfo')}
      ${row('Phone app', 'companion')}
      <div class="opt"><div><div class="t">Recent calls</div><div class="d">Clears the call history kept on this screen</div></div><button class="btn sink" data-act="clear_recents">Clear</button></div>`;
  },
  display() {
    const s = settings();
    const d = (S.state && S.state.display) || {};
    const modes = d.modes || [];
    return `<h2>Head unit screen</h2>
      ${slider('data-bright', 'Brightness', Math.max(1, s.brightness || 1), 1, 100, 1, `${Math.max(1, s.brightness || 1)}%`)}
      <p class="note" style="margin-top:-.6rem">The moon button steps down through ten levels. Hold it to turn the screen off.</p>
      <div class="opt"><div><div class="t">Dim at night</div><div class="d">Lowers the screen after dark</div></div>${sw('data-toggle="night_dim"', g('night_dim'), 'Dim at night')}</div>

      ${slider('data-night', 'Night brightness', g('night_level'), 1, 100, 1, `${g('night_level')}%`)}
      <div class="opt"><div><div class="t">Hardware dimming</div><div class="d">Also sets the screen’s own backlight, if it supports it (DDC)</div></div>${sw('data-toggle="use_ddc"', !!s.use_ddc, 'Hardware dimming')}</div>
      <div class="opt"><div><div class="t">Turn screen off</div><div class="d">Tap anywhere to wake it</div></div><button class="btn sink" data-act="screen_off">Turn off</button></div>
      <p class="note">The cluster’s brightness is in Settings › Cluster › Screen.</p>
      <h2>Resolution</h2>
      <p class="note">Now: <b data-k="displayNow"></b>. After you pick one, you get 15 seconds to keep it, or it switches back on its own.</p>
      <div class="res-list">${modes.length ? modes.map((m) => `<button class="sink ${m.current ? 'on' : ''}" data-mode="${m.id}">${m.w} × ${m.h}<small>${m.r} Hz${m.preferred ? ', native' : ''}</small></button>`).join('')
        : '<div class="empty">The screen hasn’t reported its resolutions yet.</div>'}</div>
      ${slider('data-uiscale', 'Text and button size', g('ui_scale'), 70, 140, 5, `${g('ui_scale')}%`)}
      <h2>Units</h2>
      <div class="opt"><span>Speed</span>${seg('data-set', [['speed_units:auto', 'Auto'], ['speed_units:mph', 'mph'], ['speed_units:kmh', 'km/h']], `speed_units:${settings().speed_units || 'auto'}`)}</div>
      <div class="opt"><span>Time format</span>${seg('data-hour', [['12', '12-hour'], ['24', '24-hour']], g('clock_24h') ? '24' : '12')}</div>
      <h2>Maps and YouTube Music</h2>
      <div class="opt"><div><div class="t">Side panel</div><div class="d">Speed, next turn and music next to the app</div></div>${sw('data-toggle="maps_panel"', g('maps_panel'), 'Side panel')}</div>
      <div class="opt"><div><div class="t">Just the map on Home</div><div class="d">Hides Maps’ search bar and bottom buttons on the Home card</div></div>${sw('data-toggle="map_only"', g('map_only') !== false, 'Just the map')}</div>
      <div class="opt"><span>How Maps is drawn</span>${seg('data-set', [['app_view:page', 'In the page'], ['app_view:window', 'Classic window']], `app_view:${g('app_view') || 'page'}`)}</div>
      <div class="opt"><div><div class="t">App size</div><div class="d">How big things look inside the phone apps on this screen</div></div>
        ${seg('data-set', [['app_size:small', 'Small'], ['app_size:medium', 'Medium'], ['app_size:large', 'Large'], ['app_size:xl', 'Extra large']], `app_size:${g('app_size')}`)}</div>`;
  },
  about() {
    return `<h2>Weather</h2><div class="opt"><div class="d" data-k="city"></div></div>
      <h2>Knob</h2><div class="opt"><div><div class="t">Volume knob</div><div class="d" data-k="knob"></div></div></div>
      <h2>Screen</h2>
      <div class="opt"><div><div class="t">Reload the screen</div><div class="d">Redraws everything. Music and calls keep going.</div></div><button class="btn sink" data-act="reload">Reload</button></div>`;
  },
};

// ================================================================ render + page transitions
const NAV_ORDER = ['home', 'gauges', 'maps', 'music', 'phone', 'audio', 'look', 'settings'];
const homeHasMaps = () => !S.edit && (g('home_layout') === 'free'
  ? freeCards().some((c) => c.t === 'maps')
  : cardsFor(LAYOUTS[g('home_layout')] ? g('home_layout') : 'dashboard').includes('maps'));
// Live map background: Google Maps fills the screen behind Home and the tiles float over it.
// Only with the in-page stream (the classic window would cover everything).
const mapBgOn = () => !!g('map_bg') && S.screen === 'home' && !S.edit && ((S.state && S.state.app) || {}).view !== 'window';
const isStage = (s) => s === 'maps' || s === 'ytm' || (s === 'home' && (homeHasMaps() || (!!g('map_bg') && !S.edit && ((S.state && S.state.app) || {}).view !== 'window')));
// where the phone stream is drawn right now
function streamArea() { return mapBgOn() ? document.getElementById('mapBg') : document.getElementById('appArea'); }
function applyMapBg() {
  const on = mapBgOn();
  const b = document.body;
  b.classList.toggle('mapbg-home', on);
  b.classList.toggle('mapglass-tint', on && g('map_glass') === 'tint');
  document.documentElement.style.setProperty('--mapdim', String((g('map_dim') ?? 25) / 100));
  // Map opacity: below 100% the theme's own background shows through Google Maps (not on YouTube Music)
  const op = Math.max(20, Math.min(100, g('map_opacity') ?? 100));
  b.classList.toggle('mapsee', op < 100 && S.screen !== 'ytm');
  document.documentElement.style.setProperty('--mapop', String(op / 100));
}
// Full-screen Maps: no side panel, no margins, just the slim button rail
S.full = (() => { try { return localStorage.getItem('hu_full') === '1'; } catch (e) { return false; } })();
function setFull(on) {
  S.full = on;
  try { localStorage.setItem('hu_full', on ? '1' : '0'); } catch (e) { /* storage is optional */ }
  render(true);
}
const navIndex = (s) => NAV_ORDER.indexOf(s === 'ytm' ? 'music' : s);
const animOn = () => settings().animate !== false && g('transition') !== 'none';
const DUR = () => ({ calm: 560, lively: 440, wild: 320 }[g('motion')] || 440);
const EASE = 'cubic-bezier(.22,1,.36,1)';

// Fade the panels themselves, not their parents, so the frosted glass keeps blurring the background
function fadeTargets(el) {
  const glass = $$('.glass', el);
  const loose = Array.from(el.children).filter((c) => !c.classList.contains('glass') && !c.querySelector('.glass'));
  return [...loose, ...glass].filter((t, i, a) => !a.some((o) => o !== t && o.contains(t) && o.classList.contains('glass')));
}
function moveFrames(kind, dir, leaving) {
  const s = leaving ? -1 : 1;
  const dock = g('nav') === 'dock';
  if (kind === 'slide') {
    const axis = dock ? 'X' : 'Y';
    const d = dir * 7 * (leaving ? -1 : 1);
    return leaving ? [{ transform: 'none' }, { transform: `translate${axis}(${d}%)` }] : [{ transform: `translate${axis}(${d}%)` }, { transform: 'none' }];
  }
  if (kind === 'flip') {
    const r = (dock ? 1 : -1) * dir * 16 * s;
    const prop = dock ? 'rotateY' : 'rotateX';
    return leaving ? [{ transform: 'none' }, { transform: `${prop}(${-r}deg) scale(.96)` }] : [{ transform: `${prop}(${r}deg) scale(.96)` }, { transform: 'none' }];
  }
  if (kind === 'fade') return leaving ? [{ transform: 'none' }, { transform: 'none' }] : [{ transform: 'none' }, { transform: 'none' }];
  return leaving ? [{ transform: 'none' }, { transform: 'scale(.93) translateZ(0)' }] : [{ transform: 'scale(1.05)' }, { transform: 'none' }];
}
let transitionDone = Promise.resolve();
function animateIn(el, dir) {
  if (!animOn()) { transitionDone = Promise.resolve(); return; }
  const d = DUR(), kind = g('transition');
  const move = el.animate(moveFrames(kind, dir, false), { duration: d, easing: EASE });
  fadeTargets(el).forEach((t, i) => t.animate([{ opacity: 0, translate: '0 .9rem' }, { opacity: 1, translate: '0 0' }],
    { duration: d, delay: 60 + i * 45, easing: EASE, fill: 'backwards' }));
  transitionDone = move.finished.catch(() => {});
}
function animateOut(el, dir) {
  el.style.pointerEvents = 'none';
  el.style.zIndex = '0';
  $$('[id]', el).forEach((x) => x.removeAttribute('id'));
  if (!animOn()) { el.remove(); return; }
  const d = DUR() * 0.7;
  fadeTargets(el).forEach((t) => t.animate([{ opacity: 1 }, { opacity: 0 }], { duration: d * 0.8, easing: 'ease-in', fill: 'forwards' }));
  el.animate(moveFrames(g('transition'), dir, true), { duration: d, easing: 'cubic-bezier(.4,0,1,1)', fill: 'forwards' })
    .finished.then(() => el.remove(), () => el.remove());
}

function render(soft, dir = 1) {
  const view = $('#view');
  const old = view.lastElementChild;
  const tpl = document.createElement('template');
  tpl.innerHTML = views[S.screen]().trim();
  const neu = tpl.content.firstElementChild;
  neu.style.zIndex = '1';
  const oldScroll = soft && old ? (old.querySelector('.pane-scroll') || {}).scrollTop : 0;
  if (old) {
    const hole = old.querySelector('#appArea');
    if (hole) hole.removeAttribute('id');
    if (soft) { $$('[id]', old).forEach((x) => x.removeAttribute('id')); old.remove(); }
    else animateOut(old, dir);
  }
  view.appendChild(neu);
  if (oldScroll) neu.querySelector('.pane-scroll').scrollTop = oldScroll;
  if (!soft) animateIn(neu, dir); else transitionDone = Promise.resolve();
  $$('.nav-btn[data-go]').forEach((b) => b.classList.toggle('on', b.dataset.go === (S.screen === 'ytm' ? 'music' : S.screen)));
  movePill();
  if (S.screen === 'audio') mountPad(neu);
  if (S.screen === 'phone') renderList();
  if (S.screen === 'music') { S.queueScrolled = false; renderMusicPanel(); if (S.mtab === 'library' && !S.library) openLibrary(null); }
  $$('input[type=range]', neu).forEach(paintRange);
  document.body.classList.toggle('app-full', S.full && (S.screen === 'maps' || S.screen === 'ytm'));
  applyMapBg();
  { const ap = (S.state && S.state.app) || {};
    if (S.screen === 'home' && !isStage('home') && ap.current === 'maps' && ap.status !== 'idle') send('close_app'); }
  update();
  if (isStage(S.screen)) {
    reportRect();
    const app = (S.state && S.state.app) || {};
    if (S.screen === 'home' && (!app.status || app.status === 'idle')) send('open_app', { app: 'maps' });
  }
}

function movePill() {
  const pill = $('#navPill');
  const on = $('.nav-btn.on');
  if (!pill) return;
  if (!on) { pill.style.opacity = '0'; return; }
  pill.style.transform = `translate(${on.offsetLeft}px, ${on.offsetTop}px)`;
  pill.style.width = `${on.offsetWidth}px`;
  pill.style.height = `${on.offsetHeight}px`;
  pill.style.opacity = '1';
}

function go(screen) {
  if (!views[screen]) return;
  if (S.edit && screen !== 'home') { S.edit = false; S.sel = null; } // leaving Home cancels editing
  if (screen !== 'gauges') S.gEdit = false;
  const app = (S.state && S.state.app) || {};
  const wantApp = screen === 'ytm' ? 'music' : 'maps';
  if (screen === S.screen) {
    if (isStage(screen) && app.status !== 'running' && app.status !== 'starting') send('open_app', { app: wantApp });
    return;
  }
  const leavingApp = app.current || isStage(S.screen);
  if (leavingApp && (!isStage(screen) || (app.current || (S.screen === 'ytm' ? 'music' : 'maps')) !== wantApp)) send('close_app');
  const dir = Math.sign(navIndex(screen) - navIndex(S.screen)) || 1;
  S.screen = screen;
  render(false, dir);
  if (typeof flowApply === 'function') flowApply();
  if (isStage(screen)) {
    reportRect();
    const live = app.current === wantApp && (app.status === 'running' || app.status === 'starting');
    if (!live && screen !== 'home') send('open_app', { app: wantApp });
  }
}

// Tell the backend exactly where the phone stream should sit (screen pixels). Measured from the
// layout itself, so it's right even while the page is still animating in.
function layoutRect(el) {
  let x = 0, y = 0, n = el;
  while (n) { x += n.offsetLeft; y += n.offsetTop; n = n.offsetParent; }
  return { left: x, top: y, width: el.offsetWidth, height: el.offsetHeight };
}
// How far in from the frame edge the stream has to sit so its square corners stay inside the
// frame's rounded (or cut) corners: a bit under a third of the corner radius, never less than 8 px.
function bezelFor(area) {
  const frame = area.closest('.card') || area;
  const cs = getComputedStyle(frame);
  const rad = Math.max(parseFloat(cs.borderTopLeftRadius) || 0, parseFloat(getComputedStyle(area).borderTopLeftRadius) || 0);
  const rem = parseFloat(getComputedStyle(document.documentElement).fontSize) || 16;
  let inset = Math.max(8, Math.ceil(rad * 0.3));
  if (cs.clipPath && cs.clipPath !== 'none') inset = Math.max(inset, Math.ceil(rem * 0.8)); // Carbon's cut corners
  return inset;
}
function reportRect() {
  if (!isStage(S.screen)) return;
  const a = streamArea();
  if (!a) return;
  const r = layoutRect(a);
  const d = devicePixelRatio || 1;
  const full = document.body.classList.contains('app-full');
  const pageView = ((S.state && S.state.app) || {}).view !== 'window';
  const inset = full || pageView ? 0 : bezelFor(a); // in-page video is clipped to the frame's own corners
  a.style.setProperty('--bezel', `${inset}px`);
  // the stream is a plain rectangle drawn on top, so it sits inside the rounded frame like a screen in a
  // bezel; sizes snap to 8 px for the video encoder and the leftover is split evenly on both sides
  const rw = (r.width - inset * 2) * d, rh = (r.height - inset * 2) * d;
  const w = Math.floor(rw / 8) * 8, h = Math.floor(rh / 8) * 8;
  const x = Math.round((r.left + inset + (window.screenX || 0)) * d + (rw - w) / 2);
  const y = Math.round((r.top + inset + (window.screenY || 0)) * d + (rh - h) / 2);
  const crop = S.screen === 'home'; // the Home card shows just the map; the full Maps screen keeps its buttons
  const sig = `${x},${y},${w},${h},${crop}`;
  if (sig === S.lastRect || w < 64 || h < 64) return;
  S.lastRect = sig;
  send('app_rect', { x, y, w, h, crop });
}

// ================================================================ live updates
// ================================================================ OBD (car data)
const OBD_TILES = [['rpm', 'Engine rpm'], ['speed', 'Speed'], ['coolant', 'Coolant'], ['oil', 'Oil'], ['intake', 'Intake air'], ['ambient', 'Outside air'],
  ['volts', 'Battery'], ['load', 'Engine load'], ['throttle', 'Throttle'], ['fuel', 'Fuel'], ['map', 'Manifold'], ['maf', 'Air flow']];
const DTC = {
  P0011: 'Camshaft timing over-advanced (bank 1)', P0021: 'Camshaft timing over-advanced (bank 2)', P0030: 'Front oxygen sensor heater circuit',
  P0031: 'Front oxygen sensor heater circuit low', P0037: 'Rear oxygen sensor heater circuit low', P0101: 'Air flow sensor range or performance',
  P0102: 'Air flow sensor reading low', P0113: 'Intake air temperature sensor high', P0117: 'Coolant temperature sensor low', P0118: 'Coolant temperature sensor high',
  P0125: 'Engine slow to reach temperature for closed loop', P0128: 'Engine running cool (thermostat)', P0133: 'Front oxygen sensor slow response',
  P0137: 'Rear oxygen sensor low voltage', P0139: 'Rear oxygen sensor slow response', P0141: 'Rear oxygen sensor heater circuit',
  P0171: 'Running lean (bank 1)', P0172: 'Running rich (bank 1)', P0174: 'Running lean (bank 2)', P0175: 'Running rich (bank 2)',
  P0300: 'Random misfire', P0301: 'Cylinder 1 misfire', P0302: 'Cylinder 2 misfire', P0303: 'Cylinder 3 misfire', P0304: 'Cylinder 4 misfire',
  P0305: 'Cylinder 5 misfire', P0306: 'Cylinder 6 misfire', P0327: 'Knock sensor circuit low', P0335: 'Crankshaft position sensor circuit',
  P0340: 'Camshaft position sensor circuit', P0400: 'EGR flow', P0420: 'Catalytic converter below efficiency (bank 1)', P0430: 'Catalytic converter below efficiency (bank 2)',
  P0440: 'EVAP system', P0441: 'EVAP purge flow', P0442: 'EVAP small leak', P0455: 'EVAP large leak (check the gas cap)', P0456: 'EVAP very small leak (often the gas cap)',
  P0457: 'EVAP leak: gas cap loose or missing', P0500: 'Vehicle speed sensor', P0505: 'Idle control system', P0506: 'Idle lower than expected',
  P0507: 'Idle higher than expected', P0562: 'System voltage low', P0563: 'System voltage high', P0600: 'Engine computer communication',
  P0700: 'Transmission fault (read the transmission codes)', P0715: 'Transmission input speed sensor', P0720: 'Transmission output speed sensor',
  P1152: 'Front oxygen sensor lean (Subaru)', P1153: 'Front oxygen sensor rich (Subaru)', P2096: 'Running lean after the catalytic converter (bank 1)',
  P2097: 'Running rich after the catalytic converter (bank 1)', P2101: 'Throttle motor circuit', P2135: 'Throttle position sensors disagree',
  P2401: 'EVAP leak detection pump circuit low', P2402: 'EVAP leak detection pump circuit high', P2419: 'EVAP switching valve circuit low',
  P2420: 'EVAP switching valve circuit high', U0073: 'Communication bus off', U0100: 'Lost communication with the engine computer',
  U0101: 'Lost communication with the transmission computer', U0121: 'Lost communication with ABS', U0155: 'Lost communication with the gauge cluster',
};
const tempUnits = () => (((settings().location || {}).units) === 'celsius' ? 'C' : 'F');
function obdText(k, v) {
  if (v === undefined || v === null) return '--';
  if (['coolant', 'oil', 'intake', 'ambient'].includes(k)) return tempUnits() === 'F' ? `${Math.round(v * 9 / 5 + 32)}°` : `${Math.round(v)}°`;
  if (k === 'speed') { const u = speedUnits(S.state || {}); return `${Math.round(u === 'kmh' ? v : v * 0.621371)} ${u === 'kmh' ? 'km/h' : 'mph'}`; }
  if (k === 'volts') return `${v.toFixed(1)} V`;
  if (k === 'rpm') return String(Math.round(v / 10) * 10);
  if (k === 'map') return `${Math.round(v)} kPa`;
  if (k === 'maf') return `${v.toFixed(1)} g/s`;
  return `${Math.round(v)}%`;
}
// The car sends readings 10-25 times a second; gauges glide between them at the screen's own frame rate,
// so needles move smoothly instead of stepping.
const OBDS = { tgt: {}, cur: {}, raf: 0, last: 0, fresh: false, liveTimer: 0 };
function onObd(data) {
  if (!S.state) return;
  S.state.obd = Object.assign(S.state.obd || {}, { data });
  Object.assign(OBDS.tgt, data);
  OBDS.fresh = true;
  document.body.classList.add('obd-live'); // quick gauge transitions while the car is feeding them
  clearTimeout(OBDS.liveTimer);
  OBDS.liveTimer = setTimeout(() => document.body.classList.remove('obd-live'), 3000);
  if (!OBDS.raf) { OBDS.last = performance.now(); OBDS.raf = requestAnimationFrame(obdAnim); }
}
function obdAnim(now) {
  const dt = Math.min(0.1, (now - OBDS.last) / 1000);
  OBDS.last = now;
  const k = 1 - Math.exp(-dt / 0.08);
  let moving = false;
  for (const key of ['rpm', 'speed']) {
    const t = OBDS.tgt[key];
    if (t === undefined) continue;
    const c = OBDS.cur[key] ?? t;
    const n = Math.abs(t - c) < 0.05 ? t : c + (t - c) * k;
    OBDS.cur[key] = n;
    if (n !== t) moving = true;
  }
  if (OBDS.cur.speed !== undefined) {
    S.state.speed = { mps: OBDS.cur.speed / 3.6, at: Date.now() / 1000, src: 'obd' };
    updateSpeedos();
    const v = speedValue(S.state);
    $$('[data-k="speed"]').forEach((el) => { if (el.textContent !== String(v)) el.textContent = v; });
  }
  updateObd(OBDS.fresh);
  OBDS.fresh = false;
  OBDS.raf = moving ? requestAnimationFrame(obdAnim) : 0;
}
function updateObd(all = true) {
  const d = ((S.state || {}).obd || {}).data || {};
  const val = (k) => (k === 'rpm' || k === 'speed') && OBDS.cur[k] !== undefined ? OBDS.cur[k] : d[k];
  $$(all ? '[data-obd]' : '[data-obd="rpm"],[data-obd="speed"]').forEach((el) => { const t = obdText(el.dataset.obd, val(el.dataset.obd)); if (el.textContent !== t) el.textContent = t; });
  $$('[data-obd-arc]').forEach((el) => { const v = val('rpm') || 0; el.style.strokeDashoffset = String(100 - Math.min(1, v / 7000) * 100); el.classList.toggle('hot', v > 5500); });
}
function obdSig() { const o = (S.state && S.state.obd) || {}; return JSON.stringify([o.status, o.scanning, o.found, o.codes, o.pids, (settings().obd || {}).addr, S.clearArmed, (o.events || [])[0]]); }

function update() {
  if (!S.state) return;
  const b = binds();
  $$('[data-k]').forEach((el) => { const v = b[el.dataset.k]; if (v !== undefined && el.textContent !== String(v)) el.textContent = v; });
  $$('[data-k-html]').forEach((el) => { const v = b[el.dataset.kHtml]; if (v !== undefined && el._html !== v) { el.innerHTML = v; el._html = v; } });
  $$('[data-show]').forEach((el) => el.classList.toggle('hidden', !b[el.dataset.show]));
  $$('[data-w]').forEach((el) => { el.style.width = b[el.dataset.w]; });
  $('#call').classList.toggle('hidden', !(b.callIncoming || b.callOngoing));
  document.body.classList.toggle('playing', !!(S.state.media && S.state.media.status === 'playing'));
  $$('.clock').forEach((clock) => {
    if (clock._last !== b.clock) {
      if (clock._last && settings().animate !== false) { clock.classList.remove('tick'); void clock.offsetWidth; clock.classList.add('tick'); }
      clock._last = b.clock;
    }
  });
  updateSpeedos();
  updateObd();
  // sliders the user isn't touching follow the backend
  const a = settings().audio || {};
  $$('input[data-audio]').forEach((el) => { if (!el._drag) { el.value = a[el.dataset.audio]; paintRange(el); } });
  $$('input[data-bright]').forEach((el) => { if (!el._drag) { el.value = Math.max(1, settings().brightness || 1); paintRange(el); } });
  $$(`[data-out="${outKey('data-bright')}"]`).forEach((el) => { el.textContent = `${Math.max(1, settings().brightness || 1)}%`; });
  if (S.screen === 'audio') placeDot();
  if (S.screen === 'phone') {
    const sig = JSON.stringify([settings().recents, settings().favorites, S.tab]);
    if (sig !== S.recentsSig) renderList();
  }
  $$('.c-music, .c-nav, .info').forEach((el) => el.classList.toggle('lit', document.body.classList.contains('playing') && el.classList.contains('c-music')));
  showDisplayConfirm();
  if (S.screen === 'settings' && S.setTab === 'cluster') updateClusterPane();
  movePill();
  const av = $('#assistBar');
  if (av) av.classList.toggle('show', !!b.assistantOn);
  if (window.appView) appView.sync();
}

function onState(st) {
  const firstLoad = !S.state;
  // a Look being edited (Theme Studio) shows here live, without saving it
  const pv = st.look_preview;
  if (pv) {
    const base = st.settings, ps = pv.set || {};
    st.settings = Object.assign({}, base, ps);
    for (const k of ['glass', 'flow', 'cluster']) if (ps[k]) st.settings[k] = Object.assign({}, base[k], ps[k]);
  }
  const pvSig = pv ? JSON.stringify(pv.set || {}) + JSON.stringify(pv.colors || {}) : '';
  const pvChanged = !firstLoad && pvSig !== S.pvSig;
  S.pvSig = pvSig;
  S.state = st;
  renderCarLights();
  const ringing = st.call && (st.call.state === 'incoming' || st.call.state === 'waiting');
  if (ringing && st.settings.brightness === 0) {
    st.settings.brightness = st.settings.brightness_last || 100; // wake for calls
    send('settings', { patch: { brightness: st.settings.brightness } });
  }
  applyLook();
  if (firstLoad) addGaugeCards();
  if (firstLoad) {   // testing: ?screen=look&lt=dash opens a screen (and Look tab) straight away
    const q = new URLSearchParams(location.search);
    if (q.get('screen')) S.screen = q.get('screen');
    if (q.get('lt')) S.lookTab = q.get('lt');
    if (q.get('st')) S.setTab = q.get('st');
    render(false);
  }
  else if (pvChanged) render(true);
  else if (S.screen === 'look' && lookSig() !== S.lookSig) render(true);   // a Look switched or got tweaked elsewhere
  else if (S.screen === 'settings' && S.setTab === 'car' && obdSig() !== S.obdSig) render(true);
  S.obdSig = obdSig();
  S.lookSig = lookSig();
  update();
}

// ================================================================ music panel
const artImg = (b64, iconName = 'music') => b64 ? `<img class="art-img" src="data:image/jpeg;base64,${b64}" alt="">` : ico(iconName, 26);
const EQ = '<span class="eq"><i></i><i></i><i></i><i></i></span>';
function phoneLinked() { return !!(S.state && S.state.companion && S.state.companion.connected); }

const MPANEL = {
  queue() {
    const q = S.queue;
    if (!phoneLinked()) return `<div class="mempty">${ico('phone', 40)}<b>Phone app not connected</b><span>Open Head Unit Link on your phone to see what's coming up.</span></div>`;
    if (!q || !q.items || !q.items.length) return `<div class="mempty">${ico('list', 40)}<b>Nothing queued</b><span>Start a playlist, album or mix in YouTube Music and its songs show up here. Tap any song to jump to it.</span></div>`;
    return `<div class="mhead"><div><div class="label">Playing from</div><b>${esc(q.title || 'your queue')}</b></div><button class="icon-btn sink" data-act="queue_refresh" aria-label="Refresh">${sv('<polyline points="23 4 23 10 17 10"/><path d="M20.5 15a9 9 0 1 1-2.1-9.4L23 10"/>', 24)}</button></div>
      <div class="qlist">${q.items.map((it, i) => {
        const on = it.id === q.active;
        const past = q.items.findIndex((x) => x.id === q.active) > i;
        return `<button class="qitem sink ${on ? 'on' : ''} ${past ? 'past' : ''}" data-queue="${it.id}">
          <span class="qart">${artImg(it.art)}</span>
          <span class="qtext"><b>${esc(it.title)}</b><span>${esc(it.artist)}</span></span>
          ${on ? EQ : `<span class="qplay">${ICON.play}</span>`}</button>`;
      }).join('')}</div>`;
  },
  library() {
    if (!phoneLinked()) return MPANEL.queue();
    const lib = S.library;
    const crumb = S.libStack.length ? `<div class="mhead"><button class="btn small sink" data-act="lib_back">${ico('left', 18)}Back</button><b class="crumb">${esc(S.libStack[S.libStack.length - 1].title)}</b>
      <button class="icon-btn sink" data-act="pin_current" aria-label="Pin this list">${ico('pin', 22)}</button></div>` : '<div class="mhead"><b>Your YouTube Music</b></div>';
    if (!lib || lib.status === 'loading') return `${crumb}<div class="mempty"><div class="spinner"></div><span>Asking YouTube Music…</span></div>`;
    if (lib.status === 'unavailable') return `${crumb}<div class="mempty">${ico('library', 40)}<b>Library not available</b><span>${esc(lib.message || '')}</span>
      <button class="btn primary sink" data-act="mtab:search">${ico('search', 20)}Search by name instead</button></div>`;
    const items = lib.items || [];
    if (!items.length) return `${crumb}<div class="mempty"><span>This list is empty.</span></div>`;
    return `${crumb}<div class="lgrid2">${items.map((it, i) => `<button class="ltile sink" data-lib="${i}">
        <span class="lart">${artImg(it.art, it.browsable ? 'library' : 'music')}${it.playable ? `<span class="lplay">${ICON.play}</span>` : ''}</span>
        <b>${esc(it.title)}</b><span>${esc(it.subtitle || (it.browsable ? 'Open' : ''))}</span></button>`).join('')}</div>`;
  },
  search() {
    const recent = S.recentSearches.slice(0, 6);
    return `<div class="sfield"><span>${ico('search', 22)}</span><div class="stext">${esc(S.search)}<i class="caret"></i>${S.search ? '' : '<em>Song, artist, album or playlist</em>'}</div>
        ${S.search ? `<button class="icon-btn sink" data-act="s_clear" aria-label="Clear">${ico('x', 20)}</button>` : ''}</div>
      ${recent.length ? `<div class="chips srecent">${recent.map((r) => `<button class="sink" data-sq="${esc(r)}">${esc(r)}</button>`).join('')}</div>` : ''}
      <div class="kbd">${[['1234567890'], ['qwertyuiop'], ['asdfghjkl'], ['zxcvbnm']].map(([row], ri) => `<div class="krow">${
        row.split('').map((c) => `<button class="kk sink" data-kk="${c}">${c}</button>`).join('')}${ri === 3 ? `<button class="kk wide sink" data-act="s_back" aria-label="Delete">${ico('back', 22)}</button>` : ''}</div>`).join('')}
        <div class="krow"><button class="kk wide sink" data-act="s_pin" ${S.search ? '' : 'disabled'}>${ico('pin', 20)}Pin</button><button class="kk space sink" data-kk=" ">space</button>
        <button class="kk go sink" data-act="s_go">${ico('play', 18)}Play</button></div>
      </div>`;
  },
  pins() {
    const pins = settings().music_pins || [];
    if (!pins.length) return `<div class="mempty">${ico('pin', 40)}<b>No pinned music yet</b><span>Pin a playlist from the Library, or search for one (“chill drive”, “liked music”) and tap Pin. They show up here as one-tap buttons.</span></div>`;
    return `<div class="mhead"><b>Pinned</b><button class="btn small sink ${S.pinEdit ? 'primary' : ''}" data-act="pin_edit">${S.pinEdit ? 'Done' : 'Edit'}</button></div>
      <div class="lgrid2">${pins.map((p, i) => `<button class="ltile sink ${S.pinEdit ? 'editing' : ''}" data-pin="${i}">
        <span class="lart">${artImg(p.art, 'pin')}${S.pinEdit ? `<span class="lx">${ico('x', 22)}</span>` : `<span class="lplay">${ICON.play}</span>`}</span>
        <b>${esc(p.name)}</b><span>${p.id ? 'From your library' : 'Plays by search'}</span></button>`).join('')}</div>`;
  },
};
// The playing song moved within the same list: just move the highlight, no rebuild (keeps it instant)
function markQueueActive() {
  const list = document.querySelector('#mpanel .qlist');
  if (!list || !S.queue) return;
  const items = [...list.querySelectorAll('.qitem')];
  const at = items.findIndex((b) => String(b.dataset.queue) === String(S.queue.active));
  items.forEach((b, i) => {
    const on = i === at;
    b.classList.toggle('on', on);
    b.classList.toggle('past', at >= 0 && i < at);
    const tail = b.lastElementChild;
    const isEq = !tail.classList.contains('qplay');
    if (on && !isEq) tail.outerHTML = EQ;
    else if (!on && isEq) tail.outerHTML = `<span class="qplay">${ICON.play}</span>`;
  });
  if (at >= 0) items[at].scrollIntoView({ block: 'nearest', behavior: 'smooth' });
}
function renderMusicPanel() {
  const el = $('#mpanel');
  if (!el) return;
  const keep = el.querySelector('.qlist, .lgrid2');
  const top = keep ? keep.scrollTop : 0;
  el.innerHTML = (MPANEL[S.mtab] || MPANEL.queue)();
  $$('.mtab').forEach((b) => b.classList.toggle('on', b.dataset.act === `mtab:${S.mtab}`));
  const list = el.querySelector('.qlist');
  if (list && !S.queueScrolled) { // bring the playing song into view the first time
    const on = list.querySelector('.qitem.on');
    if (on) list.scrollTop = Math.max(0, on.offsetTop - list.offsetTop - 8);
    S.queueScrolled = true;
  } else if (list || el.querySelector('.lgrid2')) (list || el.querySelector('.lgrid2')).scrollTop = top;
}
function openLibrary(id, title) {
  if (id === null) S.libStack = []; else S.libStack.push({ id, title });
  S.library = { status: 'loading' };
  renderMusicPanel();
  send('library_open', { id: id || '' });
}

// ================================================================ phone list
function renderList() {
  const el = $('#plist');
  if (!el) return;
  const s = settings();
  S.recentsSig = JSON.stringify([s.recents, s.favorites, S.tab]);
  const phoneBtn = `<span class="callme">${sv(P.phone, 22)}</span>`;
  if (S.tab === 'favorites') {
    const favs = (s.favorites || []).filter((f) => f.number);
    el.innerHTML = favs.length
      ? favs.map((f) => `<button class="pitem sink" data-dial="${esc(f.number)}"><span class="avatar">${esc(initial(f.name))}</span><span class="who"><div>${esc(f.name)}</div><div>${esc(f.number)}</div></span>${phoneBtn}</button>`).join('')
      : '<div class="empty">No favorites yet. Star contacts on your phone and they show up here.</div>';
  } else {
    const rec = s.recents || [];
    el.innerHTML = rec.length
      ? rec.map((r) => `<button class="pitem sink ${r.kind === 'missed' ? 'missed' : ''}" data-dial="${esc(r.number)}"><span class="avatar">${esc(initial(r.name))}</span><span class="who"><div>${esc(r.name || r.number)}</div><div>${{ missed: 'Missed', incoming: 'Incoming', outgoing: 'Outgoing' }[r.kind] || ''}, ${ago(r.time)}</div></span>${phoneBtn}</button>`).join('')
      : '<div class="empty">Calls you make and get while connected show up here.</div>';
  }
}

// ================================================================ sliders
function paintRange(el) {
  const min = +el.min, max = +el.max;
  el.style.setProperty('--fill', `${((el.value - min) / (max - min)) * 100}%`);
}
const throttle = (fn, ms) => { let last = 0, timer; return (...a) => { const now = Date.now(); clearTimeout(timer);
  if (now - last >= ms) { last = now; fn(...a); } else timer = setTimeout(() => { last = Date.now(); fn(...a); }, ms - (now - last)); }; };
const sendAudio = throttle((patch) => send('audio', { patch }), 80);
const sendSettings = throttle((patch) => send('settings', { patch }), 120);
const out = (attr, text) => $$(`[data-out="${outKey(attr)}"]`).forEach((o) => { o.textContent = text; });

document.addEventListener('input', (e) => {
  const el = e.target;
  if (el.type !== 'range') return;
  paintRange(el);
  const v = +el.value;
  const st = S.state.settings;
  if (el.dataset.audio) {
    const k = el.dataset.audio;
    st.audio[k] = v;
    const o = $(`#v_${k}`);
    if (o && S.fmt) o.textContent = S.fmt[k](v);
    if (k === 'call_volume') $$('[data-k="callVolume"]').forEach((x) => { x.textContent = v; });
    sendAudio({ [k]: v });
  } else if (el.hasAttribute('data-bright')) {
    st.brightness = v; st.brightness_last = v;
    applyLook(); out('data-bright', `${v}%`);
    sendSettings({ brightness: v });
  } else if (el.hasAttribute('data-night')) {
    st.night_level = v; applyLook(); out('data-night', `${v}%`);
    sendSettings({ night_level: v });
  } else if (el.hasAttribute('data-tank')) {
    st.tank = v; out('data-tank', `${(v / 10).toFixed(1)} gal`);
    sendSettings({ tank: v });
  } else if (el.hasAttribute('data-clarity')) {
    st.glass = Object.assign(glassSet(), clarityGlass(v));
    applyLook();
    out('data-clarity', v < 34 ? 'Clear' : v < 67 ? 'Frosted' : 'Solid');
    sendSettings({ glass: st.glass });
  } else if (el.dataset.glass) {
    const k = el.dataset.glass;
    st.glass = Object.assign(glassSet(), { [k]: v });
    applyLook();
    out(`data-glass="${k}"`, k === 'blur' ? `${v}` : `${v}%`);
    sendSettings({ glass: st.glass });
  } else if (el.dataset.lch) {
    lookColorFromSliders();
  } else if (el.dataset.flowint) {
    const k = el.dataset.flowint;
    out(`data-flowint="${k}"`, `${v}%`);
    setFlow({ [k]: v });
  } else if (el.dataset.clint) {
    const k = el.dataset.clint;
    out(`data-clint="${k}"`, k === 'shift' || k === 'redline' ? (v ? `${v} rpm` : 'Off') : k === 'map_trim' ? `${v}` : `${v}%`);
    st.cluster = Object.assign(clusterSet(), { [k]: v });
    sendSettings({ cluster: st.cluster });
  } else if (el.dataset.intset) {
    const k = el.dataset.intset;
    st[k] = v; out(`data-intset="${k}"`, `${v}%`);
    if (k.startsWith('map_')) applyMapBg();
    sendSettings({ [k]: v });
  } else if (el.hasAttribute('data-uiscale')) {
    out('data-uiscale', `${v}%`); // applied when you let go, so the slider doesn't jump under your finger
  }
});
document.addEventListener('toggle', (e) => { if (e.target.matches && e.target.matches('[data-fine]')) S.fineOpen = e.target.open; }, true);
document.addEventListener('change', (e) => {
  const el = e.target;
  if (el.type === 'range' && el.dataset.lch) render(true);   // shows the "Original" button once you've changed something
  if (el.type === 'range' && el.hasAttribute('data-uiscale')) {
    setSetting({ ui_scale: +el.value });
    requestAnimationFrame(() => { movePill(); reportRect(); });
  }
});
document.addEventListener('pointerdown', (e) => { if (e.target.type === 'range') e.target._drag = true; });
// for 15 minutes after the screen loads, report where taps land (to check the touch mapping with two screens)
const TOUCH_LOG_UNTIL = Date.now() + 15 * 60 * 1000;
document.addEventListener('pointerdown', (e) => { if (Date.now() < TOUCH_LOG_UNTIL) send('touch_log', { x: Math.round(e.clientX), y: Math.round(e.clientY), w: innerWidth, h: innerHeight }); }, true);
document.addEventListener('pointerup', () => $$('input[type=range]').forEach((r) => { r._drag = false; }));

// ================================================================ fader pad
function placeDot() {
  const a = settings().audio || {};
  const dot = $('#dot');
  if (!dot || S.padDrag) return;
  dot.style.left = `${50 + (a.balance || 0) * 4.2}%`;
  dot.style.top = `${50 - (a.fader || 0) * 4.2}%`;
  const fv = a.fader || 0, bv = a.balance || 0;
  $('#faderVal').textContent = fv === 0 ? 'Center' : fv > 0 ? `Front ${fv}` : `Rear ${-fv}`;
  $('#balVal').textContent = bv === 0 ? 'Center' : bv > 0 ? `Right ${bv}` : `Left ${-bv}`;
}
function mountPad(root) {
  const pad = $('#pad', root);
  if (!pad) return;
  const move = (e) => {
    const r = pad.getBoundingClientRect();
    const x = Math.min(1, Math.max(0, (e.clientX - r.left) / r.width));
    const y = Math.min(1, Math.max(0, (e.clientY - r.top) / r.height));
    const a = S.state.settings.audio;
    a.balance = Math.max(-10, Math.min(10, Math.round(((x - 0.5) / 0.42) * 10)));
    a.fader = Math.max(-10, Math.min(10, Math.round(((0.5 - y) / 0.42) * 10)));
    S.padDrag = false; placeDot(); S.padDrag = true;
    sendAudio({ balance: a.balance, fader: a.fader });
  };
  pad.addEventListener('pointerdown', (e) => { pad.setPointerCapture(e.pointerId); S.padDrag = true; move(e); });
  pad.addEventListener('pointermove', (e) => { if (S.padDrag) move(e); });
  const end = () => { S.padDrag = false; placeDot(); };
  pad.addEventListener('pointerup', end);
  pad.addEventListener('pointercancel', end);
  placeDot();
}

// ================================================================ sheets and dialogs
function openSlotSheet(i) {
  const lay = g('home_layout');
  const cur = cardsFor(lay)[i];
  S.editSlot = i;
  $$('.card').forEach((c, k) => c.classList.toggle('editing', c.dataset.hold === `slot:${i}`));
  $('#overlay').innerHTML = `<div class="sheet-wrap" data-act="sheet_close"><div class="sheet glass" data-stop>
    <div class="head"><h2>Spot ${i + 1}: choose a card</h2><button class="btn small sink" data-act="sheet_close">Done</button></div>
    <div class="opts">${Object.entries(CARD_NAMES).filter(([id]) => !id.startsWith('g_')).map(([id, l]) => `<button class="sink ${cur === id ? 'on' : ''}" data-slot="${i}:${id}">${ico(CARD_ICONS[id], 24)}${l}</button>`).join('')}</div>
    <h3 class="opts-h">OBD gauges</h3>
    <div class="opts">${Object.entries(CARD_NAMES).filter(([id]) => id.startsWith('g_')).map(([id, l]) => `<button class="sink ${cur === id ? 'on' : ''}" data-slot="${i}:${id}">${ico('gauge', 24)}${l.replace(' gauge', '')}</button>`).join('')}</div>
  </div></div>`;
}
function wxIconName() {
  const w = (S.state && S.state.weather) || {}, c = +w.code;
  if (c >= 95) return 'storm';
  if ((c >= 51 && c <= 67) || (c >= 80 && c <= 82)) return 'rain';
  if ((c >= 71 && c <= 77) || c === 85 || c === 86) return 'snow';
  if (c === 2 || c === 3 || c === 45 || c === 48) return 'cloud';
  return w.day === false ? 'moon' : 'sun';
}
function openGaugeSheet(i) {
  const cur = gaugeSet().slots[i];
  $('#overlay').innerHTML = `<div class="sheet-wrap" data-act="sheet_close"><div class="sheet glass" data-stop>
    <div class="head"><h2>Gauge ${i + 1}</h2><button class="btn small sink" data-act="sheet_close">Done</button></div>
    <div class="gopts">${(window.GAUGE_LIST || []).map(([id, l, d]) => `<button class="sink ${cur === id ? 'on' : ''}" data-gpick="${i}:${id}"><b>${l}</b><small>${d}</small></button>`).join('')}</div>
  </div></div>`;
}
const autoSet = () => JSON.parse(JSON.stringify(Object.assign({ on: false, rules: [] }, settings().look_schedule || {})));
const autoWeatherRules = () => AUTO_WEATHER.filter(([, id]) => lookById(id)).map(([when, look]) => ({ when, look }));
function openLookSheet(i) {
  const cur = (autoSet().rules[i] || {}).look, all = [...((S.state && S.state.my_looks) || []), ...LOOKS];
  $('#overlay').innerHTML = `<div class="sheet-wrap" data-act="sheet_close"><div class="sheet glass" data-stop>
    <div class="head"><h2>Which Look?</h2><button class="btn small sink" data-act="sheet_close">Done</button></div>
    <div class="lk-grid lk-sheet">${all.map((x) => `<button class="lk-card sink ${cur === x.id ? 'on' : ''}" data-autopick="${i}:${esc(x.id)}">${lookSwatch(x.colors)}<b>${esc(x.name)}</b></button>`).join('')}</div>
  </div></div>`;
}
function closeSheet() {
  $('#overlay').innerHTML = '';
  $$('.card.editing').forEach((c) => c.classList.remove('editing'));
}
function setSlot(i, id) {
  const lay = g('home_layout');
  const all = Object.assign({}, DEF.home_cards, settings().home_cards || {});
  const list = cardsFor(lay);
  list[i] = id;
  all[lay] = list;
  setSetting({ home_cards: all });
}

let confirmTimer = null;
function showDisplayConfirm() {
  const d = S.state && S.state.display;
  const box = $('#confirmBox');
  if (!d || !d.pending) { if (box) box.remove(); clearInterval(confirmTimer); confirmTimer = null; return; }
  if (!box) {
    const el = document.createElement('div');
    el.className = 'confirm'; el.id = 'confirmBox';
    el.innerHTML = `<div class="box glass"><h2>Keep this resolution?</h2><div class="count" id="confirmCount"></div>
      <p class="note">If you don’t answer, the screen switches back by itself.</p>
      <div class="row"><button class="btn sink" data-act="display_revert">Switch back</button><button class="btn primary sink" data-act="display_keep">Keep it</button></div></div>`;
    document.body.appendChild(el);
    const tick = () => { const c = $('#confirmCount'); const p = S.state.display.pending; if (c && p) c.textContent = String(Math.max(0, Math.ceil(p.revert_at - Date.now() / 1000))); };
    tick();
    confirmTimer = setInterval(tick, 250);
  }
}

// ================================================================ taps
const RERENDER = new Set(['home_layout', 'speedo', 'speed_units', 'nav', 'header', 'quick', 'maps_panel', 'map_only', 'app_view', 'map_bg']);
let suppressClick = false;
document.addEventListener('click', (e) => {
  if (suppressClick) { suppressClick = false; e.preventDefault(); e.stopPropagation(); return; }
  const gp = e.target.closest('[data-gpick]');
  if (gp) {
    const [i, id] = gp.dataset.gpick.split(':'), gs = gaugeSet(), slots = gs.slots.slice();
    slots[+i] = id; closeSheet(); setSetting({ gauges: Object.assign(gs, { slots }) }, true); return;
  }
  // ---- Settings > Cluster (changes are kept light: re-rendering would reload the live preview)
  const clp = e.target.closest('[data-clpick]');
  if (clp) {
    const [i, id] = clp.dataset.clpick.split(':'), slots = clusterSet().slots.slice();
    slots[+i] = id; closeSheet(); setCluster({ slots });
    const box = $('#clSlots'); if (box) box.innerHTML = clusterSlotsHtml();
    return;
  }
  const cls = e.target.closest('[data-clslot]');
  if (cls) return openClusterSheet(+cls.dataset.clslot);
  // ---- Look > Dash: Flow, dash themes, where the screens sit
  const ft = e.target.closest('[data-flowtoggle]');
  if (ft) {
    const k = ft.dataset.flowtoggle, f = flowSet(), v = !(f[k] !== false);
    setFlow({ [k]: v });
    if (k === 'on' && v) flowSplash(e);
    render(true);
    return;
  }
  const fv = e.target.closest('[data-flow]');
  if (fv) {
    const i = fv.dataset.flow.indexOf(':'), k = fv.dataset.flow.slice(0, i), v = fv.dataset.flow.slice(i + 1);
    setFlow(k === 'scene' ? { scene: v, on: true } : { [k]: v });
    if (k === 'scene') { S.flowPrev = null; render(true); } else $$(`[data-flow^="${k}:"]`).forEach((b) => b.classList.toggle('on', b === fv));
    return;
  }
  const lkc = e.target.closest('[data-look]');
  if (lkc) { useLook(lkc.dataset.look, e); return; }
  const fxo = e.target.closest('[data-fxonly]');
  if (fxo) { setSetting({ effect: fxo.dataset.fxonly, flow: Object.assign(flowSet(), { on: false }) }); render(true); return; }
  const ap = e.target.closest('[data-autopick]');
  if (ap) {
    const [i, id] = ap.dataset.autopick.split(/:(.*)/s), sc = autoSet();
    sc.rules[+i].look = id;
    setSetting({ look_schedule: sc }); closeSheet(); render(true); return;
  }
  const dsel = e.target.closest('[data-dashsel]');
  if (dsel) { S.dashSel = dsel.dataset.dashsel; if (typeof FLOWPV !== 'undefined') FLOWPV.sel = S.dashSel; $$('[data-dashsel]').forEach((b) => b.classList.toggle('on', b === dsel)); return; }
  const dn = e.target.closest('[data-dashnudge]');
  if (dn) {
    const [dx, dy] = dn.dataset.dashnudge.split(',').map(Number), n = S.dashSel || 'hu';
    const d = Object.assign({}, window.FLOW_DASH, settings().dash || {}), v = (d[n] || window.FLOW_DASH[n]).slice();
    v[0] += dx; v[1] += dy;
    setSetting({ dash: Object.assign({}, d, { [n]: v }) });
    if (typeof FLOWPV !== 'undefined') FLOWPV.sel = n;
    return;
  }
  const fa = e.target.closest('[data-act="flow_lineup"],[data-act="dash_reset"]');
  if (fa) {
    if (fa.dataset.act === 'dash_reset') setSetting({ dash: JSON.parse(JSON.stringify(window.FLOW_DASH)) });
    else if (flowSet().scene === 'calibrate') setFlow({ scene: S.flowPrev || 'liquid' });
    else { S.flowPrev = flowSet().scene; setFlow({ scene: 'calibrate', on: true }); }
    render(true);
    return;
  }
  const clt = e.target.closest('[data-cltoggle]');
  if (clt) {
    const k = clt.dataset.cltoggle, c = clusterSet(), v = !(c[k] !== false && c[k] !== undefined);
    setCluster({ [k]: v }); clt.classList.toggle('on', v);
    if (k === 'on') updateClusterPane();
    return;
  }
  const clv = e.target.closest('[data-cl]');
  if (clv) {
    const i = clv.dataset.cl.indexOf(':'), k = clv.dataset.cl.slice(0, i), v = clv.dataset.cl.slice(i + 1);
    setCluster({ [k]: v });
    $$(`[data-cl^="${k}:"]`).forEach((b) => b.classList.toggle('on', b === clv));
    if (k === 'layout') {
      const box = $('#clSlots'); if (box) box.innerHTML = clusterSlotsHtml();
      const L = (window.CLUSTER_LAYOUTS || []).find((l) => l[0] === v) || [];
      const mid = $('#clMid'); if (mid) mid.classList.toggle('hidden', !L[4]);
    }
    return;
  }
  const gl = e.target.closest('[data-glayout]');
  if (gl) { setSetting({ gauges: Object.assign(gaugeSet(), { layout: gl.dataset.glayout }) }, true); return; }
  const gs0 = e.target.closest('[data-gslot]');
  if (gs0 && S.gEdit) return openGaugeSheet(+gs0.dataset.gslot);
  const ob = e.target.closest('[data-obd-use]');
  if (ob) { const [addr, kind, ...n] = ob.dataset.obdUse.split('|'); toast(`Connecting to ${n.join('|')}…`); return send('obd_use', { addr, kind, name: n.join('|') }); }
  const mel = e.target.closest('[data-queue],[data-lib],[data-pin],[data-kk],[data-sq]');
  if (mel && !mel.disabled) return musicTap(mel);
  const el = e.target.closest('[data-tool],[data-style-pick],[data-act],[data-go],[data-go-card],[data-dial],[data-key],[data-theme],[data-toggle],[data-set],[data-knob],[data-slot],[data-gtint],[data-gtoggle],[data-mode],[data-hour],[data-stop]');
  if (!el || el.hasAttribute('data-stop') && !el.matches('[data-act],[data-slot]')) return;
  const d = el.dataset;
  if (d.go) return go(d.go);
  if (d.goCard) return go(d.goCard);
  if (d.dial !== undefined) {
    if (!d.dial) return toast('No number saved for this contact.');
    return send('dial', { number: d.dial });
  }
  if (d.key) { if (S.dial.length < 20) S.dial += d.key; return update(); }
  if (d.tool) {
    // big ones need a second tap within 4 seconds
    if (['reboot', 'restart', 'usb_update', 'phone_update'].includes(d.tool) && S.armed !== d.tool) {
      S.armed = d.tool; toast('Tap again to confirm');
      clearTimeout(S.armTimer); S.armTimer = setTimeout(() => { S.armed = null; }, 4000);
      return;
    }
    S.armed = null;
    send('tool', { tool: d.tool });
    return;
  }
  if (d.stylePick) {
    themeWipe(() => {
      setSetting({ style: d.stylePick });
      S.lastRect = '';
      render(true);
      requestAnimationFrame(() => { movePill(); if (isStage(S.screen)) reportRect(); });
    }, e.clientX, e.clientY);
    return;
  }
  if (d.theme) {   // a ready-made color set for the Look you're on
    const t = THEMES.find((x) => x.id === d.theme);
    if (t) themeWipe(() => { usePalette(t); render(true); }, e.clientX, e.clientY);
    return;
  }
  if (d.toggle) {
    const k = d.toggle;
    const cur = k === 'animate' || k === 'glow' ? settings()[k] !== false : !!g(k);
    setSetting({ [k]: !cur });
    el.classList.toggle('on', !cur);
    if (RERENDER.has(k)) { S.lastRect = ''; if (isStage(S.screen)) render(true); }
    if ((k === 'rain_glass' || k === 'rain_over' || k === 'map_bg') && S.screen === 'look') render(true); // shows/hides options
    return;
  }
  if (d.set) {
    const i = d.set.indexOf(':');
    const k = d.set.slice(0, i), v = d.set.slice(i + 1);
    setSetting({ [k]: v });
    $$(`[data-set^="${k}:"]`).forEach((b) => b.classList.toggle('on', b.dataset.set === d.set));
    if (RERENDER.has(k)) { render(true); S.lastRect = ''; requestAnimationFrame(() => { movePill(); reportRect(); }); }
    else if ((k === 'effect' || k === 'map_style') && S.screen === 'look') render(true); // shows/hides the options that go with it
    return;
  }
  if (d.knob) { setSetting({ knob_style: d.knob }); $$('.kcard').forEach((c) => c.classList.toggle('on', c.dataset.knob === d.knob)); return; }
  if (d.slot) {
    const [i, id] = d.slot.split(':');
    setSlot(+i, id);
    if (S.screen === 'home') { closeSheet(); render(true); } else render(true);
    return;
  }
  if (d.hour) { setSetting({ clock_24h: d.hour === '24' }); $$('[data-hour]').forEach((b) => b.classList.toggle('on', b === el)); return update(); }
  if (d.gtint) { setGlass({ tint: d.gtint }); $$('[data-gtint]').forEach((b) => b.classList.toggle('on', b === el)); return; }
  if (d.gtoggle) { const v = glassSet()[d.gtoggle] === false; setGlass({ [d.gtoggle]: v }); el.classList.toggle('on', v); return; }
  if (d.mode) return send('display_mode', { mode: d.mode });
  if (!d.act) return;
  const [act, arg] = d.act.split(/:(.*)/s);
  switch (act) {
    case 'media': return send('media', { action: arg });
    case 'playpause': return send('media', { action: S.state.media.status === 'playing' ? 'pause' : 'play' });
    case 'open': return send('open_app', { app: arg });
    case 'tab': S.tab = arg; $$('[data-act^="tab:"]').forEach((b) => b.classList.toggle('on', b.dataset.act === d.act)); return renderList();
    case 'backspace': S.dial = S.dial.slice(0, -1); return update();
    case 'call': if (!S.dial) return toast('Enter a number first.'); send('dial', { number: S.dial }); S.dial = ''; return update();
    case 'center': S.state.settings.audio.fader = 0; S.state.settings.audio.balance = 0; placeDot(); return send('audio', { patch: { fader: 0, balance: 0 } });
    case 'tone_reset':
      Object.assign(S.state.settings.audio, { bass: 0, mid: 0, treble: 0 });
      send('audio', { patch: { bass: 0, mid: 0, treble: 0 } });
      return render(true);
    case 'screen_off': return screenOff();
    case 'cluster_restart': toast('Restarting the cluster…'); return send('cluster_restart');
    case 'looktab': S.lookTab = arg; return render(true);
    case 'lookpart': S.lookPart = arg; return render(true);
    case 'lookgroup': S.lookGroup = arg; return render(true);
    case 'looksave': toast('Saved as one of your Looks'); return send('look_save', {});
    case 'lookreset': toast('Back to the original'); return send('look_reset', {});
    case 'lookdel':
      if (S.armed !== d.act) { S.armed = d.act; render(true); clearTimeout(S.armTimer); S.armTimer = setTimeout(() => { S.armed = null; if (S.screen === 'look') render(true); }, 4000); return; }
      S.armed = null; return send('look_delete', { id: arg });
    case 'auto_on': { const sc = autoSet(); sc.on = !sc.on; if (sc.on && !sc.rules.length) sc.rules = autoWeatherRules(); setSetting({ look_schedule: sc }); return render(true); }
    case 'auto_weather': { const sc = autoSet(); sc.on = true; sc.rules = autoWeatherRules(); setSetting({ look_schedule: sc }); toast('The dash follows the weather now'); return render(true); }
    case 'auto_add': { const sc = autoSet(); sc.rules.push({ when: 'time', from: 19 * 60, to: 7 * 60, look: (S.state.look || {}).id }); setSetting({ look_schedule: sc }); return render(true); }
    case 'auto_del': { const sc = autoSet(); sc.rules.splice(+arg, 1); setSetting({ look_schedule: sc }); return render(true); }
    case 'auto_when': {
      const sc = autoSet(), r = sc.rules[+arg], w = AUTO_WHEN.map((x) => x[0]);
      r.when = w[(w.indexOf(r.when) + 1) % w.length];
      if (r.when === 'time' && r.from === undefined) Object.assign(r, { from: 19 * 60, to: 7 * 60 });
      setSetting({ look_schedule: sc }); return render(true);
    }
    case 'auto_t': {
      const [i, k, dm] = arg.split(':'), sc = autoSet(), r = sc.rules[+i];
      r[k] = ((r[k] || 0) + +dm + 1440) % 1440;
      setSetting({ look_schedule: sc }); return render(true);
    }
    case 'auto_look': return openLookSheet(+arg);
    case 'settab': S.setTab = arg; return render(true);
    case 'cltab':   // cluster sub-tabs switch in place, so the live preview keeps running
      S.clTab = arg;
      $$('[data-clpane]').forEach((p) => p.classList.toggle('hidden', p.dataset.clpane !== arg));
      $$('.cl-tabs button').forEach((b) => b.classList.toggle('on', b.dataset.act === `cltab:${arg}`));
      return;
    case 'car_settings': S.setTab = 'car'; return go('settings');
    case 'can_open': go('can'); return renderCan();
    case 'can_listen': send('can_listen', { on: arg === '1' }); if (arg === '1') { CAN.data = null; CAN.mark = 0; } return;
    case 'can_ignore': return send('can_ignore', { secs: 10 });
    case 'can_clear': return send('can_clear');
    case 'can_mark': CAN.mark = (CAN.mark || 0) + 1; toast(`Mark ${CAN.mark}: now do the thing`); send('can_mark', { label: `mark ${CAN.mark}` }); return renderCan();
    case 'cluster_settings': S.setTab = 'cluster'; return go('settings');
    case 'cl_edit': return ceOpen();
    case 'gauges_edit': S.gEdit = !S.gEdit; return render(true);
    case 'obd_scan': return send('obd_scan');
    case 'obd_retry': toast('Trying again…'); return send('obd_retry');
    case 'obd_forget': return send('obd_forget');
    case 'obd_codes': toast('Asking the car…'); return send('obd_codes');
    case 'obd_clear':
      if (!S.clearArmed) { S.clearArmed = true; render(true); setTimeout(() => { if (S.clearArmed) { S.clearArmed = false; if (S.setTab === 'car') render(true); } }, 4000); return; }
      S.clearArmed = false; render(true); toast('Clearing…'); return send('obd_codes', { clear: true });
    case 'group': S.group = arg; return render(true);
    case 'splash_play': return send('splash_play', {});
    case 'shuffle': {
      const pick = THEMES[Math.floor(Math.random() * THEMES.length)];
      themeWipe(() => { usePalette(pick); render(true); }, e.clientX, e.clientY);
      return toast(pick.name);
    }
    case 'lcslot': S.lcSlot = arg; render(true); return;
    case 'lcq': setLookColors({ [S.lcSlot && LC_SLOTS.some(([k]) => k === S.lcSlot) ? S.lcSlot : 'accent']: arg }); render(true); return;
    case 'lcreset': send('look_colors', { colors: null }); toast('Back to the original colors'); return;
    case 'gpreset': { const p = GLASS_PRESETS[arg]; if (p) { setGlass(p[1]); render(true); toast(`${p[0]} glass`); } return; }
    case 'sheet_close': return closeSheet();
    case 'mtab':
      S.mtab = arg;
      if (arg === 'library' && !S.library) return openLibrary(null);
      return renderMusicPanel();
    case 'queue_refresh': return send('queue_refresh');
    case 'lib_back': S.libStack.pop(); { const top = S.libStack.pop(); return top ? openLibrary(top.id, top.title) : openLibrary(null); }
    case 'pin_current': {
      const top = S.libStack[S.libStack.length - 1];
      if (top) { send('pin_add', { name: top.title, id: top.id, art: top.art || null }); toast(`Pinned “${top.title}”`); }
      return;
    }
    case 'pin_edit': S.pinEdit = !S.pinEdit; return renderMusicPanel();
    case 's_clear': S.search = ''; return renderMusicPanel();
    case 's_back': S.search = S.search.slice(0, -1); return renderMusicPanel();
    case 's_go': return musicSearch(S.search);
    case 's_pin': if (S.search.trim()) { send('pin_add', { name: S.search.trim(), query: S.search.trim() }); toast(`Pinned “${S.search.trim()}”`); } return;
    case 'fix_audio': toast('Checking the sound routing…'); return send('fix_audio');
    case 'reload': return location.reload();
    case 'ripple_test': {
      const v = (settings().audio || {}).volume ?? 40; let i = 0;
      const step = () => { window.knobFx({ dir: 1, vol: Math.min(100, v + i * 2) }); if (++i < 6) setTimeout(step, 120); else setTimeout(() => window.knobFx({ act: 'press' }), 700); };
      return step();
    }
    case 'fullmap': setFull(!S.full); $('#nav').innerHTML = navHtml(); movePill(); update(); return;
    case 'pair': toast('Pairing is on for 3 minutes. On your phone, open Bluetooth and choose “Pi Head Unit”.'); return send('pair');
    default: return send(act);
  }
});

function musicSearch(q) {
  q = (q || '').trim();
  if (!q) return toast('Type what you want to hear first.');
  S.recentSearches = [q, ...S.recentSearches.filter((x) => x !== q)].slice(0, 8);
  send('music_search', { query: q });
  toast(`Playing “${q}”`);
  S.mtab = 'queue'; S.queueScrolled = false;
  setTimeout(() => send('queue_refresh'), 2500);
  renderMusicPanel();
}
function musicTap(el) {
  const d = el.dataset;
  if (d.kk !== undefined) { if (S.search.length < 60) S.search += d.kk; return renderMusicPanel(); }
  if (d.sq) { S.search = d.sq; return musicSearch(d.sq); }
  if (d.queue) { send('queue_play', { id: Number(d.queue) }); $$('.qitem').forEach((q) => q.classList.toggle('on', q === el)); return; }
  if (d.lib !== undefined) {
    const it = ((S.library || {}).items || [])[+d.lib];
    if (!it) return;
    if (it.browsable) { openLibrary(it.id, it.title); S.libStack[S.libStack.length - 1].art = it.art; return; }
    if (it.playable) { send('library_play', { id: it.id }); toast(`Playing “${it.title}”`); setTimeout(() => send('queue_refresh'), 2500); }
    return;
  }
  if (d.pin !== undefined) {
    const p = (settings().music_pins || [])[+d.pin];
    if (!p) return;
    if (S.pinEdit) { send('pin_remove', { name: p.name }); S.state.settings.music_pins = settings().music_pins.filter((x) => x !== p); return renderMusicPanel(); }
    if (p.id) send('library_play', { id: p.id }); else send('music_search', { query: p.query || p.name });
    toast(`Playing “${p.name}”`);
    setTimeout(() => send('queue_refresh'), 2500);
  }
}

// Hold a home card to choose what it shows. Nothing else reacts to a long press.
let hold = null;
document.addEventListener('pointerdown', (e) => {
  const el = e.target.closest('[data-hold]');
  if (!el || e.target.closest('button, input, .appview')) return;
  hold = { el, x: e.clientX, y: e.clientY, fired: false };
  hold.timer = setTimeout(() => {
    hold.fired = true;
    suppressClick = true;
    const [kind, arg] = el.dataset.hold.split(':');
    if (kind === 'slot') openSlotSheet(+arg);
  }, 600);
});
document.addEventListener('pointermove', (e) => {
  if (hold && Math.hypot(e.clientX - hold.x, e.clientY - hold.y) > 14) { clearTimeout(hold.timer); hold = null; }
});
const endHold = () => { if (hold) { clearTimeout(hold.timer); if (!hold.fired) suppressClick = false; hold = null; } };
document.addEventListener('pointerup', endHold);
document.addEventListener('pointercancel', endHold);
document.addEventListener('contextmenu', (e) => e.preventDefault(), true); // no right-click menu from long presses
document.addEventListener('selectstart', (e) => e.preventDefault());
document.addEventListener('dragstart', (e) => e.preventDefault());

// dim button: tap = one step dimmer, hold = screen off
function wireDim() {
  const btn = $('#dimBtn');
  let timer, held = false;
  btn.addEventListener('pointerdown', () => { held = false; timer = setTimeout(() => { held = true; screenOff(); }, 650); });
  const cancel = () => clearTimeout(timer);
  btn.addEventListener('pointerup', cancel);
  btn.addEventListener('pointerleave', cancel);
  btn.addEventListener('click', (e) => { e.stopPropagation(); if (!held) cycleDim(); });
  $('#dim').addEventListener('click', () => { if (effectiveBrightness() === 0) screenOn(); });
}

// ================================================================ boot
async function boot() {
  const load = (f) => fetch(`/static/${f}`, { cache: 'no-store' }).then((r) => r.json()).catch(() => []);
  [THEMES, FACES, LOOKS] = await Promise.all([load('themes.json'), load('knob_faces.json'), load('looks.json')]);
  $('#nav').innerHTML = navHtml();
  $$('[data-icon]').forEach((el) => { el.innerHTML = ICON[el.dataset.icon]; });
  $$('[data-icon-name]').forEach((el) => { el.innerHTML = ico(el.dataset.iconName, 24); });
  wireDim();
  if (new URLSearchParams(location.search).has('cursor')) document.body.classList.add('cursor');
  connect();
  setInterval(update, 1000);
  addEventListener('resize', () => { if (S.state) applyLook(); movePill(); S.lastRect = ''; reportRect(); });
}
boot();
