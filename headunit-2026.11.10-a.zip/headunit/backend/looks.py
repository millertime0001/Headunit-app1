"""Looks: the one theme system for the whole dash.

A Look is everything about how the dash looks, in one object:
  {id, name, desc, group, colors: {base, b1, b2, b3, accent, light}, set: {settings it controls},
   knob: {colors}, vars: {css variables}, css: "free-form css"}
`set` only holds the "look" settings (LOOK_TOP, and the look parts of glass / flow / cluster).
Layouts, units, screen placement and so on are setup, not look: a Look never changes them.

Built-in Looks live in web/looks.json. Your own Looks live in ~/.config/headunit/looks/<id>.json (ids start with
"u-"). Any look setting you change while a built-in Look is on is remembered for that Look in
settings.look_edits[<id>] (so going back to it brings your tweaks back; "Reset" drops them). Changes to one of
your own Looks are written straight into its file.

The backend works out the final Look once and every screen (head unit, cluster, knob, splash) uses state.look.
"""
import json
import logging
import re
import time

log = logging.getLogger("headunit")

HEX = re.compile(r"^#[0-9a-fA-F]{6}$")
COLOR_KEYS = ("base", "b1", "b2", "b3", "accent")
KNOB_COLOR_KEYS = ("accent", "base", "text", "b1", "b2", "b3")
CSS_VAR = re.compile(r"^--[a-zA-Z0-9_-]{1,40}$")
ID = re.compile(r"^[a-z0-9-]{1,48}$")

# settings a Look controls (everything else is setup)
LOOK_TOP = ("style", "effect", "motion", "button_fx", "clock_style", "glow", "ripple_style", "knob_style",
            "splash_style", "map_style", "map_fx_amt", "rain_glass", "rain_amount", "rain_over", "transition")
LOOK_SUB = {
    "glass": ("opacity", "blur", "depth", "shine", "tint", "edge", "textshadow", "tilt"),
    "flow": ("on", "scene", "amount", "react", "pulses"),
    "cluster": ("look", "face", "needle", "ticks", "numerals", "arc", "glow", "map_style"),
}
# what a key goes back to when the new Look doesn't say (so nothing leaks over from the previous Look)
LOOK_DEFAULTS = {
    "style": "glass", "effect": "off", "motion": "lively", "button_fx": "glass", "clock_style": "thin", "glow": True,
    "ripple_style": "waves", "knob_style": "aurora", "splash_style": "warp", "map_style": "theme", "map_fx_amt": 100,
    "rain_glass": False, "rain_amount": "steady", "rain_over": True, "transition": "depth",
    "glass": {"opacity": 22, "blur": 30, "depth": 70, "shine": 70, "tint": "theme", "edge": True, "textshadow": True,
              "tilt": True},
    "flow": {"on": True, "scene": "liquid", "amount": 75, "react": True, "pulses": "on"},
    "cluster": {"look": "scene", "face": "neon", "needle": "face", "ticks": "face", "numerals": "face", "arc": "face",
                "glow": 60, "map_style": "same"},
}
FALLBACK_COLORS = {"base": "#05070B", "b1": "#14B8A6", "b2": "#7C3AED", "b3": "#0EA5E9", "accent": "#5EEAD4",
                   "light": False}


def look_part(settings):
    """Just the look settings out of a settings dict (or a design/look `set`)."""
    out = {}
    for k in LOOK_TOP:
        if k in settings:
            out[k] = settings[k]
    for k, subs in LOOK_SUB.items():
        if isinstance(settings.get(k), dict):
            part = {s: settings[k][s] for s in subs if s in settings[k]}
            if part:
                out[k] = part
    return out


def merge(a, b):
    out = json.loads(json.dumps(a or {}))
    for k, v in (b or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = merge(out[k], v)
        else:
            out[k] = v
    return out


def clean_colors(c):
    if not isinstance(c, dict):
        return {}
    out = {k: v.upper() for k, v in c.items() if k in COLOR_KEYS and isinstance(v, str) and HEX.match(v)}
    if isinstance(c.get("light"), bool):
        out["light"] = c["light"]
    return out


def slug(name):
    return re.sub(r"[^a-z0-9]+", "-", str(name).lower()).strip("-")[:40] or "look"


def clean_look(d, user=True):
    """Checks a Look (or an old Theme Studio design) and keeps only the parts the head unit understands."""
    if not isinstance(d, dict):
        raise ValueError("not a look")
    if d.get("format") == "headunit-design":   # the older Theme Studio format: same parts, settings under "settings"
        d = dict(d, set=d.get("settings") or {})
    name = str(d.get("name") or "Untitled").strip()[:60] or "Untitled"
    out = {"name": name, "colors": clean_colors(d.get("colors")),
           "set": look_part(d.get("set") if isinstance(d.get("set"), dict) else {}), "vars": {}, "css": ""}
    for key, n in (("desc", 200), ("author", 40), ("group", 30), ("from", 48), ("request", 64)):
        if isinstance(d.get(key), str) and d[key].strip():
            out[key] = d[key].strip()[:n]
    if isinstance(d.get("vars"), dict):
        for k, v in list(d["vars"].items())[:200]:
            if CSS_VAR.match(str(k)) and isinstance(v, (str, int, float)):
                v = str(v)
                if len(v) <= 400 and not re.search(r"[;{}<>]", v):
                    out["vars"][k] = v
    css = d.get("css") if isinstance(d.get("css"), str) else ""
    if len(css) > 6_000_000:
        raise ValueError("too big")
    out["css"] = re.sub(r"</\s*style", "", css, flags=re.I)
    k = d.get("knob")
    if isinstance(k, dict) and isinstance(k.get("colors"), dict):
        kc = {c: v.upper() for c, v in k["colors"].items() if c in KNOB_COLOR_KEYS and isinstance(v, str) and HEX.match(v)}
        if kc:
            out["knob"] = {"colors": kc}
    did = str(d.get("id") or "")
    if user:
        did = did if did.startswith("u-") and ID.match(did) else f"u-{slug(name)}"
    out["id"] = did
    return out


class Looks:
    """Owns the current Look. `hub` gives settings/state; `apply_settings(patch)` is the normal settings path
    (validates and applies); `check_set(set)` validates a look's settings without saving them (for previews)."""

    def __init__(self, hub, web_dir, conf_dir, apply_settings, check_set):
        self.hub = hub
        self.builtin_file = web_dir / "looks.json"
        self.palettes_file = web_dir / "themes.json"
        self.dir = conf_dir / "looks"
        self.dir.mkdir(parents=True, exist_ok=True)
        self.apply_settings = apply_settings
        self.check_set = check_set
        self.applying = False
        self.css_rev = 0
        self._css = ""
        self.preview_at = 0
        self.builtin = {}
        self.order = []
        self.mine = {}
        self.load()

    # ------------------------------------------------------------------ files
    def load(self):
        try:
            lst = json.loads(self.builtin_file.read_text())
        except Exception:
            log.exception("looks.json")
            lst = []
        self.builtin = {}
        self.order = []
        for d in lst:
            try:
                lk = clean_look(d, user=False)
            except ValueError:
                continue
            lk["id"] = str(d.get("id"))
            lk["group"] = d.get("group", "")
            self.builtin[lk["id"]] = lk
            self.order.append(lk["id"])
        self.mine = {}
        for f in sorted(self.dir.glob("u-*.json")):
            try:
                lk = clean_look(json.loads(f.read_text()))
                lk["id"] = f.stem
                lk["at"] = int(f.stat().st_mtime)
                self.mine[f.stem] = lk
            except Exception:
                log.warning("skipping unreadable look %s", f)

    def palettes(self):
        try:
            return {t["id"]: t for t in json.loads(self.palettes_file.read_text())}
        except Exception:
            return {}

    def save_mine(self, lk):
        lk = dict(lk)
        lk.pop("at", None)
        (self.dir / f"{lk['id']}.json").write_text(json.dumps(lk))
        lk["at"] = int(time.time())
        self.mine[lk["id"]] = lk

    def get(self, lid):
        return self.mine.get(lid) or self.builtin.get(lid)

    # ------------------------------------------------------------------ resolving
    def current_id(self):
        s = self.hub.settings
        lid = s.get("look")
        if lid in self.mine or lid in self.builtin:
            return lid
        return self.order[0] if self.order else None

    def effective(self, lid):
        """The Look with your tweaks on top: (look, colors, set)."""
        lk = self.get(lid) or {}
        ed = {} if lid in self.mine else ((self.hub.settings.get("look_edits") or {}).get(lid) or {})
        colors = {**FALLBACK_COLORS, **lk.get("colors", {}), **ed.get("colors", {})}
        return lk, colors, merge(lk.get("set") or {}, ed.get("set") or {})

    def resolve(self):
        """Puts the finished Look in state.look (what every screen draws with)."""
        lid = self.current_id()
        lk, colors, _ = self.effective(lid)
        css = lk.get("css") or ""
        if css != self._css:
            self._css = css
            self.css_rev += 1
        ed = (self.hub.settings.get("look_edits") or {}).get(lid) or {}
        self.hub.state["look"] = {
            "id": lid, "name": lk.get("name", ""), "desc": lk.get("desc", ""), "colors": colors,
            "vars": lk.get("vars") or {}, "css_rev": self.css_rev if css else 0,
            "knob": lk.get("knob"), "mine": lid in self.mine, "edited": bool(ed.get("set") or ed.get("colors")),
            "from": lk.get("from"),
        }
        self.hub.state["my_looks"] = [self.summary(x) for x in sorted(self.mine.values(), key=lambda x: -x.get("at", 0))]

    def css(self):
        return self._css

    @staticmethod
    def summary(lk):
        st = lk.get("set") or {}
        return {"id": lk["id"], "name": lk.get("name", ""), "desc": lk.get("desc", ""), "colors": lk.get("colors") or {},
                "scene": (st.get("flow") or {}).get("scene") if (st.get("flow") or {}).get("on", True) else None,
                "style": st.get("style"), "author": lk.get("author"), "img": "url(" in (lk.get("css") or "")}

    def full_settings(self, lid):
        """The look settings a switch to this Look writes: its own, with defaults for whatever it leaves out."""
        _, _, st = self.effective(lid)
        out = {}
        for k in LOOK_TOP:
            out[k] = st.get(k, LOOK_DEFAULTS[k])
        for k in LOOK_SUB:
            out[k] = merge(LOOK_DEFAULTS[k], st.get(k) or {})
        return out

    # ------------------------------------------------------------------ actions
    async def use(self, lid):
        if not self.get(lid):
            raise KeyError(lid)
        self.hub.settings["look"] = lid
        self.resolve()   # colors first: the settings change below rewrites the splash and the knob with them
        await self.write(self.full_settings(lid))
        self.resolve()
        self.hub.save()
        self.hub.changed()

    async def write(self, patch):
        self.applying = True
        try:
            await self.apply_settings(patch)
        finally:
            self.applying = False

    def snapshot(self):
        return json.loads(json.dumps(look_part(self.hub.settings)))

    def record(self, before):
        """After any settings change: look settings that changed are kept with the current Look."""
        if self.applying:
            return
        after = look_part(self.hub.settings)
        diff = {}
        for k, v in after.items():
            if isinstance(v, dict):
                sub = {s: x for s, x in v.items() if (before.get(k) or {}).get(s) != x}
                if sub:
                    diff[k] = sub
            elif before.get(k) != v:
                diff[k] = v
        if not diff:
            return
        lid = self.current_id()
        if lid in self.mine:
            lk = self.mine[lid]
            lk["set"] = merge(lk.get("set") or {}, diff)
            self.save_mine(lk)
        else:
            eds = self.hub.settings.setdefault("look_edits", {})
            ed = eds.setdefault(lid, {})
            ed["set"] = merge(ed.get("set") or {}, diff)
        self.resolve()

    def set_colors(self, colors):
        """Your colors for the current Look (a dict of slots, or None = back to its own)."""
        lid = self.current_id()
        c = clean_colors(colors) if colors else {}
        if lid in self.mine:
            lk = self.mine[lid]
            if colors is None and lk.get("orig_colors"):
                lk["colors"] = lk["orig_colors"]
            else:
                lk.setdefault("orig_colors", dict(lk.get("colors") or {}))
                lk["colors"] = dict(lk.get("colors") or {}, **c)
            self.save_mine(lk)
        else:
            eds = self.hub.settings.setdefault("look_edits", {})
            ed = eds.setdefault(lid, {})
            if colors is None:
                ed.pop("colors", None)
            else:
                ed["colors"] = dict(ed.get("colors") or {}, **c)
            if not ed:
                eds.pop(lid, None)
        self.resolve()
        self.hub.save()
        self.hub.changed()

    async def reset(self):
        """Drops your tweaks to a built-in Look."""
        lid = self.current_id()
        (self.hub.settings.get("look_edits") or {}).pop(lid, None)
        if lid in self.mine and self.mine[lid].get("orig_colors"):
            self.mine[lid]["colors"] = self.mine[lid].pop("orig_colors")
            self.save_mine(self.mine[lid])
        await self.use(lid)

    async def save_as(self, name):
        """Copies the current Look, with your tweaks, into a new Look of your own and switches to it."""
        lid = self.current_id()
        lk, colors, st = self.effective(lid)
        name = str(name or "").strip()[:60] or f"My {lk.get('name', 'look')}"
        new = dict(lk, name=name, colors=colors, set=st, author="You")
        new.pop("orig_colors", None)
        new["from"] = lk.get("from") or lid
        nid = f"u-{slug(name)}"
        n = 2
        while nid in self.mine and nid != lid:
            nid = f"u-{slug(name)}-{n}"
            n += 1
        new["id"] = nid
        self.save_mine(new)
        if lid in self.builtin:
            (self.hub.settings.get("look_edits") or {}).pop(lid, None)
        await self.use(nid)
        return nid

    async def add(self, d, use=True):
        """A Look sent from the Theme Studio (or an old design file): saved as one of yours."""
        lk = clean_look(d)
        lk["author"] = lk.get("author") or "You"
        self.save_mine(lk)
        self.hub.state["look_preview"] = None
        if use:
            await self.use(lk["id"])
        else:
            self.resolve()
            self.hub.changed()
        return lk

    async def delete(self, lid):
        if lid in self.mine:
            (self.dir / f"{lid}.json").unlink(missing_ok=True)
            self.mine.pop(lid)
        if self.hub.settings.get("look") == lid:
            await self.use(self.mine_or_first())
        else:
            self.resolve()
            self.hub.changed()

    def mine_or_first(self):
        return next(iter(self.mine), None) or (self.order[0] if self.order else None)

    async def rename(self, lid, name):
        if lid in self.mine and str(name).strip():
            self.mine[lid]["name"] = str(name).strip()[:60]
            self.save_mine(self.mine[lid])
            self.resolve()
            self.hub.changed()

    def preview(self, d):
        """Shows a Look being edited on every screen without saving it (cleared after 150 s without updates)."""
        if not d:
            self.hub.state["look_preview"] = None
            self.hub.changed()
            return
        base = self.get(d.get("id")) if isinstance(d.get("id"), str) and not d.get("set") else None
        lk = clean_look(base or d, user=False)
        st = self.check_set(merge(self.full_settings(self.current_id()), lk["set"]))
        self.hub.state["look_preview"] = {
            "id": "preview", "name": lk["name"], "colors": {**FALLBACK_COLORS, **lk["colors"]},
            "vars": lk["vars"], "css": lk["css"], "knob": lk.get("knob"), "set": st}
        self.preview_at = time.time()
        self.hub.changed()

    def tick(self):
        if self.hub.state.get("look_preview") and time.time() - self.preview_at > 150:
            self.hub.state["look_preview"] = None
            self.hub.changed()

    def listing(self):
        """Everything the Look screens and the Theme Studio need."""
        return {"builtin": [self.builtin[i] for i in self.order], "mine": sorted(self.mine.values(), key=lambda x: -x.get("at", 0)),
                "current": self.current_id(), "edits": self.hub.settings.get("look_edits") or {},
                "look": self.hub.state.get("look")}

    # ------------------------------------------------------------------ moving over from the old theme system
    def migrate(self, design_dir, design_active_file):
        """Once: old designs become your Looks, and what's on screen now is kept as a Look so nothing changes."""
        s = self.hub.settings
        if s.get("look"):
            return False
        pal = self.palettes()
        lc = s.get("look_colors") or {}
        ids = {}
        for f in sorted(design_dir.glob("*.json")) if design_dir.exists() else []:
            try:
                d = json.loads(f.read_text())
                d = dict(d, id=f"u-{f.stem}")
                d.setdefault("set", d.get("settings") or {})
                base = pal.get((d.get("settings") or {}).get("theme")) or {}
                d["colors"] = {**{k: base[k] for k in COLOR_KEYS if k in base}, **(d.get("colors") or {}),
                               **(lc.get(f"d:{f.stem}") or {})}
                lk = clean_look(d)
                lk["author"] = lk.get("author") or "You"
                self.save_mine(lk)
                ids[f.stem] = lk["id"]
            except Exception:
                log.exception("moving design %s", f)
        try:
            active = design_active_file.read_text().strip()
        except OSError:
            active = ""
        if active in ids:
            s["look"] = ids[active]
        else:
            t = pal.get(s.get("theme")) or {}
            colors = {**{k: t[k] for k in COLOR_KEYS if k in t}, **(lc.get(f"t:{s.get('theme')}") or {})}
            if "light" in t:
                colors["light"] = bool(t["light"])
            lk = clean_look({"id": "u-my-look", "name": "My look", "desc": "What your dash looked like before the new Looks",
                             "colors": colors, "set": look_part(s)})
            lk["author"] = "You"
            self.save_mine(lk)
            s["look"] = lk["id"]
        sc = s.get("look_schedule") or {}
        for r in sc.get("rules") or []:
            kind, _, val = str(r.get("look") or "").partition(":")
            r["look"] = ids.get(val) if kind == "design" else (val if kind != "theme" and val else None)
        for k in ("look_colors", "dash_theme", "weather_look_prev"):
            s.pop(k, None)
        s.setdefault("look_edits", {})
        log.info("looks: moved %d designs over, now on %s", len(ids), s["look"])
        return True
