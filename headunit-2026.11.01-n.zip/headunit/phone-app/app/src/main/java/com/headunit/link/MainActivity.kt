package com.headunit.link

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/**
 * One screen: shows the connection and lets you grant anything the Pi couldn't grant itself.
 * When the phone is plugged into the Pi, the Pi installs this app and grants everything over USB.
 */
class MainActivity : Activity() {
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var status: TextView
    private lateinit var weather: TextView
    private lateinit var checks: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        fun text(size: Float, bold: Boolean = false) = TextView(this).apply {
            textSize = size
            if (bold) typeface = Typeface.DEFAULT_BOLD
            setPadding(0, pad / 3, 0, pad / 3)
        }
        fun button(label: String, action: () -> Unit) = Button(this).apply {
            text = label
            isAllCaps = false
            setOnClickListener { action() }
        }
        col.addView(text(26f, true).apply { text = "Head Unit Link" })
        col.addView(button("Theme Studio: design the screen, knob and startup") {
            startActivity(Intent(this, StudioActivity::class.java))
        })
        status = text(18f).also { col.addView(it) }
        weather = text(15f).also { col.addView(it) }
        checks = text(15f).apply { setTextColor(Color.GRAY) }.also { col.addView(it) }
        col.addView(text(14f).apply {
            text = "If the phone has been plugged into the Pi, everything below is already done."
        })
        col.addView(button("Allow location, contacts and notifications") { askBasic() })
        col.addView(button("Allow location all the time (weather)") { askBackground() })
        col.addView(button("Allow notification access (turns and album art)") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })
        col.addView(button("Keep running in the background") { askBattery() })
        col.addView(button("Send an update to the head unit") { pickUpdate() })
        col.addView(button("Start") { startForegroundService(Intent(this, LinkService::class.java)) })
        col.addView(button("Stop") {
            getSharedPreferences("link", MODE_PRIVATE).edit().putBoolean("enabled", false).apply()
            stopService(Intent(this, LinkService::class.java))
        })
        setContentView(ScrollView(this).apply { addView(col) })
        col.gravity = Gravity.START
        startForegroundService(Intent(this, LinkService::class.java))
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onPause() {
        ui.removeCallbacksAndMessages(null)
        super.onPause()
    }

    private fun refresh() {
        status.text = Bus.status.value
        weather.text = Bus.weather.value
        val mark = { ok: Boolean -> if (ok) "✓" else "✗" }
        val loc = granted(Manifest.permission.ACCESS_FINE_LOCATION)
        val bg = granted(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
        val contacts = granted(Manifest.permission.READ_CONTACTS)
        val listener = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
            ?.contains(packageName) == true
        val battery = getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName)
        checks.text = "${mark(loc)} Location   ${mark(bg)} All the time   ${mark(contacts)} Contacts\n" +
            "${mark(listener)} Notification access   ${mark(battery)} Background"
        ui.postDelayed({ refresh() }, 1000)
    }

    private fun pickUpdate() {
        val pick = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/zip", "application/x-zip-compressed",
                "application/vnd.android.package-archive", "application/octet-stream"))
        }
        startActivityForResult(pick, PICK_UPDATE)
    }

    @Deprecated("Activity result API kept simple on purpose")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (requestCode != PICK_UPDATE || resultCode != RESULT_OK || uri == null) return
        Toast.makeText(this, "Sending the update…", Toast.LENGTH_SHORT).show()
        Thread {
            val msg = try { Updater.send(this, uri) } catch (e: Exception) { "Update failed: ${e.message}" }
            ui.post { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }
        }.start()
    }

    companion object { private const val PICK_UPDATE = 7 }

    private fun granted(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun askBasic() {
        val perms = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.READ_CONTACTS,
        )
        if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
        requestPermissions(perms.toTypedArray(), 1)
    }

    private fun askBackground() {
        requestPermissions(arrayOf(Manifest.permission.ACCESS_BACKGROUND_LOCATION), 2)
    }

    private fun askBattery() {
        startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
    }
}
