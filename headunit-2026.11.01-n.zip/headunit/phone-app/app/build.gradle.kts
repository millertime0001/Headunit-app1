plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.headunit.link"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.headunit.link"
        minSdk = 29
        targetSdk = 35
        versionCode = 9
        versionName = "7.0"
    }
    // One fixed key for every build, so a new version installs over the old one.
    signingConfigs {
        create("hu") {
            storeFile = file("headunit.keystore")
            storePassword = "headunit"
            keyAlias = "headunit"
            keyPassword = "headunit"
        }
    }
    buildTypes {
        debug { signingConfig = signingConfigs.getByName("hu") }
        release { isMinifyEnabled = false; signingConfig = signingConfigs.getByName("hu") }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
}
