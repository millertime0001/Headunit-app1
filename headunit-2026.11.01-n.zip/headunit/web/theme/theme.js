// Theme Studio: design how the head unit, the knob and the startup animation look, from a photo, from a
// few words, from the gallery (including designs Claude made) or by hand. Changes show on the car screen and
// knob live while you edit. Runs inside the Head Unit Link phone app (window.HUApp bridge) or in any browser
// that can reach the head unit (http://10.42.0.1:8080/theme).
'use strict';
const $ = (q, el = document) => el.querySelector(q);
const $$ = (q, el = document) => [...el.querySelectorAll(q)];
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const APP = window.HUApp || null;
const frame = $('#frame'), splashFrame = $('#splashFrame'), panel = $('#panel');

let THEMES = [], FACES = [], GALLERY = [], CAR = { designs: [], active: null, settings: null, schedule_now: null }, H = null;
let lib = [], cur = 0, tab = localStorage.getItem('ts-tab') || 'create', screen = 'home', ready = false;
let live = localStorage.getItem('ts-live') !== '0', carOk = null;
let hist = [], fut = [], dirty = false, gseg = 'claude', reqs = [], part = 'both';
let photo = null, results = [], resultsFrom = '';

// ================================================================ talking to the head unit
let reqId = 0;
const pend = {};
window.huReply = (id, status, text) => { const p = pend[id]; if (!p) return; delete pend[id]; p({ status, ok: status >= 200 && status < 300, text }); };
function api(method, path, body) {
  const data = body == null ? null : JSON.stringify(body);
  if (APP && APP.request) {
    return new Promise((res) => {
      const id = ++reqId;
      pend[id] = res;
      APP.request(id, method, path, data || '');
      setTimeout(() => { if (pend[id]) { delete pend[id]; res({ status: 0, ok: false, text: '' }); } }, 25000);
    });
  }
  return fetch(path, { method, headers: data ? { 'Content-Type': 'application/json' } : {}, body: data || undefined })
    .then(async (r) => ({ status: r.status, ok: r.ok, text: await r.text() }))
    .catch(() => ({ status: 0, ok: false, text: '' }));
}
async function apiJson(method, path, body) {
  const r = await api(method, path, body);
  try { r.json = JSON.parse(r.text); } catch (e) { r.json = null; }
  return r;
}
const NO_CAR = 'Can’t reach the head unit. Join the “Pi Head Unit” Wi-Fi or plug into the Pi.';

// ================================================================ colors
const hexRgb = (h) => { const n = parseInt(String(h || '#000000').slice(1), 16); return [n >> 16, (n >> 8) & 255, n & 255]; };
const rgbHex = (r, g, b) => '#' + [r, g, b].map((v) => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, '0')).join('').toUpperCase();
function rgbHsl(r, g, b) {
  r /= 255; g /= 255; b /= 255;
  const mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2;
  if (mx === mn) return [0, 0, l * 100];
  const d = mx - mn, s = l > 0.5 ? d / (2 - mx - mn) : d / (mx + mn);
  const h = mx === r ? (g - b) / d + (g < b ? 6 : 0) : mx === g ? (b - r) / d + 2 : (r - g) / d + 4;
  return [h * 60, s * 100, l * 100];
}
function hsl(h, s, l) {
  h = ((h % 360) + 360) % 360; s = Math.max(0, Math.min(100, s)) / 100; l = Math.max(0, Math.min(100, l)) / 100;
  const k = (n) => (n + h / 30) % 12, a = s * Math.min(l, 1 - l);
  const f = (n) => l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1)));
  return rgbHex(f(0) * 255, f(8) * 255, f(4) * 255);
}
const hexHsl = (h) => rgbHsl(...hexRgb(h));
const lum = (h) => { const [r, g, b] = hexRgb(h).map((v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4; }); return 0.2126 * r + 0.7152 * g + 0.0722 * b; };
const hueDist = (a, b) => { const d = Math.abs(a - b) % 360; return d > 180 ? 360 - d : d; };

// ================================================================ designs
const FONTS = [['', 'Style default'], ['system-ui, sans-serif', 'System'], ['"DejaVu Sans", sans-serif', 'DejaVu Sans'],
  ['"DejaVu Sans Condensed", sans-serif', 'Condensed'], ['"DejaVu Serif", serif', 'Serif'], ['"DejaVu Sans Mono", monospace', 'Monospace'],
  ['StudioFont', 'My uploaded font']];
const SPLASHES = [['warp', 'Warp ring', 'Light streaks pull into a glowing ring'], ['hyper', 'Hyperspace', 'Neon rings fly out of a tunnel'],
  ['plasma', 'Plasma', 'Color clouds swirl around the ring'], ['ignition', 'Ignition', 'Tach needle sweeps to redline and back'],
  ['chrome', 'Chrome', 'Metal ring with a light sweep'], ['dawn', 'Dawn', 'A sun rises over the horizon']];
const SCREENS = [['home', 'Home'], ['music', 'Music'], ['gauges', 'Gauges'], ['phone', 'Phone'], ['audio', 'Sound'], ['startup', 'Startup']];

function blank(name) {
  return { format: 'headunit-design', version: 2, name: name || 'My design',
    settings: { style: 'glass', theme: 'aurora', effect: 'blobs', button_fx: 'glass', ripple_style: 'waves', clock_style: 'thin', knob_style: 'aurora', splash_style: 'warp' },
    colors: null, studio: {}, customCss: '' };
}
const D = () => lib[cur];
const themeById = (id) => THEMES.find((t) => t.id === id) || THEMES[0] || { id: 'aurora', base: '#05070B', b1: '#14B8A6', b2: '#7C3AED', b3: '#0EA5E9', accent: '#5EEAD4' };
function colorsOf(d) {
  const t = themeById((d.settings || {}).theme);
  const c = Object.assign({ base: t.base, b1: t.b1, b2: t.b2, b3: t.b3, accent: t.accent, light: !!t.light }, d.colors || {});
  c.text = (d.studio && d.studio.textColor) || (c.light ? '#0B1220' : '#F5F7FA');
  return c;
}
function knobColorsOf(d) {
  const c = colorsOf(d);
  return Object.assign({ accent: c.accent, base: c.base, text: c.light ? '#0B1220' : '#F5F7FA', b1: c.b1, b2: c.b2, b3: c.b3 }, (d.knob && d.knob.colors) || {});
}
function setting(k, d = D()) {
  const s = d.settings || {};
  if (s[k] !== undefined) return s[k];
  const car = CAR.settings || {};
  return car[k];
}
const glassOf = (d = D()) => Object.assign({ opacity: 22, blur: 30, depth: 70, shine: 70, tint: 'theme', edge: true, textshadow: true, tilt: true }, (CAR.settings || {}).glass || {}, (d.settings || {}).glass || {});

// The file that goes to the car (and to the live preview)
function compile(d) {
  const st = d.studio || {}, css = [], vars = Object.assign({}, d.vars || {});
  if (st.radius != null) { vars['--r-xl'] = `${st.radius}rem`; vars['--r-lg'] = `${(st.radius * 0.8).toFixed(2)}rem`; vars['--r-md'] = `${(st.radius * 0.55).toFixed(2)}rem`; }
  if (st.fontData) css.push(`@font-face{font-family:StudioFont;src:url(${st.fontData})}`);
  if (st.font) css.push(`body,button,input{font-family:${st.font} !important}`);
  if (st.weight) css.push(`:is(h1,h2,.clock,.big-num,.nav-speed b,.label){font-weight:${st.weight} !important}`);
  if (st.border) css.push(`.glass{outline:${st.border}px solid ${st.borderColor || '#ffffff'};outline-offset:-${st.border}px}`);
  if (st.glow) css.push(`.glass{box-shadow:0 0 ${st.glow}px -${Math.round(st.glow / 3)}px var(--accent),0 1rem 2rem -1rem rgb(0 0 0/.6) !important}`);
  if (st.wall) {
    const dim = (st.wallDim ?? 35) / 100;
    css.push(`.bg{background:linear-gradient(rgb(0 0 0/${dim}),rgb(0 0 0/${dim})),url(${st.wall}) center/cover no-repeat !important}`,
      '.bg .blob,.bg #fx{display:none !important}');
  }
  if (st.textColor) css.push(`:root{--text:${st.textColor} !important}`);
  const out = { format: 'headunit-design', version: 2, name: d.name, settings: d.settings, colors: d.colors,
    vars, css: css.join('\n') + (d.customCss ? `\n/* custom */\n${d.customCss}` : ''), studio: d.studio, customCss: d.customCss };
  if (d.knob && d.knob.colors) out.knob = { colors: d.knob.colors };
  if (d.author) out.author = d.author;
  if (d.desc) out.desc = d.desc;
  return out;
}
// A design file (from the car, the gallery or a share) back into an editable design
function fromFile(f) {
  const d = Object.assign(blank(f.name), JSON.parse(JSON.stringify(f)));
  d.settings = Object.assign({}, f.settings || {});
  d.studio = Object.assign({}, f.studio || {});
  d.customCss = f.customCss || '';
  delete d.css; delete d.vars; delete d.id; delete d.at;
  return d;
}

// ================================================================ library (kept on the phone)
function loadLib() {
  try { lib = JSON.parse((APP ? APP.loadLib() : localStorage.getItem('hu-designs')) || '[]'); } catch (e) { lib = []; }
  if (!Array.isArray(lib) || !lib.length) lib = [blank('My first design')];
  cur = Math.max(0, Math.min(+(localStorage.getItem('hu-cur') || 0), lib.length - 1));
}
let saveT;
function saveLib() {
  clearTimeout(saveT);
  saveT = setTimeout(() => {
    const t = JSON.stringify(lib);
    try { if (APP) APP.saveLib(t); else localStorage.setItem('hu-designs', t); localStorage.setItem('hu-cur', cur); }
    catch (e) { toast('Couldn’t save on the phone. A wallpaper or font may be too big.'); }
  }, 300);
}

// ================================================================ editing, undo, preview
function snapshot() { hist.push(JSON.stringify(D())); if (hist.length > 60) hist.shift(); fut = []; }
let dragging = false;
function edit(fn, opts = {}) {
  if (opts.hist !== false && !(opts.drag && dragging)) snapshot();
  if (opts.drag) dragging = true;
  fn(D());
  markDirty();
  saveLib();
  preview();
  if (opts.render) render();
  undoState();
}
function markDirty(v = true) { dirty = v; $('#saveBtn').classList.toggle('dirty', dirty); }
function undo() { if (!hist.length) return; fut.push(JSON.stringify(D())); lib[cur] = JSON.parse(hist.pop()); after(); }
function redo() { if (!fut.length) return; hist.push(JSON.stringify(D())); lib[cur] = JSON.parse(fut.pop()); after(); }
function after() { markDirty(); saveLib(); preview(); render(); undoState(); }
function undoState() { $('#undoBtn').disabled = !hist.length; $('#redoBtn').disabled = !fut.length; }
function openDesign(i) { cur = i; hist = []; fut = []; markDirty(false); saveLib(); preview(); render(); undoState(); }

let pT, lT, beat;
function preview() {
  clearTimeout(pT);
  pT = setTimeout(() => {
    if (ready) frame.contentWindow.postMessage({ type: 'design', design: compile(D()) }, '*');
    drawKnobPv();
    if (screen === 'startup') showSplash();
    $('#dname').value = D().name;
  }, 60);
  if (live) {
    clearTimeout(lT);
    lT = setTimeout(sendLive, 320);
  }
}
async function sendLive() {
  if (!live || document.hidden) return;
  const r = await api('POST', '/design/preview', compile(D()));
  setCarOk(r.ok);
  clearInterval(beat);
  beat = setInterval(() => { if (live && !document.hidden) api('POST', '/design/preview', compile(D())).then((x) => setCarOk(x.ok)); }, 60000);
}
function stopLive() { clearInterval(beat); api('POST', '/design/preview', {}); }
function setCarOk(ok) {
  carOk = ok;
  const b = $('#liveBtn');
  b.classList.toggle('off-car', !ok);
  b.querySelector('span').textContent = !live ? 'Live off' : ok ? 'Live' : 'No car';
}
function setLive(v) {
  live = v; localStorage.setItem('ts-live', v ? '1' : '0');
  $('#liveBtn').setAttribute('aria-pressed', String(v));
  if (v) { sendLive(); toast('Changes show on the car as you make them'); } else { stopLive(); toast('Car shows its saved look again'); }
  setCarOk(carOk !== false);
}
document.addEventListener('visibilitychange', () => {
  if (document.hidden) { if (live) stopLive(); } else if (live) { sendLive(); refreshCar(); }
});

// ================================================================ the preview frame
function fit() {
  const w = $('#bezel').clientWidth;
  for (const f of [frame, splashFrame]) f.style.transform = `scale(${w / 1024})`;
}
new ResizeObserver(fit).observe($('#bezel'));
addEventListener('message', (e) => {
  if (!e.data || e.data.type !== 'preview-ready' || e.source !== frame.contentWindow) return;
  ready = true;
  const w = frame.contentWindow;
  const get = (n) => { try { return w.eval(n); } catch (er) { return null; } };
  H = { styles: get('STYLES') || [], effects: get('EFFECTS') || [], layouts: get('LAYOUTS') || {}, buttons: get('BUTTONS') || [],
    clocks: get('CLOCKS') || [], ripples: get('RIPPLES') || [], speedos: get('SPEEDOS') || [] };
  const f = get('FACES');
  if (f && f.length) FACES = f;
  if (!lib.length) return;  // still starting: start() draws everything once the library is loaded
  preview(); render();
  setTimeout(() => goScreen(screen), 150);
});
function goScreen(s) {
  screen = s;
  $$('#screens .chip').forEach((c) => c.classList.toggle('on', c.dataset.screen === s));
  const sp = s === 'startup';
  splashFrame.classList.toggle('hidden', !sp);
  frame.classList.toggle('hidden', sp);
  if (sp) showSplash();
  else { splashFrame.removeAttribute('src'); if (ready) frame.contentWindow.postMessage({ type: 'go', screen: s }, '*'); }
}
let spN = 0, spKey = '';
function showSplash() {
  const c = colorsOf(D());
  const data = { base: c.base, b1: c.b1, b2: c.b2, b3: c.b3, accent: c.accent, style: setting('splash_style') || 'warp', name: setting('splash_text') || 'Pi Head Unit' };
  const key = JSON.stringify(data);
  if (key === spKey && splashFrame.getAttribute('src')) return;
  spKey = key;
  splashFrame.src = `/static/splash.html?preview&v=${++spN}#${encodeURIComponent(key)}`;
}
function renderScreens() {
  $('#screens').innerHTML = SCREENS.map(([id, n]) => `<button class="chip ${screen === id ? 'on' : ''}" data-screen="${id}">${n}</button>`).join('');
}
$('#screens').addEventListener('click', (e) => { const b = e.target.closest('[data-screen]'); if (b) goScreen(b.dataset.screen); });

// ================================================================ knob drawings (the screen code's own knob artwork)
let kuid = 0;
function knobSvg(faceId, d = D()) {
  if (!ready) return '';
  try {
    const w = frame.contentWindow, S = w.eval('S');
    const face = FACES.find((f) => f.id === faceId) || FACES[0];
    if (!face) return '';
    const kc = knobColorsOf(d), saved = S.theme;
    S.theme = { accent: kc.accent, base: kc.base, b1: kc.b1, b2: kc.b2, b3: kc.b3, light: kc.text === '#0B1220' };
    const svg = w.knobSVG(face, `ts${++kuid}`);
    S.theme = saved;
    return svg;
  } catch (e) { return ''; }
}
function drawKnobPv() {
  if (!lib.length) return;
  $('#knobPv').innerHTML = knobSvg(setting('knob_style') || 'aurora');
  const big = $('#knobBig');
  if (big) { big.innerHTML = knobSvg(setting('knob_style') || 'aurora'); big.style.setProperty('--kglow', knobColorsOf(D()).accent + '66'); }
}
$('#knobPv').addEventListener('click', () => {
  if (ready) frame.contentWindow.postMessage({ type: 'knob', act: 'turn', vol: 30 + Math.random() * 50 }, '*');
  if (tab !== 'knob') setTab('knob');
});

// ================================================================ the mini head unit drawn on gallery cards
function mini(d, extra = '') {
  const c = colorsOf(d), k = knobColorsOf(d), st = d.studio || {};
  const g = glassOf(d), a = Math.max(0.06, Math.min(0.5, (g.opacity || 22) / 100));
  const glass = c.light ? `rgb(255 255 255 / ${a + 0.25})` : `rgb(255 255 255 / ${a * 0.55})`;
  const r = st.radius != null ? `${Math.max(1, st.radius * 7)}px` : '7px';
  const wall = st.wall ? ` wall" style="--wall:url('${st.wall}');` : '" style="';
  return `<div class="mini${wall}--base:${c.base};--b1:${c.b1};--b2:${c.b2};--b3:${c.b3};--acc:${c.accent};--txt:${c.text};--glass:${glass};--mr:${r};--kbase:${k.base};--kacc:${k.accent}">
    <i class="nv"></i><i class="t t1"></i><i class="t t2"></i><i class="t t3"></i><i class="kn"></i>${extra}</div>`;
}
function dcard(d, act, opts = {}) {
  const s = d.settings || {};
  const sty = (H && H.styles.find((x) => x[0] === s.style)) || null, eff = (H && H.effects.find((x) => x[0] === s.effect)) || null;
  const sub = opts.sub || [sty && sty[1], eff && eff[1]].filter(Boolean).join(' · ') || 'Custom';
  const badge = opts.badge ? `<span class="badge ${opts.badgeCls || ''}">${esc(opts.badge)}</span>` : '';
  const liveB = opts.live ? '<span class="badge live">On car</span>' : '';
  return `<button class="dcard ${opts.on ? 'on' : ''}" data-act="${act}">${badge}${liveB}${mini(d)}<div class="meta"><b>${esc(d.name)}</b><span>${esc(sub)}</span></div></button>`;
}

// ================================================================ "Describe it": words into a design
const COLOR_WORDS = { red: 0, crimson: 350, scarlet: 5, ruby: 350, orange: 25, copper: 22, bronze: 30, amber: 40, gold: 45, golden: 45, yellow: 55,
  lime: 85, green: 130, emerald: 150, mint: 160, jade: 155, teal: 175, aqua: 185, cyan: 188, turquoise: 178, sky: 200, blue: 220, cobalt: 215,
  navy: 225, indigo: 245, violet: 265, purple: 275, lavender: 265, magenta: 305, fuchsia: 310, pink: 330, rose: 345, coral: 12, peach: 22 };
const MOODS = [
  [/neon|cyber|vegas|arcade/, { hues: [315, 190], sat: 96, style: 'synth', effect: 'lasers', button: 'neon', ripple: 'shock', knob: 'neon', splash: 'hyper', clock: 'glow' }],
  [/tokyo|city|night ?life|downtown|skyline|metro/, { hues: [320, 200], sat: 90, effect: 'skyline', style: 'glass', knob: 'nightdrive', splash: 'hyper', clock: 'glow' }],
  [/synth|retro|80s|outrun|vapor/, { hues: [300, 190, 30], sat: 95, style: 'synth', effect: 'grid', button: 'neon', knob: 'neon', splash: 'hyper', clock: 'glow' }],
  [/sunset|dusk|evening|golden hour/, { hues: [18, 330, 45], sat: 88, effect: 'waves', style: 'glass', splash: 'dawn', knob: 'bloom' }],
  [/sunrise|dawn|morning/, { hues: [35, 200, 340], sat: 75, effect: 'aurora', splash: 'dawn', knob: 'sunburst' }],
  [/ocean|sea|beach|wave|surf|tropic|island|lagoon/, { hues: [190, 170, 210], sat: 80, style: 'sea', effect: 'underwater', ripple: 'liquid', knob: 'liquid', splash: 'plasma' }],
  [/forest|wood|cabin|pine|moss|jungle|nature/, { hues: [130, 95, 45], sat: 55, style: 'soft', effect: 'fireflies', knob: 'halo', splash: 'dawn' }],
  [/fire|lava|ember|flame|inferno|volcan|hell/, { hues: [12, 35, 350], sat: 95, effect: 'embers', style: 'carbon', knob: 'pulse', splash: 'ignition', ripple: 'sparks' }],
  [/ice|arctic|frost|frozen|glacier|winter|snow/, { hues: [195, 210, 180], sat: 45, effect: 'snow', style: 'glass', knob: 'ice', splash: 'chrome', glass: { opacity: 30, blur: 40 } }],
  [/space|galaxy|cosmic|star|nebula|astro|universe/, { hues: [265, 210, 310], sat: 80, effect: 'galaxy', style: 'holo', knob: 'starfield', splash: 'warp' }],
  [/rally|subaru|wrc|wrx|sti|race|racing|track|motorsport/, { hues: [222, 48], sat: 90, style: 'rally', effect: 'road', knob: 'rally', splash: 'ignition', button: 'chrome', clock: 'bold', speedo: 'sport' }],
  [/carbon|stealth|murdered|black ?out|dark ?mode|blackout/, { hues: [210], sat: 8, style: 'carbon', effect: 'hex', knob: 'carbonfibre', splash: 'ignition', button: 'chrome', mono: true }],
  [/matrix|hacker|terminal|code/, { hues: [130], sat: 90, effect: 'matrix', style: 'hud', knob: 'dotmatrix', splash: 'warp', font: '"DejaVu Sans Mono", monospace', mono: true }],
  [/rain|storm|thunder|wet|drizzle/, { hues: [215, 200, 260], sat: 45, style: 'rainy', effect: 'window', knob: 'rainy', ripple: 'rain', splash: 'plasma' }],
  [/lux|luxury|gold|royal|elegant|premium|classy/, { hues: [42, 30], sat: 70, style: 'lux', effect: 'bokeh', knob: 'classic', splash: 'chrome', button: 'chrome', clock: 'thin' }],
  [/cherry|sakura|blossom|spring|flower|petal/, { hues: [335, 350, 120], sat: 70, effect: 'petals', style: 'soft', knob: 'bloom', splash: 'dawn' }],
  [/minimal|clean|simple|calm|zen/, { hues: [210], sat: 25, style: 'minimal', effect: 'off', knob: 'minimal', splash: 'chrome', motion: 'calm' }],
  [/paper|daylight|bright|light mode|white/, { hues: [215], sat: 40, style: 'paper', effect: 'off', light: true, knob: 'minimal', splash: 'dawn' }],
  [/chrome|metal|steel|silver|titanium/, { hues: [210, 200], sat: 12, style: 'lux', effect: 'liquid', knob: 'chrono', splash: 'chrome', button: 'chrome' }],
  [/toxic|slime|radioactive|acid/, { hues: [95, 280], sat: 95, style: 'slime', effect: 'slime', knob: 'liquid', splash: 'plasma' }],
  [/aurora|northern lights|borealis/, { hues: [160, 280, 200], sat: 80, effect: 'aurora', style: 'glass', knob: 'auroraclock', splash: 'warp' }],
  [/desert|sand|canyon|dune|western|cowboy/, { hues: [28, 15, 200], sat: 60, effect: 'blobs', style: 'soft', knob: 'amber', splash: 'dawn' }],
  [/hud|fighter|jet|military|cockpit|tactical/, { hues: [150, 45], sat: 70, style: 'hud', effect: 'radar', knob: 'hud', splash: 'ignition', mono: true }],
  [/halloween|spooky|ghost|horror/, { hues: [28, 275], sat: 90, effect: 'smoke', style: 'carbon', knob: 'pulse', splash: 'plasma' }],
  [/christmas|holiday|festive/, { hues: [355, 140, 45], sat: 80, effect: 'snow', style: 'soft', knob: 'halo', splash: 'warp' }],
  [/party|rave|club|disco|edm/, { hues: [290, 180, 50], sat: 98, effect: 'lasers', style: 'pop', button: 'pulse', ripple: 'bars', knob: 'equalizer', splash: 'hyper' }],
];
const EFFECT_POOL = { dark: ['blobs', 'liquid', 'aurora', 'nebula', 'particles', 'bokeh', 'waves', 'smoke', 'plasma'], calm: ['blobs', 'aurora', 'smoke', 'waves'] };
const titleCase = (s) => s.replace(/\s+/g, ' ').trim().split(' ').slice(0, 4).map((w) => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
function closestTheme(c) {
  const [ah] = hexHsl(c.accent), [bh] = hexHsl(c.b1);
  let best = THEMES[0], bd = 1e9;
  for (const t of THEMES) {
    if (!!t.light !== !!c.light) continue;
    const d = hueDist(hexHsl(t.accent)[0], ah) + hueDist(hexHsl(t.b1)[0], bh) * 0.6;
    if (d < bd) { bd = d; best = t; }
  }
  return best ? best.id : 'aurora';
}
function describe(text) {
  const q = ` ${text.toLowerCase()} `;
  const P = { hues: [], sat: null };
  const named = THEMES.find((t) => q.includes(` ${t.name.toLowerCase()} `));
  for (const [re, p] of MOODS) {
    if (!re.test(q)) continue;
    for (const k in p) {
      if (k === 'hues') P.hues.push(...p.hues);
      else if (P[k] == null) P[k] = p[k];
    }
  }
  const colorHues = [];
  for (const [w, h] of Object.entries(COLOR_WORDS)) if (new RegExp(`\\b${w}\\b`).test(q)) colorHues.push(h);
  if (colorHues.length) P.hues = colorHues.concat(P.hues); // colors you name come first
  if (/\b(black|dark|night|midnight|moody)\b/.test(q)) P.dark = true;
  if (/\b(pastel|soft|muted|gentle)\b/.test(q)) P.sat = Math.min(P.sat ?? 50, 45);
  if (/\b(bright|vivid|loud|bold|electric)\b/.test(q)) P.sat = 98;
  if (/\b(calm|chill|relax)\b/.test(q)) P.motion = 'calm';
  if (/\b(wild|crazy|intense|energetic)\b/.test(q)) P.motion = 'wild';
  const name = titleCase(text.replace(/[^\w\s'-]/g, '')) || 'New look';
  const seed = P.hues.length ? P.hues[0] : Math.random() * 360;
  return [0, 1, 2].map((v) => build(P, v, seed, named, name));
}
function build(P, v, seed, named, name) {
  const sat = P.sat ?? 80, light = !!P.light;
  const h = P.hues.length ? P.hues : [seed];
  const off = [35, 180, 120][v];
  const h1 = h[0] + (v === 2 && h.length < 2 ? 10 : 0), h2 = h[1] ?? h1 + off, h3 = h[2] ?? (h1 + (h2 - h1) / 2 + (v === 1 ? 200 : 25));
  const s = v === 2 ? Math.min(100, sat + 10) : v === 1 ? sat * 0.85 : sat;
  let c;
  if (named && v === 0) {
    c = { base: named.base, b1: named.b1, b2: named.b2, b3: named.b3, accent: named.accent, light: !!named.light };
  } else if (P.mono) {
    c = { base: hsl(h1, 12, 4), b1: hsl(h1, s * 0.6, 22), b2: hsl(h1, s * 0.4, 14), b3: hsl(h1 + 10, s * 0.5, 30), accent: hsl(h[1] ?? h1, Math.max(60, s), 60), light: false };
  } else if (light) {
    c = { base: hsl(h1, 30, 95), b1: hsl(h1, s, 70), b2: hsl(h2, s * 0.9, 74), b3: hsl(h3, s * 0.8, 78), accent: hsl(h1, Math.min(100, s + 10), 40), light: true };
  } else {
    const dl = v === 1 || P.dark ? 3 : 5;
    c = { base: hsl(h1, Math.min(45, s * 0.45), dl), b1: hsl(h1, s, v === 1 ? 34 : 45), b2: hsl(h2, s, v === 1 ? 30 : 46), b3: hsl(h3, s * 0.9, 50),
      accent: hsl(v === 2 ? h2 : h1, Math.min(100, s + 6), 68), light: false };
  }
  const styles = ['glass', 'holo', 'soft', 'lux', 'synth'];
  const pool = P.motion === 'calm' ? EFFECT_POOL.calm : EFFECT_POOL.dark;
  const effect = v === 0 && P.effect ? P.effect : v === 1 ? (P.effect && P.effect !== 'off' ? pool[(Math.round(seed) + 3) % pool.length] : 'smoke') : (P.effect || pool[Math.round(seed) % pool.length]);
  const d = blank(v === 0 ? name : `${name} · ${['', 'Deep', 'Bold'][v]}`);
  d.colors = c;
  Object.assign(d.settings, {
    theme: named ? named.id : closestTheme(c), style: P.style || styles[(Math.round(seed) + v) % styles.length], effect,
    button_fx: P.button || ['glass', 'holo', 'neon'][v], ripple_style: P.ripple || ['waves', 'aurora', 'shock'][v], clock_style: P.clock || ['thin', 'outline', 'bold'][v],
    knob_style: P.knob || ['aurora', 'halo', 'neon'][v], splash_style: P.splash || ['warp', 'plasma', 'hyper'][v],
  });
  if (P.speedo) d.settings.speedo = P.speedo;
  if (P.motion) d.settings.motion = P.motion;
  if (P.glass) d.settings.glass = Object.assign({}, glassOf(d), P.glass);
  if (v === 1) d.settings.glass = Object.assign({}, glassOf(d), { opacity: 34, blur: 44 });
  if (d.settings.style === 'rainy') Object.assign(d.settings, { rain_over: true });
  if (P.font) d.studio.font = P.font;
  return d;
}

// ================================================================ "From a photo": colors out of a picture
function loadImage(file) {
  return new Promise((res, rej) => {
    const url = URL.createObjectURL(file), img = new Image();
    img.onload = () => res(img); img.onerror = rej; img.src = url;
  });
}
function wallpaperOf(img) {  // the photo cropped to the screen's shape, small enough to send
  const W = 1280, Hh = 750, cv = document.createElement('canvas');
  cv.width = W; cv.height = Hh;
  const s = Math.max(W / img.width, Hh / img.height), w = img.width * s, h = img.height * s;
  cv.getContext('2d').drawImage(img, (W - w) / 2, (Hh - h) / 2, w, h);
  return cv.toDataURL('image/jpeg', 0.8);
}
function paletteOf(img) {
  const N = 72, cv = document.createElement('canvas');
  cv.width = N; cv.height = N;
  const x = cv.getContext('2d');
  x.drawImage(img, 0, 0, N, N);
  const px = x.getImageData(0, 0, N, N).data, pts = [];
  for (let i = 0; i < px.length; i += 4) if (px[i + 3] > 200) pts.push([px[i], px[i + 1], px[i + 2]]);
  // k-means, 7 groups
  const K = 7;
  let cen = Array.from({ length: K }, (_, i) => pts[Math.floor((i + 0.5) * pts.length / K)].slice());
  let lab = new Array(pts.length).fill(0);
  for (let it = 0; it < 10; it++) {
    const sum = cen.map(() => [0, 0, 0, 0]);
    pts.forEach((p, i) => {
      let b = 0, bd = 1e9;
      cen.forEach((c, k) => { const d = (p[0] - c[0]) ** 2 + (p[1] - c[1]) ** 2 + (p[2] - c[2]) ** 2; if (d < bd) { bd = d; b = k; } });
      lab[i] = b; const s = sum[b]; s[0] += p[0]; s[1] += p[1]; s[2] += p[2]; s[3]++;
    });
    cen = sum.map((s, k) => (s[3] ? [s[0] / s[3], s[1] / s[3], s[2] / s[3]] : cen[k]));
    cen.n = sum.map((s) => s[3]);
  }
  return cen.map((c, k) => ({ hex: rgbHex(...c), n: cen.n[k] / pts.length, hsl: rgbHsl(...c) })).filter((c) => c.n > 0.01).sort((a, b) => b.n - a.n);
}
function fromPhoto(pal, wall) {
  const colorful = pal.slice().sort((a, b) => (b.hsl[1] * Math.sqrt(b.n) * (b.hsl[2] > 12 && b.hsl[2] < 90 ? 1 : 0.2)) - (a.hsl[1] * Math.sqrt(a.n) * (a.hsl[2] > 12 && a.hsl[2] < 90 ? 1 : 0.2)));
  const picks = [];
  for (const c of colorful) if (picks.every((p) => hueDist(p.hsl[0], c.hsl[0]) > 22)) picks.push(c);
  while (picks.length < 3) picks.push(colorful[picks.length % colorful.length] || pal[0]);
  const dark = pal.slice().sort((a, b) => a.hsl[2] - b.hsl[2])[0];
  const [h1, s1] = picks[0].hsl, [h2, s2] = picks[1].hsl, [h3, s3] = picks[2].hsl;
  const vivid = (s) => Math.max(55, Math.min(100, s * 1.25));
  const base = hsl(dark.hsl[0], Math.min(40, dark.hsl[1] * 0.7), 4);
  const make = (name, c, extra) => {
    const d = blank(name);
    d.colors = c;
    Object.assign(d.settings, { theme: closestTheme(c) }, extra.settings || {});
    Object.assign(d.studio, extra.studio || {});
    return d;
  };
  return [
    make('Photo colors', { base, b1: hsl(h1, vivid(s1), 45), b2: hsl(h2, vivid(s2), 45), b3: hsl(h3, vivid(s3), 50), accent: hsl(h1, vivid(s1), 68), light: false },
      { settings: { effect: 'liquid', style: 'glass', knob_style: 'aurora', splash_style: 'plasma' } }),
    make('Photo background', { base, b1: hsl(h1, vivid(s1), 45), b2: hsl(h2, vivid(s2), 45), b3: hsl(h3, vivid(s3), 50), accent: hsl(h1, vivid(s1), 70), light: false },
      { settings: { effect: 'off', style: 'glass', knob_style: 'minimal', splash_style: 'warp', glass: Object.assign({}, glassOf(D()), { opacity: 26, blur: 36 }) }, studio: { wall, wallDim: 35 } }),
    make('Photo moody', { base: hsl(dark.hsl[0], Math.min(30, dark.hsl[1]), 3), b1: hsl(h2, s2 * 0.8, 28), b2: hsl(h3, s3 * 0.8, 24), b3: hsl(h1, s1 * 0.8, 32), accent: hsl(h2, vivid(s2), 64), light: false },
      { settings: { effect: 'smoke', style: 'lux', knob_style: 'nightdrive', splash_style: 'chrome' } }),
  ];
}

// ================================================================ voice ("Describe it" by talking)
let rec = null;
const canTalk = () => !!(APP && APP.listen) || !!(window.SpeechRecognition || window.webkitSpeechRecognition);
window.huVoice = (text) => {
  $$('.mic').forEach((m) => m.classList.remove('on'));
  if (!text) return;
  const t = $('#descIn');
  if (t) { t.value = text; makeFromWords(); }
};
function listen() {
  $$('.mic').forEach((m) => m.classList.add('on'));
  if (APP && APP.listen) { APP.listen(); return; }
  const R = window.SpeechRecognition || window.webkitSpeechRecognition;
  rec = new R(); rec.lang = 'en-US'; rec.interimResults = false;
  rec.onresult = (e) => window.huVoice(e.results[0][0].transcript);
  rec.onend = () => $$('.mic').forEach((m) => m.classList.remove('on'));
  rec.start();
}

// ================================================================ tabs
const ICONS = {
  create: '<path d="M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9z"/><path d="M19 15l.8 2.2L22 18l-2.2.8L19 21l-.8-2.2L16 18l2.2-.8z"/>',
  gallery: '<rect x="3" y="3" width="7" height="7" rx="2"/><rect x="14" y="3" width="7" height="7" rx="2"/><rect x="3" y="14" width="7" height="7" rx="2"/><rect x="14" y="14" width="7" height="7" rx="2"/>',
  edit: '<path d="M4 6h10M18 6h2M4 12h4M12 12h8M4 18h12M20 18h0"/><circle cx="16" cy="6" r="2"/><circle cx="10" cy="12" r="2"/><circle cx="18" cy="18" r="2"/>',
  knob: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="4"/><path d="M12 3v3"/>',
  schedule: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
};
const TABS = [['create', 'Create'], ['gallery', 'Gallery'], ['edit', 'Edit'], ['knob', 'Knob'], ['schedule', 'Schedule']];
function renderTabs() {
  $('#tabs').innerHTML = TABS.map(([id, n]) => `<button class="tab ${tab === id ? 'on' : ''}" data-tab="${id}"><svg viewBox="0 0 24 24">${ICONS[id]}</svg>${n}</button>`).join('');
}
$('#tabs').addEventListener('click', (e) => { const b = e.target.closest('[data-tab]'); if (b) setTab(b.dataset.tab); });
function setTab(t) {
  tab = t; localStorage.setItem('ts-tab', t);
  renderTabs(); render(); panel.scrollTop = 0;
  if (t === 'gallery' || t === 'schedule') refreshCar();
  if (t === 'create') refreshRequests();
}

function render() {
  const open = $$('details.acc[open]').map((x) => x.dataset.sec);
  const top = panel.scrollTop;
  panel.innerHTML = (VIEWS[tab] || VIEWS.create)();
  if (tab === 'edit') $$('details.acc').forEach((x) => { if (open.includes(x.dataset.sec)) x.open = true; });
  if (tab === 'edit' && !open.length && !render.once) { const f = $('details.acc'); if (f) f.open = true; render.once = true; }
  panel.scrollTop = top;
  $$('input[type=range]', panel).forEach(paintRange);
  drawKnobPv();
}
const paintRange = (r) => r.style.setProperty('--p', `${((r.value - r.min) / (r.max - r.min)) * 100}%`);

// ---------------------------------------------------------------- small builders
const svgI = (p, s = 22) => `<svg viewBox="0 0 24 24" style="width:${s}px;height:${s}px">${p}</svg>`;
const I = {
  photo: '<rect x="3" y="5" width="18" height="14" rx="3"/><circle cx="9" cy="10" r="2"/><path d="m21 16-5-5-8 8"/>',
  dice: '<rect x="3" y="3" width="18" height="18" rx="4"/><circle cx="8" cy="8" r="1.2" fill="currentColor"/><circle cx="16" cy="16" r="1.2" fill="currentColor"/><circle cx="12" cy="12" r="1.2" fill="currentColor"/>',
  claude: '<path d="M12 2v6M12 16v6M2 12h6M16 12h6M5 5l4 4M15 15l4 4M19 5l-4 4M9 15l-4 4"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  mic: '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/>',
  send: '<path d="M5 12h14M13 6l6 6-6 6"/>',
  palette: '<circle cx="12" cy="12" r="9"/><circle cx="8" cy="10" r="1.3" fill="currentColor"/><circle cx="12" cy="7.5" r="1.3" fill="currentColor"/><circle cx="16" cy="10" r="1.3" fill="currentColor"/><path d="M12 21a3 3 0 0 1 0-6h2"/>',
  layers: '<path d="m12 3 9 5-9 5-9-5z"/><path d="m3 13 9 5 9-5"/>',
  wave: '<path d="M2 12c3-6 5-6 8 0s5 6 8 0 4-4 4-4"/>',
  panel: '<rect x="3" y="4" width="18" height="16" rx="3"/><path d="M3 10h18"/>',
  type: '<path d="M4 7V5h16v2M9 19h6M12 5v14"/>',
  grid: '<rect x="3" y="3" width="8" height="8" rx="2"/><rect x="13" y="3" width="8" height="5" rx="2"/><rect x="13" y="10" width="8" height="11" rx="2"/><rect x="3" y="13" width="8" height="8" rx="2"/>',
  rocket: '<path d="M5 15c-1.5 1.5-2 5-2 5s3.5-.5 5-2M9 15l-3-3c1-4 4-8 9-9 1 0 2 1 2 2-1 5-5 8-9 9z"/><circle cx="14" cy="9" r="1.5"/>',
  code: '<path d="m8 8-5 4 5 4M16 8l5 4-5 4M14 4l-4 16"/>',
  file: '<path d="M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/><path d="M14 3v6h6"/>',
  trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
  copy: '<rect x="8" y="8" width="13" height="13" rx="2"/><path d="M16 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h3"/>',
  share: '<circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="m8.6 13.5 6.8 4M15.4 6.5l-6.8 4"/>',
  play: '<path d="M7 4v16l13-8z"/>',
  car: '<path d="M5 17h14v-5l-2-5H7l-2 5zM3 12h18"/><circle cx="7.5" cy="17" r="1.5"/><circle cx="16.5" cy="17" r="1.5"/>',
};
const tog = (on, attr) => `<button class="tog ${on ? 'on' : ''}" ${attr} aria-pressed="${!!on}"></button>`;
const swRow = (title, sub, on, attr) => `<div class="sw-row"><div><b>${title}</b>${sub ? `<span>${sub}</span>` : ''}</div>${tog(on, attr)}</div>`;
function range(label, path, val, min, max, step = 1, unit = '') {
  return `<div class="field"><label>${label}<output>${val}${unit}</output></label><input type="range" min="${min}" max="${max}" step="${step}" value="${val}" data-range="${path}" data-unit="${unit}"></div>`;
}
const acc = (sec, icon, title, sub, body) => `<details class="acc" data-sec="${sec}"><summary><span class="ai">${svgI(I[icon] || '', 20)}</span><div><b>${title}</b><span>${sub}</span></div></summary><div class="body">${body}</div></details>`;
const opts = (key, list, val, cls = '') => `<div class="opts ${cls}">${list.map(([id, n, desc]) => `<button class="opt ${val === id ? 'on' : ''}" data-set="${key}" data-val="${esc(id)}"><b>${esc(n)}</b>${desc ? `<span>${esc(desc)}</span>` : ''}</button>`).join('')}</div>`;
const pills = (key, list, val) => `<div class="pills">${list.map(([id, n]) => `<button class="pill ${val === id ? 'on' : ''}" data-set="${key}" data-val="${esc(id)}">${esc(n)}</button>`).join('')}</div>`;
function colorPick(label, path, hex) {
  return `<label class="cpick"><div class="sw2" style="background:${hex}"></div><b>${label}</b><span>${hex}</span><input type="color" value="${hex}" data-color="${path}"></label>`;
}

// ================================================================ the five screens
const SUGGEST = ['Neon Tokyo night', 'Subaru rally blue and gold', 'Sunset beach', 'Arctic glass', 'Stealth carbon', 'Forest cabin',
  'Synthwave', 'Rainy city', 'Deep space', 'Cherry blossom', 'Black and gold luxury', 'Toxic green'];
const VIEWS = {
  create() {
    const res = results.length ? `<h3>${esc(resultsFrom)}</h3><div class="results">${results.map((d, i) => dcard(d, `try:${i}`, { on: D()._try === i && D()._tryFrom === resultsFrom })).join('')}</div>
      <p class="muted" style="margin:10px 4px">Tap one to see it on the car. Change anything in Edit, then <b>Save to car</b>.</p>` : '';
    const ph = photo ? `<div class="card photo-box"><img src="${photo.wall}" alt=""><div><b>Colors in your photo</b><div class="pal" style="margin-top:8px">${photo.pal.slice(0, 7).map((c) => `<i style="background:${c.hex}"></i>`).join('')}</div></div></div>` : '';
    return `<h2>Make a new look</h2><p class="lead">Start from words, a photo, or let Claude design it.</p>
      <div class="hero"><h4>${svgI(ICONS.create, 20)} Describe it</h4><p>Say a mood, a place, colors, a car. You get three takes on it.</p>
        <div class="ask"><textarea id="descIn" rows="1" placeholder="e.g. moody blue rally">${esc(localStorage.getItem('ts-desc') || '')}</textarea>
        ${canTalk() ? `<button class="mic" data-act="listen" aria-label="Talk">${svgI(I.mic)}</button>` : ''}<button class="go" data-act="describe" aria-label="Make it">${svgI(I.send)}</button></div>
        <div class="sugg">${SUGGEST.map((s) => `<button class="chip" data-act="sugg" data-val="${esc(s)}">${esc(s)}</button>`).join('')}</div></div>
      <div class="duo">
        <button class="tile photo" data-act="photo"><span class="ti">${svgI(I.photo)}</span><div><b>From a photo</b><br><span>Your wallpaper, a sunset, your car</span></div></button>
        <button class="tile dice" data-act="surprise"><span class="ti">${svgI(I.dice)}</span><div><b>Surprise me</b><br><span>Three random looks</span></div></button>
        <button class="tile claude" data-act="claude"><span class="ti">${svgI(I.claude)}</span><div><b>Ask Claude</b><br><span>Claude designs it for you</span></div></button>
        <button class="tile blank" data-act="blank"><span class="ti">${svgI(I.plus)}</span><div><b>Start blank</b><br><span>Build it by hand in Edit</span></div></button>
      </div>${ph}${res}${reqs.length ? `<h3>Your requests to Claude</h3><div class="card">${reqList()}</div>` : ''}`;
  },
  gallery() {
    const segs = [['claude', 'From Claude'], ['car', 'On the car'], ['mine', 'On this phone'], ['themes', 'Color themes']];
    let body = '';
    if (gseg === 'claude') {
      body = GALLERY.length ? `<p class="lead">Complete looks Claude designed: screen, knob and startup. Tap to try one.</p><div class="grid">${GALLERY.map((g, i) => dcard(g, `pick:claude:${i}`, { badge: g.request ? 'For you' : 'Claude', badgeCls: 'claude', sub: g.desc })).join('')}</div>`
        : '<div class="empty"><b>Nothing here yet</b>Designs from Claude show up here.</div>';
    } else if (gseg === 'car') {
      body = CAR.designs.length ? `<p class="lead">Saved on the head unit. Schedules can switch between these.</p><div class="grid">${CAR.designs.map((g, i) => dcard(g, `pick:car:${i}`, { live: CAR.active === g.id, badge: g.author === 'Claude' ? 'Claude' : '', badgeCls: 'claude' })).join('')}</div>`
        : `<div class="empty"><b>${carOk === false ? 'Not connected' : 'No saved designs yet'}</b>${carOk === false ? NO_CAR : 'Tap Save to car on any design and it lands here.'}</div>`;
    } else if (gseg === 'mine') {
      body = `<div class="grid">${lib.map((d, i) => dcard(d, `open:${i}`, { on: i === cur })).join('')}</div>
        <div class="btns" style="margin-top:12px"><button class="btn ghost" data-act="import">${svgI(I.file, 18)}Import file</button><button class="btn ghost" data-act="blank">${svgI(I.plus, 18)}New</button></div>`;
    } else {
      const groups = {};
      THEMES.forEach((t) => { (groups[t.group || 'More'] = groups[t.group || 'More'] || []).push(t); });
      const cur_ = setting('theme');
      body = `<p class="lead">Swap just the colors of this design. Everything else stays.</p>${Object.entries(groups).map(([g, ts]) => `<h3>${esc(g)}</h3><div class="swatches">${ts.map((t) => `<button class="sw ${cur_ === t.id && !D().colors ? 'on' : ''}" data-act="theme:${t.id}"><div class="bar4"><i style="background:${t.base}"></i><i style="background:${t.b1}"></i><i style="background:${t.b2}"></i><i style="background:${t.b3}"></i><i style="background:${t.accent}"></i></div><b>${esc(t.name)}</b></button>`).join('')}</div>`).join('')}`;
    }
    return `<h2>Gallery</h2><div class="seg">${segs.map(([id, n]) => `<button class="${gseg === id ? 'on' : ''}" data-act="seg:${id}">${n}</button>`).join('')}</div>${body}`;
  },
  edit() {
    const d = D(), c = colorsOf(d), st = d.studio || {}, g = glassOf(d), s = (k) => setting(k);
    const L = H || { styles: [], effects: [], layouts: {}, buttons: [], clocks: [], ripples: [], speedos: [] };
    const styleOpts = `<div class="opts wide">${L.styles.map(([id, n, desc, , th]) => `<button class="opt ${s('style') === id ? 'on' : ''}" data-act="style:${id}"><div class="th" style="background:${th ? th[0] : '#111'}"></div><b>${esc(n)}</b><span>${esc(desc)}</span></button>`).join('')}</div>`;
    return `<h2>Fine-tune</h2><p class="lead">Every change shows on the preview${live ? ' and the car' : ''} right away.</p>
    ${acc('colors', 'palette', 'Colors', 'Background, glows, accent, text', `
      <div class="colors">${colorPick('Background', 'c.base', c.base)}${colorPick('Glow 1', 'c.b1', c.b1)}${colorPick('Glow 2', 'c.b2', c.b2)}${colorPick('Glow 3', 'c.b3', c.b3)}${colorPick('Accent', 'c.accent', c.accent)}${colorPick('Text', 'st.textColor', c.text)}</div>
      <div class="field"><label>Spin all colors around the color wheel</label><input type="range" class="hue" min="-180" max="180" value="0" data-act-range="hue"></div>
      <div class="harm"><button class="pill" data-act="harm:analog">Neighbors</button><button class="pill" data-act="harm:comp">Opposites</button><button class="pill" data-act="harm:triad">Triad</button><button class="pill" data-act="harm:mono">One color</button><button class="pill" data-act="harm:shuffle">Shuffle</button></div>
      ${swRow('Light mode', 'Bright background, dark text', c.light, 'data-act="light"')}
      ${d.colors ? '<button class="btn ghost wide" style="margin-top:6px" data-act="resetcolors">Use the base theme’s colors</button>' : ''}`)}
    ${acc('style', 'layers', 'Style', 'The overall look, buttons, clock, speedometer', `${styleOpts}
      <h3>Buttons</h3>${pills('button_fx', L.buttons, s('button_fx'))}
      <h3>Clock</h3>${pills('clock_style', L.clocks, s('clock_style'))}
      <h3>Speedometer</h3>${pills('speedo', L.speedos, s('speedo'))}`)}
    ${acc('bg', 'wave', 'Background', 'Moving background, rain, wallpaper', `${opts('effect', L.effects, s('effect'))}
      <h3>Motion</h3>${pills('motion', [['calm', 'Calm'], ['lively', 'Lively'], ['wild', 'Wild']], s('motion') || 'lively')}
      <h3>Rain on the glass</h3>${swRow('Raindrops over the screen', 'Works with any background', !!s('rain_glass'), 'data-tog="s.rain_glass"')}
      ${s('rain_glass') ? pills('rain_amount', [['light', 'Light'], ['steady', 'Steady'], ['heavy', 'Heavy']], s('rain_amount') || 'steady') : ''}
      <h3>Wallpaper</h3>${st.wall ? `<div class="mini wall" style="--wall:url('${st.wall}');border-radius:12px;margin-bottom:8px"></div>${range('Darken', 'st.wallDim', st.wallDim ?? 35, 0, 85, 1, '%')}` : '<p class="muted">Use a photo instead of the moving background.</p>'}
      <div class="btns"><button class="btn" data-act="wall">${svgI(I.photo, 18)}${st.wall ? 'Change photo' : 'Pick a photo'}</button>${st.wall ? '<button class="btn ghost" data-act="nowall">Remove</button>' : ''}</div>`)}
    ${acc('glass', 'panel', 'Panels', 'Glass, corners, borders, glow', `
      ${range('Glass strength', 's.glass.opacity', g.opacity, 0, 100, 1, '%')}${range('Blur', 's.glass.blur', g.blur, 0, 60, 1, 'px')}
      ${range('Depth', 's.glass.depth', g.depth, 0, 100, 1, '%')}${range('Shine', 's.glass.shine', g.shine, 0, 100, 1, '%')}
      <h3>Tint</h3>${pills('glass.tint', [['theme', 'Theme color'], ['clear', 'Clear'], ['smoke', 'Smoke']], g.tint)}
      ${range('Corner roundness', 'st.radius', st.radius ?? 1.4, 0, 3, 0.1, '')}
      ${range('Border', 'st.border', st.border ?? 0, 0, 4, 1, 'px')}${st.border ? `<div class="colors" style="grid-template-columns:1fr 1fr 1fr">${colorPick('Border color', 'st.borderColor', st.borderColor || '#FFFFFF')}</div>` : ''}
      ${range('Accent glow', 'st.glow', st.glow ?? 0, 0, 60, 1, 'px')}
      ${swRow('Shiny edges', '', g.edge !== false, 'data-tog="s.glass.edge"')}${swRow('Tilt when touched', '', g.tilt !== false, 'data-tog="s.glass.tilt"')}`)}
    ${acc('text', 'type', 'Text', 'Font and weight', `<div class="opts">${FONTS.map(([f, n]) => `<button class="opt ${(st.font || '') === f ? 'on' : ''}" data-act="font:${esc(f)}" style="font-family:${f === 'StudioFont' ? 'inherit' : f || 'inherit'}"><b>${esc(n)}</b><span>Aa 12:45</span></button>`).join('')}</div>
      <div class="btns" style="margin-top:8px"><button class="btn ghost" data-act="fontup">${svgI(I.file, 18)}${st.fontData ? 'Replace my font' : 'Upload a font'}</button></div>
      ${range('Heading weight', 'st.weight', st.weight || 400, 100, 900, 100, '')}`)}
    ${acc('layout', 'grid', 'Layout', 'Home layout, menu side, transitions', `<div class="opts">${Object.entries(L.layouts).map(([id, l]) => `<button class="opt ${s('home_layout') === id ? 'on' : ''}" data-set="home_layout" data-val="${id}"><b>${esc(l.name)}</b><span>${l.slots ? `${l.slots} panels` : 'Free'}</span></button>`).join('')}</div>
      <h3>Menu</h3>${pills('nav', [['left', 'Left'], ['right', 'Right'], ['dock', 'Bottom dock']], s('nav') || 'left')}
      <h3>Screen changes</h3>${pills('transition', [['depth', 'Depth'], ['slide', 'Slide'], ['flip', 'Flip'], ['fade', 'Fade'], ['none', 'None']], s('transition') || 'depth')}`)}
    ${acc('startup', 'rocket', 'Startup', 'The animation when the car turns on', `${opts('splash_style', SPLASHES, s('splash_style') || 'warp', 'wide')}
      <div class="field"><label>Name on the startup screen</label><input class="txt" maxlength="24" data-text="s.splash_text" value="${esc(s('splash_text') || 'Pi Head Unit')}"></div>
      <div class="btns" style="margin-top:10px"><button class="btn" data-act="splashpv">${svgI(I.play, 18)}Preview</button><button class="btn" data-act="splashcar">${svgI(I.car, 18)}Play on car</button></div>
      <p class="muted">Play on car shows the saved startup, so save first.</p>`)}
    ${acc('css', 'code', 'Custom CSS', 'For anything the controls can’t do', `<textarea class="txt code" data-text="customCss" spellcheck="false" placeholder=".card { border-radius: 0 }">${esc(d.customCss || '')}</textarea>`)}
    ${acc('file', 'file', 'This design', 'Copy, share, delete', `<div class="btns"><button class="btn" data-act="dup">${svgI(I.copy, 18)}Duplicate</button><button class="btn" data-act="share">${svgI(I.share, 18)}Share file</button></div>
      <div class="btns" style="margin-top:8px"><button class="btn ghost" data-act="import">${svgI(I.file, 18)}Import</button><button class="btn ghost" data-act="del" style="color:var(--bad)">${svgI(I.trash, 18)}Delete</button></div>`)}`;
  },
  knob() {
    const d = D(), own = !!(d.knob && d.knob.colors), kc = knobColorsOf(d), face = setting('knob_style') || 'aurora';
    const f = FACES.find((x) => x.id === face) || {};
    return `<h2>Knob</h2><div class="knob-big"><div class="k" id="knobBig"></div></div>
      <div class="card"><div class="row between"><div><b>${esc(f.name || face)}</b><div class="muted">${esc(f.desc || '')}</div></div><button class="btn" data-act="kturn">Try a turn</button></div></div>
      <h3>Face</h3><div class="faces">${FACES.map((x) => `<button class="face ${x.id === face ? 'on' : ''}" data-set="knob_style" data-val="${x.id}"><div class="fc">${knobSvg(x.id)}</div>${esc(x.name)}</button>`).join('')}</div>
      <h3>Colors</h3><div class="card">${swRow('Match the screen', 'Knob uses the same colors as the screen', !own, 'data-act="kmatch"')}
        ${own ? `<div class="colors" style="margin-top:8px">${colorPick('Background', 'k.base', kc.base)}${colorPick('Accent', 'k.accent', kc.accent)}${colorPick('Text', 'k.text', kc.text)}${colorPick('Glow 1', 'k.b1', kc.b1)}${colorPick('Glow 2', 'k.b2', kc.b2)}${colorPick('Glow 3', 'k.b3', kc.b3)}</div>` : ''}</div>
      <h3>When you turn it</h3><div class="card"><p class="muted" style="margin-top:0">The ripple that runs across the screen when the knob is pressed or turned.</p>
        ${opts('ripple_style', (H && H.ripples) || [], setting('ripple_style') || 'waves')}
        ${range('Strength', 's.ripple_power', setting('ripple_power') ?? 60, 20, 100, 1, '%')}
        <h3>Starts from</h3>${pills('ripple_from', [['bottom', 'Bottom'], ['right', 'Right'], ['left', 'Left'], ['center', 'Center']], setting('ripple_from') || 'bottom')}</div>`;
  },
  schedule() {
    const sc = (CAR.settings && CAR.settings.look_schedule) || { on: false, rules: [] };
    if (!CAR.settings) return `<h2>Schedule</h2><div class="empty"><b>${carOk === false ? 'Not connected' : 'Loading…'}</b>${carOk === false ? NO_CAR : ''}</div>`;
    const looks = `<optgroup label="Saved on the car">${CAR.designs.map((x) => `<option value="design:${esc(x.id)}">${esc(x.name)}</option>`).join('')}</optgroup>
      <optgroup label="Color themes">${THEMES.map((t) => `<option value="theme:${t.id}">${esc(t.name)}</option>`).join('')}</optgroup>`;
    const WHEN = [['day', 'Daytime', '☀️'], ['night', 'Night', '🌙'], ['rain', 'Rain', '🌧️'], ['snow', 'Snow', '❄️'], ['storm', 'Thunderstorm', '⛈️'],
      ['fog', 'Fog', '🌫️'], ['clear', 'Clear sky', '🌤️'], ['cloudy', 'Cloudy', '☁️'], ['time', 'Between times', '🕒']];
    const hm = (m) => `${String(Math.floor(m / 60)).padStart(2, '0')}:${String(m % 60).padStart(2, '0')}`;
    const rules = sc.rules.map((r, i) => {
      const w = WHEN.find((x) => x[0] === r.when) || WHEN[0];
      const isNow = CAR.schedule_now === r.look && sc.on;
      return `<div class="rule ${isNow ? 'now' : ''}"><div class="when"><i>${w[2]}</i><select data-rule="${i}" data-f="when">${WHEN.map((x) => `<option value="${x[0]}" ${x[0] === r.when ? 'selected' : ''}>${x[1]}</option>`).join('')}</select>${isNow ? '<span class="now-tag">NOW</span>' : ''}</div>
        <button class="ib" data-act="rdel:${i}" aria-label="Remove">${svgI(I.trash, 18)}</button>
        ${r.when === 'time' ? `<div class="when look"><input type="time" value="${hm(r.from || 0)}" data-rule="${i}" data-f="from"> to <input type="time" value="${hm(r.to || 0)}" data-rule="${i}" data-f="to"></div>` : ''}
        <div class="look"><select data-rule="${i}" data-f="look">${looks.replace(`value="${esc(r.look)}"`, `value="${esc(r.look)}" selected`)}</select></div></div>`;
    }).join('');
    return `<h2>Schedule</h2><p class="lead">Switch looks by itself: day and night, the weather, or the time. The first rule that fits wins.</p>
      <div class="card">${swRow('Change looks automatically', sc.on ? `Using: ${esc(lookName(CAR.schedule_now) || 'nothing yet')}` : 'Off', sc.on, 'data-act="son"')}
        ${swRow('Simple: follow the weather', 'Built-in looks for sun, rain, snow and night', !!CAR.settings.weather_look, 'data-act="wlook"')}</div>
      <h3>Rules</h3>${rules || '<p class="muted" style="margin:0 4px 10px">No rules yet. Start with a preset or add one.</p>'}
      <div class="btns"><button class="btn" data-act="radd">${svgI(I.plus, 18)}Add rule</button></div>
      <h3>Presets</h3><div class="btns"><button class="btn ghost" data-act="preset:daynight">Day + night</button><button class="btn ghost" data-act="preset:weather">Weather</button><button class="btn ghost" data-act="preset:commute">Commute times</button></div>
      <p class="muted" style="margin:12px 4px">A look picked by hand stays until the next rule starts. Designs must be saved to the car to be scheduled.</p>`;
  },
};
function lookName(ref) {
  if (!ref) return '';
  const [k, v] = ref.split(':');
  if (k === 'design') return (CAR.designs.find((x) => x.id === v) || {}).name || v;
  return (THEMES.find((t) => t.id === v) || {}).name || v;
}
function reqList() {
  return reqs.slice().reverse().map((r) => `<div class="req"><span class="st ${r.status === 'done' ? 'done' : ''}">${r.status === 'done' ? 'Ready' : 'Waiting'}</span><div class="grow">${esc(r.text)}<div class="muted">${{ screen: 'Screen', knob: 'Knob', both: 'Screen + knob' }[r.part] || ''} · ${new Date(r.at * 1000).toLocaleDateString()}</div></div></div>`).join('');
}

// ================================================================ actions
function setPath(d, path, val) {
  const [root, ...rest] = path.split('.');
  let o;
  if (root === 's') o = d.settings = d.settings || {};
  else if (root === 'st') o = d.studio = d.studio || {};
  else if (root === 'c') { if (!d.colors) { const c = colorsOf(d); d.colors = { base: c.base, b1: c.b1, b2: c.b2, b3: c.b3, accent: c.accent, light: c.light }; } o = d.colors; }
  else if (root === 'k') { d.knob = d.knob || {}; if (!d.knob.colors) d.knob.colors = Object.assign({}, knobColorsOf(d)); o = d.knob.colors; }
  else if (root === 'customCss') { d.customCss = val; return; }
  if (root === 's' && rest[0] === 'glass') { d.settings.glass = Object.assign({}, glassOf(d), d.settings.glass); o = d.settings.glass; rest.shift(); }
  o[rest[0]] = val;
}
function useDesign(d, from) {
  const i = lib.findIndex((x) => x._src && x._src === from);
  const copy = JSON.parse(JSON.stringify(d));
  copy._src = from;
  if (i >= 0 && !dirtyLib(i)) { lib[i] = copy; openDesign(i); }
  else { lib.push(copy); openDesign(lib.length - 1); }
}
const dirtyLib = (i) => i === cur && dirty;
function tryResult(i) {
  // trying results replaces the last tried one, so tapping through them doesn't fill the library
  const d = JSON.parse(JSON.stringify(results[i]));
  d._try = i; d._tryFrom = resultsFrom; d._src = 'try';
  const j = lib.findIndex((x) => x._src === 'try');
  if (j >= 0) { lib[j] = d; openDesign(j); } else { lib.push(d); openDesign(lib.length - 1); }
}
function shiftHue(deg, base) {
  const c = {};
  for (const k of ['base', 'b1', 'b2', 'b3', 'accent']) { const [h, s, l] = hexHsl(base[k]); c[k] = hsl(h + deg, s, l); }
  c.light = base.light;
  return c;
}
function harmony(kind) {
  const c = colorsOf(D()), [h, s, l] = hexHsl(c.accent), sat = Math.max(55, s);
  const dl = c.light ? 72 : 45;
  const sets = {
    analog: [h - 30, h + 30, h + 60], comp: [h, h + 180, h + 200], triad: [h, h + 120, h + 240], mono: [h, h, h],
    shuffle: [Math.random() * 360, Math.random() * 360, Math.random() * 360],
  }[kind];
  edit((d) => {
    const hs = sets;
    const nc = { base: c.base, b1: hsl(hs[0], sat, kind === 'mono' ? dl - 12 : dl), b2: hsl(hs[1], sat, kind === 'mono' ? dl - 22 : dl), b3: hsl(hs[2], sat * 0.9, dl + 5), accent: c.accent, light: c.light };
    if (kind === 'shuffle') { nc.accent = hsl(hs[0], 90, c.light ? 40 : 68); nc.base = c.light ? hsl(hs[0], 30, 95) : hsl(hs[0], 35, 4); }
    d.colors = nc;
  }, { render: true });
}
async function makeFromWords() {
  const t = $('#descIn');
  const text = (t && t.value.trim()) || '';
  if (!text) { toast('Type or say what you want first'); return; }
  localStorage.setItem('ts-desc', text);
  results = describe(text); resultsFrom = `“${text}”`;
  render(); tryResult(0);
  setTimeout(() => { const r = $('.results'); if (r) r.scrollIntoView({ behavior: 'smooth', block: 'center' }); }, 60);
}
function surprise() {
  const pick = () => SUGGEST[Math.floor(Math.random() * SUGGEST.length)];
  const words = [pick(), pick(), pick()];
  results = words.map((w, i) => { const r = describe(w)[i % 3]; r.name = titleCase(w); return r; });
  resultsFrom = 'Surprise';
  render(); tryResult(0);
}
async function onPhoto(file) {
  try {
    toast('Reading the colors…');
    const img = await loadImage(file);
    const pal = paletteOf(img), wall = wallpaperOf(img);
    photo = { pal, wall };
    results = fromPhoto(pal, wall); resultsFrom = 'From your photo';
    if (tab !== 'create') setTab('create');
    render(); tryResult(0);
    setTimeout(() => { const r = $('.results'); if (r) r.scrollIntoView({ behavior: 'smooth', block: 'center' }); }, 60);
  } catch (e) { toast('Couldn’t read that picture'); }
}
function claudeSheet() {
  sheet(`<h2 style="margin-top:0">Ask Claude</h2><p class="lead">Describe the look. Claude designs the full thing (colors, style, background, knob face, startup) and it appears in Gallery › From Claude.</p>
    <textarea class="txt" id="claudeIn" rows="4" placeholder="e.g. Match my car: Azurite blue paint, black interior, a little gold. Calm at night."></textarea>
    <h3>For</h3><div class="pills" id="partPills">${[['both', 'Screen + knob'], ['screen', 'Screen'], ['knob', 'Knob']].map(([id, n]) => `<button class="pill ${part === id ? 'on' : ''}" data-part="${id}">${n}</button>`).join('')}</div>
    <button class="btn primary wide" style="margin-top:16px" id="claudeSend">${svgI(I.send, 18)}Send to Claude</button>
    <p class="muted">Claude works on it the next time Claude Code is open on the head unit (Settings › Tools › Start Claude Code). Just tell it “do my design requests”.</p>`);
  $('#partPills').addEventListener('click', (e) => { const b = e.target.closest('[data-part]'); if (!b) return; part = b.dataset.part; $$('#partPills .pill').forEach((p) => p.classList.toggle('on', p === b)); });
  $('#claudeSend').addEventListener('click', async () => {
    const text = $('#claudeIn').value.trim();
    if (!text) { toast('Say what you want first'); return; }
    const r = await apiJson('POST', '/design/request', { text, part });
    if (!r.ok) { toast(r.status ? r.text : NO_CAR); return; }
    reqs = r.json.requests || []; closeSheet(); toast('Sent. Claude will design it.'); if (tab === 'create') render();
  });
}
function cardSheet(src, i) {
  const d = src === 'car' ? CAR.designs[i] : GALLERY[i];
  sheet(`<div style="border-radius:16px;overflow:hidden;margin-bottom:12px">${mini(d)}</div><h2 style="margin:0 0 2px">${esc(d.name)}</h2><p class="lead">${esc(d.desc || '')}</p>
    <div class="btns"><button class="btn primary" data-sheet="edit">Open in editor</button>${src === 'car' ? '<button class="btn" data-sheet="use">Use now</button>' : ''}</div>
    ${src === 'car' ? `<div class="btns" style="margin-top:8px"><button class="btn ghost" data-sheet="del" style="color:var(--bad)">${svgI(I.trash, 18)}Delete from car</button></div>` : ''}`);
  $('#sheet').onclick = async (e) => {
    const b = e.target.closest('[data-sheet]'); if (!b) return;
    const a = b.dataset.sheet;
    if (a === 'edit') { useDesign(fromFile(d), `${src}:${d.id || d.name}`); closeSheet(); toast(`Opened “${d.name}”`); }
    else if (a === 'use') { const r = await api('POST', '/cmd', { cmd: 'design_use', id: d.id }); closeSheet(); toast(r.ok ? `“${d.name}” is on the car` : NO_CAR); refreshCar(); }
    else if (a === 'del') { if (!confirm(`Delete “${d.name}” from the head unit?`)) return; const r = await api('POST', '/cmd', { cmd: 'design_delete', id: d.id }); closeSheet(); toast(r.ok ? 'Deleted' : NO_CAR); refreshCar(); }
  };
}
async function saveSchedule(fn) {
  const sc = JSON.parse(JSON.stringify((CAR.settings && CAR.settings.look_schedule) || { on: false, rules: [] }));
  fn(sc);
  CAR.settings.look_schedule = sc;
  render();
  const r = await api('POST', '/cmd', { cmd: 'settings', patch: { look_schedule: sc } });
  if (!r.ok) toast(r.status ? r.text : NO_CAR);
  setTimeout(refreshCar, 800);
}
function firstDesign(pred) { const x = CAR.designs.find(pred); return x ? `design:${x.id}` : null; }
const PRESETS = {
  daynight: () => [{ when: 'night', look: firstDesign((x) => /night|dark|midnight|neon/i.test(x.name)) || 'theme:midnight' },
    { when: 'day', look: firstDesign((x) => /day|sun|light|morning/i.test(x.name)) || 'theme:lagoon' }],
  weather: () => [{ when: 'storm', look: 'theme:midnight' }, { when: 'rain', look: firstDesign((x) => /rain/i.test(x.name)) || 'theme:rainy-night' },
    { when: 'snow', look: 'theme:arctic' }, { when: 'night', look: 'theme:deepspace' }, { when: 'day', look: 'theme:lagoon' }],
  commute: () => [{ when: 'time', from: 360, to: 600, look: 'theme:lagoon' }, { when: 'time', from: 960, to: 1140, look: 'theme:desert' }, { when: 'night', look: 'theme:midnight' }],
};

panel.addEventListener('click', async (e) => {
  const set = e.target.closest('[data-set]');
  if (set) {
    const k = set.dataset.set, v = set.dataset.val;
    edit((d) => { if (k.startsWith('glass.')) setPath(d, `s.${k}`, v); else d.settings[k] = v; }, { render: true });
    return;
  }
  const t = e.target.closest('[data-tog]');
  if (t) { const p = t.dataset.tog; edit((d) => { const [r, ...rest] = p.split('.'); const cur_ = rest[0] === 'glass' ? glassOf(d)[rest[1]] : (r === 's' ? setting(rest[0], d) : (d.studio || {})[rest[0]]); setPath(d, p, !cur_); }, { render: true }); return; }
  const b = e.target.closest('[data-act]');
  if (!b) return;
  const [act, ...rest] = b.dataset.act.split(':');
  const arg = rest.join(':');
  switch (act) {
    case 'describe': return makeFromWords();
    case 'sugg': $('#descIn').value = b.dataset.val; return makeFromWords();
    case 'listen': return listen();
    case 'photo': return $('#photoIn').click();
    case 'surprise': return surprise();
    case 'claude': return claudeSheet();
    case 'blank': lib.push(blank(`My design ${lib.length + 1}`)); openDesign(lib.length - 1); setTab('edit'); return;
    case 'try': return tryResult(+arg);
    case 'seg': gseg = arg; render(); if (arg === 'car') refreshCar(); return;
    case 'pick': {
      const [src, i] = arg.split(':');
      if (src === 'claude') { const g = GALLERY[+i]; useDesign(fromFile(g), `claude:${g.name}`); toast(`Trying “${g.name}”`); return; }
      return cardSheet(src, +i);
    }
    case 'open': return openDesign(+arg);
    case 'theme': edit((d) => { d.settings.theme = arg; d.colors = null; }, { render: true }); return;
    case 'style': {
      const sty = H.styles.find((x) => x[0] === arg);
      edit((d) => { d.settings.style = arg; if (sty && sty[3]) { const { theme, ...restS } = sty[3]; Object.assign(d.settings, restS); if (!d.colors && theme) d.settings.theme = theme; } }, { render: true });
      return;
    }
    case 'harm': return harmony(arg);
    case 'light': edit((d) => { setPath(d, 'c.light', !colorsOf(d).light); const c = d.colors; if (c.light && lum(c.base) < 0.4) { const [h] = hexHsl(c.base); c.base = hsl(h, 30, 95); } else if (!c.light && lum(c.base) > 0.4) { const [h] = hexHsl(c.base); c.base = hsl(h, 35, 5); } }, { render: true }); return;
    case 'resetcolors': edit((d) => { d.colors = null; delete (d.studio || {}).textColor; }, { render: true }); return;
    case 'wall': return $('#wallIn').click();
    case 'nowall': edit((d) => { delete d.studio.wall; }, { render: true }); return;
    case 'font': edit((d) => { d.studio.font = arg; }, { render: true }); return;
    case 'fontup': return $('#fontIn').click();
    case 'splashpv': return goScreen('startup');
    case 'splashcar': { const r = await api('POST', '/cmd', { cmd: 'splash_play' }); toast(r.ok ? 'Playing on the car' : NO_CAR); return; }
    case 'dup': { const c = JSON.parse(JSON.stringify(D())); c.name = `${c.name} copy`; delete c._src; lib.push(c); openDesign(lib.length - 1); toast('Duplicated'); return; }
    case 'share': return shareDesign();
    case 'import': return $('#fileIn').click();
    case 'del':
      if (!confirm(`Delete “${D().name}” from this phone?`)) return;
      lib.splice(cur, 1); if (!lib.length) lib.push(blank('My design')); openDesign(Math.max(0, cur - 1)); toast('Deleted'); return;
    case 'kturn':
      if (ready) frame.contentWindow.postMessage({ type: 'knob', act: 'turn', vol: 30 + Math.random() * 50 }, '*');
      { const k = $('#knobBig'); k.classList.remove('spin'); void k.offsetWidth; k.classList.add('spin'); }
      return;
    case 'kmatch': edit((d) => { if (d.knob && d.knob.colors) delete d.knob; else { d.knob = { colors: Object.assign({}, knobColorsOf(d)) }; } }, { render: true }); return;
    case 'son': return saveSchedule((sc) => { sc.on = !sc.on; if (sc.on && !sc.rules.length) sc.rules = PRESETS.daynight(); });
    case 'wlook': { const v = !CAR.settings.weather_look; CAR.settings.weather_look = v; render(); const r = await api('POST', '/cmd', { cmd: 'settings', patch: { weather_look: v } }); if (!r.ok) toast(NO_CAR); return; }
    case 'radd': return saveSchedule((sc) => { sc.rules.push({ when: 'night', look: CAR.designs[0] ? `design:${CAR.designs[0].id}` : 'theme:midnight' }); });
    case 'rdel': return saveSchedule((sc) => { sc.rules.splice(+arg, 1); });
    case 'preset': return saveSchedule((sc) => { sc.rules = PRESETS[arg](); sc.on = true; });
    default:
  }
});
panel.addEventListener('input', (e) => {
  const el = e.target;
  if (el.dataset.range) {
    const v = +el.value; paintRange(el);
    const o = el.parentElement.querySelector('output'); if (o) o.textContent = `${v}${el.dataset.unit || ''}`;
    edit((d) => setPath(d, el.dataset.range, v), { drag: true });
  } else if (el.dataset.actRange === 'hue') {
    if (!hueBase) { snapshot(); hueBase = colorsOf(D()); }
    const deg = +el.value;
    edit((d) => { d.colors = shiftHue(deg, hueBase); }, { hist: false });
  } else if (el.dataset.color) {
    edit((d) => setPath(d, el.dataset.color, el.value.toUpperCase()), { drag: true });
    const card = el.closest('.cpick'); card.querySelector('.sw2').style.background = el.value; card.querySelector('span').textContent = el.value.toUpperCase();
  } else if (el.dataset.text) {
    edit((d) => setPath(d, el.dataset.text, el.value), { drag: true });
  } else if (el.id === 'descIn') {
    el.style.height = 'auto'; el.style.height = `${Math.min(120, el.scrollHeight)}px`;
  }
});
let hueBase = null;
panel.addEventListener('change', (e) => {
  const el = e.target;
  dragging = false;
  if (el.dataset.actRange === 'hue') { hueBase = null; render(); }
  if (el.dataset.color) render();
  if (el.dataset.rule) {
    const i = +el.dataset.rule, f = el.dataset.f;
    saveSchedule((sc) => {
      const r = sc.rules[i]; if (!r) return;
      if (f === 'from' || f === 'to') { const [h, m] = el.value.split(':').map(Number); r[f] = h * 60 + m; }
      else { r[f] = el.value; if (f === 'when' && el.value === 'time') { r.from = r.from ?? 420; r.to = r.to ?? 1140; } }
    });
  }
});
panel.addEventListener('keydown', (e) => { if (e.target.id === 'descIn' && e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); makeFromWords(); } });

// ---------------------------------------------------------------- files
$('#photoIn').addEventListener('change', (e) => { const f = e.target.files[0]; e.target.value = ''; if (f) onPhoto(f); });
$('#wallIn').addEventListener('change', async (e) => {
  const f = e.target.files[0]; e.target.value = ''; if (!f) return;
  try { const img = await loadImage(f); const w = wallpaperOf(img); edit((d) => { d.studio.wall = w; d.studio.wallDim = d.studio.wallDim ?? 35; }, { render: true }); }
  catch (er) { toast('Couldn’t read that picture'); }
});
$('#fontIn').addEventListener('change', (e) => {
  const f = e.target.files[0]; e.target.value = ''; if (!f) return;
  if (f.size > 1.5e6) { toast('That font is too big (over 1.5 MB)'); return; }
  const r = new FileReader();
  r.onload = () => edit((d) => { d.studio.fontData = r.result; d.studio.font = 'StudioFont'; }, { render: true });
  r.readAsDataURL(f);
});
$('#fileIn').addEventListener('change', (e) => {
  const f = e.target.files[0]; e.target.value = ''; if (!f) return;
  const r = new FileReader();
  r.onload = () => window.studioImport(r.result);
  r.readAsText(f);
});
window.studioImport = (text) => {
  try {
    const f = JSON.parse(text);
    if (f.format !== 'headunit-design') throw new Error('format');
    lib.push(fromFile(f)); openDesign(lib.length - 1); toast(`Added “${f.name}”`);
  } catch (e) { toast('That isn’t a head unit design file'); }
};
function shareDesign() {
  const json = JSON.stringify(compile(D()), null, 1), name = `${D().name.replace(/[^\w-]+/g, '_')}.headunit.json`;
  if (APP && APP.share) { APP.share(name, json); return; }
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([json], { type: 'application/json' })); a.download = name; a.click();
}

// ---------------------------------------------------------------- save
async function save() {
  const btn = $('#saveBtn'), d = D();
  btn.disabled = true; btn.innerHTML = '<span class="spin-dot"></span>';
  let msg, ok = false;
  if (APP && !APP.request && APP.send) {  // older app: only knows how to send
    msg = await new Promise((res) => { window.studioSent = res; APP.send(JSON.stringify(compile(d))); });
    ok = !/couldn|refused|failed/i.test(msg);
  } else {
    const r = await api('POST', '/design', compile(d));
    ok = r.ok; msg = r.ok ? r.text : r.status ? r.text : NO_CAR;
  }
  btn.disabled = false; btn.innerHTML = 'Save<span class="long"> to car</span>';
  if (ok) { markDirty(false); if (d._src === 'try') { delete d._src; delete d._try; delete d._tryFrom; saveLib(); } refreshCar(); }
  toast(msg);
}

// ---------------------------------------------------------------- refreshing from the car
async function refreshCar() {
  const r = await apiJson('GET', '/designs/full');
  setCarOk(r.ok);
  if (!r.ok || !r.json) { if (tab === 'gallery' || tab === 'schedule') render(); return; }
  CAR.designs = r.json.designs || []; CAR.active = r.json.active; CAR.settings = r.json.settings; CAR.schedule_now = r.json.schedule_now;
  if (tab === 'gallery' || tab === 'schedule') render();
}
async function refreshRequests() {
  const r = await apiJson('GET', '/design/request');
  if (r.ok && r.json) { const had = reqs.length; reqs = r.json.requests || []; if (tab === 'create' && reqs.length !== had) render(); }
}

// ---------------------------------------------------------------- sheet + toast
function sheet(html) { $('#sheet').innerHTML = html; $('#sheet').onclick = null; $('#sheet').classList.remove('hidden'); $('#sheetBg').classList.remove('hidden'); }
function closeSheet() { $('#sheet').classList.add('hidden'); $('#sheetBg').classList.add('hidden'); }
$('#sheetBg').addEventListener('click', closeSheet);
let toastT;
function toast(t) { const el = $('#toast'); el.textContent = t; el.classList.add('show'); clearTimeout(toastT); toastT = setTimeout(() => el.classList.remove('show'), 2600); }
window.studioSent = (m) => toast(m);

// ---------------------------------------------------------------- header
$('#dname').addEventListener('input', (e) => edit((d) => { d.name = e.target.value.slice(0, 60) || 'Untitled'; }, { drag: true }));
$('#dname').addEventListener('change', () => { dragging = false; });
$('#undoBtn').addEventListener('click', undo);
$('#redoBtn').addEventListener('click', redo);
$('#liveBtn').addEventListener('click', () => setLive(!live));
$('#saveBtn').addEventListener('click', save);
addEventListener('pagehide', () => { if (live) stopLive(); });

// ================================================================ start
(async function start() {
  const load = (f) => fetch(`/static/${f}`).then((r) => (r.ok ? r.json() : [])).catch(() => []);
  [THEMES, FACES, GALLERY] = await Promise.all([load('themes.json'), load('knob_faces.json'), load('gallery.json')]);
  if (!Array.isArray(GALLERY)) GALLERY = [];
  loadLib();
  $('#liveBtn').setAttribute('aria-pressed', String(live));
  renderTabs(); renderScreens(); render(); undoState(); fit();
  $('#dname').value = D().name;
  refreshCar(); refreshRequests();
  if (live) sendLive();
  if (ready) { preview(); setTimeout(() => goScreen(screen), 150); }
})();
