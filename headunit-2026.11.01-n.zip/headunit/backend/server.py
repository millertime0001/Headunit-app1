#!/usr/bin/env python3
"""Pi Head Unit backend.

Serves the touch UI and connects it to:
  - Bluetooth music (BlueZ AVRCP): track info and controls
  - Phone calls and the voice assistant (oFono hands-free)
  - The 5-channel audio processor on the DAC8x (PipeWire filter-chain)
  - Google Maps / YouTube Music from the phone (scrcpy virtual display)
  - Weather (Open-Meteo, no API key)
"""
import asyncio
import base64
import glob
import hashlib
import json
import threading
import logging
import math
import os
import re
import signal
import shutil
import struct
import time
import wave
import zipfile
import secrets
import py_compile
from pathlib import Path

from aiohttp import ClientSession, ClientTimeout, WSMsgType, web

try:
    from dbus_next import BusType, Message, MessageType, Variant
    from dbus_next.aio import MessageBus
    from dbus_next.service import ServiceInterface, method
except ImportError:  # lets the UI run on a PC for testing
    MessageBus = None
    ServiceInterface = object

    def method(*_a, **_k):
        return lambda f: f

log = logging.getLogger("headunit")

BASE = Path(__file__).resolve().parent.parent
WEB = BASE / "web"
CONF_DIR = Path.home() / ".config" / "headunit"
SETTINGS_FILE = CONF_DIR / "settings.json"
DESIGN_DIR = CONF_DIR / "designs"          # designs sent from the Design Studio, one JSON file each
DESIGN_ACTIVE = CONF_DIR / "design_active"  # id of the design in use (empty = built-in look)
HEX_COLOR = re.compile(r"^#[0-9a-fA-F]{6}$")
CSS_VAR = re.compile(r"^--[a-zA-Z0-9_-]{1,40}$")


def clean_design(d):
    """Checks a design file from the Studio and keeps only the parts the head unit understands:
    settings (checked later like any settings change), colors, CSS variables and free-form CSS."""
    if not isinstance(d, dict) or d.get("format") != "headunit-design":
        raise UserError("That isn't a head unit design file.")
    name = str(d.get("name") or "Untitled").strip()[:60] or "Untitled"
    out = {"format": "headunit-design", "version": 1, "name": name,
           "settings": d.get("settings") if isinstance(d.get("settings"), dict) else {},
           "colors": None, "vars": {}, "css": ""}
    if isinstance(d.get("colors"), dict):
        cols = {k: v for k, v in d["colors"].items() if k in ("base", "b1", "b2", "b3", "accent")
                and isinstance(v, str) and HEX_COLOR.match(v)}
        if isinstance(d["colors"].get("light"), bool):
            cols["light"] = d["colors"]["light"]
        out["colors"] = cols or None
    if isinstance(d.get("vars"), dict):
        for k, v in list(d["vars"].items())[:200]:
            if CSS_VAR.match(str(k)) and isinstance(v, (str, int, float)):
                v = str(v)
                if len(v) <= 400 and not re.search(r"[;{}<>]", v):
                    out["vars"][k] = v
    css = d.get("css") or ""
    if not isinstance(css, str):
        css = ""
    if len(css) > 6_000_000:
        raise UserError("That design is too big (wallpaper images should be under about 4 MB).")
    out["css"] = re.sub(r"</\s*style", "", css, flags=re.I)
    k = d.get("knob")
    if isinstance(k, dict) and isinstance(k.get("colors"), dict):
        kc = {c: v for c, v in k["colors"].items() if c in ("accent", "base", "text", "b1", "b2", "b3")
              and isinstance(v, str) and HEX_COLOR.match(v)}
        if kc:
            out["knob"] = {"colors": kc}
    for key, n in (("author", 40), ("desc", 200)):
        if isinstance(d.get(key), str) and d[key].strip():
            out[key] = d[key].strip()[:n]
    did = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")[:40] or "design"
    out["id"] = did
    return out
FAVORITES_FILE = CONF_DIR / "favorites.json"
TMP = CONF_DIR / "tmp"
PORT = 8080

DEFAULTS = {
    "theme": "aurora",
    "animate": True,
    "glow": True,
    "brightness": 100,
    "brightness_last": 100,
    "use_ddc": False,
    "night_dim": False,
    "night_level": 25,
    "audio": {"volume": 40, "fader": 0, "balance": 0, "sub": 0, "xover": 80,
              "bass": 0, "mid": 0, "treble": 0, "call_volume": 70, "assistant_volume": 60},
    "music_pins": [],
    "favorites": [
        {"name": "Mom", "number": ""},
        {"name": "Work", "number": ""},
    ],
    "recents": [],
    "location": {"lat": None, "lon": None, "units": "fahrenheit"},
    "bt_name": "Pi Head Unit",
    "speed_units": "auto",
    "knob_style": "aurora",
    "knob_top": "clock",
    "effect": "blobs",
    "motion": "lively",
    "glass": {"opacity": 22, "blur": 30, "depth": 70, "shine": 70, "tint": "theme",
              "edge": True, "textshadow": True, "tilt": True},
    "ui_scale": 100,
    "nav": "left",
    "home_layout": "dashboard",
    "home_cards": {"dashboard": ["music", "nav"], "cockpit": ["nav", "speed", "music"],
                   "focus": ["music", "speed", "weather"], "grid": ["music", "nav", "speed", "clock"],
                   "duo": ["art", "speed"]},
    "header": True,
    "quick": True,
    "maps_panel": True,
    "transition": "depth",
    "speedo": "sport",
    "clock_style": "thin",
    "app_size": "medium",
    "display_mode": "",
    "clock_24h": False,
    "obd": {},  # the OBD adapter: {addr, name, kind: bt | ble}
    "gauges": {"layout": "quad", "slots": ["tach", "speed", "fuel", "coolant", "volts", "mpg"]},
    "look_schedule": {"on": False, "rules": []},
    "tank": 185,  # fuel tank in tenths of a gallon (a 2011 Outback holds 18.5)
    "rain_glass": False,
    "rain_amount": "steady",
}

# Shared with the touch UI (web/themes.json) and the knob firmware (web/knob_faces.json, same order)
try:
    THEMES = json.loads((WEB / "themes.json").read_text())
except Exception:
    THEMES = [{"id": "aurora", "base": "#05070B", "b1": "#14B8A6", "b2": "#7C3AED", "b3": "#0EA5E9", "accent": "#5EEAD4"}]
try:
    KNOB_STYLES = tuple(f["id"] for f in json.loads((WEB / "knob_faces.json").read_text()))
except Exception:
    KNOB_STYLES = ("aurora", "gauge", "neon", "minimal", "speed")
THEME_COLORS = {  # accent, background, text, blob 1, blob 2, blob 3 for the knob
    t["id"]: tuple(c.lstrip("#").upper() for c in (t["accent"], t["base"], "#0B1220" if t.get("light") else "#F5F7FA",
                                                   t["b1"], t["b2"], t["b3"]))
    for t in THEMES
}
LAYOUT_SLOTS = {"dashboard": 2, "cockpit": 3, "focus": 3, "grid": 4, "duo": 2, "minimal": 0, "free": 0,
                "wide": 3, "strip": 4, "sidebar": 4, "bento": 4, "mosaic": 5, "cinema": 3, "cluster": 3,
                "orbit": 5, "hive": 5, "wall": 3, "scatter": 4, "angled": 3, "split": 2}
CARD_TYPES = ("music", "nav", "speed", "weather", "clock", "favs", "controls", "viz", "art", "maps", "engine",
              "g_tach", "g_speed", "g_fuel", "g_coolant", "g_volts", "g_mpg", "g_intake", "g_load", "g_throttle")
GAUGE_TYPES = ("tach", "speed", "fuel", "coolant", "volts", "mpg", "intake", "load", "throttle")
GAUGE_LAYOUTS = {"duo": 2, "trio": 3, "quad": 4, "six": 6}
EFFECTS = ("blobs", "liquid", "aurora", "nebula", "road", "warp", "grid", "tunnel", "rain", "bokeh",
           "particles", "fireflies", "waves", "hex", "matrix",
           "slime", "goo", "plasma", "embers", "snow", "storm", "pond", "circuit", "galaxy", "smoke",
           "petals", "lasers", "skyline", "dna", "radar", "kaleido", "fireworks", "underwater", "window", "off")
APP_SIZE_FACTOR = {"small": 0.85, "medium": 1.0, "large": 1.2, "xl": 1.45}

# What the touch screen may change, and the allowed values
SCHEMA = {
    "theme": ("enum", tuple(THEME_COLORS)),
    "animate": ("bool",), "glow": ("bool",), "use_ddc": ("bool",), "header": ("bool",),
    "quick": ("bool",), "maps_panel": ("bool",), "night_dim": ("bool",), "clock_24h": ("bool",),
    "speed_units": ("enum", ("auto", "mph", "kmh")),
    "knob_style": ("enum", KNOB_STYLES),
    "knob_top": ("enum", ("clock", "speed")),
    "effect": ("enum", EFFECTS),
    "motion": ("enum", ("calm", "lively", "wild")),
    "nav": ("enum", ("left", "right", "dock")),
    "home_layout": ("enum", tuple(LAYOUT_SLOTS)),
    "transition": ("enum", ("depth", "slide", "flip", "fade", "none")),
    "speedo": ("enum", ("sport", "arc", "hud", "ring")),
    "clock_style": ("enum", ("thin", "bold", "outline", "glow")),
    "button_fx": ("enum", ("glass", "neon", "holo", "liquid", "chrome", "pulse")),
    "style": ("enum", ("glass", "carbon", "synth", "minimal", "hud", "lux", "rally", "soft", "pop", "sea", "paper", "holo", "slime", "rainy")),
    "knob_ripple": ("bool",),
    "ripple_from": ("enum", ("bottom", "right", "left", "center")),
    "knob_x": ("int", 0, 100),
    "ripple_style": ("enum", ("waves", "shock", "aurora", "sparks", "edge", "rain", "liquid", "curtain", "bars")),
    "ripple_power": ("int", 20, 100),
    "ripple_edge": ("bool",),
    "ripple_hud": ("bool",),
    "splash_style": ("enum", ("warp", "hyper", "plasma", "ignition", "chrome", "dawn")),
    "splash_knob": ("bool",),
    "splash_text": ("str", 24),
    "app_size": ("enum", tuple(APP_SIZE_FACTOR)),
    "ui_scale": ("int", 70, 140),
    "night_level": ("int", 1, 100),
    "app_view": ("enum", ("page", "window")),      # Maps drawn inside the page (rounded, layered) or as its own window
    "map_only": ("bool",),                         # Home card: crop Maps' search bar and bottom buttons off
    "map_crop_top": ("int", 0, 240),               # how much to crop, in Android dp
    "map_crop_bottom": ("int", 0, 200),
    "map_bg": ("bool",),                           # live Google Maps behind the Home screen
    "map_dim": ("int", 0, 90),                     # how much darker the background map is (%)
    "map_glass": ("enum", ("frost", "tint")),
    "rain_over": ("bool",),
    "rain_glass": ("bool",),                       # rain on the glass over any theme and background
    "weather_look": ("bool",),                     # theme and background follow the weather
    "rain_amount": ("enum", ("light", "steady", "heavy")),
    "tank": ("int", 50, 400),                        # Rainy window: drops also run down over the tiles      # frosted tiles over the map, or lighter tinted ones
}
GLASS_SCHEMA = {"opacity": ("int", 0, 100), "blur": ("int", 0, 60), "depth": ("int", 0, 100),
                "shine": ("int", 0, 100), "tint": ("enum", ("theme", "clear", "smoke")),
                "edge": ("bool",), "textshadow": ("bool",), "tilt": ("bool",)}


def check(rule, v):
    """Returns the cleaned value, or raises ValueError."""
    kind = rule[0]
    if kind == "bool":
        return bool(v)
    if kind == "int":
        return int(clamp(int(round(float(v))), rule[1], rule[2]))
    if kind == "str":
        v = re.sub(r"[<>\n\r]", "", str(v)).strip()[:rule[1]]
        if v:
            return v
        raise ValueError(v)
    if kind == "enum":
        if v in rule[1]:
            return v
        raise ValueError(v)
    raise ValueError(kind)


def migrate(settings):
    """Carries settings from the first version of the UI over to the new names."""
    old = settings.pop("layout", None)
    if isinstance(old, dict):
        if old.get("rail") in ("left", "right"):
            settings["nav"] = old["rail"]
        if isinstance(old.get("home"), list) and len(old["home"]) == 2:
            settings["home_cards"]["dashboard"] = [c if c in CARD_TYPES else "music" for c in old["home"]]
        for k, new in (("header", "header"), ("quick", "quick")):
            if k in old:
                settings[new] = bool(old[k])
        if "maps" in old:
            settings["maps_panel"] = old["maps"] == "panel"
    for k in ("screen", "app_dpi", "blur"):
        settings.pop(k, None)
    if settings.get("theme") not in THEME_COLORS:
        settings["theme"] = "aurora"
    if settings.get("knob_style") not in KNOB_STYLES:
        settings["knob_style"] = "aurora"
    if "home_grid" not in settings:  # freeform Home went from 6 x 4 squares to 12 x 8: same layout, finer steps
        for c in settings.get("home_tiles") or []:
            for k in ("x", "y", "w", "h"):
                if isinstance(c.get(k), int):
                    c[k] *= 2
        settings["home_grid"] = 12
    return settings

AUDIO_LIMITS = {"volume": (0, 100), "fader": (-10, 10), "balance": (-10, 10),
                "sub": (-12, 12), "xover": (40, 160), "bass": (-10, 10),
                "mid": (-10, 10), "treble": (-10, 10), "call_volume": (0, 100), "assistant_volume": (0, 100)}
VOLUME_KEY = {"call": "call_volume", "assistant": "assistant_volume"}  # which volume the knob and speakers use


def clamp(v, lo, hi):
    return max(lo, min(hi, v))


def deep_merge(base, extra):
    out = json.loads(json.dumps(base))
    for k, v in (extra or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = deep_merge(out[k], v)
        else:
            out[k] = v
    return out


async def run(*args, timeout=10):
    """Run a command, return (returncode, stdout, stderr). Never raises."""
    try:
        proc = await asyncio.create_subprocess_exec(
            *args, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
    except FileNotFoundError:
        return 127, "", f"{args[0]} is not installed"
    try:
        out, err = await asyncio.wait_for(proc.communicate(), timeout)
    except asyncio.TimeoutError:
        proc.kill()
        return 124, "", "timed out"
    return proc.returncode, out.decode(errors="replace"), err.decode(errors="replace")


# --------------------------------------------------------------------------- hub
class Hub:
    def __init__(self):
        CONF_DIR.mkdir(parents=True, exist_ok=True)
        TMP.mkdir(parents=True, exist_ok=True)
        saved = {}
        if SETTINGS_FILE.exists():
            try:
                saved = json.loads(SETTINGS_FILE.read_text())
            except Exception:
                log.exception("settings.json is not valid JSON; using defaults")
        self.settings = migrate(deep_merge(DEFAULTS, saved))
        self.clients = set()
        self.phone_ws = None    # the phone app's connection: gets commands, not the screen's state
        self.queue = None       # "Up next" from the phone, sent to screens on its own (it can be large)
        self.library = None     # the YouTube Music list being browsed
        self.state = {
            "version": read_version(),  # the screen reloads itself when this changes after an update
            "phone": {"connected": False, "name": None},
            "media": {"available": False, "title": "", "artist": "", "album": "",
                      "status": "stopped", "position": 0, "duration": 0, "at": 0},
            "call": {"available": False, "state": None, "name": "", "number": "",
                     "since": None, "muted": False},
            "weather": None,
            "app": {"current": None, "status": "idle", "message": ""},
            "app_rect": None,
            "voice": None,          # "call" or "assistant" while the phone's voice audio is playing
            "display": None,
            "adb": {"mode": None, "serial": None},
            "companion": {"connected": False, "name": None, "seen": 0},
            "nav": {"active": False, "title": "", "text": "", "sub": "", "icon": None},
            "art": None,
            "knob": {"connected": False},
            "obd": {"status": "off", "message": "", "name": None, "data": {}, "found": [], "scanning": False,
                    "codes": None, "pids": []},
            "speed": None,
            "audio": {"ready": False, "message": "Starting the audio processor…", "testing": None},
            "bt": {"discoverable": False, "available": MessageBus is not None},
            "hotspot": self._hotspot(),
            "settings": self.settings,
            "design": None,      # the design in use (colors, CSS variables, CSS), or None for the built-in look
            "designs": [],       # [{id, name}] of every design on the head unit
            "design_preview": None,  # a design being edited in the Theme Studio, shown live but not saved
            "schedule_now": None,    # which look the schedule picked ("design:<id>" / "theme:<id>")
        }
        self.preview_at = 0
        self.sched_key = None
        self._pending = False
        self._save_handle = None
        self.dbus = Dbus()
        self.bt = Bluetooth(self)
        self.calls = Calls(self)
        self.audio = Audio(self)
        self.apps = Apps(self)
        self.weather = Weather(self)
        self.knob = Knob(self)
        self.display = Display(self)
        self.obd = Obd(self)

    @staticmethod
    def _hotspot():
        try:
            return json.loads((CONF_DIR / "hotspot.json").read_text())
        except Exception:
            return None

    def start(self):
        if MessageBus:
            asyncio.create_task(self.bt.loop())
            asyncio.create_task(self.calls.loop())
            asyncio.create_task(self.obd.loop())
        asyncio.create_task(self.audio.loop())
        asyncio.create_task(self.weather.loop())
        asyncio.create_task(self.favorites_loop())
        asyncio.create_task(self.apps.link_loop())
        self.knob.start()
        asyncio.create_task(self.display.loop())
        asyncio.create_task(self.look_loop())

    async def look_loop(self):
        """Clears a Theme Studio preview the phone stopped updating, and runs the look schedule."""
        while True:
            try:
                if self.state["design_preview"] and time.time() - self.preview_at > 150:
                    self.state["design_preview"] = None
                    self.changed()
                self.run_schedule()
            except Exception:
                log.exception("look loop")
            await asyncio.sleep(10)

    def schedule_match(self):
        sc = self.settings.get("look_schedule") or {}
        if not sc.get("on"):
            return None
        w = self.state.get("weather") or {}
        try:
            code = int(w["code"])
        except (KeyError, TypeError, ValueError):
            code = -1
        lt = time.localtime()
        day = w.get("day") if isinstance(w.get("day"), bool) else 7 <= lt.tm_hour < 19
        now = lt.tm_hour * 60 + lt.tm_min
        for i, r in enumerate(sc.get("rules") or []):
            wh = r.get("when")
            if wh == "time":
                a, b = r.get("from", 0), r.get("to", 0)
                ok = a <= now < b if a <= b else (now >= a or now < b)
            else:
                ok = {"day": day, "night": not day,
                      "rain": code in range(51, 68) or code in range(80, 83),
                      "snow": code in range(71, 78) or code in (85, 86),
                      "storm": code in range(95, 100), "fog": code in (45, 48),
                      "clear": code in (0, 1), "cloudy": code in (2, 3)}.get(wh, False)
            if ok:
                return i, r.get("look")
        return None

    def run_schedule(self):
        """Switches the look when a different schedule rule starts to apply (not every check, so a look
        picked by hand stays until the next change)."""
        m = self.schedule_match()
        key = f"{m[0]}:{m[1]}" if m else None
        if self.state.get("schedule_now") != (m[1] if m else None):
            self.state["schedule_now"] = m[1] if m else None
            self.changed()
        if key == self.sched_key:
            return
        self.sched_key = key
        if m and m[1]:
            log.info("look schedule: %s", m[1])
            asyncio.create_task(self.use_look(m[1]))

    async def use_look(self, ref):
        kind, _, val = str(ref).partition(":")
        try:
            if kind == "design":
                await self.design_use(val)
            elif kind == "theme" and val in THEME_COLORS:
                await self.design_use(None)
                await handle(self, {"cmd": "settings", "patch": {"theme": val}}, None)
        except UserError as e:
            log.info("look %s: %s", ref, e)

    def design_preview(self, d):
        """Shows a design on the screen and knob while it's being edited, without saving anything."""
        if not d:
            self.state["design_preview"] = None
            self.changed()
            return
        cd = clean_design(d)
        sets = {}
        for k, v in (cd.get("settings") or {}).items():
            if k == "glass" and isinstance(v, dict):
                g = dict(self.settings.get("glass") or {})
                for gk, gv in v.items():
                    if gk in GLASS_SCHEMA:
                        try:
                            g[gk] = check(GLASS_SCHEMA[gk], gv)
                        except (ValueError, TypeError):
                            pass
                sets["glass"] = g
            elif k in SCHEMA and k not in ("brightness", "use_ddc", "tank", "weather_look"):
                try:
                    sets[k] = check(SCHEMA[k], v)
                except (ValueError, TypeError):
                    pass
        self.state["design_preview"] = {"id": "preview", "name": cd["name"], "colors": cd["colors"], "vars": cd["vars"],
                                        "css": cd["css"], "knob": cd.get("knob"), "settings": sets}
        self.preview_at = time.time()
        self.changed()

    async def favorites_loop(self):
        """favorites.json is easy to hand-edit; reload it whenever it changes."""
        if not FAVORITES_FILE.exists():
            FAVORITES_FILE.write_text(json.dumps(self.settings["favorites"], indent=2))
        mtime = None
        while True:
            try:
                m = FAVORITES_FILE.stat().st_mtime
                if m != mtime:
                    mtime = m
                    favs = json.loads(FAVORITES_FILE.read_text())
                    self.settings["favorites"] = [{"name": str(f.get("name", "")), "number": str(f.get("number", ""))}
                                                  for f in favs if isinstance(f, dict)]
                    self.changed()
            except Exception as e:
                log.warning("favorites.json: %s", e)
            await asyncio.sleep(5)

    def changed(self):
        if self._pending:
            return
        self._pending = True
        asyncio.get_running_loop().call_later(0.05, lambda: asyncio.create_task(self._flush()))

    async def _flush(self):
        self._pending = False
        self.knob.push()
        msg = json.dumps({"type": "state", "state": self.state})
        for ws in list(self.clients):
            if ws is self.phone_ws:
                continue
            try:
                await ws.send_str(msg)
            except Exception:
                self.clients.discard(ws)

    async def broadcast_raw(self, msg):
        """Sends one message to every screen (not the phone app)."""
        text = json.dumps(msg)
        for ws in list(self.clients):
            if ws is self.phone_ws:
                continue
            try:
                await ws.send_str(text)
            except Exception:
                self.clients.discard(ws)

    async def broadcast(self, kind, payload):
        msg = json.dumps({"type": kind, kind: payload})
        for ws in list(self.clients):
            if ws is self.phone_ws:
                continue
            try:
                await ws.send_str(msg)
            except Exception:
                self.clients.discard(ws)

    async def to_phone(self, do, **kw):
        ws = self.phone_ws
        if ws is None or ws.closed:
            raise UserError("The phone app isn't connected. Open Head Unit Link on your phone.")
        await ws.send_str(json.dumps({"type": "phone_cmd", "do": do, **kw}))

    async def set_voice(self, mode):
        """Calls and the voice assistant get their own volume, separate from music."""
        if self.state["voice"] == mode:
            return
        was, self.state["voice"] = self.state["voice"], mode
        log.info("voice audio: %s -> %s", was, mode)
        self.audio.watch("call" if mode == "call" or was == "call" else "assistant")
        await self.audio.apply_volume()
        self.changed()
        if was and not mode:
            # the phone has handed the audio back to music: make sure it comes back on the right path
            asyncio.create_task(self.audio.repair_later())

    def save(self):
        if self._save_handle:
            self._save_handle.cancel()
        self._save_handle = asyncio.get_running_loop().call_later(1.0, self._write)

    # ------------------------------------------------------------------ designs
    def load_designs(self):
        """Reads the design list and the active design at startup."""
        DESIGN_DIR.mkdir(parents=True, exist_ok=True)
        self.state["designs"] = []
        for f in sorted(DESIGN_DIR.glob("*.json")):
            try:
                d = json.loads(f.read_text())
                self.state["designs"].append({"id": f.stem, "name": d.get("name", f.stem), "author": d.get("author")})
            except Exception:
                log.warning("skipping unreadable design %s", f)
        try:
            active = DESIGN_ACTIVE.read_text().strip()
        except OSError:
            active = ""
        self.state["design"] = self._design_live(active) if active else None

    def _design_live(self, did):
        f = DESIGN_DIR / f"{did}.json"
        if not re.fullmatch(r"[a-z0-9-]{1,40}", did or "") or not f.exists():
            return None
        d = json.loads(f.read_text())
        return {"id": did, "name": d.get("name", did), "colors": d.get("colors"), "vars": d.get("vars", {}), "css": d.get("css", ""),
                "knob": d.get("knob")}

    async def design_add(self, d):
        """Saves a design from the Studio and switches to it (its settings are applied like a normal change)."""
        d = clean_design(d)
        DESIGN_DIR.mkdir(parents=True, exist_ok=True)
        (DESIGN_DIR / f"{d['id']}.json").write_text(json.dumps(d))
        self.state["designs"] = [x for x in self.state["designs"] if x["id"] != d["id"]] + \
            [{"id": d["id"], "name": d["name"], "author": d.get("author")}]
        self.state["design_preview"] = None
        await self.design_use(d["id"])
        return d["name"]

    async def design_use(self, did):
        if did:
            live = self._design_live(did)
            if not live:
                raise UserError("That design isn't on the head unit anymore.")
            d = json.loads((DESIGN_DIR / f"{did}.json").read_text())
            if d.get("settings"):
                await handle(self, {"cmd": "settings", "patch": d["settings"]}, None)
            self.state["design"] = live
        else:
            self.state["design"] = None
        DESIGN_ACTIVE.write_text(did or "")
        write_splash(self)
        self.changed()

    async def design_delete(self, did):
        f = DESIGN_DIR / f"{did}.json"
        if re.fullmatch(r"[a-z0-9-]{1,40}", did or "") and f.exists():
            f.unlink()
        self.state["designs"] = [x for x in self.state["designs"] if x["id"] != did]
        if self.state["design"] and self.state["design"]["id"] == did:
            await self.design_use(None)
        self.changed()

    def _write(self):
        tmp = SETTINGS_FILE.with_suffix(".tmp")
        tmp.write_text(json.dumps(self.settings, indent=2))
        tmp.replace(SETTINGS_FILE)

    def lookup_name(self, number):
        digits = re.sub(r"\D", "", number or "")[-10:]
        if not digits:
            return None
        for f in self.settings.get("favorites", []):
            if re.sub(r"\D", "", f.get("number", ""))[-10:] == digits:
                return f.get("name")
        return None


# -------------------------------------------------------------------------- dbus
class DbusError(Exception):
    def __init__(self, name, body):
        super().__init__(f"{name}: {body}")
        self.name = name


def unwrap(v):
    if MessageBus and isinstance(v, Variant):
        return unwrap(v.value)
    if isinstance(v, dict):
        return {k: unwrap(x) for k, x in v.items()}
    if isinstance(v, list):
        return [unwrap(x) for x in v]
    return v


class Dbus:
    def __init__(self):
        self.bus = None
        self.lock = asyncio.Lock()

    async def get(self):
        async with self.lock:
            if self.bus is None or not self.bus.connected:
                self.bus = await MessageBus(bus_type=BusType.SYSTEM).connect()
            return self.bus

    async def call(self, dest, path, iface, member, sig="", body=None):
        bus = await self.get()
        reply = await bus.call(Message(destination=dest, path=path, interface=iface,
                                       member=member, signature=sig, body=body or []))
        if reply.message_type == MessageType.ERROR:
            raise DbusError(reply.error_name, reply.body)
        return unwrap(reply.body)

    async def set_prop(self, dest, path, iface, name, sig, value):
        return await self.call(dest, path, "org.freedesktop.DBus.Properties", "Set", "ssv",
                               [iface, name, Variant(sig, value)])


# --------------------------------------------------------------------- bluetooth
class PairingAgent(ServiceInterface):
    """Accepts pairing from the phone with no prompts and marks it trusted, like a car stereo."""

    def __init__(self, bt):
        super().__init__("org.bluez.Agent1")
        self.bt = bt

    def _ok(self, device):
        asyncio.get_running_loop().create_task(self.bt.trust(device))

    @method()
    def Release(self):
        pass

    @method()
    def RequestPinCode(self, device: "o") -> "s":
        self._ok(device)
        return self.bt.pins.get(device, "0000")

    @method()
    def DisplayPinCode(self, device: "o", pincode: "s"):
        pass

    @method()
    def RequestPasskey(self, device: "o") -> "u":
        self._ok(device)
        return 0

    @method()
    def DisplayPasskey(self, device: "o", passkey: "u", entered: "q"):
        pass

    @method()
    def RequestConfirmation(self, device: "o", passkey: "u"):
        self._ok(device)

    @method()
    def RequestAuthorization(self, device: "o"):
        self._ok(device)

    @method()
    def AuthorizeService(self, device: "o", uuid: "s"):
        self._ok(device)

    @method()
    def Cancel(self):
        pass


class Bluetooth:
    def __init__(self, hub):
        self.hub = hub
        self.adapter = "/org/bluez/hci0"
        self.player = None
        self.ready = False
        self.pins = {}  # device path -> PIN to offer when it asks (OBD adapters want 1234 or 0000)

    async def setup(self):
        d = self.hub.dbus
        await d.set_prop("org.bluez", self.adapter, "org.bluez.Adapter1", "Powered", "b", True)
        await d.set_prop("org.bluez", self.adapter, "org.bluez.Adapter1", "Alias", "s",
                         self.hub.settings.get("bt_name", "Pi Head Unit"))
        await d.set_prop("org.bluez", self.adapter, "org.bluez.Adapter1", "Pairable", "b", True)
        bus = await d.get()
        if not getattr(self, "agent", None):
            self.agent = PairingAgent(self)
            bus.export("/headunit/agent", self.agent)
        try:
            await d.call("org.bluez", "/org/bluez", "org.bluez.AgentManager1", "UnregisterAgent", "o", ["/headunit/agent"])
        except Exception:
            pass
        await d.call("org.bluez", "/org/bluez", "org.bluez.AgentManager1", "RegisterAgent", "os",
                     ["/headunit/agent", "NoInputNoOutput"])
        await d.call("org.bluez", "/org/bluez", "org.bluez.AgentManager1", "RequestDefaultAgent", "o",
                     ["/headunit/agent"])
        log.info("bluetooth pairing agent ready")
        self.ready = True

    async def trust(self, device):
        try:
            await self.hub.dbus.set_prop("org.bluez", device, "org.bluez.Device1", "Trusted", "b", True)
        except Exception as e:
            log.info("trust %s: %s", device, e)

    async def loop(self):
        while True:
            try:
                if not self.ready:
                    await self.setup()
                await self.poll()
            except Exception as e:
                log.warning("bluetooth: %s", e)
                self.ready = False
                await asyncio.sleep(3)
            await asyncio.sleep(1)

    async def poll(self):
        (objs,) = await self.hub.dbus.call("org.bluez", "/", "org.freedesktop.DBus.ObjectManager",
                                           "GetManagedObjects")
        phone = None
        player = None
        discoverable = False
        obd_addr = (self.hub.settings.get("obd") or {}).get("addr")
        for path, ifaces in objs.items():
            ad = ifaces.get("org.bluez.Adapter1")
            if ad and path == self.adapter:
                discoverable = bool(ad.get("Discoverable"))
            dev = ifaces.get("org.bluez.Device1")
            if dev and dev.get("Paired") and not dev.get("Trusted"):
                await self.trust(path)
            if dev and dev.get("Connected") and dev.get("Address") != obd_addr:
                phone = dev.get("Alias") or dev.get("Name") or "Phone"
            mp = ifaces.get("org.bluez.MediaPlayer1")
            if mp:
                player = (path, mp)
        self._tick = getattr(self, "_tick", 0) + 1
        if self._tick % 30 == 0:  # stay the default pairing helper even if the desktop starts its own
            try:
                await self.hub.dbus.call("org.bluez", "/org/bluez", "org.bluez.AgentManager1",
                                         "RequestDefaultAgent", "o", ["/headunit/agent"])
            except Exception:
                pass
        st = self.hub.state
        st["phone"] = {"connected": phone is not None, "name": phone}
        st["bt"]["discoverable"] = discoverable
        if player:
            self.player = player[0]
            mp = player[1]
            track = mp.get("Track") or {}
            old = st.get("media") or {}
            if (track.get("Title") or "") != old.get("title") or (mp.get("Status") or "stopped") != old.get("status"):
                self.hub.audio.watch("song change")  # the phone often restarts its stream here
            st["media"] = {
                "available": True,
                "title": track.get("Title") or "",
                "artist": track.get("Artist") or "",
                "album": track.get("Album") or "",
                "status": mp.get("Status") or "stopped",
                "position": int(mp.get("Position") or 0),
                "duration": int(track.get("Duration") or 0),
                "at": time.time(),
            }
        else:
            self.player = None
            st["media"] = dict(st["media"], available=False, status="stopped")
        self.hub.changed()

    async def media(self, action):
        member = {"play": "Play", "pause": "Pause", "next": "Next", "previous": "Previous"}.get(action)
        if not member:
            return
        if not self.player:
            raise UserError("No music player found. Connect your phone over Bluetooth and start playing music.")
        await self.hub.dbus.call("org.bluez", self.player, "org.bluez.MediaPlayer1", member)

    async def make_discoverable(self):
        d = self.hub.dbus
        await d.set_prop("org.bluez", self.adapter, "org.bluez.Adapter1", "DiscoverableTimeout", "u", 180)
        await d.set_prop("org.bluez", self.adapter, "org.bluez.Adapter1", "Discoverable", "b", True)


# ------------------------------------------------------------------------- calls
class Calls:
    def __init__(self, hub):
        self.hub = hub
        self.modem = None
        self.call_path = None
        self.info = None

    async def loop(self):
        while True:
            try:
                await self.poll()
                await asyncio.sleep(0.5)
            except DbusError as e:
                if "ServiceUnknown" in e.name or "NameHasNoOwner" in e.name:
                    self.hub.state["call"]["available"] = False
                    self.hub.changed()
                else:
                    log.warning("calls: %s", e)
                await asyncio.sleep(3)
            except Exception as e:
                log.warning("calls: %s", e)
                await asyncio.sleep(3)

    async def poll(self):
        d = self.hub.dbus
        (modems,) = await d.call("org.ofono", "/", "org.ofono.Manager", "GetModems")
        hfp = [(p, props) for p, props in modems if props.get("Type") == "hfp"]
        hfp.sort(key=lambda m: not m[1].get("Online"))
        call_state = self.hub.state["call"]
        if not hfp:
            self.modem = None
            call_state["available"] = False
            await self._update_calls([])
            return
        path, props = hfp[0]
        if not props.get("Powered"):
            await d.call("org.ofono", path, "org.ofono.Modem", "SetProperty", "sv", ["Powered", Variant("b", True)])
            return
        if not props.get("Online"):
            await d.call("org.ofono", path, "org.ofono.Modem", "SetProperty", "sv", ["Online", Variant("b", True)])
            return
        self.modem = path
        call_state["available"] = True
        (calls,) = await d.call("org.ofono", path, "org.ofono.VoiceCallManager", "GetCalls")
        await self._update_calls(calls)
        mode = None
        if any(c[1].get("State") != "disconnected" for c in calls):
            mode = "call"
        else:
            try:
                (hf,) = await d.call("org.ofono", path, "org.ofono.Handsfree", "GetProperties")
                if hf.get("VoiceRecognition"):
                    mode = "assistant"
            except DbusError:
                pass
        await self.hub.set_voice(mode)

    async def _update_calls(self, calls):
        hub = self.hub
        cs = hub.state["call"]
        order = {"incoming": 0, "waiting": 1, "active": 2, "dialing": 3, "alerting": 4, "held": 5}
        calls = [c for c in calls if c[1].get("State") != "disconnected"]
        calls.sort(key=lambda c: order.get(c[1].get("State"), 9))
        if calls:
            path, p = calls[0]
            state = p.get("State")
            number = p.get("LineIdentification") or ""
            name = hub.lookup_name(number) or p.get("Name") or number or "Unknown caller"
            if path != self.call_path:
                self.call_path = path
                self.info = {"number": number, "name": name, "answered": False,
                             "kind": "incoming" if state in ("incoming", "waiting") else "outgoing"}
            if state == "active" and not self.info["answered"]:
                self.info["answered"] = True
                cs["since"] = time.time()
            muted = cs.get("muted", False)
            try:
                (vol,) = await hub.dbus.call("org.ofono", self.modem, "org.ofono.CallVolume", "GetProperties")
                muted = bool(vol.get("Muted"))
            except Exception:
                pass
            was = cs.get("state")
            cs.update(state=state, number=number, name=name, muted=muted)
            if state != "active":
                cs["since"] = cs["since"] if self.info["answered"] else None
            if state in ("incoming", "waiting", "dialing") and was not in ("incoming", "waiting", "dialing", "active", "alerting"):
                await hub.apps.suspend_for_call()
        else:
            if self.call_path and self.info:
                kind = self.info["kind"]
                if kind == "incoming" and not self.info["answered"]:
                    kind = "missed"
                recent = {"name": self.info["name"], "number": self.info["number"], "kind": kind,
                          "time": time.time()}
                hub.settings["recents"] = ([recent] + hub.settings.get("recents", []))[:30]
                hub.save()
                self.call_path = None
                self.info = None
                cs.update(state=None, number="", name="", since=None, muted=False)
                await hub.apps.resume_after_call()
        hub.changed()

    def _need_modem(self):
        if not self.modem:
            raise UserError("Calls aren't connected. Pair your phone in Settings and allow call access.")

    async def dial(self, number):
        self._need_modem()
        number = re.sub(r"[^0-9+*#]", "", number or "")
        if not number:
            raise UserError("Enter a number first.")
        await self.hub.dbus.call("org.ofono", self.modem, "org.ofono.VoiceCallManager", "Dial", "ss",
                                 [number, "default"])

    async def answer(self):
        if self.call_path:
            await self.hub.dbus.call("org.ofono", self.call_path, "org.ofono.VoiceCall", "Answer")

    async def hangup(self):
        if self.call_path:
            await self.hub.dbus.call("org.ofono", self.call_path, "org.ofono.VoiceCall", "Hangup")
        elif self.modem:
            await self.hub.dbus.call("org.ofono", self.modem, "org.ofono.VoiceCallManager", "HangupAll")

    async def mute(self):
        self._need_modem()
        muted = not self.hub.state["call"].get("muted")
        await self.hub.dbus.call("org.ofono", self.modem, "org.ofono.CallVolume", "SetProperty", "sv",
                                 ["Muted", Variant("b", muted)])
        self.hub.state["call"]["muted"] = muted
        self.hub.changed()

    async def assistant(self):
        self._need_modem()
        await self.hub.set_voice("assistant")  # turn its volume to the assistant level before it speaks
        await self.hub.dbus.call("org.ofono", self.modem, "org.ofono.Handsfree", "SetProperty", "sv",
                                 ["VoiceRecognition", Variant("b", True)])


# ------------------------------------------------------------------------- audio
class Audio:
    """Keeps the PipeWire processor (hu_dsp) wired to the DAC8x and applies settings."""
    TEST = [("fl", "Front left", 440), ("fr", "Front right", 440), ("rl", "Rear left", 440),
            ("rr", "Rear right", 440), ("sub", "Subwoofer", 50)]

    def __init__(self, hub):
        self.hub = hub
        self.dsp_id = None
        self.target = None
        self.dirty = False
        self.applying = False
        self.testing = False
        self.watch_until = 0      # check often until this time (after a song change, volume change, call...)
        self.watch_kick = asyncio.Event()
        self.pushed = {}          # the processor's settings as last sent, so only real changes are sent
        self.vol_target = None    # newest volume asked for; one worker sends it, skipping stale in-between values
        self.vol_busy = False

    def status(self, ready, message=""):
        a = self.hub.state["audio"]
        if a["ready"] != ready or a["message"] != message:
            a["ready"], a["message"] = ready, message
            self.hub.changed()

    async def loop(self):
        while True:
            ok = False
            try:
                ok = await self.ensure()
            except Exception as e:
                log.warning("audio: %s", e)
            # every 2 s for half a minute after anything that can upset the sound path, otherwise every 8 s
            fast = time.time() < self.watch_until
            try:
                await asyncio.wait_for(self.watch_kick.wait(), 2 if fast else 8)
                await asyncio.sleep(0.8)  # give the phone a moment to finish switching
            except asyncio.TimeoutError:
                pass
            self.watch_kick.clear()

    async def dump(self):
        rc, out, err = await run("pw-dump", timeout=8)
        if rc != 0:
            return []
        try:
            return json.loads(out)
        except json.JSONDecodeError:
            return []

    async def ensure(self):
        objs = await self.dump()
        if not objs:
            self.status(False, "PipeWire isn't running yet.")
            return False
        nodes = [o for o in objs if o.get("type") == "PipeWire:Interface:Node"]
        devices = [o for o in objs if o.get("type") == "PipeWire:Interface:Device"]

        def props(o):
            return (o.get("info") or {}).get("props") or {}

        dsp = next((n for n in nodes if props(n).get("node.name") == "hu_dsp"), None)
        out = next((n for n in nodes if props(n).get("node.name") == "hu_dsp_out"), None)
        if not dsp or not out:
            self.status(False, "The audio processor isn't loaded. Restart the Pi once after installing.")
            return False
        if dsp["id"] != self.dsp_id:
            self.dsp_id = dsp["id"]
            self.target = None
            self.pushed = {}
            await run("wpctl", "set-default", str(self.dsp_id))
            await self.apply_volume()
            self.request_apply()

        dac = next((d for d in devices
                    if re.search(r"hifiberry|dac8x", json.dumps(props(d)), re.I)), None)
        if not dac:
            self.status(False, "DAC8x not found. Check that it's seated and that /boot/firmware/config.txt "
                               "has dtoverlay=hifiberry-dac8x, then restart.")
            return False
        params = (dac.get("info") or {}).get("params") or {}
        current = (params.get("Profile") or [{}])[0].get("name")
        if current != "pro-audio":
            pro = next((p for p in params.get("EnumProfile") or [] if p.get("name") == "pro-audio"), None)
            if pro is None:
                self.status(False, "The DAC8x has no multichannel profile yet. Restart the Pi.")
                return False
            await run("wpctl", "set-profile", str(dac["id"]), str(pro["index"]))
            self.status(False, "Switching the DAC8x to 8-channel mode…")
            return False
        sink = next((n for n in nodes if str(props(n).get("device.id")) == str(dac["id"])
                     and props(n).get("media.class") == "Audio/Sink"), None)
        if not sink:
            self.status(False, "Waiting for the DAC8x output…")
            return False
        sink_name = props(sink).get("node.name")
        if self.target != sink_name:
            await run("pw-metadata", str(out["id"]), "target.object", sink_name)
            self.target = sink_name
        await self.guard(objs, nodes, dsp, out, sink)
        self.status(True, "")
        return True

    async def guard(self, objs, nodes, dsp, out, sink, log_it=False):
        """Keeps every sound going through the processor. If anything plays straight into the DAC8x
        (which sounds like bass only, or one speaker), it's moved back, and the processor's settings
        are sent again."""
        def props(o):
            return (o.get("info") or {}).get("props") or {}
        links = [o for o in objs if o.get("type") == "PipeWire:Interface:Link"]
        linked = {}
        for ln in links:
            info = ln.get("info") or {}
            linked.setdefault(info.get("output-node-id"), set()).add(info.get("input-node-id"))
        fixed = []
        node_by_id = {n["id"]: n for n in nodes}
        why = getattr(self, "why", None) if time.time() < self.watch_until else None
        # 1. the processor is the default speaker
        meta = next((o for o in objs if o.get("type") == "PipeWire:Interface:Metadata"
                     and props(o).get("metadata.name") == "default"), None)
        default_name = None
        for m in (meta or {}).get("metadata") or []:
            if m.get("key") == "default.audio.sink":
                v = m.get("value")
                default_name = v.get("name") if isinstance(v, dict) else None
        if default_name and default_name != "hu_dsp":
            await run("wpctl", "set-default", str(dsp["id"]))
            fixed.append(f"default speaker was {default_name}")
        # 2. no music or voice stream skips the processor
        for n in nodes:
            p = props(n)
            if p.get("media.class") != "Stream/Output/Audio" or p.get("node.name") == "hu_dsp_out":
                continue
            targets = linked.get(n["id"], set())
            if targets and dsp["id"] not in targets:
                await run("pw-metadata", str(n["id"]), "target.object", "hu_dsp")
                fixed.append(f"moved {p.get('node.name') or n['id']} back to the processor")
        # 2b. nothing else plays straight into the DAC8x (a raw stereo feed there sounds thin and wrong).
        # Never just cut it off: first connect it to the processor, and only then remove the direct link.
        # If it can't be connected to the processor, it's left alone (thin sound beats no sound).
        direct = {}
        for ln in links:
            info = ln.get("info") or {}
            src = info.get("output-node-id")
            if info.get("input-node-id") == sink["id"] and src != out["id"]:
                direct.setdefault(src, []).append(ln)
        for src, lns in direct.items():
            n = node_by_id.get(src)
            name = props(n).get("node.name") if n else src
            if n and props(n).get("media.class") == "Stream/Output/Audio":
                await run("pw-metadata", str(src), "target.object", "hu_dsp")
                fixed.append(f"{name} was playing straight into the DAC (moved to the processor)")
            elif n and await self.reroute(objs, n, dsp):
                for ln in lns:
                    await run("pw-link", "-d", str(ln["id"]))
                fixed.append(f"{name} was playing straight into the DAC (reconnected through the processor)")
            else:
                log.warning("audio: %s plays straight into the DAC and couldn't be moved; leaving it", name)
        # 2c. the processor's own settings haven't drifted (for example stuck on the subwoofer only)
        if not self.testing and time.time() - getattr(self, "last_push", 0) > 2:  # not while a change is landing
            want = self.gains(self.hub.settings["audio"])
            have = {}
            for entry in ((dsp.get("info") or {}).get("params") or {}).get("Props") or []:
                ps = entry.get("params") if isinstance(entry, dict) else None
                if isinstance(ps, list):
                    for i in range(0, len(ps) - 1, 2):
                        k = str(ps[i])
                        if k.endswith(":Gain 1") and k.split(":")[0] in want:
                            have[k.split(":")[0]] = ps[i + 1]
            off = [k for k, v in want.items() if k in have and isinstance(have[k], (int, float)) and abs(have[k] - v) > 0.02]
            if off:
                fixed.append("speaker levels had changed (" + ", ".join(off) + ")")
        # 3. the processor feeds all five speaker channels
        out_links = [ln for ln in links if (ln.get("info") or {}).get("output-node-id") == out["id"]
                     and (ln.get("info") or {}).get("input-node-id") == sink["id"]]
        if len(out_links) < 5:
            self.target = None
            await run("pw-metadata", str(out["id"]), "target.object", props(sink).get("node.name"))
            fixed.append(f"only {len(out_links)} of 5 speaker channels were connected")
        if fixed or log_it:
            log.warning("audio routing check: %s", "; ".join(fixed) or "all good")
            self.request_apply()
        if fixed:
            a = self.hub.state["audio"]
            a["fixes"] = ([{"at": time.time(), "what": "; ".join(fixed), "voice": self.hub.state.get("voice"), "after": why}] + (a.get("fixes") or []))[:6]
            self.pushed = {}  # send every setting again, not just the changes
            self.hub.changed()
            if not log_it:  # found by the automatic check: say so, so it's easy to tell when it happens
                asyncio.create_task(self.hub.broadcast_raw({"type": "toast", "text": "Sound path fixed: " + fixed[0]}))
        return fixed

    async def reroute(self, objs, node, dsp):
        """Links a node's outputs to the processor's inputs, channel by channel. True if it worked."""
        def pp(o):
            return (o.get("info") or {}).get("props") or {}
        ports = [o for o in objs if o.get("type") == "PipeWire:Interface:Port"]
        def of(nid, direction):
            return [p for p in ports if str(pp(p).get("node.id")) == str(nid)
                    and ((p.get("info") or {}).get("direction") == direction
                         or pp(p).get("port.direction") == {"output": "out", "input": "in"}[direction])]
        outs, ins = of(node["id"], "output"), of(dsp["id"], "input")
        ins = [p for p in ins if not pp(p).get("port.monitor")]
        if not outs or not ins:
            return False
        chan = lambda p: str(pp(p).get("audio.channel") or "")
        made = 0
        for o in outs:
            c = chan(o)
            targets = [i for i in ins if chan(i) == c] or (ins if c in ("MONO", "") or len(outs) == 1 else [])
            for i in targets:
                rc, _, err = await run("pw-link", str(o["id"]), str(i["id"]))
                if rc == 0 or "exist" in err.lower():
                    made += 1
        return made > 0

    def watch(self, why):
        """Something just happened that has upset the sound before: check right away, then often for a while."""
        self.watch_until = time.time() + 30
        self.watch_kick.set()
        self.why = why

    async def repair_later(self):
        """After a call or the assistant: check twice, once the phone has switched back to music."""
        for wait in (2.5, 5):
            await asyncio.sleep(wait)
            await self.repair(log_it=True)

    async def repair(self, log_it=False):
        objs = await self.dump()
        nodes = [o for o in objs if o.get("type") == "PipeWire:Interface:Node"]

        def props(o):
            return (o.get("info") or {}).get("props") or {}
        dsp = next((n for n in nodes if props(n).get("node.name") == "hu_dsp"), None)
        out = next((n for n in nodes if props(n).get("node.name") == "hu_dsp_out"), None)
        sink = next((n for n in nodes if props(n).get("node.name") == self.target), None)
        if not (dsp and out and sink):
            self.target = None
            await self.ensure()
            return ["audio was reconnected"]
        fixed = await self.guard(objs, nodes, dsp, out, sink, log_it=log_it)
        self.request_apply()
        await self.apply_volume()
        return fixed

    async def apply_volume(self):
        key = VOLUME_KEY.get(self.hub.state.get("voice"), "volume")
        await self.set_volume(self.hub.settings["audio"].get(key, self.hub.settings["audio"]["volume"]))

    def gains(self, a):
        f = clamp(a["fader"] / 10, -1, 1)
        b = clamp(a["balance"] / 10, -1, 1)
        front = 1.0 if f >= 0 else 1 + f
        rear = 1.0 if f <= 0 else 1 - f
        left = 1.0 if b <= 0 else 1 - b
        right = 1.0 if b >= 0 else 1 + b
        return {"fl": front * left, "fr": front * right, "rl": rear * left, "rr": rear * right,
                "sub": 10 ** (a["sub"] / 20)}

    def params(self, a, only=None):
        g = self.gains(a)
        if only:
            g = {k: (v if k == only else 0.0) for k, v in g.items()}
            if only != "sub":
                g[only] = 1.0
        xo = float(a["xover"])
        p = {f"{k}:Gain 1": v for k, v in g.items()}
        for n in ("hpL", "hpR", "lp1", "lp2"):
            p[f"{n}:Freq"] = xo
        for side in "LR":
            p[f"ls{side}:Gain"] = float(a["bass"])
            p[f"pk{side}:Gain"] = float(a["mid"])
            p[f"hs{side}:Gain"] = float(a["treble"])
        return p

    async def push(self, p, all_params=False):
        if self.dsp_id is None:
            return
        if not all_params:  # leave the filters alone unless they actually changed
            p = {k: v for k, v in p.items() if self.pushed.get(k) is None or abs(self.pushed[k] - v) > 1e-4}
            if not p:
                return
        self.last_push = time.time()
        body = " ".join(f'"{k}" {v:.4f}' for k, v in p.items())
        rc, _, err = await run("pw-cli", "set-param", str(self.dsp_id), "Props", "{ params = [ " + body + " ] }")
        if rc != 0:
            log.warning("pw-cli set-param failed: %s", err.strip())
            self.pushed = {}
        else:
            self.pushed.update(p)

    def request_apply(self):
        self.dirty = True
        if not self.applying:
            asyncio.create_task(self._apply_loop())

    async def _apply_loop(self):
        self.applying = True
        try:
            while self.dirty:
                self.dirty = False
                if not self.testing:
                    await self.push(self.params(self.hub.settings["audio"]))
                await asyncio.sleep(0.05)
        finally:
            self.applying = False

    async def set_volume(self, v):
        """Turning the knob fast asks for many volumes in a row; only the newest one is sent, one at a time."""
        self.vol_target = clamp(v, 0, 100)
        if not self.vol_busy:
            self.vol_busy = True
            asyncio.create_task(self._volume_worker())  # the caller (the knob) doesn't wait for it

    async def _volume_worker(self):
        try:
            while self.vol_target is not None and self.dsp_id is not None:
                v, self.vol_target = self.vol_target, None
                await run("wpctl", "set-volume", str(self.dsp_id), f"{v / 100:.2f}")
        finally:
            self.vol_busy = False

    @staticmethod
    def tone(path, freq, secs=1.6, rate=48000):
        n = int(rate * secs)
        fade = int(rate * 0.05)
        with wave.open(str(path), "wb") as w:
            w.setnchannels(2)
            w.setsampwidth(2)
            w.setframerate(rate)
            frames = bytearray()
            for i in range(n):
                env = min(1.0, i / fade, (n - i) / fade)
                s = int(0.35 * env * 32767 * math.sin(2 * math.pi * freq * i / rate))
                frames += struct.pack("<hh", s, s)
            w.writeframes(bytes(frames))

    async def speaker_test(self):
        if self.testing:
            return
        if not self.hub.state["audio"]["ready"]:
            raise UserError(self.hub.state["audio"]["message"] or "Audio isn't ready yet.")
        self.testing = True
        try:
            for key, label, freq in self.TEST:
                path = TMP / f"tone_{freq}.wav"
                if not path.exists():
                    await asyncio.to_thread(self.tone, path, freq)
                await self.push(self.params(self.hub.settings["audio"], only=key), all_params=True)
                self.hub.state["audio"]["testing"] = label
                self.hub.changed()
                await run("pw-play", "--target", "hu_dsp", str(path), timeout=6)
                await asyncio.sleep(0.3)
        finally:
            self.testing = False
            self.hub.state["audio"]["testing"] = None
            self.hub.changed()
            self.pushed = {}
            await self.push(self.params(self.hub.settings["audio"]))


# -------------------------------------------------------------------- phone apps
class PageStream:
    """Runs the phone's scrcpy server directly (no scrcpy window) and relays its H.264 video to the
    page over /appws, where Chromium decodes it onto a canvas. That lets the map have rounded corners,
    be cropped to just the map, and sit underneath other things. Touches come back as scrcpy control
    messages. If any of it fails, Apps falls back to the classic scrcpy window."""
    JAR = "/data/local/tmp/scrcpy-server.jar"

    def __init__(self, apps):
        self.apps = apps
        self.viewers = set()
        self.reset()

    def reset(self):
        self.video = self.control = None
        self.task = None
        self.port = None
        self.serial = None
        self.meta = None            # {"w", "h", "crop": [top, bottom]} in stream pixels
        self.config = None          # last SPS/PPS packet
        self.gop = []               # packets since the last key frame, replayed to a new viewer
        self.started = False
        self.closing = False
        self.listener = None
        self.sock = None
        self.conns = None
        self.key = None

    def reset_video(self):
        """scrcpy's RESET_VIDEO control message: restarts the encoder, which sends a new key frame."""
        if self.control:
            try:
                self.control.write(bytes([17]))
            except Exception:
                pass

    @staticmethod
    def server_path():
        cands = [os.environ.get("SCRCPY_SERVER_PATH")]
        exe = shutil.which("scrcpy")
        if exe:
            real = Path(exe).resolve()
            cands += [real.parent.parent / "share/scrcpy/scrcpy-server", Path(exe).parent.parent / "share/scrcpy/scrcpy-server"]
        cands += ["/usr/local/share/scrcpy/scrcpy-server", "/usr/share/scrcpy/scrcpy-server"]
        for c in cands:
            if c and Path(c).is_file():
                return Path(c)
        return None

    async def version(self):
        if not hasattr(self, "_version"):
            _, out, _ = await run("scrcpy", "--version", timeout=5)
            m = re.match(r"scrcpy (\S+)", out.strip())
            self._version = m.group(1) if m else None
        return self._version

    def crop_px(self, name, dpi):
        r = self.apps.hub.state.get("app_rect") or {}
        st = self.apps.hub.settings
        if name != "maps" or not r.get("crop") or not st.get("map_only", True):
            return 0, 0
        top = st.get("map_crop_top", 112) * dpi / 160
        bottom = st.get("map_crop_bottom", 80) * dpi / 160
        return int(round(top / 2) * 2), int(round(bottom / 2) * 2)

    @staticmethod
    def master(ver):
        return f"/data/local/tmp/hu-scrcpy-{ver}.jar"

    async def stage(self, serial):
        """Makes sure the phone has the spare copy of the stream server. Checked once per phone link;
        the link loop calls this ahead of time so opening Maps never has to wait for it."""
        server, ver = self.server_path(), await self.version()
        if not server or not ver:
            return False
        staged = self.apps.staged
        if staged.get(serial) == ver:
            return True
        adb = ("adb", "-s", serial)
        size = server.stat().st_size
        _, out, _ = await run(*adb, "shell", "stat", "-c", "%s", self.master(ver), timeout=6)
        if out.strip() != str(size):
            t = time.monotonic()
            rc, out, err = await run(*adb, "push", str(server), self.master(ver), timeout=15)
            if rc != 0 and ":" in serial:
                # a Wi-Fi link that looks connected but has gone dead: drop it, reconnect, try once more
                log.warning("stream helper: push failed (%s), reconnecting %s", (err or out).strip()[:80], serial)
                await run("adb", "disconnect", serial, timeout=5)
                await asyncio.sleep(1)
                await run("adb", "connect", serial, timeout=6)
                rc, out, err = await run(*adb, "push", str(server), self.master(ver), timeout=15)
            if rc != 0:
                log.warning("stream helper: push failed %s %s", out, err)
                return False
            log.info("stream helper copied to %s in %.1f s", serial, time.monotonic() - t)
        staged[serial] = ver
        return True

    async def open(self, name, serial, mode, w, h, dpi):
        """Starts the stream. Returns False if this Pi can't do in-page streaming at all."""
        server, ver = self.server_path(), await self.version()
        if not server or not ver:
            log.warning("in-page stream: scrcpy server %s, version %s", server, ver)
            return False
        await self.stop()
        self.reset()
        top, bottom = self.crop_px(name, dpi)
        self.key = (name, w, h, dpi, (top, bottom))
        full_h = (h + top + bottom) // 8 * 8
        bottom = full_h - h - top   # whatever rounding left over comes off the bottom
        self.meta = {"w": w, "h": full_h, "crop": [top, max(0, bottom)]}
        self.serial = serial
        adb = ("adb", "-s", serial)
        # The server deletes its own file once it starts, so it can't simply be left on the phone. A spare
        # copy stays there instead and is copied into place at launch (on the phone, instantly). Pushing it
        # over Wi-Fi every time was the slowest and flakiest part of opening Maps.
        if not await self.stage(serial):
            self.apps.set(name, "error", "Couldn't send the stream helper to the phone.")
            return True
        # Same connection method as the scrcpy app ("reverse"): the Pi listens and the phone's server
        # connects out to it, first for video, then for control. The socket name stays the same for the
        # whole run, so each start just re-points it (nothing to clean up afterwards).
        scid = self.apps.scid
        self.sock = f"scrcpy_{scid:08x}"
        self.conns = asyncio.Queue()
        self.listener = await asyncio.start_server(lambda r, w: self.conns.put_nowait((r, w)), "127.0.0.1", 0)
        self.port = self.listener.sockets[0].getsockname()[1]
        rc, out, err = await run(*adb, "reverse", f"localabstract:{self.sock}", f"tcp:{self.port}", timeout=8)
        if rc != 0:
            log.warning("in-page stream: adb reverse failed %s %s", out, err)
        # Over Wi-Fi the phone link is the bottleneck: 30 fps at 4 Mbit/s keeps it smooth. (Frequent
        # key frames are big bursts, which made song changes in YouTube Music stutter, so they're left
        # at the phone's normal spacing.)
        rate = 8_000_000 if mode == "usb" else 4_000_000
        fps = 60 if mode == "usb" else 30
        opts = [ver, f"scid={scid:08x}", "log_level=info", "audio=false", "control=true",
                "video_codec=h264", f"max_fps={fps}", f"video_bit_rate={rate}", "clipboard_autosync=false",
                f"new_display={w}x{full_h}/{dpi}"]
        if not hasattr(self.apps, "_no_deco"):
            _, helptext, _ = await run("scrcpy", "--help", timeout=5)
            self.apps._no_deco = "--no-vd-system-decorations" in helptext
        if self.apps._no_deco:
            opts.append("vd_system_decorations=false")   # no phone status bar on the stream
        # One trip to the phone: stop a stream that's still shutting down (only then wait a moment), put the
        # server in place, start it. The class name is pieced together from $P so pkill can't match (and
        # kill) this very command line.
        script = (f"P=com.genymobile.scrcpy; pkill -f 'com.genymobile.scrcpy.Serve[r]' && sleep 0.4; "
                  f"cp {self.master(ver)} {self.JAR} || {{ echo HU_NOJAR; exit 1; }}; "
                  f"CLASSPATH={self.JAR} exec app_process / $P.Server " + " ".join(opts))
        args = [*adb, "shell", script]
        self.apps.opened_with = (0, 0, w, h, dpi)
        self.apps.set(name, "starting")
        proc = await asyncio.create_subprocess_exec(*args, stdin=asyncio.subprocess.DEVNULL,
                                                    stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT)
        self.apps.proc = proc
        self.task = asyncio.create_task(self._run(proc, name))
        log.info("in-page stream: %s %dx%d (+%d/%d crop) at %d dpi", name, w, full_h, top, bottom, dpi)
        return True

    async def _connect(self, proc, timeout=10):
        """Waits for the phone's server to connect to us (or to exit)."""
        get = asyncio.create_task(self.conns.get())
        died = asyncio.create_task(proc.wait())
        done, _ = await asyncio.wait({get, died}, timeout=timeout, return_when=asyncio.FIRST_COMPLETED)
        died.cancel()
        if get in done:
            return get.result()
        get.cancel()
        return None

    async def _run(self, proc, name):
        tail = []

        async def logs():
            while True:
                line = await proc.stdout.readline()
                if not line:
                    return
                t = line.decode(errors="replace").strip()
                if t:
                    tail.append(t)
                    del tail[:-8]
                    log.info("phone stream %s: %s", name, t)

        logger = asyncio.create_task(logs())
        try:
            vid = await self._connect(proc)
            if not vid:
                raise ConnectionError("no video socket")
            self.video = vid
            ctl = await self._connect(proc, timeout=5)
            if not ctl:
                raise ConnectionError("no control socket")
            ctl_r, ctl_w = ctl
            self.control = ctl_w
            asyncio.create_task(self._drain(ctl_r))
            r = vid[0]
            await r.readexactly(64)                                   # device name
            codec, vw, vh = struct.unpack(">III", await r.readexactly(12))
            self.meta["w"], self.meta["h"] = vw, vh
            await self._send_meta()
            # the virtual display exists now: open the app on it (scrcpy's START_APP control message)
            pkg = self.apps.PKG[name].encode()
            self.control.write(bytes([16, len(pkg)]) + pkg)
            while True:
                head = await r.readexactly(12)
                pts, size = struct.unpack(">QI", head)
                data = await r.readexactly(size)
                if pts >> 63 & 1:
                    kind = 1
                    self.config = data
                elif pts >> 62 & 1:
                    kind = 2
                    self.gop = [data]
                else:
                    kind = 3
                    if len(self.gop) < 400:
                        self.gop.append(data)
                if kind != 1 and not self.started:
                    self.started = True
                    self.apps.page_fails = 0
                    self.apps.set(name, "running")
                await self._broadcast(bytes([kind]) + data)
        except (asyncio.IncompleteReadError, ConnectionError, OSError) as e:
            log.info("phone stream ended: %s", e)
        except asyncio.CancelledError:
            pass
        finally:
            logger.cancel()
        if self.closing or self.apps.proc is not proc:
            return
        if self.apps.parked:   # nobody is looking at it: just tidy up, it starts fresh next time
            self.apps.parked = None
            await self.stop()
            self.apps.proc = None
            return
        await self.stop(keep_state=True)
        self.apps.proc = None
        if self.started:
            self.apps.reopen = (name, time.time())   # it was working: probably a Wi-Fi blip, so retry
            self.apps.set(name, "starting", "Phone connection dropped. Reconnecting…")
        else:
            log.warning("in-page stream failed to start: %s", " | ".join(tail))
            if any("HU_NOJAR" in t for t in tail):
                self.apps.staged.pop(self.serial, None)   # the spare copy is gone: send it again
            self.apps.page_fails = getattr(self.apps, "page_fails", 0) + 1
            if self.apps.page_fails >= 3:
                self.apps.page_failed = True     # keeps failing: use the classic window instead
                self.apps.set(name, "starting", "Switching to the classic stream…")
            else:
                self.apps.set(name, "starting", "Retrying…")
                await asyncio.sleep(1.5)
            asyncio.create_task(self.apps.open(name))

    async def _drain(self, r):
        try:
            while await r.read(4096):
                pass
        except Exception:
            pass

    async def _send_meta(self, ws=None):
        text = json.dumps({"type": "meta", **(self.meta or {})})
        for v in ([ws] if ws else list(self.viewers)):
            try:
                await v.send_str(text)
            except Exception:
                self.viewers.discard(v)

    async def _broadcast(self, payload):
        for v in list(self.viewers):
            try:
                await asyncio.wait_for(v.send_bytes(payload), 1)
            except Exception:
                self.viewers.discard(v)

    async def join(self, ws):
        """A screen wants the video: give it the size, the codec setup and the frames since the last key frame."""
        self.viewers.add(ws)
        if self.meta and self.video:
            await self._send_meta(ws)
            if self.config:
                await ws.send_bytes(bytes([1]) + self.config)
            for i, d in enumerate(self.gop):
                await ws.send_bytes(bytes([2 if i == 0 else 3]) + d)

    # ---- touches and keys from the page
    def touch(self, action, pid, x, y, w, h):
        if not self.control:
            return
        pressure = 0 if action == 1 else 0xFFFF
        msg = struct.pack(">BBqiiHHHII", 2, action, pid, int(x), int(y), int(w), int(h), pressure, 0, 0)
        try:
            self.control.write(msg)
        except Exception:
            pass

    def key(self, code):
        if not self.control:
            return
        try:
            self.control.write(struct.pack(">BBIII", 0, 0, code, 0, 0) + struct.pack(">BBIII", 0, 1, code, 0, 0))
        except Exception:
            pass

    async def stop(self, keep_state=False):
        self.closing = not keep_state
        for c in (self.control, self.video[1] if self.video else None):
            if c:
                try:
                    c.close()
                except Exception:
                    pass
        proc = self.apps.proc if self.task else None
        if self.task and not self.task.done() and asyncio.current_task() is not self.task:
            self.task.cancel()
        if proc and proc.returncode is None:
            try:
                proc.terminate()
                await asyncio.wait_for(proc.wait(), 3)
            except Exception:
                try:
                    proc.kill()
                except Exception:
                    pass
        if getattr(self, "listener", None):
            self.listener.close()
            self.listener = None
        self.video = self.control = None
        self.port = None
        for v in list(self.viewers):
            try:
                await v.send_str(json.dumps({"type": "end"}))
            except Exception:
                self.viewers.discard(v)


class Apps:
    PKG = {"maps": "com.google.android.apps.maps",
           "music": "com.google.android.apps.youtube.music"}
    TITLE = "HU-App"

    def __init__(self, hub):
        self.hub = hub
        self.proc = None
        self.resume = None
        self.reopen = None          # (app name, when it dropped) after the phone's Wi-Fi blips
        self.lock = asyncio.Lock()
        self.page = PageStream(self)
        self.page_failed = False
        self.staged = {}            # serial -> scrcpy version whose spare server copy is on that phone
        self.scid = secrets.randbits(31)
        self.parked = None          # (name, opened_with): stream kept running after leaving the Maps screen
        self._companion_at = {}     # serial -> when the phone app setup was last checked
        self.park_task = None

    def set(self, current, status, message=""):
        self.hub.state["app"] = {"current": current, "status": status, "message": message, "view": self.view_mode()}
        self.hub.changed()

    def view_mode(self):
        """"page": the stream is drawn inside the head unit page (rounded corners, things on top of it).
        "window": the older scrcpy window drawn over the page. Page mode falls back to window by itself."""
        if getattr(self, "page_failed", False) or self.hub.settings.get("app_view", "page") == "window":
            return "window"
        return "page"

    PARK_SECONDS = 180

    async def open(self, name):
        if name not in self.PKG:
            return
        async with self.lock:
            if self.parked and self.unpark(name):
                return
            await self._close()
            if not shutil.which("scrcpy"):
                self.set(name, "error", "scrcpy isn't installed. Run install.sh again.")
                return
            serial, mode, problem = await self.find_phone(connect=True)
            if not serial:
                self.set(name, "error", problem)
                return
            x, y, w, h = self.geometry(name)
            if self.view_mode() == "page":
                if await self.page.open(name, serial, mode, w, h, self.dpi(w, h)):
                    return
                self.page_failed = True  # couldn't even start: use the classic window this time
                log.warning("in-page stream unavailable, using the scrcpy window")
            await self.apply_window_rule(x, y, w, h)
            dpi = self.dpi(w, h)
            rate = "8M" if mode == "usb" else "4M"
            if not hasattr(self, "_no_deco"):
                _, helptext, _ = await run("scrcpy", "--help", timeout=5)
                self._no_deco = "--no-vd-system-decorations" in helptext
            args = ["scrcpy", f"--serial={serial}", f"--new-display={w}x{h}/{dpi}", f"--start-app={self.PKG[name]}",
                    "--no-audio", f"--window-title={self.TITLE}", "--window-borderless",
                    f"--window-x={x}", f"--window-y={y}", f"--window-width={w}", f"--window-height={h}",
                    f"--max-fps={60 if mode == 'usb' else 30}", f"--video-bit-rate={rate}"]
            if self._no_deco:
                args.insert(1, "--no-vd-system-decorations")  # no phone status bar or taskbar on the stream
            self.opened_with = (x, y, w, h, dpi)
            self.set(name, "starting")
            self.proc = await asyncio.create_subprocess_exec(
                *args, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT)
            asyncio.create_task(self._watch(self.proc, name))

    # ---- phone link: USB when plugged in, otherwise Wi-Fi over the Pi's own network
    async def devices(self):
        _, out, _ = await run("adb", "devices", timeout=5)
        found = []
        for ln in out.splitlines()[1:]:
            parts = ln.split()
            if len(parts) >= 2:
                found.append((parts[0], parts[1]))
        return found

    @staticmethod
    def lease_ips():
        ips = []
        for f in Path("/var/lib/NetworkManager").glob("dnsmasq-*.leases"):
            try:
                for ln in f.read_text().splitlines():
                    parts = ln.split()
                    if len(parts) >= 3 and parts[2].startswith("10.42."):
                        ips.append(parts[2])
            except OSError:
                pass
        return ips

    async def phone_ips(self):
        """Every address the phone might have on the Pi's Wi-Fi, best guess first."""
        ips = []
        if getattr(self.hub, "phone_ip", None):
            ips.append(self.hub.phone_ip)               # told by the phone app's own connection
        _, out, _ = await run("ip", "-4", "neigh", "show", "dev", "wlan0", timeout=4)
        for ln in out.splitlines():                     # devices the Pi has talked to recently
            parts = ln.split()
            if parts and parts[0].startswith("10.42.") and "FAILED" not in ln:
                ips.append(parts[0])
        ips += self.lease_ips()                         # needs root on most setups, so last
        seen = set()
        return [i for i in ips if not (i in seen or seen.add(i))]

    async def try_wireless(self):
        # 1) Phones armed with "adb tcpip 5555" (done automatically whenever it was plugged in)
        for ip in await self.phone_ips():
            rc, out, _ = await run("adb", "connect", f"{ip}:5555", timeout=4)
            if "connected" in out and "cannot" not in out:
                return True
        # 2) Android "Wireless debugging" phones that were paired before (advertised over mDNS)
        _, out, _ = await run("adb", "mdns", "services", timeout=4)
        for ln in out.splitlines():
            m = re.search(r"_adb-tls-connect\._tcp\.?\s+(\d+\.\d+\.\d+\.\d+:\d+)", ln)
            if m:
                rc, out2, _ = await run("adb", "connect", m.group(1), timeout=4)
                if "connected" in out2 and "cannot" not in out2:
                    return True
        return False

    async def find_phone(self, connect=False):
        devs = await self.devices()
        usb = [d for d in devs if ":" not in d[0] and "._adb" not in d[0]]
        wifi = [d for d in devs if d not in usb]
        ok_usb = [d for d in usb if d[1] == "device"]
        ok_wifi = [d for d in wifi if d[1] == "device"]
        if ok_usb:
            return ok_usb[0][0], "usb", ""
        if ok_wifi:
            return ok_wifi[0][0], "wifi", ""
        if usb and all(d[1] == "unauthorized" for d in usb):
            return None, None, "Unlock your phone and tap Allow on the USB debugging prompt."
        if connect and await self.try_wireless():
            return await self.find_phone(connect=False)
        return None, None, ("Phone not found. Make sure it's on the “Pi Head Unit” Wi-Fi. "
                            "After the phone restarts, plug it into the Pi by USB once to turn wireless back on.")

    async def link_loop(self):
        armed = set()
        while True:
            try:
                devs = await self.devices()
                for serial, st in devs:
                    if ":" in serial and st == "offline":
                        # a dead Wi-Fi entry makes "adb connect" say "already connected" and do nothing
                        await run("adb", "disconnect", serial, timeout=4)
                if any(st == "offline" for _, st in devs):
                    devs = await self.devices()
                usb = [d[0] for d in devs if d[1] == "device" and ":" not in d[0] and "._adb" not in d[0]]
                # Plugged in and no stream running: make sure wireless mode is on for when it's unplugged.
                # The phone switches it off by itself (restarts, some Wi-Fi changes), so check every
                # time rather than only once.
                for serial in usb:
                    if not self.proc:
                        _, port, _ = await run("adb", "-s", serial, "shell", "getprop", "service.adb.tcp.port", timeout=5)
                        if port.strip() != "5555":
                            log.info("turning wireless mode back on for %s", serial)
                            await run("adb", "-s", serial, "tcpip", "5555", timeout=6)
                            armed.add(serial)
                            await asyncio.sleep(3)
                if not self.proc:
                    serial, mode, _ = await self.find_phone(connect=True)
                else:
                    serial, mode, _ = await self.find_phone(connect=False)
                self.hub.state["adb"] = {"mode": mode, "serial": serial}
                if serial:
                    # Every phone command shares the Wi-Fi with the map video, so this loop asks as little as
                    # it can: one look at the tunnels, and only fixes what's missing.
                    _, rev, _ = await run("adb", "-s", serial, "reverse", "--list", timeout=5)
                    # private tunnel so the phone app can reach the Pi at 127.0.0.1:8080
                    if "tcp:8080 tcp:8080" not in rev:
                        await run("adb", "-s", serial, "reverse", "tcp:8080", "tcp:8080", timeout=5)
                    # and 127.0.0.1:2222 on the phone reaches the Pi's SSH, for ConnectBot / Claude Code
                    if "tcp:2222 tcp:22" not in rev:
                        await run("adb", "-s", serial, "reverse", "tcp:2222", "tcp:22", timeout=5)
                    if time.time() - self._companion_at.get(serial, 0) > 300:
                        await self.setup_companion(serial)
                        self._companion_at[serial] = time.time()
                    if not self.proc and self.view_mode() == "page":
                        await self.page.stage(serial)   # so opening Maps never waits for a file copy
                if self.reopen and not self.proc:
                    name, since = self.reopen
                    if time.time() - since > 180:
                        self.reopen = None
                        self.set(name, "error", "The phone didn't come back. Check it's on the “Pi Head Unit” Wi-Fi.")
                    elif serial:
                        self.reopen = None
                        asyncio.create_task(self.open(name))
                sp = self.hub.state.get("speed")
                if sp and time.time() - sp["at"] > 10:
                    self.hub.state["speed"] = None
                c = self.hub.state["companion"]
                if c["connected"] and time.time() - c.get("seen", 0) > 120:
                    c["connected"] = False
                self.hub.changed()
            except Exception as e:
                log.info("phone link: %s", e)
            await asyncio.sleep(3 if self.reopen else 8)

    def geometry(self, name):
        """Where the phone stream sits, in screen pixels. The touch UI reports the exact spot (app_rect);
        until it has, estimate it from the screen size."""
        r = self.hub.state.get("app_rect")
        if r:
            return r["x"], r["y"], r["w"], r["h"]
        width, height = self.hub.display.size()
        scale = min(width / 1280, height / 800) * self.hub.settings.get("ui_scale", 100) / 100
        bar = round(112 * scale)
        panel = round(300 * scale) if self.hub.settings.get("maps_panel", True) else 0
        x = bar + panel if self.hub.settings.get("nav") != "right" else 0
        w = (width - bar - panel) // 8 * 8
        return x, 0, w, height // 8 * 8

    # Narrowest the phone app should think its screen is (in Android dp). Below about 380 dp Google Maps
    # switches to its cramped phone layout with huge buttons, which is what a small Home card got.
    MIN_DP = 380

    def dpi(self, w=None, h=None):
        """Android screen density for the stream. 160 is \"normal\" on a 600-pixel-tall screen; it grows
        with the resolution so apps keep the same physical size, then the App size setting scales it.
        Small streams (a Home card) get a lower density so the app still has room to lay itself out."""
        _, height = self.hub.display.size()
        factor = APP_SIZE_FACTOR.get(self.hub.settings.get("app_size", "medium"), 1.0)
        dpi = 160 * height / 600 * factor
        if w and h:
            dpi = min(dpi, min(w, h) * 160 / self.MIN_DP * factor)
        return int(clamp(round(dpi), 96, 640))

    async def set_rect(self, rect):
        try:
            r = {k: int(rect[k]) for k in ("x", "y", "w", "h")}
        except Exception:
            return
        if r["w"] < 64 or r["h"] < 64:
            return
        r["crop"] = bool(rect.get("crop"))
        old = self.hub.state.get("app_rect")
        self.hub.state["app_rect"] = r
        if self.proc and old and (any(abs(old[k] - r[k]) > 8 for k in ("x", "y", "w", "h")) or old.get("crop") != r["crop"]):
            await self.relayout()

    async def apply_window_rule(self, x, y, w, h):
        """Updates the window manager rule that positions the stream, then reloads it."""
        if getattr(self, "_rule", None) == (x, y, w, h):
            return
        rc_xml = Path.home() / ".config/labwc/rc.xml"
        try:
            text = rc_xml.read_text()
            text2 = re.sub(r'(<windowRule title="HU-App"[^>]*>)(.*?)(</windowRule>)',
                           lambda m: m.group(1) + f'\n      <action name="MoveTo" x="{x}" y="{y}" />'
                           f'\n      <action name="ResizeTo" width="{w}" height="{h}" />'
                           '\n      <action name="ToggleAlwaysOnTop" />\n    ' + m.group(3),
                           text, count=1, flags=re.S)
            if text2 != text:
                rc_xml.write_text(text2)
                pid = os.environ.get("LABWC_PID")
                if pid:
                    os.kill(int(pid), signal.SIGHUP)
                else:
                    await run("labwc", "--reconfigure")
                await asyncio.sleep(0.3)
            self._rule = (x, y, w, h)
        except Exception as e:
            log.warning("window rule: %s", e)

    async def relayout(self):
        """Layout changed: reopen a running stream so it lands in its new spot."""
        current = self.hub.state["app"]["current"]
        if current and self.proc:
            await self.open(current)

    COMPANION = "com.headunit.link"

    async def setup_companion(self, serial):
        """Installs and fully sets up the phone app over ADB, so nothing needs tapping on the phone."""
        apk = BASE / "phone" / "HeadUnitLink.apk"
        # the installed app's version is part of the key, so a reinstall or update gets its permissions again
        _, ver, _ = await run("adb", "-s", serial, "shell", "dumpsys", "package", self.COMPANION, timeout=8)
        m = re.search(r"versionCode=(\d+)", ver)
        key = f"{serial}:{apk.stat().st_mtime if apk.exists() else 0}:{m.group(1) if m else 0}"
        if key in getattr(self, "_setup_done", set()):
            return
        self._setup_done = getattr(self, "_setup_done", set())
        adb = ("adb", "-s", serial)
        _, out, _ = await run(*adb, "shell", "pm", "list", "packages", self.COMPANION, timeout=8)
        installed = f"package:{self.COMPANION}" in out
        if apk.exists() and (not installed or self.hub.settings.get("companion_apk") != key.split(":", 1)[1]):
            rc, out, err = await run(*adb, "install", "-r", "-g", str(apk), timeout=120)
            log.info("phone app install: %s %s", out.strip(), err.strip())
            if rc != 0 and installed:
                # e.g. the phone has a newer build signed with a different key: keep using that one
                log.info("kept the phone app that's already installed")
                self.hub.settings["companion_apk"] = key.split(":", 1)[1]
            installed = rc == 0 or installed
            if rc == 0:
                self.hub.settings["companion_apk"] = key.split(":", 1)[1]
                self.hub.save()
        if not installed:
            return
        pkg = self.COMPANION
        for perm in ("ACCESS_FINE_LOCATION", "ACCESS_COARSE_LOCATION", "ACCESS_BACKGROUND_LOCATION",
                     "READ_CONTACTS", "POST_NOTIFICATIONS"):
            await run(*adb, "shell", "pm", "grant", pkg, f"android.permission.{perm}", timeout=8)
        await run(*adb, "shell", "cmd", "notification", "allow_listener", f"{pkg}/{pkg}.NotifListener", timeout=8)
        await run(*adb, "shell", "dumpsys", "deviceidle", "whitelist", f"+{pkg}", timeout=8)
        await run(*adb, "shell", "am", "start-foreground-service", "-n", f"{pkg}/.LinkService", timeout=8)
        self._setup_done.add(key)
        log.info("phone app ready on %s", serial)

    async def _watch(self, proc, name):
        tail = []
        started = False
        while True:
            line = await proc.stdout.readline()
            if not line:
                break
            text = line.decode(errors="replace").strip()
            tail = (tail + [text])[-8:]
            if text:
                log.info("scrcpy %s: %s", name, text)  # for tracking down freezes
            if not started and ("Texture" in text or "Renderer" in text or "New display" in text):
                started = True
                if self.proc is proc:
                    self.set(name, "running")
        rc = await proc.wait()
        if self.proc is proc:
            self.proc = None
            if rc == 0:
                self.set(None, "idle")
            else:
                errors = [t for t in tail if "ERROR" in t] or tail
                msg = errors[-1] if errors else "The phone stream stopped."
                log.warning("scrcpy exited %s: %s", rc, "\n".join(tail))
                if started:
                    # it was working, so this is most likely the phone dropping off Wi-Fi: retry soon
                    self.reopen = (name, time.time())
                    self.set(name, "starting", "Phone connection dropped. Reconnecting…")
                else:
                    self.set(name, "error", msg.replace("ERROR:", "").strip())
        elif not started:
            pass

    def unpark(self, name):
        """Going back to a stream that was kept warm: show it again straight away if nothing moved."""
        pname, was = self.parked
        self.parked = None
        if self.park_task:
            self.park_task.cancel()
            self.park_task = None
        if pname != name or not self.proc or self.proc.returncode is not None or not self.page.video:
            return False
        x, y, w, h = self.geometry(name)
        dpi = self.dpi(w, h)
        if self.page.key != (name, w, h, dpi, self.page.crop_px(name, dpi)):
            return False
        self.page.reset_video()   # a fresh key frame, so the screen has a picture right away
        self.set(name, "running")
        log.info("stream: back to the warm %s stream", name)
        return True

    async def park(self):
        """Leaving the Maps/Music screen: the screen stops showing it, but the stream keeps running for a few
        minutes so coming back is instant instead of a full restart."""
        self.reopen = None
        async with self.lock:
            name = self.hub.state["app"].get("current")
            if not (name and self.proc and self.view_mode() == "page" and self.page.started):
                await self._close()
                return
            self.parked = (name, self.opened_with)
            self.set(None, "idle")
            if self.park_task:
                self.park_task.cancel()
            self.park_task = asyncio.create_task(self._park_timeout())

    async def _park_timeout(self):
        await asyncio.sleep(self.PARK_SECONDS)
        self.park_task = None
        if self.parked:
            async with self.lock:
                if self.parked:
                    await self._close()

    async def _close(self):
        self.parked = None
        if self.park_task and self.park_task is not asyncio.current_task():
            self.park_task.cancel()
        self.park_task = None
        await self.page.stop()
        proc, self.proc = self.proc, None
        if proc and proc.returncode is None:
            proc.terminate()
            try:
                await asyncio.wait_for(proc.wait(), 3)
            except asyncio.TimeoutError:
                proc.kill()
        self.set(None, "idle")

    async def close(self):
        self.reopen = None
        async with self.lock:
            await self._close()

    async def suspend_for_call(self):
        if self.parked:
            await self.close()
        current = self.hub.state["app"]["current"]
        if current and self.proc:
            self.resume = current
            await self.close()

    async def resume_after_call(self):
        if self.resume:
            name, self.resume = self.resume, None
            await self.open(name)


# ----------------------------------------------------------------------- display
class Display:
    """Screen resolution, through the window manager (wlr-randr). A new resolution has to be
    confirmed on the screen within 15 seconds, or it switches back by itself."""
    MODE_RE = re.compile(r"^\s+(\d+)x(\d+) px, ([\d.]+) Hz(.*)$")

    def __init__(self, hub):
        self.hub = hub
        self.output = None
        self.modes = []      # dicts: id, w, h, r, raw, current, preferred
        self.pending = None
        self._revert_task = None

    def size(self):
        cur = next((m for m in self.modes if m["current"]), None)
        if cur:
            return cur["w"], cur["h"]
        try:
            w, h = (int(v) for v in os.environ.get("HU_SCREEN", "1280x800").split("x"))
            return w, h
        except ValueError:
            return 1280, 800

    async def refresh(self):
        rc, out, _ = await run("wlr-randr", timeout=6)
        if rc != 0:
            return
        outputs, name, enabled = {}, None, True
        for ln in out.splitlines():
            if ln and not ln[0].isspace():
                name = ln.split()[0]
                outputs[name] = {"modes": [], "enabled": True}
            elif name and ln.strip().startswith("Enabled:"):
                outputs[name]["enabled"] = ln.strip().endswith("yes")
            elif name:
                m = self.MODE_RE.match(ln)
                if m:
                    w, h, raw, flags = int(m.group(1)), int(m.group(2)), m.group(3), m.group(4)
                    outputs[name]["modes"].append({"w": w, "h": h, "raw": raw, "r": round(float(raw)),
                                                   "current": "current" in flags, "preferred": "preferred" in flags})
        live = [n for n, o in outputs.items() if o["enabled"] and o["modes"]]
        if not live:
            return
        self.output = live[0]
        best = {}
        for m in outputs[self.output]["modes"]:
            key = (m["w"], m["h"])
            keep = best.get(key)
            if not keep or m["current"] or (not keep["current"] and m["r"] > keep["r"]):
                best[key] = m
        modes = sorted(best.values(), key=lambda m: (-m["w"] * m["h"], -m["r"]))
        for m in modes:
            m["id"] = f'{m["w"]}x{m["h"]}@{m["raw"]}'
        self.modes = modes[:24]
        self.publish()

    def publish(self):
        cur = next((m for m in self.modes if m["current"]), None)
        self.hub.state["display"] = {
            "output": self.output,
            "current": f'{cur["w"]}x{cur["h"]}@{cur["r"]}' if cur else None,
            "modes": [{k: m[k] for k in ("id", "w", "h", "r", "current", "preferred")} for m in self.modes],
            "pending": self.pending,
        }
        self.hub.changed()

    async def apply(self, mode_id):
        m = next((x for x in self.modes if x["id"] == mode_id), None)
        if not m or not self.output:
            raise UserError("That resolution isn't available on this screen.")
        rc, _, err = await run("wlr-randr", "--output", self.output, "--mode", f'{m["w"]}x{m["h"]}@{m["raw"]}Hz', timeout=8)
        if rc != 0:
            log.warning("wlr-randr: %s", err.strip())
            raise UserError("The screen didn't accept that resolution.")
        await asyncio.sleep(0.5)
        await self.refresh()

    async def choose(self, mode_id):
        prev = next((m["id"] for m in self.modes if m["current"]), None)
        if mode_id == prev:
            return
        await self.apply(mode_id)
        self.pending = {"mode": mode_id, "prev": prev, "revert_at": time.time() + 15}
        if self._revert_task:
            self._revert_task.cancel()
        self._revert_task = asyncio.create_task(self._auto_revert())
        self.publish()

    async def _auto_revert(self):
        await asyncio.sleep(15.5)
        if self.pending:
            await self.revert()

    async def keep(self):
        if self.pending:
            self.hub.settings["display_mode"] = self.pending["mode"]
            self.hub.save()
            self.pending = None
            self.publish()

    async def revert(self):
        p, self.pending = self.pending, None
        if self._revert_task and asyncio.current_task() is not self._revert_task:
            self._revert_task.cancel()
        if p and p.get("prev"):
            try:
                await self.apply(p["prev"])
            except UserError:
                pass
        self.publish()

    async def loop(self):
        """Puts back the saved resolution at start-up, then keeps the list current."""
        await asyncio.sleep(1)
        await self.refresh()
        saved = self.hub.settings.get("display_mode")
        if saved and any(m["id"] == saved and not m["current"] for m in self.modes):
            try:
                await self.apply(saved)
            except UserError:
                log.warning("saved resolution %s didn't apply", saved)
        while True:
            await asyncio.sleep(30)
            if not self.pending:
                await self.refresh()


# ----------------------------------------------------------------------- weather
WEATHER_TEXT = [((0,), "Clear"), ((1,), "Mostly clear"), ((2,), "Partly cloudy"), ((3,), "Cloudy"),
                ((45, 48), "Fog"), (range(51, 58), "Drizzle"), (range(61, 68), "Rain"),
                (range(71, 78), "Snow"), (range(80, 83), "Showers"), ((85, 86), "Snow showers"),
                (range(95, 100), "Thunderstorms")]


def weather_look(w):
    """What the head unit should look like for this weather: (label, theme, effect, rain on the glass, how hard)."""
    code, day, temp = int(w.get("code", 3)), bool(w.get("day", True)), w.get("temp")
    hot = temp is not None and temp >= (86 if temp > 45 else 30)      # works for °F or °C readings
    if code in range(95, 100):
        return "Thunderstorm", "midnight", "storm", True, "heavy"
    if code in (65, 66, 67, 82):
        return "Heavy rain", "rainy-night", "window", True, "heavy"
    if code in (63, 81):
        return "Rain", "rainy-night", "window", True, "steady"
    if code in range(51, 58) or code in (61, 80):
        return "Light rain", "rainy-night", "window", True, "light"
    if code in range(71, 78) or code in (85, 86):
        return "Snow", "snow-stage" if day else "arctic", "snow", False, "steady"
    if code in (45, 48):
        return "Fog", "ghost", "smoke", False, "light"
    if code == 3:
        return "Cloudy", "slate-soft" if day else "graphite", "smoke", False, "light"
    if code == 2:
        return "Partly cloudy", "steel" if day else "midnight", "blobs", False, "light"
    if not day:
        return "Clear night", "deepspace", "particles", False, "light"
    return ("Sunny and hot", "desert", "blobs", False, "light") if hot else ("Sunny", "lagoon", "aurora", False, "light")


WEATHER_LOOK_KEYS = ("theme", "effect", "rain_glass", "rain_amount")


def apply_weather_look(hub):
    """Keeps the look matched to the weather while "Changes with the weather" is on."""
    s, w = hub.settings, hub.state.get("weather")
    if not s.get("weather_look") or not w:
        return
    label, theme, effect, rain, amount = weather_look(w)
    want = {"theme": theme if theme in THEME_COLORS else s.get("theme"), "effect": effect, "rain_glass": rain, "rain_amount": amount}
    hub.state["weather_look"] = label
    if any(s.get(k) != v for k, v in want.items()):
        log.info("weather look: %s", label)
        s.update(want)
        hub.save()
        hub.changed()


class Weather:
    def __init__(self, hub):
        self.hub = hub
        self.city = None

    async def loop(self):
        while True:
            ok = False
            try:
                ok = await self.update()
            except Exception as e:
                log.info("weather: %s", e)
            await asyncio.sleep(900 if ok else 60)

    async def update(self):
        w = self.hub.state.get("weather") or {}
        if w.get("source") == "phone" and time.time() - w.get("at", 0) < 1800:
            return True  # the phone app keeps this fresh; no internet needed on the Pi
        loc = self.hub.settings.get("location") or {}
        lat, lon = loc.get("lat"), loc.get("lon")
        units = loc.get("units", "fahrenheit")
        async with ClientSession(timeout=ClientTimeout(total=10)) as s:
            if lat is None or lon is None:
                async with s.get("http://ip-api.com/json/?fields=status,lat,lon,city") as r:
                    j = await r.json(content_type=None)
                if j.get("status") != "success":
                    return False
                lat, lon, self.city = j["lat"], j["lon"], j.get("city")
            params = {"latitude": lat, "longitude": lon,
                      "current": "temperature_2m,weather_code,is_day",
                      "daily": "temperature_2m_max,temperature_2m_min",
                      "temperature_unit": units, "timezone": "auto", "forecast_days": 1}
            async with s.get("https://api.open-meteo.com/v1/forecast", params=params) as r:
                j = await r.json(content_type=None)
        cur, daily = j["current"], j["daily"]
        code = int(cur["weather_code"])
        text = next((t for codes, t in WEATHER_TEXT if code in codes), "")
        self.hub.state["weather"] = {
            "temp": round(cur["temperature_2m"]), "code": code, "text": text,
            "day": cur.get("is_day", 1) == 1,
            "hi": round(daily["temperature_2m_max"][0]), "lo": round(daily["temperature_2m_min"][0]),
            "city": loc.get("city") or self.city, "source": "pi", "at": time.time(),
        }
        apply_weather_look(self.hub)
        self.hub.changed()
        return True


# -------------------------------------------------------------------------- knob
class Knob:
    """Elecrow 1.28" rotary display on USB. Lines in:  R+1 / R-1, P (press), D (double), L (long),
    SL / SR (swipe), K (vertical swipe: next face). Lines out:
    S|vol|playing|accent|base|text|clock|title|artist|call|caller|face|blob1|blob2|blob3|animate|bright|speed|units|top|motion|secs"""

    def __init__(self, hub):
        self.hub = hub
        self.port = None
        self.last = ""
        self.loop = None
        self.lock = threading.Lock()

    def start(self):
        self.loop = asyncio.get_running_loop()
        threading.Thread(target=self._reader, daemon=True).start()
        asyncio.create_task(self._tick())

    @staticmethod
    def find():
        ports = glob.glob("/dev/serial/by-id/*Espressif*") + glob.glob("/dev/serial/by-id/*ESP32*")
        return ports[0] if ports else None

    def _reader(self):
        try:
            import serial  # pyserial
        except ImportError:
            log.warning("pyserial missing; knob disabled")
            return
        while True:
            path = self.find()
            if not path:
                time.sleep(2)
                continue
            try:
                with serial.Serial(path, 115200, timeout=1) as port:
                    with self.lock:
                        self.port, self.last = port, ""
                    self._set_connected(True)
                    while True:
                        line = port.readline().decode(errors="ignore").strip()
                        if line:
                            asyncio.run_coroutine_threadsafe(self.on_line(line), self.loop)
            except Exception as e:
                log.info("knob: %s", e)
            with self.lock:
                self.port = None
            self._set_connected(False)
            time.sleep(2)

    def _set_connected(self, ok):
        def apply():
            self.hub.state["knob"]["connected"] = ok
            self.hub.changed()
        self.loop.call_soon_threadsafe(apply)

    async def on_line(self, line):
        hub = self.hub
        call = hub.state["call"].get("state")
        try:
            if line.startswith("R"):
                a = hub.settings["audio"]
                key = VOLUME_KEY.get(hub.state.get("voice"), "volume")
                step = int(line[1:])
                a[key] = int(clamp(a.get(key, 50) + 2 * step, 0, 100))
                await hub.audio.apply_volume()
                hub.audio.watch("volume change")
                asyncio.create_task(hub.broadcast_raw({"type": "knob", "dir": step, "vol": a[key], "kind": key}))
                hub.save()
                hub.changed()
            elif line == "P":
                asyncio.create_task(hub.broadcast_raw({"type": "knob", "act": "press"}))
                if call in ("incoming", "waiting"):
                    await hub.calls.answer()
                else:
                    playing = hub.state["media"].get("status") == "playing"
                    await hub.bt.media("pause" if playing else "play")
            elif line == "L":
                if call:
                    await hub.calls.hangup()
                else:
                    await hub.calls.assistant()
            elif line in ("D", "SR"):
                await hub.bt.media("next")
            elif line == "SL":
                await hub.bt.media("previous")
            elif line == "K":  # vertical swipe on the knob: next knob style
                cur = hub.settings.get("knob_style", "aurora")
                nxt = KNOB_STYLES[(KNOB_STYLES.index(cur) + 1) % len(KNOB_STYLES)] if cur in KNOB_STYLES else KNOB_STYLES[0]
                hub.settings["knob_style"] = nxt
                hub.save()
                hub.changed()
        except Exception as e:
            log.info("knob action %s: %s", line, e)

    def push(self, force=False):
        with self.lock:
            port = self.port
        if not port:
            return
        st, s = self.hub.state, self.hub.settings
        theme, face = self.look()
        clean = lambda v: str(v or "").replace("|", "/").replace("\n", " ")[:60]
        m, c = st["media"], st["call"]
        style = str(KNOB_STYLES.index(face) if face in KNOB_STYLES else 0)
        bright = s.get("brightness", 100)
        w = st.get("weather") or {}
        if bright > 0 and s.get("night_dim") and w.get("day") is False:
            bright = min(bright, s.get("night_level", 25))
        lt = time.localtime()
        line = "|".join(["S", str(s["audio"]["volume"]), "1" if m.get("status") == "playing" else "0",
                         theme[0], theme[1], theme[2], time.strftime("%H:%M" if s.get("clock_24h") else "%-I:%M"),
                         clean(m.get("title")), clean(m.get("artist")), clean(c.get("state")), clean(c.get("name")),
                         style, theme[3], theme[4], theme[5], "1" if s.get("animate", True) else "0",
                         str(bright), *self.speed_fields(), str(lt.tm_hour * 3600 + lt.tm_min * 60 + lt.tm_sec),
                         self.rpm_field()])
        if line != self.last or force:
            self.last = line
            try:
                port.write((line + "\n").encode())
            except Exception:
                pass

    def look(self):
        """Knob colors (accent, background, text, blob 1-3) and face: a design being previewed in the
        Theme Studio wins, then the active design (its own knob colors, else its screen colors), then the theme."""
        st, s = self.hub.state, self.hub.settings
        pv = st.get("design_preview")
        des = pv or st.get("design") or {}
        ps = (pv or {}).get("settings") or {}
        tid = ps.get("theme") or s.get("theme")
        t = next((x for x in THEMES if x["id"] == tid), None) or THEMES[0]
        col = {"accent": t["accent"], "base": t["base"], "b1": t["b1"], "b2": t["b2"], "b3": t["b3"]}
        light = bool(t.get("light"))
        dc = des.get("colors") or {}
        col.update({k: v for k, v in dc.items() if k in col})
        if isinstance(dc.get("light"), bool):
            light = dc["light"]
        col["text"] = "#0B1220" if light else "#F5F7FA"
        col.update(((des.get("knob") or {}).get("colors")) or {})
        theme = tuple(col[k].lstrip("#").upper() for k in ("accent", "base", "text", "b1", "b2", "b3"))
        return theme, ps.get("knob_style") or s.get("knob_style")

    def rpm_field(self):
        """Engine rpm for the Tachometer face, rounded so the knob isn't sent a new line for every tiny change."""
        o = self.hub.state.get("obd") or {}
        rpm = (o.get("data") or {}).get("rpm")
        return "" if o.get("status") != "connected" or rpm is None else str(int(round(rpm / 25.0) * 25))

    def speed_fields(self):
        """Speed, units and what the knob's top line shows."""
        s, sp = self.hub.settings, self.hub.state.get("speed")
        units = s.get("speed_units", "auto")
        if units == "auto":
            units = "kmh" if (s.get("location") or {}).get("units") == "celsius" else "mph"
        value = "" if not sp else str(round(sp["mps"] * (3.6 if units == "kmh" else 2.23694)))
        motion = {"calm": "0", "lively": "1", "wild": "2"}.get(s.get("motion", "lively"), "1")
        return [value, "km/h" if units == "kmh" else "mph", s.get("knob_top", "clock"), motion]

    async def _tick(self):
        while True:
            await asyncio.sleep(15)
            self.push(force=True)  # keeps the knob's clock current and shows the Pi is alive


# --------------------------------------------------------------------------- OBD-II
# A Bluetooth ELM327-style OBD adapter (Vgate, Veepeak, OBDLink, BAFX, generic "OBDII"...).
# Classic Bluetooth adapters talk over a serial (RFCOMM) socket; Bluetooth LE ones over GATT through
# BlueZ's D-Bus API. Neither needs extra packages. Live values go to the screens as {"type":"obd"}
# messages (several times a second); the car's speed also replaces the phone's GPS speed while it's fresh.
OBD_HINT = re.compile(r"obd|elm|vgate|v-?link|icar|veepeak|obdlink|carista|bafx|konnwei|viecar|lelink|kiwi|scan ?tool|ios-vlink", re.I)
SPP_UUID = "00001101-0000-1000-8000-00805f9b34fb"
OBD_PINS = ("1234", "0000", "6789", "1111")
# pid: (key, bytes, decode)
OBD_PIDS = {
    "0C": ("rpm", 2, lambda a, b: (a * 256 + b) / 4),
    "0D": ("speed", 1, lambda a, b: a),                    # km/h
    "05": ("coolant", 1, lambda a, b: a - 40),             # °C
    "0F": ("intake", 1, lambda a, b: a - 40),              # °C
    "04": ("load", 1, lambda a, b: a * 100 / 255),         # %
    "11": ("throttle", 1, lambda a, b: a * 100 / 255),     # %
    "2F": ("fuel", 1, lambda a, b: a * 100 / 255),         # %
    "46": ("ambient", 1, lambda a, b: a - 40),             # °C
    "5C": ("oil", 1, lambda a, b: a - 40),                 # °C
    "0B": ("map", 1, lambda a, b: a),                      # kPa (boost/vacuum)
    "10": ("maf", 2, lambda a, b: (a * 256 + b) / 100),    # g/s
}
OBD_FAST = ("0C", "0D")


class ObdError(Exception):
    pass


class _SppLink:
    """Classic Bluetooth serial port."""
    def __init__(self, addr):
        self.addr, self.reader, self.writer = addr, None, None

    async def open(self):
        import socket
        if not hasattr(socket, "AF_BLUETOOTH"):
            raise ObdError("This Python can't open Bluetooth serial ports.")
        last = None
        # Reaching out to an adapter that isn't there ties up the Bluetooth radio (music can skip), so only
        # try the other channels when the adapter is there and actively says no.
        for ch in (1, 2, 3):
            sock = socket.socket(socket.AF_BLUETOOTH, socket.SOCK_STREAM, socket.BTPROTO_RFCOMM)
            sock.settimeout(8)
            try:
                await asyncio.to_thread(sock.connect, (self.addr, ch))
                sock.setblocking(False)
                self.reader, self.writer = await asyncio.open_connection(sock=sock)
                return
            except OSError as e:
                last = e
                sock.close()
                if getattr(e, "errno", None) != 111:  # 111 = refused: wrong channel; anything else: not reachable
                    break
        raise ObdError(f"Couldn't open the adapter ({last}). Make sure the car is on and nothing else (like a phone app) is connected to it.")

    async def write(self, data):
        self.writer.write(data)
        await self.writer.drain()

    async def read_some(self):
        b = await self.reader.read(256)
        if not b:
            raise ObdError("The adapter disconnected.")
        return b

    async def close(self):
        if self.writer:
            try:
                self.writer.close()
            except Exception:
                pass


class _UsbLink:
    """An ELM327 on a USB cable: no Bluetooth involved, so it can't upset the music."""
    def __init__(self, path):
        self.path, self.port = path, None

    async def open(self):
        try:
            import serial  # pyserial
        except ImportError:
            raise ObdError("pyserial isn't installed.")
        for baud in (38400, 115200, 9600, 230400):
            try:
                port = await asyncio.to_thread(serial.Serial, self.path, baud, timeout=0.05)
            except Exception as e:
                raise ObdError(f"Couldn't open the USB adapter ({e}).")
            await asyncio.to_thread(port.write, b"\rATZ\r")
            got, end = b"", time.monotonic() + 2.5
            while time.monotonic() < end and b">" not in got:
                got += await asyncio.to_thread(port.read, 256)
            if b"ELM" in got.upper() or b">" in got:
                self.port = port
                return
            port.close()
        raise ObdError("The USB adapter didn't answer at any speed.")

    async def write(self, data):
        await asyncio.to_thread(self.port.write, data)

    async def read_some(self):
        while True:
            b = await asyncio.to_thread(self.port.read, 256)
            if b:
                return b

    async def close(self):
        if self.port:
            try:
                self.port.close()
            except Exception:
                pass


class _BleLink:
    """Bluetooth LE adapter through BlueZ GATT: one characteristic notifies, one takes writes."""
    PREFER = ("fff0", "ffe0", "18f0", "e7810a71")

    def __init__(self, hub, path):
        self.hub, self.path = hub, path
        self.buf = asyncio.Queue()
        self.notify = self.wchar = None
        self.wtype = "request"
        self.handler = None

    async def open(self):
        d = self.hub.dbus
        try:
            await asyncio.wait_for(d.call("org.bluez", self.path, "org.bluez.Device1", "Connect"), 25)
        except DbusError as e:
            if "AlreadyConnected" not in e.name:
                raise ObdError("The adapter didn't answer. Turn the car on and try again.")
        for _ in range(40):  # wait for its services to be listed
            (objs,) = await d.call("org.bluez", "/", "org.freedesktop.DBus.ObjectManager", "GetManagedObjects")
            dev = objs.get(self.path, {}).get("org.bluez.Device1", {})
            if dev.get("ServicesResolved"):
                break
            await asyncio.sleep(0.25)
        else:
            raise ObdError("The adapter connected but never listed its services.")
        services = {p: i["org.bluez.GattService1"].get("UUID", "") for p, i in objs.items()
                    if p.startswith(self.path) and "org.bluez.GattService1" in i}
        chars = [(p, i["org.bluez.GattCharacteristic1"]) for p, i in objs.items()
                 if p.startswith(self.path) and "org.bluez.GattCharacteristic1" in i]

        def rank(svc_path):
            uuid = services.get(svc_path, "")
            return next((n for n, k in enumerate(self.PREFER) if k in uuid), 99)
        best = None
        for svc in sorted(services, key=rank):
            mine = [(p, c) for p, c in chars if c.get("Service") == svc]
            n = next((p for p, c in mine if {"notify", "indicate"} & set(c.get("Flags", []))), None)
            w = next(((p, c) for p, c in mine if {"write", "write-without-response"} & set(c.get("Flags", []))), None)
            if n and w:
                best = (n, w)
                break
        if not best:
            raise ObdError("This Bluetooth LE device doesn't look like an OBD adapter.")
        self.notify, (self.wchar, wc) = best[0], best[1]
        self.wtype = "command" if "write-without-response" in wc.get("Flags", []) else "request"
        bus = await d.get()
        rule = f"type='signal',interface='org.freedesktop.DBus.Properties',member='PropertiesChanged',path='{self.notify}'"
        await d.call("org.freedesktop.DBus", "/org/freedesktop/DBus", "org.freedesktop.DBus", "AddMatch", "s", [rule])

        def on_msg(msg):
            if msg.member == "PropertiesChanged" and msg.path == self.notify and msg.body and msg.body[0] == "org.bluez.GattCharacteristic1":
                v = msg.body[1].get("Value")
                if v is not None:
                    self.buf.put_nowait(bytes(unwrap(v)))
        self.handler = on_msg
        bus.add_message_handler(on_msg)
        await d.call("org.bluez", self.notify, "org.bluez.GattCharacteristic1", "StartNotify")

    async def write(self, data):
        for i in range(0, len(data), 20):  # small chunks: some adapters only take 20 bytes at a time
            await self.hub.dbus.call("org.bluez", self.wchar, "org.bluez.GattCharacteristic1", "WriteValue", "aya{sv}",
                                     [data[i:i + 20], {"type": Variant("s", self.wtype)}])

    async def read_some(self):
        return await self.buf.get()

    async def close(self):
        d = self.hub.dbus
        try:
            if self.handler:
                (await d.get()).remove_message_handler(self.handler)
            await d.call("org.bluez", self.path, "org.bluez.Device1", "Disconnect")
        except Exception:
            pass


class Obd:
    def __init__(self, hub):
        self.hub = hub
        self.link = None
        self.kick = asyncio.Event()
        self.requests = asyncio.Queue()
        self.data = {}
        self.scanning = False
        self.last_send = 0
        self.last_state = 0

    @property
    def cfg(self):
        return self.hub.settings.get("obd") or {}

    def st(self, **kw):
        self.hub.state["obd"].update(kw)
        self.hub.changed()

    # ---------------------------------------------------------------- scanning
    async def scan(self):
        if self.scanning:
            return
        self.scanning = True
        d, ad = self.hub.dbus, self.hub.bt.adapter
        self.st(scanning=True, found=[])
        try:
            try:
                await d.call("org.bluez", ad, "org.bluez.Adapter1", "StartDiscovery")
            except DbusError as e:
                if "InProgress" not in e.name:
                    raise UserError("Bluetooth isn't ready yet. Try again in a few seconds.")
            for _ in range(7):
                await asyncio.sleep(2)
                await self._collect()
        finally:
            try:
                await d.call("org.bluez", ad, "org.bluez.Adapter1", "StopDiscovery")
            except Exception:
                pass
            self.scanning = False
            await self._collect()
            self.st(scanning=False)

    async def _collect(self):
        (objs,) = await self.hub.dbus.call("org.bluez", "/", "org.freedesktop.DBus.ObjectManager", "GetManagedObjects")
        phone = (self.hub.state.get("phone") or {}).get("name")
        found = []
        for path, i in objs.items():
            dev = i.get("org.bluez.Device1")
            if not dev or not path.startswith(self.hub.bt.adapter):
                continue
            name = dev.get("Alias") or dev.get("Name") or ""
            if not dev.get("Name") or (phone and name == phone and dev.get("Connected")):
                continue
            uuids = [u.lower() for u in dev.get("UUIDs") or []]
            classic = "Class" in dev or SPP_UUID in uuids
            found.append({"addr": dev.get("Address"), "name": name, "kind": "bt" if classic else "ble",
                          "likely": bool(OBD_HINT.search(name)) or SPP_UUID in uuids,
                          "rssi": dev.get("RSSI"), "paired": bool(dev.get("Paired"))})
        for path in sorted(glob.glob("/dev/serial/by-id/*")):  # USB adapters (not the knob)
            if re.search(r"espressif|esp32", path, re.I):
                continue
            label = re.sub(r"^usb-|-if\d+.*$|_[0-9A-Fa-f]{6,}.*$", "", os.path.basename(path)).replace("_", " ")
            found.append({"addr": path, "name": label or "USB adapter", "kind": "usb", "likely": True, "rssi": 0, "paired": True})
        found.sort(key=lambda f: (f["kind"] != "usb", not f["likely"], -(f["rssi"] or -999)))
        self.hub.state["obd"]["found"] = found[:20]
        self.hub.changed()

    # ---------------------------------------------------------------- choosing an adapter
    async def use(self, addr, name, kind):
        if kind == "usb":
            if not str(addr or "").startswith("/dev/serial/by-id/") or ".." in addr:
                raise UserError("That doesn't look like a USB adapter.")
            self.hub.settings["obd"] = {"addr": addr, "name": str(name or "USB OBD adapter")[:40], "kind": "usb"}
        elif not re.match(r"^[0-9A-F]{2}(:[0-9A-F]{2}){5}$", str(addr or ""), re.I):
            raise UserError("That doesn't look like a Bluetooth adapter.")
        else:
            self.hub.settings["obd"] = {"addr": addr.upper(), "name": str(name or "OBD adapter")[:40], "kind": "ble" if kind == "ble" else "bt"}
        self.hub.save()
        self.st(status="connecting", message="Connecting…", name=self.hub.settings["obd"]["name"])
        self.restart()

    async def forget(self):
        addr = self.cfg.get("addr")
        self.hub.settings["obd"] = {}
        self.hub.save()
        self.restart()
        if addr and not addr.startswith("/dev/"):
            try:
                await self.hub.dbus.call("org.bluez", self.hub.bt.adapter, "org.bluez.Adapter1", "RemoveDevice", "o",
                                         [self._path(addr)])
            except Exception:
                pass

    def restart(self):
        self.kick.set()

    def _path(self, addr):
        return f"{self.hub.bt.adapter}/dev_{addr.upper().replace(':', '_')}"

    # ---------------------------------------------------------------- main loop
    async def loop(self):
        await asyncio.sleep(1)  # let Bluetooth come up first
        wait, quick = 5, 0
        while True:
            self.kick.clear()
            cfg = dict(self.cfg)
            if not cfg.get("addr"):
                self.st(status="off", message="", name=None, data={})
                await self.kick.wait()
                continue
            task = asyncio.create_task(self.session(cfg))
            kicked = asyncio.create_task(self.kick.wait())
            done, _ = await asyncio.wait({task, kicked}, return_when=asyncio.FIRST_COMPLETED)
            if task not in done:
                task.cancel()
                try:
                    await task
                except BaseException:
                    pass
                await self._close()
                continue
            kicked.cancel()
            err = task.exception() if not task.cancelled() else None
            await self._close()
            self.data = {}
            self.hub.state["obd"]["data"] = {}
            if err:
                msg = str(err) if isinstance(err, (ObdError, UserError)) else "Lost the adapter."
                self.event(f"Disconnected: {msg}")
                self.st(status="error", message=msg)
            if getattr(self, "was_connected", False):
                self.was_connected = False
                wait, quick = 1, 3   # it was working a moment ago: try again right away, a few times
            try:
                await asyncio.wait_for(self.kick.wait(), wait)
                wait = 5
            except asyncio.TimeoutError:
                if quick > 0:
                    quick -= 1
                    wait = 2
                else:
                    # an adapter that keeps failing is tried less and less often (each try ties up the Bluetooth
                    # radio for a few seconds, which can make music skip, so less often while music plays)
                    playing = (self.hub.state.get("media") or {}).get("status") == "playing"
                    wait = min(max(wait, 5) * 2, 60 if playing else 20)
            self.st(status="connecting", message="Trying again…")

    async def _close(self):
        if self.link:
            await self.link.close()
            self.link = None

    async def _ensure_paired(self, path):
        d = self.hub.dbus
        (objs,) = await d.call("org.bluez", "/", "org.freedesktop.DBus.ObjectManager", "GetManagedObjects")
        dev = objs.get(path, {}).get("org.bluez.Device1")
        if dev is None:
            raise ObdError("The adapter isn't in range. Turn the car on, then tap Scan.")
        if dev.get("Paired"):
            return
        for pin in OBD_PINS:
            self.hub.bt.pins[path] = pin
            try:
                await asyncio.wait_for(d.call("org.bluez", path, "org.bluez.Device1", "Pair"), 30)
                break
            except DbusError as e:
                if "AlreadyExists" in e.name:
                    break
                if "AuthenticationFailed" not in e.name and "AuthenticationRejected" not in e.name:
                    raise ObdError("Pairing didn't work. Turn the car off and on again, then tap the adapter.")
            except asyncio.TimeoutError:
                raise ObdError("Pairing timed out.")
        else:
            raise ObdError("The adapter didn't accept any of the usual PINs (1234, 0000).")
        await self.hub.bt.trust(path)

    async def session(self, cfg):
        path = self._path(cfg["addr"])
        self.st(status="connecting", message="Connecting to the adapter…", name=cfg.get("name"))
        if cfg.get("kind") == "usb":
            if not os.path.exists(cfg["addr"]):
                raise ObdError("The USB adapter isn't plugged in.")
            self.link = _UsbLink(cfg["addr"])
        elif cfg.get("kind") == "ble":
            self.link = _BleLink(self.hub, path)
        else:
            await self._ensure_paired(path)
            self.link = _SppLink(cfg["addr"])
        await self.link.open()
        t0 = time.monotonic()
        self.st(message="Waking up the adapter…")
        ver = await self.cmd("ATWS", 3)          # warm start: much quicker than a full ATZ reset
        if "?" in ver or not ver.strip():
            ver = await self.cmd("ATZ", 4)
        # What worked last time with this adapter (protocol, supported PIDs, speed tricks) is remembered,
        # so the adapter doesn't have to search every protocol and nothing needs probing again.
        cache = dict(cfg.get("cache") or {})
        proto = cache.get("proto")
        await self._init_elm(proto)
        self.st(message="Talking to the car…")
        first = await self.cmd("0100", 12 if proto else 20)
        tries = 0
        while not self._bits(first, 0):
            # The adapter is there but the car isn't answering (ignition off). Keep the Bluetooth link and
            # ask again every few seconds: the gauges come alive within seconds of starting the car.
            if tries == 0:
                self.event("Adapter ready, waiting for the ignition")
            self.st(status="connecting", message="Adapter ready. Waiting for the ignition…")
            tries += 1
            await asyncio.sleep(3)
            if proto:   # mostly the known protocol (fails fast); now and then a full search, in case it changed
                await self.cmd(f"ATSP{proto}" if tries % 6 else "ATSP0", 3)
            first = await self.cmd("0100", 12)
            t0 = time.monotonic()
        supported = self._bits(first, 0)
        cached = cache.get("pids") is not None and cache.get("proto") is not None
        if cached:
            supported |= {int(p, 16) for p in cache["pids"]}
        else:
            if 0x20 in supported:
                supported |= self._bits(await self.cmd("0120", 5), 0x20)
            if 0x40 in supported:
                supported |= self._bits(await self.cmd("0140", 5), 0x40)
        dpn = (await self.cmd("ATDPN", 3)).strip().upper().lstrip("A")[:1]
        proto = dpn if dpn and dpn in "123456789ABC" else proto
        self.can = (proto or "")[:1] in "6789ABC" and bool(proto)
        pids = [p for p in OBD_PIDS if int(p, 16) in supported] or list(OBD_FAST)
        slow = [p for p in pids if p not in OBD_FAST]
        elm = next((w for w in ver.split() if w.lower().startswith("v")), "")
        self.st(status="connected", message=f"Connected{(' (ELM327 ' + elm + ')') if elm else ''}",
                pids=[OBD_PIDS[p][0] for p in pids])
        # Speed tricks: a trailing "1" tells the adapter only one answer is coming, so it replies the moment
        # the car does instead of waiting out a timeout; on CAN cars, rpm and speed come back in one request.
        fast = [x for x in OBD_FAST if x in pids]
        if cached and cache.get("proto") == proto and "one" in cache:
            self.one, self.combo = bool(cache["one"]), bool(cache.get("combo"))
        else:
            self.one = False
            if fast and self._parse(await self.cmd("01" + fast[0] + "1", 2)):
                self.one = True
            self.combo = False
            if self.can and len(fast) == 2:
                got = self._parse(await self.cmd("01" + "".join(fast) + ("1" if self.one else ""), 2))
                self.combo = all(OBD_PIDS[p][0] in got for p in fast)
        new_cache = {"proto": proto, "pids": pids, "one": self.one, "combo": self.combo}
        live = self.hub.settings.get("obd")
        if isinstance(live, dict) and live.get("addr") == cfg.get("addr") and live.get("cache") != new_cache:
            live["cache"] = new_cache
            self.hub.save()
        log.info("obd connected in %.1f s: %s, protocol %s, pids %s, one-answer %s, combined %s%s",
                 time.monotonic() - t0, cfg.get("name"), proto, pids, self.one, self.combo,
                 " (remembered)" if cached else "")
        i = 0
        misses = 0
        empty_fast = 0
        resets = 0
        volts_at = 0
        self.timeouts = 0
        self.was_connected = True
        rate_n, rate_t = 0, time.time()
        while True:
            cycle_t = time.monotonic()
            while not self.requests.empty():
                await self._request(self.requests.get_nowait())
            got = {}
            if self.combo:
                got.update(await self.safe_ask("".join(fast)))
            else:
                for p in fast:
                    got.update(await self.safe_ask(p))
            # if the speed tricks stop working (some adapters do once you're moving), drop back to plain requests
            empty_fast = 0 if got else empty_fast + 1
            if empty_fast >= 6 and (self.combo or self.one):
                self.combo = self.one = False
                empty_fast = 0
                self.event("Switched to plain requests (the adapter stopped answering the fast ones)")
            if slow and i % 3 == 0:  # the slow-changing ones take turns, so rpm and speed stay quick
                got.update(await self.safe_ask(slow[(i // 3) % len(slow)]))
            for k, v in got.items():
                self.data[k] = round(v, 1)
            i += 1
            rate_n += 1
            if time.time() - rate_t >= 2:
                self.hub.state["obd"]["hz"] = round(rate_n / (time.time() - rate_t), 1)
                rate_n, rate_t = 0, time.time()
            if time.time() - volts_at > 5:
                volts_at = time.time()
                r = await self.cmd("ATRV", 3)
                m = re.search(r"(\d+(?:\.\d+)?)\s*V", r)
                if m:
                    self.data["volts"] = float(m.group(1))
            misses = 0 if got else misses + 1
            if misses > 25:
                if resets >= 2:
                    raise ObdError("The car stopped answering (engine off?).")
                resets += 1
                misses = 0
                self.event("No answers for a few seconds: restarting the adapter")
                await self.cmd("ATZ", 4)
                await self._init_elm(proto)
                await self.cmd("0100", 15)
            self.publish()
            # Every question to a Bluetooth adapter uses the same radio as your music. While music plays, a
            # Bluetooth adapter is asked about 8 times a second (the gauges glide between answers, so it still
            # looks smooth); otherwise, or over USB, as fast as it answers.
            playing = (self.hub.state.get("media") or {}).get("status") == "playing"
            gap = 0.12 if playing and cfg.get("kind") != "usb" else 0.005
            spent = time.monotonic() - cycle_t
            await asyncio.sleep(max(0.005, gap - spent))

    async def _init_elm(self, proto=None):
        # ATAT1: normal adaptive timing. (ATAT2 is faster but some adapters start missing answers once the
        # car's network gets busy, which is exactly what happens when you start driving.)
        # ATSPAx: try the protocol that worked last time first, and only search if it doesn't answer.
        for c in ("ATE0", "ATL0", "ATS0", "ATH0", "ATAT1", f"ATSPA{proto}" if proto else "ATSP0"):
            await self.cmd(c, 3)

    def event(self, text):
        """A short history of what the OBD link did, shown in Settings > Car."""
        ev = self.hub.state["obd"].setdefault("events", [])
        ev.insert(0, {"at": time.time(), "text": text})
        del ev[8:]
        log.info("obd: %s", text)
        self.hub.changed()

    async def safe_ask(self, pids):
        """Like ask(), but a slow or garbled answer doesn't end the connection."""
        try:
            got = await self.ask(pids)
            self.timeouts = 0
            return got
        except ObdError:
            self.timeouts = getattr(self, "timeouts", 0) + 1
            if self.timeouts >= 4:
                raise ObdError("The adapter stopped answering.")
            try:  # get the adapter's attention again and carry on
                await self.cmd("", 1.0)
            except ObdError:
                pass
            return {}

    @staticmethod
    def _bits(resp, base):
        out = set()
        for line in resp.replace(" ", "").splitlines():
            line = re.sub(r"^\d:", "", line)
            k = line.find("41" + f"{base:02X}")
            if k < 0 or len(line) < k + 12:
                continue
            mask = int(line[k + 4:k + 12], 16)
            for n in range(32):
                if mask & (1 << (31 - n)):
                    out.add(base + n + 1)
        return out

    async def cmd(self, text, timeout=2.0):
        if not text:  # just a return: ends anything half-sent and brings back the prompt
            await self.link.write(b"\r")
        else:
            await self.link.write((text + "\r").encode())
        buf = b""
        end = time.monotonic() + timeout
        while b">" not in buf:
            left = end - time.monotonic()
            if left <= 0:
                raise ObdError("The adapter stopped responding.")
            try:
                buf += await asyncio.wait_for(self.link.read_some(), left)
            except asyncio.TimeoutError:
                raise ObdError("The adapter stopped responding.")
        out = buf.split(b">")[0].decode(errors="ignore").replace("SEARCHING...", "")
        return "\n".join(l.strip() for l in out.replace("\r", "\n").split("\n") if l.strip() and l.strip() != text)

    async def ask(self, pids):
        """One mode 01 request for one or more PIDs (given as a hex string); returns {key: value}."""
        # a healthy adapter answers in well under half a second; waiting longer just freezes the gauges
        return self._parse(await self.cmd("01" + pids + ("1" if self.one else ""), 0.8))

    @staticmethod
    def _parse(resp):
        """Reads '41 PID data [PID data...]' answers, including several PIDs in one answer."""
        out = {}
        for line in resp.replace(" ", "").upper().splitlines():
            line = re.sub(r"^\d:", "", line)
            k = line.find("41")
            while k >= 0:
                j = k + 2
                while j + 2 <= len(line):
                    p = line[j:j + 2]
                    if p not in OBD_PIDS:
                        break
                    key, n, fn = OBD_PIDS[p]
                    if j + 2 + 2 * n > len(line):
                        break
                    bs = [int(line[j + 2 + 2 * m:j + 4 + 2 * m], 16) for m in range(n)] + [0]
                    out[key] = fn(bs[0], bs[1])
                    j += 2 + 2 * n
                k = line.find("41", j) if j > k + 2 else -1
        return out

    def publish(self):
        now = time.time()
        sp = self.data.get("speed")
        if sp is not None:
            self.hub.state["speed"] = {"mps": sp / 3.6, "at": now, "src": "obd"}
        self.hub.state["obd"]["data"] = self.data
        if self.hub.settings.get("knob_style") == "tach" and now - getattr(self, "last_knob", 0) > 0.08:
            self.last_knob = now  # the Tachometer face needs rpm more often than once a second
            self.hub.knob.push()
        if now - self.last_send > 0.03:
            self.last_send = now
            asyncio.create_task(self.hub.broadcast_raw({"type": "obd", "data": self.data}))
        if now - self.last_state > 1:
            self.last_state = now
            self.hub.changed()

    # ---------------------------------------------------------------- trouble codes
    async def codes(self, clear=False):
        if self.hub.state["obd"].get("status") != "connected":
            raise UserError("Connect the OBD adapter first.")
        fut = asyncio.get_running_loop().create_future()
        await self.requests.put(("clear" if clear else "read", fut))
        return await asyncio.wait_for(fut, 30)

    async def _request(self, req):
        kind, fut = req
        try:
            if kind == "clear":
                r = await self.cmd("04", 10)
                ok = "44" in r.replace(" ", "")
                self.hub.state["obd"]["codes"] = {"stored": [], "pending": [], "at": time.time()} if ok else self.hub.state["obd"].get("codes")
                fut.set_result(ok)
            else:
                stored = self._dtcs(await self.cmd("03", 10), "43")
                pending = self._dtcs(await self.cmd("07", 10), "47")
                self.hub.state["obd"]["codes"] = {"stored": stored, "pending": pending, "at": time.time()}
                fut.set_result(True)
            self.hub.changed()
        except Exception as e:
            if not fut.done():
                fut.set_exception(e)

    def _dtcs(self, resp, head):
        lines = [re.sub(r"^\d:", "", l.replace(" ", "")) for l in resp.splitlines()]
        lines = [l for l in lines if re.fullmatch(r"[0-9A-F]+", l)]
        if self.can:
            joined = "".join(l for l in lines if len(l) > 3)  # drop the multi-frame byte count line
            k = joined.find(head)
            data = joined[k + 4:] if k >= 0 else ""
        else:
            data = "".join(l[2:] for l in lines if l.startswith(head))
        out = []
        for j in range(0, len(data) - 3, 4):
            c = data[j:j + 4]
            if c == "0000":
                continue
            b0 = int(c[0], 16)
            code = "PCBU"[b0 >> 2] + str(b0 & 3) + c[1:]
            if code not in out:
                out.append(code)
        return out


# ---------------------------------------------------------------------- commands
class UserError(Exception):
    pass


async def handle(hub, msg, ws=None):
    cmd = msg.get("cmd")
    s = hub.settings
    if cmd == "media":
        await hub.bt.media(msg.get("action"))
    elif cmd == "settings":
        patch = msg.get("patch") or {}
        if "weather_look" in patch:
            if patch["weather_look"] and not s.get("weather_look"):
                s["weather_look_prev"] = {k: s.get(k) for k in WEATHER_LOOK_KEYS}
            elif not patch["weather_look"] and s.get("weather_look"):
                prev = s.pop("weather_look_prev", None) or {}
                patch = dict(patch, **{k: v for k, v in prev.items() if v is not None and k not in patch})
        elif s.get("weather_look") and ({"theme", "effect", "style"} & set(patch)):
            s["weather_look"] = False   # you picked a look yourself: the weather stops changing it
            s.pop("weather_look_prev", None)
        relayout = False
        for k, rule in SCHEMA.items():
            if k in patch:
                try:
                    v = check(rule, patch[k])
                except (ValueError, TypeError):
                    continue
                if s.get(k) != v and k in ("maps_panel", "nav", "app_size", "ui_scale", "app_view", "map_only",
                                           "map_crop_top", "map_crop_bottom", "map_bg"):
                    relayout = True
                if k == "app_view" and v == "page":
                    hub.apps.page_failed = False   # picking it again means: try the in-page stream again
                s[k] = v
        if patch.get("weather_look"):
            apply_weather_look(hub)   # match the weather right away
        if isinstance(patch.get("glass"), dict):
            for k, rule in GLASS_SCHEMA.items():
                if k in patch["glass"]:
                    try:
                        s["glass"][k] = check(rule, patch["glass"][k])
                    except (ValueError, TypeError):
                        pass
        if isinstance(patch.get("gauges"), dict):
            gp, cur = patch["gauges"], s.setdefault("gauges", dict(DEFAULTS["gauges"]))
            if gp.get("layout") in GAUGE_LAYOUTS:
                cur["layout"] = gp["layout"]
            sl = gp.get("slots")
            if isinstance(sl, list) and len(sl) == 6 and all(x in GAUGE_TYPES for x in sl):
                cur["slots"] = list(sl)
        if isinstance(patch.get("home_cards"), dict):
            for lay, cards in patch["home_cards"].items():
                n = LAYOUT_SLOTS.get(lay)
                if n and isinstance(cards, list) and len(cards) == n and all(c in CARD_TYPES for c in cards):
                    s["home_cards"][lay] = list(cards)
        if isinstance(patch.get("home_tiles"), list):
            # Freeform Home: up to 24 panels on a 12 x 8 grid, no overlaps, each with its own look
            tiles, taken = [], set()
            for c in patch["home_tiles"][:24]:
                try:
                    t = c["t"] if c["t"] in CARD_TYPES else "music"
                    w = int(clamp(int(c["w"]), 1, 12)); h = int(clamp(int(c["h"]), 1, 8))
                    x = int(clamp(int(c["x"]), 0, 12 - w)); y = int(clamp(int(c["y"]), 0, 8 - h))
                except (KeyError, TypeError, ValueError):
                    continue
                cells = {(cx, cy) for cx in range(x, x + w) for cy in range(y, y + h)}
                if cells & taken:
                    continue
                taken |= cells
                item = {"t": t, "x": x, "y": y, "w": w, "h": h}
                for k, ok in (("r", ("sharp", "soft", "round", "pill")), ("g", ("clear", "light", "normal", "heavy")),
                              ("e", ("none", "glow", "holo", "pulse"))):
                    if c.get(k) in ok:
                        item[k] = c[k]
                tiles.append(item)
            s["home_tiles"] = tiles
        if isinstance(patch.get("home_free"), list):
            # Freeform Home: up to 12 panels on a 12 x 8 grid, each with its own look
            free = []
            for c in patch["home_free"][:12]:
                try:
                    t = c["t"] if c["t"] in CARD_TYPES else "music"
                    w = int(clamp(int(c["w"]), 2, 12)); h = int(clamp(int(c["h"]), 2, 8))
                    x = int(clamp(int(c["x"]), 0, 12 - w)); y = int(clamp(int(c["y"]), 0, 8 - h))
                except (KeyError, TypeError, ValueError):
                    continue
                item = {"t": t, "x": x, "y": y, "w": w, "h": h}
                for k, ok in (("r", ("sharp", "soft", "round", "pill")), ("g", ("clear", "light", "normal", "heavy")),
                              ("e", ("none", "glow", "holo", "pulse"))):
                    if c.get(k) in ok:
                        item[k] = c[k]
                free.append(item)
            s["home_free"] = free
        if "brightness" in patch:
            b = int(clamp(int(patch["brightness"]), 0, 100))
            s["brightness"] = b
            if b > 0:
                s["brightness_last"] = b
            if s.get("use_ddc") and b > 0 and shutil.which("ddcutil"):
                asyncio.create_task(run("ddcutil", "setvcp", "10", str(b), timeout=8))
        if isinstance(patch.get("look_schedule"), dict):
            sc = patch["look_schedule"]
            rules = []
            for r in (sc.get("rules") or [])[:12]:
                if not isinstance(r, dict) or r.get("when") not in SCHEDULE_WHEN or not isinstance(r.get("look"), str):
                    continue
                item = {"when": r["when"], "look": r["look"][:60]}
                if r["when"] == "time":
                    try:
                        item["from"] = int(clamp(int(r.get("from", 0)), 0, 1439))
                        item["to"] = int(clamp(int(r.get("to", 0)), 0, 1439))
                    except (TypeError, ValueError):
                        continue
                rules.append(item)
            s["look_schedule"] = {"on": bool(sc.get("on")), "rules": rules}
            hub.sched_key = None  # apply the new schedule right away
            asyncio.get_running_loop().call_soon(hub.run_schedule)
        if {"theme", "splash_style", "splash_text"} & set(patch):
            write_splash(hub)
        if relayout and hub.apps.proc:
            asyncio.create_task(hub.apps.relayout())
        hub.save()
        hub.changed()
    elif cmd == "app_touch":
        try:
            hub.apps.page.touch(int(msg["a"]), int(msg.get("id", 0)), msg["x"], msg["y"], msg["w"], msg["h"])
        except (KeyError, TypeError, ValueError):
            pass
    elif cmd == "app_key":
        hub.apps.page.key({"back": 4, "home": 3}.get(msg.get("key"), 4))
    elif cmd == "app_view_fail":
        # the screen couldn't decode the in-page video: use the classic window from now on (until restart)
        log.warning("screen can't play the in-page stream: %s", msg.get("why"))
        if not hub.apps.page_failed:
            hub.apps.page_failed = True
            cur = hub.state["app"]["current"]
            if cur:
                asyncio.create_task(hub.apps.open(cur))
    elif cmd == "design_preview":
        hub.design_preview(msg.get("design"))
    elif cmd == "splash_play":
        await hub.broadcast_raw({"type": "splash"})
    elif cmd == "design_use":
        await hub.design_use(msg.get("id") or None)
    elif cmd == "design_delete":
        await hub.design_delete(str(msg.get("id") or ""))
    elif cmd == "app_rect":
        await hub.apps.set_rect(msg)
    elif cmd == "display_mode":
        await hub.display.choose(str(msg.get("mode", "")))
    elif cmd == "display_keep":
        await hub.display.keep()
    elif cmd == "display_revert":
        await hub.display.revert()
    elif cmd == "audio":
        patch = msg.get("patch") or {}
        a = s["audio"]
        for k, (lo, hi) in AUDIO_LIMITS.items():
            if k in patch:
                a[k] = int(clamp(int(round(float(patch[k]))), lo, hi))
        if msg.get("reset_tone"):
            a.update(bass=0, mid=0, treble=0)
        hub.save()
        hub.changed()
        if {"volume", "call_volume", "assistant_volume"} & set(patch):
            await hub.audio.apply_volume()
            hub.audio.watch("volume change")
        if set(patch) - {"volume", "call_volume", "assistant_volume"} or msg.get("reset_tone"):
            hub.audio.request_apply()
    elif cmd == "fix_audio":
        fixed = await hub.audio.repair(log_it=True)
        raise UserError("Sound fixed: " + "; ".join(fixed) + "." if fixed else "Sound routing checked: everything was already connected right.")
    elif cmd == "queue_play":
        await hub.to_phone("queue_play", id=int(msg.get("id", 0)))
    elif cmd == "queue_refresh":
        await hub.to_phone("queue_refresh")
    elif cmd == "library_open":
        hub.library = {"status": "loading", "parent": str(msg.get("id") or "")}
        await hub.broadcast("library", hub.library)
        await hub.to_phone("browse", id=str(msg.get("id") or ""))
    elif cmd == "library_play":
        await hub.to_phone("play_media", id=str(msg.get("id", "")))
    elif cmd == "music_search":
        q = str(msg.get("query", "")).strip()[:120]
        if q:
            await hub.to_phone("search", query=q)
    elif cmd == "pin_add":
        name = str(msg.get("name", "")).strip()[:60]
        pins = [p for p in s.get("music_pins", []) if p.get("name") != name]
        if name:
            pins.insert(0, {"name": name, "query": str(msg.get("query") or name)[:120],
                            "id": str(msg.get("id") or "")[:400], "art": msg.get("art") if isinstance(msg.get("art"), str) and len(msg.get("art")) < 40_000 else None})
            s["music_pins"] = pins[:24]
            hub.save()
            hub.changed()
    elif cmd == "pin_remove":
        s["music_pins"] = [p for p in s.get("music_pins", []) if p.get("name") != msg.get("name")]
        hub.save()
        hub.changed()
    elif cmd == "queue_active":
        # only the playing song changed within the same Up next list: tiny update, no re-send of the list
        if hub.queue is not None:
            hub.queue["active"] = msg.get("id")
            await hub.broadcast_raw({"type": "queue_active", "id": msg.get("id")})
    elif cmd == "queue_push":
        q = msg.get("queue")
        if isinstance(q, dict):
            hub.queue = q
            await hub.broadcast("queue", q)
    elif cmd == "library_push":
        lib = msg.get("library")
        if isinstance(lib, dict):
            hub.library = lib
            await hub.broadcast("library", lib)
    elif cmd == "speaker_test":
        await hub.audio.speaker_test()
    elif cmd == "dial":
        await hub.calls.dial(msg.get("number"))
    elif cmd == "answer":
        await hub.calls.answer()
    elif cmd == "hangup":
        await hub.calls.hangup()
    elif cmd == "mute":
        await hub.calls.mute()
    elif cmd == "assistant":
        await hub.calls.assistant()
    elif cmd == "open_app":
        await hub.apps.open(msg.get("app"))
    elif cmd == "close_app":
        await hub.apps.park()
    elif cmd == "tool" and ws is not None:
        name = str(msg.get("tool", ""))

        async def go():  # runs alongside, so the screen stays responsive during long tools
            await ws.send_str(json.dumps({"type": "tool_result", "tool": name, "running": True}))
            ok, out = await run_tool(hub, name)
            try:
                await ws.send_str(json.dumps({"type": "tool_result", "tool": name, "ok": ok, "out": out}))
            except Exception:
                pass
        asyncio.create_task(go())
    elif cmd == "pair":
        await hub.bt.make_discoverable()
    elif cmd == "phone_hello":
        if ws is not None:
            hub.phone_ws = ws
            ip = getattr(ws, "peer_ip", None)
            if ip and ip.startswith("10.42."):
                hub.phone_ip = ip   # the phone's address on the Pi's Wi-Fi, for the wireless stream
        hub.state["companion"] = {"connected": True, "name": str(msg.get("name", "Phone"))[:40], "seen": time.time()}
        hub.changed()
        # the phone app holds on to the Pi's Wi-Fi by name and password (Android's device-network request)
        hot = hub._hotspot()
        if ws is not None and hot and hot.get("ssid") and hot.get("password"):
            try:
                bssid = Path("/sys/class/net/wlan0/address").read_text().strip()
            except Exception:
                bssid = ""
            # with the BSSID, Android remembers the user's "allow" and stops asking every time
            await ws.send_str(json.dumps({"type": "hotspot", "ssid": hot["ssid"], "password": hot["password"],
                                          "bssid": bssid}))
    elif cmd == "time_push":
        epoch = float(msg.get("epoch", 0))
        if epoch > 1.7e9 and abs(epoch - time.time()) > 5:
            rc, _, err = await run("sudo", "-n", "date", "-s", f"@{int(epoch)}")
            log.info("clock set from phone (rc=%s) %s", rc, err.strip())
    elif cmd == "weather_push":
        w = msg.get("weather") or {}
        code = int(w.get("code", 3))
        text = next((t for codes, t in WEATHER_TEXT if code in codes), "")
        hub.state["weather"] = {"temp": round(float(w.get("temp", 0))), "code": code, "text": text,
                                "day": bool(w.get("day", True)), "hi": round(float(w.get("hi", 0))),
                                "lo": round(float(w.get("lo", 0))), "city": w.get("city"),
                                "source": "phone", "at": time.time()}
        apply_weather_look(hub)
        hub.changed()
    elif cmd == "speed_push":
        mps = msg.get("mps")
        cur = hub.state.get("speed") or {}
        if cur.get("src") == "obd" and time.time() - cur.get("at", 0) < 3:
            return  # the car's own speed wins over the phone's GPS
        hub.state["speed"] = None if mps is None else {"mps": max(0.0, float(mps)), "at": time.time()}
        hub.changed()
    elif cmd == "nav_push":
        n = msg.get("nav") or {}
        hub.state["nav"] = {"active": bool(n.get("active")), "title": str(n.get("title", ""))[:80],
                            "text": str(n.get("text", ""))[:160], "sub": str(n.get("sub", ""))[:120],
                            "icon": n.get("icon") if isinstance(n.get("icon"), str) and len(n["icon"]) < 200_000 else None}
        hub.changed()
    elif cmd == "media_art":
        art = msg.get("art")
        hub.state["art"] = {"title": str(msg.get("title", "")), "artist": str(msg.get("artist", "")),
                            "data": art if isinstance(art, str) and len(art) < 600_000 else None}
        hub.changed()
    elif cmd == "favorites_push":
        favs = [{"name": str(f.get("name", ""))[:40], "number": str(f.get("number", ""))[:30]}
                for f in (msg.get("favorites") or []) if isinstance(f, dict)]
        if favs:
            s["favorites"] = favs
            FAVORITES_FILE.write_text(json.dumps(favs, indent=2))
            hub.changed()
    elif cmd == "obd_scan":
        asyncio.create_task(_obd_task(hub, ws, hub.obd.scan()))
    elif cmd == "obd_use":
        await hub.obd.use(msg.get("addr"), msg.get("name"), msg.get("kind"))
    elif cmd == "obd_forget":
        await hub.obd.forget()
    elif cmd == "obd_retry":
        hub.obd.restart()
    elif cmd == "obd_codes":
        asyncio.create_task(_obd_task(hub, ws, hub.obd.codes(bool(msg.get("clear"))), clear=bool(msg.get("clear"))))
    elif cmd == "clear_recents":
        s["recents"] = []
        hub.save()
        hub.changed()



# --------------------------------------------------------------------------- updates
# Send headunit.zip (or just the phone app's .apk) from the phone app, or open
# http://10.42.0.1:8080/update in a browser. The Pi installs it and restarts by itself.
UPDATE_PAGE = """<!doctype html><meta name=viewport content="width=device-width,initial-scale=1">
<title>Update head unit</title><style>body{font:17px system-ui;margin:2rem;max-width:30rem}
button,input{font:inherit;margin-top:1rem}</style><h2>Update the head unit</h2>
<p>Pick <b>headunit.zip</b>, or the phone app's <b>.apk</b>.</p>
<form method=post enctype=multipart/form-data><input type=file name=file accept=".zip,.apk"><br>
<button>Send update</button></form>"""


async def _obd_task(hub, ws, coro, clear=None):
    """Runs a slow OBD job without holding up the screen's other taps; reports problems as a toast."""
    try:
        r = await coro
        if clear is True:
            text = "Trouble codes cleared. The check engine light goes off now." if r else "The car didn't clear the codes. Try with the engine off and the ignition on."
        elif clear is False:
            c = hub.state["obd"].get("codes") or {}
            n = len(c.get("stored", [])) + len(c.get("pending", []))
            text = "No trouble codes." if not n else f"Found {n} trouble code{'s' if n > 1 else ''}."
        else:
            return
    except (UserError, ObdError) as e:
        text = str(e)
    except asyncio.TimeoutError:
        text = "The car took too long to answer."
    except Exception:
        log.exception("obd task")
        text = "Something went wrong. Details are in the backend log."
    try:
        await ws.send_str(json.dumps({"type": "toast", "text": text}))
    except Exception:
        pass


SCHEDULE_WHEN = ("time", "day", "night", "rain", "snow", "storm", "fog", "clear", "cloudy")


def write_splash(hub):
    """Lets the start-up splash (shown before the backend is up) use the current look: colors (the
    active design's own colors win), animation style and name."""
    s = hub.settings
    t = next((t for t in THEMES if t["id"] == s.get("theme")), THEMES[0])
    data = {k: t[k] for k in ("base", "b1", "b2", "b3", "accent") if k in t}
    des = hub.state.get("design") or {}
    if des.get("colors"):
        data.update({k: v for k, v in des["colors"].items() if k in data})
    data["style"] = s.get("splash_style", "warp")
    data["name"] = s.get("splash_text") or "Pi Head Unit"
    try:
        (WEB / "splash_theme.js").write_text(f"window.HU_THEME = {json.dumps(data)};\n")
    except OSError as e:
        log.warning("splash theme: %s", e)


def read_version():
    try:
        return (BASE / "VERSION").read_text().strip()
    except OSError:
        return "unknown"


def install_update(data: bytes, filename: str) -> str:
    """Checks and installs an update. Returns a message; raises UserError if it's not a valid update."""
    TMP.mkdir(parents=True, exist_ok=True)
    if filename.lower().endswith(".apk"):
        if data[:2] != b"PK":
            raise UserError("That doesn't look like an Android app (.apk).")
        dest = BASE / "phone" / "HeadUnitLink.apk"
        dest.parent.mkdir(exist_ok=True)
        tmp = dest.with_suffix(".new")
        tmp.write_bytes(data)
        tmp.replace(dest)
        return "Phone app saved. The Pi installs it on the phone within a few seconds."
    zpath = TMP / "update.zip"
    zpath.write_bytes(data)
    try:
        z = zipfile.ZipFile(zpath)
    except zipfile.BadZipFile:
        raise UserError("That file isn't a zip.")
    names = z.namelist()
    if "headunit/backend/server.py" not in names:
        raise UserError("That zip isn't a head unit update (no headunit/backend/server.py inside).")
    if any(n.startswith("/") or ".." in Path(n).parts for n in names):
        raise UserError("That zip has unsafe file paths, so it was ignored.")
    stage = TMP / "update"
    shutil.rmtree(stage, ignore_errors=True)
    z.extractall(stage)
    new = stage / "headunit"
    try:
        py_compile.compile(str(new / "backend" / "server.py"), doraise=True)
    except py_compile.PyCompileError as e:
        raise UserError(f"The update has an error in it, so nothing was changed: {e.msg[:120]}")
    # keep the current version so a bad update can be undone with scripts/rollback.sh
    backup = BASE.parent / "headunit-previous"
    shutil.rmtree(backup, ignore_errors=True)
    shutil.copytree(BASE, backup, ignore=shutil.ignore_patterns("venv", "__pycache__"), symlinks=True)
    for src in new.rglob("*"):
        rel = src.relative_to(new)
        dst = BASE / rel
        if src.is_dir():
            dst.mkdir(parents=True, exist_ok=True)
            continue
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(src, dst)
        if dst.suffix == ".sh":
            dst.chmod(0o755)
    shutil.rmtree(stage, ignore_errors=True)
    zpath.unlink(missing_ok=True)
    return f"Updated to {read_version()}. The head unit restarts in a moment."


async def update_page(request):
    return web.Response(text=UPDATE_PAGE, content_type="text/html")


async def update_post(request):
    hub = request.app["hub"]
    try:
        reader = await request.multipart()
        part = await reader.next()
        while part is not None and part.name != "file":
            part = await reader.next()
        if part is None or not part.filename:
            raise UserError("No file was sent.")
        data = await part.read()
        msg = await asyncio.to_thread(install_update, data, part.filename)
    except UserError as e:
        return web.Response(status=400, text=str(e))
    log.info("update: %s", msg)
    for ws in list(hub.clients):
        try:
            await ws.send_str(json.dumps({"type": "toast", "text": msg}))
        except Exception:
            pass
    if not part.filename.lower().endswith(".apk"):
        # the start script restarts the backend; the screen reloads once it's back
        asyncio.get_running_loop().call_later(1.5, os._exit, 0)
    return web.Response(text=msg)



# --------------------------------------------------------------------------- tools and phone terminal
# One-tap maintenance (Settings > Tools on the screen, and in the phone app), plus a terminal in the
# phone app. The terminal needs a secret key, which the Pi only hands out over the phone's ADB tunnel
# (requests that arrive from 127.0.0.1), so other devices on the Wi-Fi can't use it.
TERM_TOKEN_FILE = CONF_DIR / "term_token"
SCRIPTS = BASE / "scripts"


def term_token():
    try:
        return TERM_TOKEN_FILE.read_text().strip()
    except OSError:
        tok = secrets.token_hex(24)
        TERM_TOKEN_FILE.write_text(tok)
        TERM_TOKEN_FILE.chmod(0o600)
        return tok


async def shell(cmd, timeout=300, cwd=None):
    """Runs a shell command, returns (exit code, combined output). Never raises."""
    try:
        proc = await asyncio.create_subprocess_exec(
            "bash", "-lc", cmd, cwd=cwd or str(Path.home()),
            stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT, stdin=asyncio.subprocess.DEVNULL)
        out, _ = await asyncio.wait_for(proc.communicate(), timeout)
        return proc.returncode, out.decode(errors="replace")[-60000:]
    except asyncio.TimeoutError:
        try:
            proc.kill()
        except Exception:
            pass
        return 124, f"Stopped after {timeout} seconds (took too long)."
    except Exception as e:
        return 1, str(e)


LOGS_DIR = CONF_DIR / "logs"
TOOLS = {
    "phone_update": ("Install update from phone", "", "restart"),
    "usb_update": ("Install update from USB stick", f'bash "{SCRIPTS}/usb-update.sh"', "restart"),
    "clear_cache": ("Clear screen cache", 'cd ~/.config/headunit/chromium/Default && rm -rf Cache "Code Cache" GPUCache && echo "Screen cache cleared."', "browser"),
    "restart": ("Restart head unit", 'echo "Restarting…"', "restart"),
    "reboot": ("Reboot the Pi", 'echo "Rebooting…"; (sleep 2; sudo -n reboot) >/dev/null 2>&1 &', None),
    "fix_internet": ("Fix phone internet", f'bash "{SCRIPTS}/fix-phone-internet.sh"', None),
    "fix_boot": ("Fix boot flashes", f'bash "{SCRIPTS}/fix-boot-flash.sh"', None),
    "fix_splash": ("Reinstall boot logo", f'bash "{SCRIPTS}/set-splash.sh"', None),
    "wifi_check": ("Wi-Fi check", "echo '— Hotspot —'; nmcli -t -f NAME,DEVICE,STATE connection show --active; "
                   "echo; echo '— Local-only fix —'; cat /etc/NetworkManager/dnsmasq-shared.d/headunit-local-only.conf 2>/dev/null "
                   "|| echo 'NOT applied (tap Fix phone internet)'; echo; echo '— Phones on the Pi Wi-Fi —'; "
                   "cat /var/lib/NetworkManager/dnsmasq-wlan0.leases 2>/dev/null || ip neigh show dev wlan0", None),
    "claude_code": ("Start Claude Code", f'bash "{SCRIPTS}/claude-code.sh"', None),
    "sound_report": ("Sound report", 'echo "— what plays where —"; pw-link -l 2>&1 | head -70; echo; echo "— devices —"; wpctl status 2>&1 | sed -n "1,60p"', None),
    "logs": ("Show logs", f'tail -n 40 "{LOGS_DIR}/backend.log"; echo; echo "— screen —"; tail -n 15 "{LOGS_DIR}/ui.log"', None),
}


async def run_tool(hub, name):
    """Runs one maintenance tool. Returns (ok, output); restarts things afterwards if the tool needs it."""
    if name not in TOOLS:
        return False, "Unknown tool."
    label, cmd, after = TOOLS[name]
    if name == "phone_update":
        code, out = await update_from_phone(hub)
    else:
        code, out = await shell(cmd, timeout=600)
    if "a password is required" in out or "a terminal is required" in out:
        out += "\n\nThis needs a one-time setup. Run once on the Pi:\n  bash ~/headunit/scripts/enable-tools.sh"
    ok = code == 0
    if ok and after == "browser":
        await shell("pkill -f -- '--user-data-dir=.*headunit/chromium' || true", timeout=10)
    if ok and after == "restart":
        await shell("cd ~/.config/headunit/chromium/Default && rm -rf Cache 'Code Cache' GPUCache", timeout=20)
        asyncio.get_running_loop().call_later(1.5, os._exit, 0)
    log.info("tool %s -> %s", name, code)
    return ok, out.strip() or ("Done." if ok else "It didn't work.")


async def update_from_phone(hub):
    """Finds the newest headunit*.zip in the phone's Download folder over ADB and installs it."""
    serial = (hub.state.get("adb") or {}).get("serial")
    if not serial:
        return 1, "The phone isn't connected over ADB right now (needed to read its Download folder)."
    _, listing, _ = await run("adb", "-s", serial, "shell", "ls", "-t", "/sdcard/Download/", timeout=10)
    names = [n.strip() for n in listing.splitlines() if n.strip().lower().startswith("headunit") and n.strip().lower().endswith(".zip")]
    if not names:
        return 1, "No headunit zip in the phone's Download folder. Download it there first."
    name = names[0]  # ls -t: newest first
    TMP.mkdir(parents=True, exist_ok=True)
    dest = TMP / "from-phone.zip"
    rc, _, err = await run("adb", "-s", serial, "pull", f"/sdcard/Download/{name}", str(dest), timeout=120)
    if rc != 0:
        return 1, f"Couldn't copy {name} from the phone: {err.strip()[:200]}"
    try:
        msg = await asyncio.to_thread(install_update, dest.read_bytes(), name)
    except UserError as e:
        return 1, str(e)
    return 0, f"Found {name} on the phone.\n{msg}"


def _local(request):
    # the Pi itself, or the phone through its ADB tunnel (phone's localhost:8080 -> Pi)
    return request.remote in ("127.0.0.1", "::1")


def _authorized(request, data):
    return _local(request) or secrets.compare_digest(str(data.get("token", "")), term_token())


async def term_token_get(request):
    # only over the phone's ADB tunnel (it arrives from this machine), never straight over Wi-Fi
    if request.remote not in ("127.0.0.1", "::1"):
        return web.json_response({"error": "Connect the phone to the Pi once with ADB to unlock the terminal."}, status=403)
    return web.json_response({"token": term_token()})


async def term_post(request):
    try:
        data = await request.json()
    except Exception:
        return web.json_response({"error": "Bad request"}, status=400)
    if not _authorized(request, data):
        return web.json_response({"error": "This phone isn't unlocked for the terminal yet."}, status=403)
    cmd = str(data.get("cmd", ""))[:4000]
    cwd = str(data.get("cwd") or Path.home())
    if not Path(cwd).is_dir():
        cwd = str(Path.home())
    marker = "\x1fCWD:"
    code, out = await shell(f"{cmd}\n__rc=$?; printf '\\n{marker}%s' \"$PWD\"; exit $__rc", timeout=int(clamp(int(data.get("timeout", 120)), 5, 900)), cwd=cwd)
    newcwd = cwd
    if marker in out:
        out, _, newcwd = out.rpartition(marker)
        newcwd = newcwd.strip() or cwd
    return web.json_response({"out": out.rstrip("\n"), "code": code, "cwd": newcwd})


async def tool_post(request):
    try:
        data = await request.json()
    except Exception:
        return web.json_response({"error": "Bad request"}, status=400)
    if not _authorized(request, data):
        return web.json_response({"error": "This phone isn't unlocked yet."}, status=403)
    ok, out = await run_tool(request.app["hub"], str(data.get("tool", "")))
    return web.json_response({"ok": ok, "out": out})


TERM_PAGE = r"""<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><title>Pi Terminal</title>
<style>
:root{color-scheme:dark}*{box-sizing:border-box}body{margin:0;background:#05070B;color:#E5E7EB;font:15px system-ui;padding:env(safe-area-inset-top) 0 env(safe-area-inset-bottom)}
header{padding:14px 16px 6px;font-weight:700;font-size:20px}.tools{display:flex;gap:8px;overflow-x:auto;padding:6px 16px 10px;scrollbar-width:none}
.tools button{flex:0 0 auto;padding:10px 14px;border-radius:14px;border:0;background:#1F2937;color:#E5E7EB;font:600 14px system-ui}
.tools button.busy{outline:2px solid #5EEAD4}
#out{margin:0 12px;padding:12px;height:calc(100vh - 230px);overflow:auto;background:#000;border-radius:14px;font:13px/1.45 ui-monospace,"DejaVu Sans Mono",monospace;white-space:pre-wrap;word-break:break-word}
.cmd{color:#5EEAD4}.err{color:#FCA5A5}.cwd{color:#9CA3AF;font-size:12px;padding:8px 16px 4px}
form{display:flex;gap:8px;padding:6px 12px 12px}input{flex:1;min-width:0;padding:14px;border-radius:14px;border:1px solid #374151;background:#0B0F17;color:#fff;font:15px ui-monospace,monospace}
form button{padding:0 18px;border-radius:14px;border:0;background:#5EEAD4;color:#06080C;font:700 15px system-ui}
.quick{display:flex;gap:6px;overflow-x:auto;padding:0 12px 8px}.quick button{flex:0 0 auto;padding:7px 10px;border-radius:10px;border:0;background:#111827;color:#9CA3AF;font:13px ui-monospace,monospace}
</style></head><body>
<header>Pi Terminal</header>
<div class="tools" id="tools"></div>
<pre id="out"></pre>
<div class="cwd" id="cwd">~</div>
<div class="quick" id="quick"></div>
<form id="f"><input id="c" autocomplete="off" autocapitalize="off" spellcheck="false" placeholder="type a command"><button>Run</button></form>
<script>
const out=document.getElementById('out'),c=document.getElementById('c');let cwd='',hist=[],hi=0;
const add=(t,cls)=>{const s=document.createElement('span');if(cls)s.className=cls;s.textContent=t+'\n';out.appendChild(s);out.scrollTop=out.scrollHeight;};
async function post(url,body){const r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});return r.json();}
async function run(cmd){add('$ '+cmd,'cmd');hist.push(cmd);hi=hist.length;
  try{const r=await post('/term',{cmd,cwd});if(r.error)return add(r.error,'err');if(r.out)add(r.out,r.code?'err':'');cwd=r.cwd;document.getElementById('cwd').textContent=cwd;}
  catch(e){add('Lost the connection to the Pi.','err');}}
document.getElementById('f').onsubmit=e=>{e.preventDefault();const v=c.value.trim();if(v){c.value='';run(v);}};
c.onkeydown=e=>{if(e.key==='ArrowUp'&&hi>0){c.value=hist[--hi];e.preventDefault();}if(e.key==='ArrowDown'){c.value=hist[++hi]||'';hi=Math.min(hi,hist.length);e.preventDefault();}};
['bash ~/headunit/scripts/claude-code.sh','ls','cd ~/headunit','cat VERSION','df -h /','free -h','uptime','tail -n 30 ~/.config/headunit/logs/backend.log','systemctl status ofono --no-pager','wpctl status','bluetoothctl devices'].forEach(q=>{
  const b=document.createElement('button');b.textContent=q;b.onclick=()=>run(q);document.getElementById('quick').appendChild(b);});
fetch('/tool').then(r=>r.json()).then(d=>d.tools.forEach(([k,l])=>{const b=document.createElement('button');b.textContent=l;
  b.onclick=async()=>{if(['reboot','restart','usb_update','phone_update'].includes(k)&&!confirm(l+'?'))return;b.classList.add('busy');add('▶ '+l,'cmd');
    try{const r=await post('/tool',{tool:k});add(r.error||r.out,r.ok?'':'err');}catch(e){add('The Pi is restarting… reload in a few seconds.','err');}b.classList.remove('busy');};
  document.getElementById('tools').appendChild(b);}));
add('Connected to the Pi. Commands run as you, and sudo works if you ran enable-tools.sh once.');
add('Interactive programs (nano, top) won\u2019t work here; use cat, tail, and one-shot commands.');
</script></body></html>"""


async def term_page(request):
    if not _local(request):
        return web.Response(status=403, text="Open this on the phone as http://localhost:8080/term (it goes through the phone's ADB link).")
    return web.Response(text=TERM_PAGE, content_type="text/html")


async def tool_list(request):
    return web.json_response({"tools": [[k, v[0]] for k, v in TOOLS.items()]})


# --------------------------------------------------------------------------- web
async def ws_handler(request):
    hub = request.app["hub"]
    ws = web.WebSocketResponse(heartbeat=20)
    await ws.prepare(request)
    ws.peer_ip = request.remote
    hub.clients.add(ws)
    await ws.send_str(json.dumps({"type": "state", "state": hub.state}))
    if hub.queue:
        await ws.send_str(json.dumps({"type": "queue", "queue": hub.queue}))
    async for m in ws:
        if m.type != WSMsgType.TEXT:
            continue
        try:
            await handle(hub, json.loads(m.data), ws)
        except UserError as e:
            await ws.send_str(json.dumps({"type": "toast", "text": str(e)}))
        except DbusError as e:
            log.warning("command failed: %s", e)
            await ws.send_str(json.dumps({"type": "toast", "text": "The phone didn't accept that. Check that it's connected."}))
        except Exception:
            log.exception("command failed")
            await ws.send_str(json.dumps({"type": "toast", "text": "Something went wrong. Details are in the backend log."}))
    hub.clients.discard(ws)
    if hub.phone_ws is ws:
        hub.phone_ws = None
    return ws


async def appws_handler(request):
    """The phone stream's video for the page (binary: 1 byte kind + H.264 data)."""
    hub = request.app["hub"]
    ws = web.WebSocketResponse(heartbeat=20, max_msg_size=0)
    await ws.prepare(request)
    await hub.apps.page.join(ws)
    async for _ in ws:
        pass
    hub.apps.page.viewers.discard(ws)
    return ws


async def design_post(request):
    """The Design Studio (phone app or phone browser) sends a design here; it's applied right away."""
    hub = request.app["hub"]
    try:
        d = await request.json()
        name = await hub.design_add(d)
    except UserError as e:
        return web.Response(status=400, text=str(e))
    except Exception:
        log.exception("design upload failed")
        return web.Response(status=400, text="That design file couldn't be read.")
    return web.Response(text=f"“{name}” is on the head unit now.")


async def designs_get(request):
    hub = request.app["hub"]
    did = request.query.get("id")
    if did:
        f = DESIGN_DIR / f"{did}.json"
        if re.fullmatch(r"[a-z0-9-]{1,40}", did) and f.exists():
            return web.FileResponse(f)
        raise web.HTTPNotFound()
    return web.json_response({"designs": hub.state["designs"], "active": (hub.state["design"] or {}).get("id")})


async def design_preview_post(request):
    """The Theme Studio sends the design being edited here (empty body or {} = stop previewing)."""
    hub = request.app["hub"]
    try:
        d = await request.json() if request.can_read_body else None
        hub.design_preview(d if d else None)
    except UserError as e:
        return web.Response(status=400, text=str(e))
    except Exception:
        return web.Response(status=400, text="That design couldn't be read.")
    return web.Response(text="ok")


async def designs_full_get(request):
    """Every design on the head unit with the parts the Theme Studio's gallery needs."""
    hub = request.app["hub"]
    out = []
    for f in sorted(DESIGN_DIR.glob("*.json"), key=lambda f: f.stat().st_mtime, reverse=True):
        try:
            d = json.loads(f.read_text())
        except Exception:
            continue
        out.append(dict(d, id=f.stem, at=int(f.stat().st_mtime)))
    return web.json_response({"designs": out, "active": (hub.state["design"] or {}).get("id"),
                              "settings": hub.settings, "schedule_now": hub.state.get("schedule_now")})


THEME_CMDS = ("settings", "design_use", "design_delete", "design_preview", "splash_play")


async def cmd_post(request):
    """A few screen commands for the Theme Studio, which talks HTTP instead of a websocket."""
    hub = request.app["hub"]
    try:
        msg = await request.json()
        if msg.get("cmd") not in THEME_CMDS:
            return web.Response(status=400, text="Not allowed here.")
        await handle(hub, msg, None)
    except UserError as e:
        return web.Response(status=400, text=str(e))
    except Exception:
        log.exception("theme studio command")
        return web.Response(status=400, text="That didn't work. Details are in the backend log.")
    return web.Response(text="ok")


DESIGN_REQUESTS = CONF_DIR / "design_requests.json"


def read_requests():
    try:
        r = json.loads(DESIGN_REQUESTS.read_text())
        return r if isinstance(r, list) else []
    except Exception:
        return []


async def design_request(request):
    """"Ask Claude" in the Theme Studio: requests wait here until Claude Code makes the design
    (it puts the finished design in web/gallery.json with "request": <id> and marks the request done)."""
    reqs = read_requests()
    if request.method == "POST":
        try:
            b = await request.json()
            text = str(b.get("text") or "").strip()[:600]
        except Exception:
            text = ""
        if not text:
            return web.Response(status=400, text="Say what the design should look like.")
        part = str(b.get("part") or "both")
        reqs.append({"id": f"r{int(time.time())}", "text": text, "part": part if part in ("screen", "knob", "both") else "both",
                     "at": int(time.time()), "status": "waiting"})
        DESIGN_REQUESTS.write_text(json.dumps(reqs[-40:], indent=1))
        log.info("design request: %s", text)
    return web.json_response({"requests": reqs[-40:]})


async def studio_page(request):
    return web.FileResponse(WEB / "studio.html", headers={"Cache-Control": "no-cache"})


async def theme_page(request):
    return web.FileResponse(WEB / "theme" / "index.html", headers={"Cache-Control": "no-cache"})


async def studio_manifest(request):
    """The phone app keeps its own copy of the screen files for offline previews; this lists them so
    it can fetch whatever changed after a head unit update."""
    files = {}
    for f in sorted(WEB.rglob("*")):
        if f.is_file() and f.suffix in (".html", ".js", ".css", ".json", ".svg", ".png", ".woff2", ".ttf"):

            files[str(f.relative_to(WEB))] = hashlib.sha1(f.read_bytes()).hexdigest()
    return web.json_response({"version": read_version(), "files": files})


async def index(request):
    return web.FileResponse(WEB / "index.html", headers={"Cache-Control": "no-cache"})


def main():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    @web.middleware
    async def no_stale_files(request, handler):
        # the screen files change with every update, so the browser must always check for new ones
        resp = await handler(request)
        if request.path.startswith("/static/"):
            resp.headers["Cache-Control"] = "no-cache"
        return resp

    app = web.Application(client_max_size=200 * 1024 * 1024, middlewares=[no_stale_files])
    hub = Hub()
    app["hub"] = hub
    try:
        hub.load_designs()
    except Exception:
        log.exception("couldn't load designs")
    app.router.add_get("/", index)
    app.router.add_get("/ws", ws_handler)
    app.router.add_get("/appws", appws_handler)
    app.router.add_post("/design", design_post)
    app.router.add_get("/designs", designs_get)
    app.router.add_get("/designs/full", designs_full_get)
    app.router.add_post("/design/preview", design_preview_post)
    app.router.add_route("*", "/design/request", design_request)
    app.router.add_get("/theme", theme_page)
    app.router.add_post("/cmd", cmd_post)
    app.router.add_get("/studio", studio_page)
    app.router.add_get("/studio/manifest", studio_manifest)
    app.router.add_static("/static/", WEB)
    app.router.add_get("/update", update_page)
    app.router.add_get("/term/token", term_token_get)
    app.router.add_post("/term", term_post)
    app.router.add_get("/term", term_page)
    app.router.add_post("/tool", tool_post)
    app.router.add_get("/tool", tool_list)
    app.router.add_post("/update", update_post)

    async def on_start(_app):
        write_splash(hub)
        hub.start()

    async def on_stop(_app):
        await hub.apps.close()

    app.on_startup.append(on_start)
    app.on_cleanup.append(on_stop)
    web.run_app(app, host="0.0.0.0", port=PORT, print=None)


if __name__ == "__main__":
    main()
