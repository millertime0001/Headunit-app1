// Design Studio: edit every part of the head unit's look with a live preview, keep a library of
// designs, import/export them as files, and send one to the car. Runs in the Head Unit Link app
// (window.HUApp bridge) or in any browser that can reach the head unit (localhost:8080/studio).
const $ = (q, el = document) => el.querySelector(q);
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const APP = window.HUApp || null;
const frame = $('#frame');
let H = null;          // lists read from the preview page: themes, styles, effects, layouts …
let lib = [], cur = 0, tab = 'designs', screen = 'home', ready = false;

const FONTS = [['', 'Style default'], ['system-ui, sans-serif', 'System'], ['"DejaVu Sans", sans-serif', 'DejaVu Sans'],
  ['"DejaVu Sans Condensed", sans-serif', 'Condensed'], ['"DejaVu Serif", serif', 'Serif'], ['"DejaVu Sans Mono", monospace', 'Monospace'],
  ['StudioFont', 'My uploaded font']];
const SCREENS = [['home', 'Home'], ['music', 'Music'], ['phone', 'Phone'], ['audio', 'Sound'], ['look', 'Look'], ['settings', 'Settings']];
const TABS = [['designs', 'Designs'], ['colors', 'Colors'], ['style', 'Style'], ['panels', 'Panels'], ['text', 'Text'],
  ['motion', 'Motion'], ['layout', 'Layout'], ['knob', 'Knob'], ['wallpaper', 'Wallpaper'], ['css', 'CSS']];

function blank(name) {
  return { format: 'headunit-design', version: 1, name: name || 'My design',
    settings: { style: 'glass', theme: 'aurora', effect: 'blobs', button_fx: 'glass', ripple_style: 'waves', clock_style: 'thin' },
    colors: null, studio: {}, customCss: '' };
}
const D = () => lib[cur];

// ---------------------------------------------------------------- storage
function loadLib() {
  try { lib = JSON.parse((APP ? APP.loadLib() : localStorage.getItem('hu-designs')) || '[]'); } catch (e) { lib = []; }
  if (!Array.isArray(lib) || !lib.length) lib = [blank('My first design')];
  cur = Math.min(+(localStorage.getItem('hu-cur') || 0), lib.length - 1);
}
let saveT;
function saveLib() {
  clearTimeout(saveT);
  saveT = setTimeout(() => {
    const t = JSON.stringify(lib);
    try { if (APP) APP.saveLib(t); else localStorage.setItem('hu-designs', t); localStorage.setItem('hu-cur', cur); }
    catch (e) { toast('Couldn\u2019t save. A wallpaper or font may be too big.'); }
  }, 300);
}

// ---------------------------------------------------------------- the file that goes to the car
function compile(d) {
  const st = d.studio || {}, css = [], vars = Object.assign({}, d.vars || {});
  if (st.radius != null) { vars['--r-xl'] = `${st.radius}rem`; vars['--r-lg'] = `${(st.radius * 0.8).toFixed(2)}rem`; vars['--r-md'] = `${(st.radius * 0.55).toFixed(2)}rem`; }
  if (st.fontData) css.push(`@font-face{font-family:StudioFont;src:url(${st.fontData})}`);
  if (st.font) css.push(`body,button,input{font-family:${st.font} !important}`);
  if (st.weight) css.push(`:is(h1,h2,.clock,.big-num,.nav-speed b,.label){font-weight:${st.weight} !important}`);
  if (st.border) css.push(`.glass{outline:${st.border}px solid ${st.borderColor || '#ffffff'};outline-offset:-${st.border}px}`);
  if (st.glow) css.push(`.glass{box-shadow:0 0 ${st.glow}px -${Math.round(st.glow / 3)}px var(--accent),0 1rem 2rem -1rem rgb(0 0 0/.6) !important}`);
  if (st.wall) {
    const dim = (st.wallDim ?? 35) / 100;
    css.push(`.bg{background:linear-gradient(rgb(0 0 0/${dim}),rgb(0 0 0/${dim})),url(${st.wall}) center/cover no-repeat !important}`,
      '.bg .blob,.bg #fx{display:none !important}');
  }
  if (st.textColor) css.push(`:root{--text:${st.textColor} !important}`);
  return { format: 'headunit-design', version: 1, name: d.name, settings: d.settings, colors: d.colors,
    vars, css: css.join('\n') + (d.customCss ? `\n/* custom */\n${d.customCss}` : ''), studio: d.studio, customCss: d.customCss };
}

// ---------------------------------------------------------------- preview
function fit() {
  const w = $('#pv').clientWidth;
  frame.style.transform = `scale(${w / 1024})`;
}
addEventListener('resize', fit);
let pT;
function preview() {
  clearTimeout(pT);
  pT = setTimeout(() => { if (ready) frame.contentWindow.postMessage({ type: 'design', design: compile(D()) }, '*'); }, 90);
}
addEventListener('message', (e) => {
  if (e.data && e.data.type === 'preview-ready') {
    ready = true;
    const w = frame.contentWindow;
    const get = (n) => { try { return w.eval(n); } catch (er) { return null; } };
    H = { themes: get('THEMES') || [], styles: get('STYLES') || [], effects: get('EFFECTS') || [], layouts: get('LAYOUTS') || {},
      buttons: get('BUTTONS') || [], clocks: get('CLOCKS') || [], ripples: get('RIPPLES') || [], speedos: get('SPEEDOS') || [] };
    if (!H.themes.length) setTimeout(() => { H.themes = get('THEMES') || []; render(); }, 800);
    preview(); render();
    setTimeout(() => goScreen(screen), 200);
  }
});
function goScreen(s) {
  screen = s;
  if (ready) frame.contentWindow.postMessage({ type: 'go', screen: s }, '*');
  $('#screens').innerHTML = SCREENS.map(([k, l]) => `<button class="${k === screen ? 'on' : ''}" data-screen="${k}">${l}</button>`).join('');
}

// ---------------------------------------------------------------- controls
const set = (k) => D().settings[k];
const theme = () => (H && H.themes.find((t) => t.id === set('theme'))) || { base: '#07080d', b1: '#5eead4', b2: '#7c3aed', b3: '#22d3ee', accent: '#5eead4' };
function sel(key, list, label, hint) {
  return `<div class="row"><label>${label}${hint ? `<small>${hint}</small>` : ''}</label><select data-set="${key}">${
    list.map(([v, n]) => `<option value="${esc(v)}" ${String(set(key) ?? '') === String(v) ? 'selected' : ''}>${esc(n)}</option>`).join('')}</select></div>`;
}
function sw(key, label, def = true, hint) {
  const on = set(key) ?? def;
  return `<div class="row"><label>${label}${hint ? `<small>${hint}</small>` : ''}</label><span class="sw"><input type="checkbox" data-set="${key}" ${on ? 'checked' : ''}><i></i></span></div>`;
}
function rng(path, label, min, max, step, val, unit = '') {
  return `<div class="row"><label>${label}</label><input type="range" min="${min}" max="${max}" step="${step}" value="${val}" data-rng="${path}"><span class="val">${val}${unit}</span></div>`;
}
const glass = () => Object.assign({ opacity: 55, blur: 18, depth: 60, shine: 60, tint: 'theme', edge: true }, set('glass') || {});
const stu = () => (D().studio = D().studio || {});

const PANES = {
  designs() {
    return `<div class="grp"><h3>Your designs</h3><div class="lib">${lib.map((d, i) => {
      const c = d.colors || (H && H.themes.find((t) => t.id === d.settings.theme)) || {};
      return `<button class="${i === cur ? 'on' : ''}" data-pick="${i}"><span class="dots">${['base', 'b1', 'b2', 'accent'].map((k) => `<i style="background:${c[k] || '#333'}"></i>`).join('')}</span><span>${esc(d.name)}</span></button>`;
    }).join('')}</div>
    <div class="btns"><button class="btn" data-do="new">New</button><button class="btn" data-do="dup">Duplicate</button>
    <button class="btn" data-do="import">Import file</button><button class="btn" data-do="export">Export file</button><button class="btn warn" data-do="del">Delete</button></div>
    <p class="hint">When we design something together, I give you a design file. Use Import file to add it here, adjust anything you like, then tap Send to car.</p></div>`;
  },
  colors() {
    const t = theme(), c = D().colors;
    const groups = {};
    (H ? H.themes : []).forEach((x) => (groups[x.group || 'Other'] = groups[x.group || 'Other'] || []).push(x));
    return `<div class="grp"><h3>Base theme</h3><div class="row"><label>Theme<small>${H ? H.themes.length : ''} built-in color sets</small></label><select data-set="theme">${
      Object.entries(groups).map(([gname, ts]) => `<optgroup label="${esc(gname)}">${ts.map((x) => `<option value="${x.id}" ${x.id === set('theme') ? 'selected' : ''}>${esc(x.name)}</option>`).join('')}</optgroup>`).join('')}</select></div></div>
    <div class="grp"><h3>Your own colors</h3>
      ${[['base', 'Background'], ['b1', 'Color 1'], ['b2', 'Color 2'], ['b3', 'Color 3'], ['accent', 'Accent (buttons, highlights)']].map(([k, n]) =>
        `<div class="row"><label>${n}</label><input type="color" data-col="${k}" value="${(c && c[k]) || t[k]}"></div>`).join('')}
      <div class="row"><label>Light mode<small>Dark text on light panels</small></label><span class="sw"><input type="checkbox" data-col="light" ${(c ? c.light : t.light) ? 'checked' : ''}><i></i></span></div>
      <div class="row"><label>Text color</label><input type="color" data-stu="textColor" value="${stu().textColor || '#f5f7fa'}"></div>
      <div class="btns"><button class="btn" data-do="resetcolors">Use the theme\u2019s colors</button></div></div>`;
  },
  style() {
    return `<div class="grp"><h3>Starting style</h3><p class="hint">A style sets panel shapes, buttons and effects at once. Everything else you change sits on top of it.</p>
      <div class="picks">${(H ? H.styles : []).map(([id, name, desc]) => `<button class="${set('style') === id ? 'on' : ''}" data-style="${id}">${esc(name)}<small>${esc(desc)}</small></button>`).join('')}</div></div>`;
  },
  panels() {
    const g = glass(), s = stu();
    return `<div class="grp"><h3>Glass</h3>
      ${rng('glass.opacity', 'Opacity', 0, 100, 1, g.opacity)}${rng('glass.blur', 'Blur', 0, 60, 1, g.blur, 'px')}
      ${rng('glass.depth', 'Depth / shadow', 0, 100, 1, g.depth)}${rng('glass.shine', 'Shine', 0, 100, 1, g.shine)}
      <div class="row"><label>Tint</label><select data-glass="tint">${[['theme', 'Theme color'], ['smoke', 'Smoke'], ['clear', 'Clear']].map(([v, n]) => `<option value="${v}" ${g.tint === v ? 'selected' : ''}>${n}</option>`).join('')}</select></div>
      <div class="row"><label>Edge highlight</label><span class="sw"><input type="checkbox" data-glass="edge" ${g.edge !== false ? 'checked' : ''}><i></i></span></div></div>
    <div class="grp"><h3>Shape</h3>
      <div class="row"><label>Custom corners<small>Off = the style\u2019s own corners</small></label><span class="sw"><input type="checkbox" data-do="radiusOn" ${s.radius != null ? 'checked' : ''}><i></i></span></div>
      ${s.radius != null ? rng('studio.radius', 'Corner radius', 0, 3, 0.05, s.radius, 'rem') : ''}
      ${rng('studio.border', 'Border', 0, 4, 0.5, s.border || 0, 'px')}
      ${s.border ? `<div class="row"><label>Border color</label><input type="color" data-stu="borderColor" value="${s.borderColor || '#ffffff'}"></div>` : ''}
      ${rng('studio.glow', 'Accent glow', 0, 60, 2, s.glow || 0, 'px')}</div>`;
  },
  text() {
    const s = stu();
    return `<div class="grp"><h3>Text</h3>
      <div class="row"><label>Font</label><select data-stu="font">${FONTS.map(([v, n]) => `<option value="${esc(v)}" ${(s.font || '') === v ? 'selected' : ''}>${n}</option>`).join('')}</select></div>
      <div class="btns"><button class="btn" data-do="font">${s.fontData ? 'Replace my font' : 'Upload a font file'}</button>${s.fontData ? '<button class="btn warn" data-do="nofont">Remove font</button>' : ''}</div>
      ${rng('studio.weight', 'Heading weight', 100, 900, 100, s.weight || 600)}
      ${rng('set.ui_scale', 'Size of everything', 70, 140, 5, set('ui_scale') || 100, '%')}
      ${sel('clock_style', H ? H.clocks : [], 'Clock')}</div>`;
  },
  motion() {
    return `<div class="grp"><h3>Background animation</h3>${sel('effect', H ? H.effects.map(([v, n]) => [v, n]) : [], 'Animation')}
      ${sel('motion', [['calm', 'Calm'], ['lively', 'Lively'], ['wild', 'Wild']], 'Speed')}
      ${sw('animate', 'Animations on')}${sw('glow', 'Glow')}</div>
    <div class="grp"><h3>Buttons and screens</h3>${sel('button_fx', H ? H.buttons : [], 'Button style')}
      ${sel('transition', [['depth', 'Depth'], ['slide', 'Slide'], ['flip', 'Flip'], ['fade', 'Fade'], ['none', 'None']], 'Screen change')}
      ${sel('speedo', H ? H.speedos : [], 'Speedometer')}</div>`;
  },
  layout() {
    const L = H ? Object.entries(H.layouts) : [];
    return `<div class="grp"><h3>Home screen</h3><div class="picks">${L.map(([id, l]) => `<button class="${(set('home_layout') || 'dashboard') === id ? 'on' : ''}" data-layout="${id}">${esc(l.name)}${l.fancy ? `<small>${esc(l.fancy)}</small>` : ''}</button>`).join('')}</div></div>
      <div class="grp">${sel('nav', [['left', 'Left'], ['right', 'Right'], ['dock', 'Bottom']], 'Button bar')}${sw('header', 'Clock header on Home')}${sw('quick', 'Favorites row on Home')}</div>`;
  },
  knob() {
    return `<div class="grp"><h3>Knob animation</h3>${sel('ripple_style', H ? H.ripples.map(([v, n]) => [v, n]) : [], 'Effect')}
      ${rng('set.ripple_power', 'Strength', 20, 100, 5, set('ripple_power') ?? 60)}
      ${sw('ripple_edge', 'Trace volume around the edge')}${sw('ripple_hud', 'Volume pop-up')}
      <div class="btns"><button class="btn" data-do="knobtest">Test turn</button><button class="btn" data-do="knobpress">Test press</button></div></div>`;
  },
  wallpaper() {
    const s = stu();
    return `<div class="grp"><h3>Wallpaper</h3><div class="wall" style="${s.wall ? `background-image:url(${s.wall})` : ''}">${s.wall ? '' : 'No wallpaper'}</div>
      <div class="btns"><button class="btn" data-do="wall">${s.wall ? 'Change picture' : 'Pick a picture'}</button>${s.wall ? '<button class="btn warn" data-do="nowall">Remove</button>' : ''}</div>
      ${s.wall ? rng('studio.wallDim', 'Darken', 0, 90, 5, s.wallDim ?? 35, '%') : ''}
      <p class="hint">A wallpaper replaces the animated background. The picture is shrunk to the screen size so the design stays small.</p></div>`;
  },
  css() {
    return `<div class="grp"><h3>Custom CSS</h3><p class="hint">Restyle any part. Useful targets: <b>.glass</b> every panel, <b>.card</b> Home cards, <b>.nav</b> the button bar, <b>.clock</b>, <b>.btn</b>, <b>.round</b> round buttons, <b>.bg</b> background. Variables: --accent, --b1, --b2, --b3, --base, --text, --r-xl. Designs I make for you may already have CSS here.</p>
      <textarea id="cssBox" spellcheck="false" placeholder=".card { border-radius: 0; }">${esc(D().customCss || '')}</textarea></div>`;
  },
};

function render() {
  $('#dname').value = D().name;
  $('#tabs').innerHTML = TABS.map(([k, l]) => `<button class="${k === tab ? 'on' : ''}" data-tab="${k}">${l}</button>`).join('');
  $('#panel').innerHTML = (PANES[tab] || PANES.designs)();
  $('.tabs').style.top = innerWidth < 760 ? `${$('.top').offsetHeight + $('.stage').offsetHeight}px` : '';
}
function changed(rerender) { saveLib(); preview(); if (rerender) render(); }

// ---------------------------------------------------------------- events
document.addEventListener('click', (e) => {
  const b = e.target.closest('button, [data-screen]');
  if (!b) return;
  if (b.dataset.screen) return goScreen(b.dataset.screen);
  if (b.dataset.tab) { tab = b.dataset.tab; return render(); }
  if (b.dataset.pick) { cur = +b.dataset.pick; changed(true); return; }
  if (b.dataset.style) {
    const st = H.styles.find((x) => x[0] === b.dataset.style);
    Object.assign(D().settings, st ? st[3] : {}, { style: b.dataset.style });
    return changed(true);
  }
  if (b.dataset.layout) { D().settings.home_layout = b.dataset.layout; return changed(true); }
  const act = b.dataset.do;
  if (!act) return;
  if (act === 'new') { lib.push(blank(`Design ${lib.length + 1}`)); cur = lib.length - 1; changed(true); }
  else if (act === 'dup') { const c = JSON.parse(JSON.stringify(D())); c.name += ' copy'; lib.push(c); cur = lib.length - 1; changed(true); }
  else if (act === 'del') { if (lib.length > 1 && confirm(`Delete \u201c${D().name}\u201d?`)) { lib.splice(cur, 1); cur = 0; changed(true); } }
  else if (act === 'import') $('#fileIn').click();
  else if (act === 'export') exportDesign();
  else if (act === 'resetcolors') { D().colors = null; delete stu().textColor; changed(true); }
  else if (act === 'font') $('#fontIn').click();
  else if (act === 'nofont') { delete stu().fontData; if (stu().font === 'StudioFont') delete stu().font; changed(true); }
  else if (act === 'wall') $('#imgIn').click();
  else if (act === 'nowall') { delete stu().wall; changed(true); }
  else if (act === 'knobtest' || act === 'knobpress') { goScreen('home'); setTimeout(() => frame.contentWindow.postMessage({ type: 'knob', act: act === 'knobpress' ? 'press' : 'turn', vol: 30 + Math.round(Math.random() * 50) }, '*'), 250); }
});
document.addEventListener('input', (e) => {
  const el = e.target;
  if (el.id === 'dname') { D().name = el.value; return changed(); }
  if (el.id === 'cssBox') { D().customCss = el.value; return changed(); }
  if (el.dataset.do === 'radiusOn') { if (el.checked) stu().radius = 1.4; else delete stu().radius; return changed(true); }
  if (el.dataset.rng) {
    const [where, key] = el.dataset.rng.split('.'), v = +el.value;
    if (where === 'glass') D().settings.glass = Object.assign(glass(), { [key]: v });
    else if (where === 'studio') stu()[key] = v;
    else D().settings[key] = v;
    el.nextElementSibling.textContent = `${v}${el.nextElementSibling.textContent.replace(/^[\d.]+/, '')}`;
    return changed();
  }
  if (el.dataset.col) {
    const t = theme();
    D().colors = D().colors || { base: t.base, b1: t.b1, b2: t.b2, b3: t.b3, accent: t.accent, light: !!t.light };
    D().colors[el.dataset.col] = el.type === 'checkbox' ? el.checked : el.value;
    return changed();
  }
  if (el.dataset.stu) { stu()[el.dataset.stu] = el.value || undefined; return changed(); }
  if (el.dataset.glass) { D().settings.glass = Object.assign(glass(), { [el.dataset.glass]: el.type === 'checkbox' ? el.checked : el.value }); return changed(); }
  if (el.dataset.set) {
    D().settings[el.dataset.set] = el.type === 'checkbox' ? el.checked : el.value;
    return changed(el.dataset.set === 'theme');
  }
});

// files: import a design, pick a wallpaper or a font
$('#fileIn').onchange = async (e) => {
  const f = e.target.files[0]; e.target.value = '';
  if (f) importText(await f.text());
};
function importText(text) {
  try {
    const d = JSON.parse(text);
    if (d.format !== 'headunit-design') throw new Error('format');
    const c = Object.assign(blank(d.name), d);
    if (!d.studio && d.css && !d.customCss) c.customCss = d.css; // a hand-written design: keep its CSS editable
    c.settings = d.settings || {};
    lib.push(c); cur = lib.length - 1; tab = 'designs';
    changed(true); toast(`Added \u201c${c.name}\u201d`);
  } catch (er) { toast('That isn\u2019t a design file.'); }
}
window.studioImport = importText; // the app calls this when a design file is opened with it
$('#imgIn').onchange = (e) => {
  const f = e.target.files[0]; e.target.value = '';
  if (!f) return;
  const img = new Image();
  img.onload = () => {
    const c = document.createElement('canvas'); c.width = 1280; c.height = 750;
    const k = Math.max(1280 / img.width, 750 / img.height), w = img.width * k, h = img.height * k;
    c.getContext('2d').drawImage(img, (1280 - w) / 2, (750 - h) / 2, w, h);
    stu().wall = c.toDataURL('image/jpeg', 0.82); URL.revokeObjectURL(img.src);
    changed(true);
  };
  img.src = URL.createObjectURL(f);
};
$('#fontIn').onchange = (e) => {
  const f = e.target.files[0]; e.target.value = '';
  if (!f) return;
  if (f.size > 1.5e6) return toast('That font is too big (keep it under 1.5 MB).');
  const r = new FileReader();
  r.onload = () => { stu().fontData = r.result; stu().font = 'StudioFont'; changed(true); };
  r.readAsDataURL(f);
};

function exportDesign() {
  const text = JSON.stringify(compile(D()), null, 1), name = `${D().name.replace(/[^\w -]+/g, '').trim() || 'design'}.json`;
  if (APP) return APP.share(name, text);
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([text], { type: 'application/json' })); a.download = name; a.click();
}

// ---------------------------------------------------------------- send to the car
window.studioSent = (msg) => { toast(msg); $('#sendBtn').disabled = false; };
$('#sendBtn').onclick = async () => {
  const body = JSON.stringify(compile(D()));
  $('#sendBtn').disabled = true;
  if (APP) return APP.send(body); // answers through studioSent()
  try {
    const r = await fetch('/design', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body });
    studioSent(await r.text());
  } catch (er) { studioSent('Couldn\u2019t reach the head unit. Join the \u201cPi Head Unit\u201d Wi-Fi.'); }
};

let toastT;
function toast(t) { const el = $('#toast'); el.textContent = t; el.classList.add('show'); clearTimeout(toastT); toastT = setTimeout(() => el.classList.remove('show'), 2600); }

loadLib(); goScreen('home'); render(); fit();
frame.addEventListener('load', fit);
