# Pi Head Unit

Your own car stereo for the Raspberry Pi 5: glass touch UI with 12 themes, Bluetooth music,
hands-free calls, voice assistant, Google Maps and YouTube Music from your phone,
and a 5-channel audio processor on the HiFiBerry DAC8x.

## What you need

- Raspberry Pi 5 + HiFiBerry DAC8x + 10.1" HDMI touchscreen (1280×800)
- **A USB microphone** for calls and voice commands (the DAC8x is output-only)
- An Android phone and a USB cable to the Pi (for Maps and YouTube Music)
- No phone hotspot: the Pi makes its own Wi-Fi network ("Pi Head Unit") that your phone joins,
  while the phone keeps using mobile data for Maps and YouTube Music

**Start with `WEEKEND_SETUP.md`** — it's the step-by-step checklist for everything below.

## What's in this folder

- `install.sh` — sets up the Pi
- `phone-app/` — the Android companion app (weather, next turn, album art, starred contacts)
- `phone/` — put the built `HeadUnitLink.apk` here; the Pi installs it on your phone over USB
- `knob/` — firmware for the Elecrow 1.28" rotary knob

## Install (about 15 minutes, mostly waiting)

1. Flash **Raspberry Pi OS (64-bit) with desktop** using Raspberry Pi Imager.
   In the Imager settings, set your username/password and your home Wi-Fi (only used during install).
2. Boot the Pi, copy this `headunit` folder to your home folder (USB stick works), then open a terminal:
   ```
   cd ~/headunit
   ./install.sh
   ```
3. Say yes to reboot. The Pi now boots straight into the head unit.

## First-time phone setup

**Bluetooth (music, calls, voice):** On the Pi screen go to Settings → *Pair a phone*.
On your phone, pair with **Pi Head Unit** and allow contacts and call access.

**Maps and YouTube Music:** On the phone, turn on Developer options (tap *Build number* 7 times),
then turn on *USB debugging* and *Disable adb authorization timeout*. Plug the phone into the Pi
and tap **Allow** (check *Always allow*). Tap Maps on the Pi.

**Pi Wi-Fi:** join "Pi Head Unit" on the phone (password is in Settings on the Pi screen).
When Android warns the network has no internet, choose to stay connected, and turn off
"switch to mobile data" for it. Your phone stays on mobile data for everything else.

**Wireless Maps and YouTube Music:** plug the phone in by USB once — the Pi switches it to
wireless mode automatically. From then on it connects over the Pi's Wi-Fi with no cable.
After the phone restarts, plug it in once more to re-arm wireless. Streaming wirelessly
uses battery, so a wireless charging mount is a good pairing. Phones that use Android's
"Wireless debugging" and were paired with the Pi also reconnect on their own.

## Wiring

| DAC8x channel | Goes to |
|---|---|
| 1 | 4-ch amp: front left |
| 2 | 4-ch amp: front right |
| 3 | 4-ch amp: rear left |
| 4 | 4-ch amp: rear right |
| 5 | Mono sub amp |

Run **Sound → Test speakers** after wiring. It plays a tone on each speaker in order;
if the wrong one plays, swap those RCA cables. Start with amp gains low.

## Using it

- **Moon button:** tap to step brightness down (100 → 60 → 30 → 10%). Hold it to turn the screen off;
  tap anywhere to wake. Incoming calls wake it automatically.
- **Mic button:** starts your phone's assistant. Try "Navigate to…", "Play … on YouTube Music", "Call …".
- **Themes:** 12 themes, moving background, glowing buttons, and glass blur strength.
- **Sound:** drag the dot for fader/balance; sub level, crossover, bass, mid, treble.

## Look and layout

Palette button → **Look and layout**:
- **Colors:** 12 themes, moving background, glowing buttons, glass blur
- **Layout:** button bar on the left or right, pick the two Home cards (Music, Navigation,
  Speed, Weather), show/hide the clock and favorites bar, Maps as a full map or map + speed panel,
  speed units
- **Knob:** Aurora, Gauge, Neon or Minimal

Speed comes from the phone app's GPS (only while connected to the car) and shows in the top of
the button bar on every screen, including over Maps.

## Knob controls

Turn: volume · Press: play/pause (answers an incoming call) · Double-press: next track ·
Hold: voice assistant (hangs up during a call) · Swipe left/right: previous/next ·
Swipe up/down: next knob style · Tap: play/pause.
If one click changes the volume by two steps (or you need two clicks per step), change
`TRANSITIONS_PER_CLICK` at the top of the firmware.

## Favorites

Starred contacts on your phone sync automatically once the phone app is running. You can also

edit `~/.config/headunit/favorites.json` by hand (it reloads within 5 seconds):
```json
[
  {"name": "Mom", "number": "5551234567"},
  {"name": "Work", "number": "5559876543"}
]
```

## Weather location

Found automatically from the internet connection. To set it, edit `~/.config/headunit/settings.json`
while the head unit isn't running, under `"location"`: `{"lat": 40.7, "lon": -74.0, "units": "fahrenheit"}`.

## Troubleshooting

Logs: `~/.config/headunit/logs/backend.log` and `ui.log`. Send me the last 50 lines of
`backend.log` if something doesn't work: `tail -50 ~/.config/headunit/logs/backend.log`

- **No sound:** Sound screen shows what's wrong at the bottom. Check `aplay -l` lists the DAC8x.
- **Maps opens in the wrong spot or as a separate window:** the window rules live in
  `~/.config/labwc/rc.xml` — tell me what you see.
- **Maps shows black:** unlock the phone once; some phones block apps on extra displays while locked.
- **Calls say "not ready":** re-pair the phone and make sure call access is allowed.
- **Exit to the desktop:** connect a keyboard, press Ctrl+Alt+T for a terminal, or SSH in.

## Undo

Backups were saved next to each changed file with `.before-headunit` on the end
(config.txt, labwc autostart, rc.xml).

## What's new in this version

- **Glass UI:** see-through 3D glass panels. Look > Glass has Opacity, Frost, Depth and Shine sliders, a tint choice and presets.
- **Layouts:** six Home layouts, nine card types, and the button bar on the left, right or bottom. Hold any Home card to swap it.
- **Looks:** 60 themes, 16 animated backgrounds, page transitions, 4 clock styles and 4 speedometers.
- **Display:** Settings > Display has a 1–100% brightness slider and a 10-step moon button, plus night dimming, resolution switching (keep within 15 seconds or it switches back) and text size.
- **Maps and YouTube Music:** the stream now sits exactly in its area. If apps look too big or small, change Settings > Display > App size.
- **Knob:** 34 faces (new: Rainy glass, Tachometer, Liquid, Orbit); flash `knob/HeadUnitKnob` again to get them.
- **Long press:** no longer opens a copy/paste menu anywhere.

If a resolution ever leaves the screen black after a restart, SSH in and run:
`sed -i 's/"display_mode": ".*"/"display_mode": ""/' ~/.config/headunit/settings.json` then reboot.

## Music, calls and the boot splash (this update)

- **Music screen:** four tabs. Up next shows the playing queue (tap a song to jump to it), Library browses your YouTube Music playlists if YouTube Music allows it, Search has an on-screen keyboard, and Pinned holds one-tap favorites.
  Needs the updated phone app: push `phone-app` to GitHub, download the new HeadUnitLink.apk from the Actions build, put it in `phone/`, and plug the phone in once. The Pi installs it.
- **Separate volumes:** music, calls and the voice assistant each have their own volume (Sound screen). The knob changes whichever one is playing.
- **Bass-only sound after calls:** the Pi now checks the sound routing every 10 seconds and right after every call, and puts it back. The Sound screen has a Fix sound button. Anything it fixes is written to `~/.config/headunit/logs/backend.log` ("audio routing check").
- **Boot splash:** now its own theme. To apply it on an existing install: `bash ~/headunit/scripts/set-splash.sh`

## Updating without reinstalling
1. Download the new headunit.zip on your phone.
2. Open Head Unit Link and tap "Send an update to the head unit", then pick the zip
   (or a new HeadUnitLink .apk). The phone must be on the "Pi Head Unit" Wi-Fi or plugged in by USB.
3. The Pi installs it, restarts, and the screen reloads. Settings are kept.
If an update misbehaves: bash ~/headunit/scripts/rollback.sh
Changes to install-lite.sh (new system packages) still need the installer run once.
