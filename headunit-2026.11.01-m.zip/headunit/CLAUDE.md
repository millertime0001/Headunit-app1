# Pi 5 car head unit (Ryan's 2011 Subaru Outback)

Claude Code runs on the Pi itself; Ryan drives it from the Claude app on his Galaxy Z Fold7 (Remote Control).
He hates typing on the car screen: give short, one-per-line commands; do the work yourself where you can.

## System
- Raspberry Pi 5, Pi OS Lite (Trixie). labwc + Chromium kiosk. Python aiohttp backend.
- Code: ~/headunit (this repo). Version in VERSION (bump the letter suffix on every change, e.g. 2026.10.31-t → -u).
- backend/server.py (one file), web/ (app.js, style.css, styles.css, fx.js, ripple.js, editor.js, appview.js,
  preview.js, studio.html/js/css, themes.json, knob_faces.json), scripts/, knob/ (ESP32 firmware), phone-app/ (Android).
- Logs: ~/.config/headunit/logs/backend.log (use `grep -a`, it has binary bytes). Settings: ~/.config/headunit/settings.json.
- Restart the head unit after backend changes: Settings > Tools > Restart, or scripts in scripts/. Screen picks up
  web/ changes on reload; the screen reloads itself when VERSION changes.
- 10.1" 1024x600 HDMI, HiFiBerry DAC8x, USB mic, Elecrow 1.28" rotary knob (ESP32-S3, firmware in knob/).
- Pi runs hotspot "Pi Head Unit" (NetworkManager con HeadUnitHotspot, 10.42.0.1, password in
  ~/.config/headunit/hotspot.json). It hands out NO gateway/DNS (dnsmasq-shared.d/headunit-local-only.conf) so the
  phone keeps mobile data for internet. Samsung "Switch to mobile data" must stay ON.

## Phone link (adb)
- Phone = Galaxy Z Fold7 (Android 17). USB serial RFCY61T5TAA. Wireless adb on port 5555 (adb tcpip); the backend
  re-arms it whenever the phone is plugged in and it's off. Phone's Wi-Fi IP changes (e.g. 10.42.0.164); the backend
  learns it from the phone app's websocket connection (hub.phone_ip), then `ip neigh`, then leases (root-only file).
- Phone app "Head Unit Link" (com.headunit.link, phone-app/), v6.0. Built by GitHub Actions in Ryan's repo
  millertime0001/Headunit-app1 from an uploaded headunit zip (workflow builds the newest *.zip, publishes a Release
  with HeadUnitLink.apk). Signed with phone-app/app/headunit.keystore so updates install over the old one.
  It holds the Pi Wi-Fi with a WifiNetworkSpecifier request (Pi sends ssid/password on phone_hello) and contains the
  Design Studio (WebView of web/ + studio). Bump versionCode in phone-app/app/build.gradle.kts for app changes.

## Maps / YouTube Music streaming
- Default: in-page stream (PageStream in server.py). Runs scrcpy-server 3.1 directly: push jar EVERY time (it deletes
  itself), adb reverse localabstract (phone dials in; forward mode broke restarts), START_APP control message (type 16)
  after codec meta (start_app server option is unknown on this phone). Video relayed over /appws, decoded in Chromium
  with WebCodecs (web/appview.js) onto a canvas: rounded corners, "map only" crop, live map background.
- Wi-Fi: 30 fps / 4 Mbit. USB: 60 fps / 8 Mbit. Falls back to the classic scrcpy window after 3 failed starts.
- Live map background: setting map_bg (+ map_dim, map_glass frost|tint), Home only, #mapBg in .bg layer.

## Look system
- 120 themes (themes.json), 13 Styles (STYLES in app.js + styles.css), 34 background effects (fx.js, FXN map),
  26 Home layouts (LAYOUTS in app.js; gen:true ones built from wireframes), button styles, knob ripple (ripple.js).
- Designs: JSON files {format:"headunit-design", name, settings, colors, vars, css}. POST /design applies one;
  stored in ~/.config/headunit/designs. Studio at /studio (and in the phone app). Samples: "Chrome Night", "Night Pilot".
- Knob turns do NOT flash panels any more (only presses do).
- Rainy Window (v -v): web/rain.js (loaded after fx.js). Adds FXN.window (night city bokeh + beads + running drops
  that refract a flipped "sharp" copy of the scene) and #rainTop, a full-screen canvas (z 24, no pointer events) where
  drops run over the tiles; on when effect=window and setting rain_over (default true), hidden on maps/ytm screens.
  Style 'rainy' (STYLES.push in app.js, styles.css) + theme 'rainy-night'. Backend: EFFECTS/style enum/rain_over.
- Scroll fix (-v): .lgrid2 needs grid-auto-rows:max-content or the Library/Pinned tiles squash instead of scrolling.

## Car data (OBD, -w)
- Obd class in server.py: Bluetooth ELM327 adapters. Classic = RFCOMM socket (channels 1-3), paired via BlueZ with PINs
  1234/0000/6789/1111 (Bluetooth.pins feeds PairingAgent.RequestPinCode). BLE = BlueZ GATT over D-Bus (no bleak):
  picks the notify + write characteristics, prefers services FFF0/FFE0/18F0. Settings key obd {addr,name,kind}.
- Polls rpm+speed every cycle, one slow PID per cycle (only supported ones from 0100/0120/0140), ATRV every 5 s.
  Live values go out as {"type":"obd","data":...} at ~6 Hz; state.speed gets {src:"obd"} and beats the phone's GPS.
- Commands: obd_scan, obd_use, obd_forget, obd_retry, obd_codes {clear}. UI: Settings > Car, Home card "engine".
- Wi-Fi ELM327s aren't supported (wlan0 is the hotspot).
- Speed (-x): ATAT2; trailing "1" response-count on mode 01 requests (probed at connect, self.one); on CAN, rpm+speed
  in one request "010C0D1" (self.combo); slow PIDs every 3rd cycle. Rate shown as state.obd.hz. Screen: obdAnim()
  eases rpm/speed every frame; body.obd-live shortens the speedo CSS transitions.
- Knob ripple styles added (-x): rain, liquid, curtain, bars (neo object in ripple.js). Rainy Window style uses rain.
- Knob faces 30-33 (2026.11.01-a): Rainy glass (BG_RAIN), Tachometer (R_TACH, Face.speed=2 -> rpm), Liquid (BG_LIQUID),
  Orbit (R_ORBIT). Knob line gained field 22 = rpm ("" without OBD); Obd.publish pushes the knob ~12/s when knob_style=tach.
  Syntax-checked against stub headers only, never compiled for real: first real build may need small fixes.
- Look screen (2026.11.01-a): five tabs looks/colors/background/home/knob (old tab ids map over). "Clarity" slider =
  opacity+blur together (clarityGlass/glassClarity). Units, 24h and Maps options moved to Settings > Display.
- Audio guard (2026.11.01-a): runs every 3 s; also unlinks anything feeding the DAC8x directly, and re-pushes if the
  hu_dsp gains read back from pw-dump differ from settings. Auto-fixes toast "Sound path fixed: ..." and the last one
  shows under Sound. User reported twice: music collapsed to a faint, wrong-sounding signal from the subs only.
  Triggers he noticed: once right after changing songs; once while turning the volume when the Pi seemed overloaded
  (animations slow). -b: Audio.watch(why) = immediate check + every 2 s for 30 s after song change/play-pause,
  volume change, call/assistant; otherwise every 8 s. Volume goes through one background wpctl worker that sends only
  the newest value; volume-only changes no longer re-send DSP params; push() sends only params that changed
  (self.pushed cache, cleared on fixes/new dsp id). Rain overlay canvas at 0.7 scale, drops to 15 fps when frames lag.

## Open items
- Wireless link is still slow to connect / sometimes stalls (push timeout → reconnect+retry added in -t).
- More knob animations; knob faces that match the screen's background animation (needs knob firmware build +
  a way to flash it from the Pi over USB).
- Bluetooth: Pi says connected but phone says can't connect; calls "Not ready", "No music player found".
- Planned: splash style picker, theme builder, knob face builder, synced startup across knob/head unit/cluster,
  instrument-cluster display.

## Gauges (2026.11.01-c)
- New nav screen "gauges" (views.gauges): layouts duo/trio/quad/six, 6 slots in settings.gauges {layout, slots};
  "Change gauges" = edit mode (S.gEdit), tap a slot -> openGaugeSheet. Backend validates GAUGE_TYPES/GAUGE_LAYOUTS.
- web/gauges.js draws every canvas[data-gauge] (tach, speed, fuel, coolant, volts, mpg, intake, load, throttle),
  30 fps, only while one is visible. Fuel: sloshing tank (tilts with acceleration), range = fuel% x tank x trip mpg
  (settings.tank in tenths of a gallon, default 185, set in Settings > Car). Coolant zones in F: <160 cold, <225 ok,
  <240 warm, else hot. Home tiles g_tach/g_speed/g_fuel/g_coolant reuse the same canvases.
- OBD vs music (user heard skips): while media is playing, Bluetooth OBD polls about 8 cycles/s (0.12 s gap);
  RFCOMM connect tries other channels only on ECONNREFUSED, 8 s timeout, retry backoff up to 60 s.
  USB ELM327/OBDLink adapters supported (kind "usb", path under /dev/serial/by-id, pyserial, baud autodetect).

## No Bluetooth sound after -a..-c (fixed in -d, cause not yet confirmed)
- Suspect: guard step 2b unlinked anything feeding the DAC directly. If the phone's audio node is an Audio/Source
  (not a Stream) linked straight to the DAC, it was cut off with nothing to replace it: silence, and WirePlumber
  relinking it just got cut again. -d: Audio.reroute() links its ports to hu_dsp first (by audio.channel) and only
  then removes the direct links; if that can't be done it's left alone and logged. Tools > Sound report shows
  pw-link -l and wpctl status. Ask the user for that report if sound is still wrong.
- -e: every gauge type is a Home tile (g_<type>, GAUGE_TILES in app.js); the card picker lists them under "OBD gauges".

## Freeform Home 12 x 8 + rain anywhere (2026.11.01-f)
- editor.js: FREE_COLS 12 x FREE_ROWS 8 (was 6 x 4); backend migrate() doubles old home_tiles once and sets
  home_grid=12; up to 24 panels. Toolbar floats (top, or bottom via the arrow button; S.feLow) and fades while
  dragging (body.fe-dragging), so editing uses the same space as Home. Smaller minimums (FE_MIN), gauges 2x2.
- Rain over any theme: setting rain_glass (bool) + rain_amount light/steady/heavy. Look > Background "Rain on the
  glass" switch drives rain_over when the effect is Rainy window, otherwise rain_glass.
- -g: overlay rain realism: running drops are DOM "lens" elements (#rainLens i) with backdrop-filter, so they blur
  and brighten the real UI under them; canvas keeps beads, fine mist (P.mist) and faint wet tracks (P.wet).
  Lenses switch off automatically when frames lag (top.ema > 45 ms). Freeform tile CSS (.free ...) sizes contents
  by cqh/cqw to fill the glass; gauge tiles draw edge to edge with the label overlaid.

## OBD while driving + weather look (2026.11.01-h)
- User: gauges froze completely once he started driving. Likely a single slow/garbled answer killed the session
  (any cmd timeout raised) and the reconnect backoff then grew. Now: ATAT1 (not ATAT2); safe_ask() swallows up to
  3 timeouts in a row (sends a bare CR to recover); per-PID timeout 0.8 s; if the fast tricks ("1" suffix /
  combined PIDs) return nothing 6 cycles running they're turned off; 25 empty cycles -> soft reset (ATZ + init)
  up to twice before giving up; after losing a working link it retries after 1 s, then 2 s x3, then backs off.
  Obd.event() keeps the last 8 events in state.obd.events, shown in Settings > Car.
- Weather look: settings.weather_look; weather_look(w) maps WMO code/day/temp -> (label, theme, effect, rain, amount);
  apply_weather_look() runs on every weather update and when switched on. Turning it on saves weather_look_prev;
  off restores it; picking a theme/effect/style yourself turns it off. Card at the top of Look > Looks.
- -i: the phone link loop also keeps adb reverse tcp:2222 -> tcp:22, so ConnectBot (ryan@127.0.0.1:2222) always reaches the Pi's SSH.
- -j: Settings > Tools > Start Claude Code (scripts/claude-code.sh): ssh on, adb reverse 2222->22 on every device, tmux session 'claude' running Claude Code in ~/headunit, then sends /remote-control. Also the first quick button in the phone terminal.

## Fast Maps + fast OBD + tile sizing (2026.11.01-k)
- Maps start: scrcpy-server is pushed ONCE per phone link to /data/local/tmp/hu-scrcpy-<ver>.jar (PageStream.stage,
  also pre-staged by link_loop) and copied into place on the phone in the same adb shell that launches it
  (P=com.genymobile.scrcpy; pkill pattern 'Serve[r]' so it can't kill its own shell). Fixed socket name per run
  (apps.scid): adb reverse is just re-pointed, never removed. USB cold open ~0.6 s to first frame.
- Leaving Maps/Music = close_app -> Apps.park(): stream keeps running hidden for 3 min (PARK_SECONDS); open_app with
  the same size/dpi/crop unparks instantly and sends RESET_VIDEO (control msg 17) for a fresh key frame.
- link_loop: one `adb reverse --list` instead of re-adding tunnels every 8 s; setup_companion (dumpsys) every 5 min.
- OBD: 1 s boot delay, ATWS warm start, settings.obd.cache {proto, pids, one, combo} -> ATSPA<proto>, skips PID
  discovery/probes. Car not answering = keeps the Bluetooth link and re-asks 0100 every 3 s (status connecting,
  "Waiting for the ignition"). Retry backoff cap 20 s (60 s while music plays). Boot -> live ~5 s.
- Gauges: tiles with aspect >= 1.8 draw wide() (big number + name + bar); CSS hides the tile label there
  (@container min-aspect-ratio 9/5). Round dials use more of the tile. Gauge tiles can be 2x1.
  Free tiles: bigger clock/weather, short tiles drop extra lines, nav goes side-by-side. Weather label fallback "Weather".
- -l: Wi-Fi prompt every time: the WifiNetworkSpecifier had only the SSID, and Android only remembers "Allow" for exact
  SSID+BSSID. Pi now sends bssid (wlan0 MAC 88:a2:9e:05:bb:16) in the hotspot message; app v6.1 (versionCode 7) uses setBssid.
- -m: phone didn't rejoin the Pi Wi-Fi after a car restart. Android drops an app's WifiNetworkSpecifier request once that
  network is lost and never retries; the app kept heldSsid so it never re-asked. App v6.2 (versionCode 8): new callback per
  request, re-files 3 s after onLost/onUnavailable, and every 60 s while there's no Pi Wi-Fi.
