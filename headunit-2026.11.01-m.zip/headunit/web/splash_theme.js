window.HU_THEME = {"base": "#05070B", "b1": "#14B8A6", "b2": "#7C3AED", "b3": "#0EA5E9", "accent": "#5EEAD4"};
