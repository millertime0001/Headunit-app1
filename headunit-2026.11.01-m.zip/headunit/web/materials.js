// Materials: lifelike surface finishes for panels and buttons (brushed aluminum, carbon fiber, piano black,
// walnut, leather, acrylic, holographic foil, ceramic, neon, chrome). The look lives in materials.css under
// body[data-mat="<id>"]; this file
//   1. paints the small tileable textures once on a <canvas> (brushing, carbon weave, wood, leather grain, noise,
//      foil glitter) and hands them to CSS as blob URLs (--tex-brush, --tex-carbon, --tex-carbon-hi, --tex-wood,
//      --tex-leather, --tex-noise, --tex-glitter),
//   2. moves one virtual light slowly around the screen (4 updates a second, only while a material is on) so every
//      panel catches the same light. It follows the 3D camera (--camx/--camy) when one is running. CSS vars on :root:
//      --lightx, --lighty  light position over the screen, 0..1 (it mostly stays above the panels)
//      --lang              direction toward the light in CSS gradient degrees (unitless: use calc(var(--lang) * 1deg))
//      --sx, --sy          which way shadows fall (-1..1, away from the light)
//      --lh                0..1, how much the light favours the horizontal carbon tows (the twill "flip")
//   3. lights the spot you touch: pointerdown on a panel/button sets --px/--py (in %) and --pa (1 → fades to 0) on it.
// API: MATERIALS = [[id, name, description], ...]; materialApply(id) — 'auto' or '' turns materials off.
// Testing: ?mat=<id> in the URL forces a material (it wins over materialApply's argument).
'use strict';

const MATERIALS = [
  ['brushed', 'Brushed Aluminum', 'Machined metal with fine brushing, a moving sheen and diamond-cut edges'],
  ['carbon', 'Carbon Fiber', '2x2 twill weave under a deep glossy clear coat'],
  ['piano', 'Piano Black', 'Deep black lacquer with a sharp reflection and chrome trim'],
  ['walnut', 'Walnut', 'Open-pore walnut veneer, satin finish, thin metal inlay'],
  ['leather', 'Leather', 'Padded, grained and perforated leather with contrast stitching'],
  ['acrylic', 'Acrylic', 'Thick frosted acrylic slabs with glowing polished edges'],
  ['holo', 'Holographic', 'Iridescent foil that shifts colour as the light moves'],
  ['ceramic', 'Ceramic', 'Matte soft-touch ceramic in soft studio light'],
  ['neon', 'Neon', 'Dark panels outlined by glowing glass neon tubes'],
  ['chrome', 'Chrome', 'Polished mirror chrome reflecting a theme-tinted sky'],
];

const materialApply = (() => {
  const root = document.documentElement;
  const URL_MAT = new URLSearchParams(location.search).get('mat');
  const IDS = new Set(MATERIALS.map((m) => m[0]));
  // textures each material needs (made on first use, then kept)
  const NEEDS = {
    brushed: ['brush'], carbon: ['carbon', 'carbonHi'], piano: ['noise'], walnut: ['wood'], leather: ['leather'],
    acrylic: ['noise'], holo: ['glitter', 'noise'], ceramic: ['noise'], neon: ['noise'], chrome: ['noise'],
  };

  // ------------------------------------------------------------------ procedural textures
  // seeded random so the textures look the same on every start
  let seed = 1234567;
  const rnd = () => ((seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296);
  // periodic value noise: a lattice of px x py cells that wraps, so the texture tiles seamlessly
  function lattice(px, py) {
    const g = new Float32Array(px * py);
    for (let i = 0; i < g.length; i++) g[i] = rnd() * 2 - 1;
    return (x, y) => { // x in 0..px, y in 0..py
      const xi = Math.floor(x), yi = Math.floor(y), fx = x - xi, fy = y - yi;
      const sx = fx * fx * (3 - 2 * fx), sy = fy * fy * (3 - 2 * fy);
      const x0 = ((xi % px) + px) % px, x1 = (x0 + 1) % px, y0 = ((yi % py) + py) % py, y1 = (y0 + 1) % py;
      const a = g[y0 * px + x0], b = g[y0 * px + x1], c = g[y1 * px + x0], d = g[y1 * px + x1];
      return a + (b - a) * sx + (c - a) * sy + (a - b - c + d) * sx * sy;
    };
  }
  // fractal noise over u,v in 0..1 (tiles), base cell counts cx,cy, octaves
  function fbm(cx, cy, oct) {
    const ls = []; for (let o = 0; o < oct; o++) ls.push(lattice(cx << o, cy << o));
    return (u, v) => { let s = 0, a = 0.5, n = 0; for (let o = 0; o < oct; o++) { s += ls[o](u * (cx << o), v * (cy << o)) * a; n += a; a *= 0.5; } return s / n; };
  }
  function canvas(w, h) { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; }
  function paint(w, h, fn) { // fn(x, y) -> [r, g, b, a] (0..255)
    const c = canvas(w, h), x = c.getContext('2d'), im = x.createImageData(w, h), d = im.data;
    for (let y = 0; y < h; y++) for (let xx = 0; xx < w; xx++) {
      const p = fn(xx, y), i = (y * w + xx) * 4;
      d[i] = p[0]; d[i + 1] = p[1]; d[i + 2] = p[2]; d[i + 3] = p[3];
    }
    x.putImageData(im, 0, 0);
    return c;
  }
  const clamp = (v, a = 0, b = 255) => (v < a ? a : v > b ? b : v);
  // a signed value (-1..1) as a see-through overlay: lighter above zero, darker below
  const over = (v, k1, k2) => (v >= 0 ? [255, 255, 255, clamp(v * k1 * 255)] : [0, 0, 0, clamp(-v * k2 * 255)]);

  const MAKE = {
    // fine horizontal brushing: every row its own slowly varying value, a few deeper scratches
    brush() {
      seed = 11;
      const W = 512, H = 256, a = lattice(4, H), b = lattice(16, H), c = lattice(64, H / 2), sc = lattice(2, H);
      const scratch = new Float32Array(H); for (let y = 0; y < H; y++) scratch[y] = rnd() < 0.04 ? (rnd() < 0.5 ? -1 : 1) * (0.5 + rnd() * 0.5) : 0;
      return paint(W, H, (x, y) => {
        const u = x / W;
        let v = a(u * 4, y) * 0.55 + b(u * 16, y) * 0.3 + c(u * 64, y / 2) * 0.15;
        v += scratch[y] * Math.max(0, sc(u * 2, y)) * 1.4;
        return over(v, 0.26, 0.32);
      });
    },
    // 2x2 twill: tows 8 px wide, each float 2 cells long. Base = both tows (opaque), Hi = sheen on the horizontal tows only
    carbon() { return carbonTex(false); },
    carbonHi() { return carbonTex(true); },
    // open-pore walnut: wavy growth rings, streaky heartwood colour, fine fibres and dark pores along the grain
    wood() {
      seed = 77;
      const W = 512, H = 256, warp = fbm(2, 3, 4), fib = lattice(6, H), streak = fbm(2, 8, 3), fine = lattice(32, H / 2);
      const pore = new Float32Array(W * H);
      for (let n = 0; n < 2600; n++) { // short dark dashes along the grain
        const px = Math.floor(rnd() * W), py = Math.floor(rnd() * H), len = 3 + Math.floor(rnd() * 9), k = 0.35 + rnd() * 0.5;
        for (let i = 0; i < len; i++) { const xx = (px + i) % W; pore[py * W + xx] = Math.max(pore[py * W + xx], k * Math.sin(Math.PI * (i + 0.5) / len)); }
      }
      const light = [118, 78, 48], dark = [40, 24, 14], mid = [78, 50, 30];
      return paint(W, H, (x, y) => {
        const u = x / W, v = y / H;
        const g = v * 13 + warp(u, v) * 1.1 + streak(u, v) * 0.35;           // 13 long, gently wavy rings over the tile (tiles)
        const f = g - Math.floor(g);
        const ring = Math.pow(Math.sin(Math.PI * f), 10);                   // thin dark late-wood band
        const tone = 0.5 + streak(u * 1, v * 1) * 0.9 + fib(u * 6, y) * 0.18 + fine(u * 32, y / 2) * 0.08;
        let r = mid[0] + (light[0] - mid[0]) * tone, gg = mid[1] + (light[1] - mid[1]) * tone, b = mid[2] + (light[2] - mid[2]) * tone;
        const dk = Math.min(1, ring * 0.5 + pore[y * W + x] * 0.7);
        r += (dark[0] - r) * dk; gg += (dark[1] - gg) * dk; b += (dark[2] - b) * dk;
        return [clamp(r), clamp(gg), clamp(b), 255];
      });
    },
    // pebbled leather grain: jittered-grid cellular noise turned into bumps and lit from the top-left
    leather() {
      seed = 5;
      const S = 256, C = 32, cell = S / C, pts = new Float32Array(C * C * 2);
      for (let i = 0; i < C * C; i++) { pts[i * 2] = (i % C + 0.15 + rnd() * 0.7) * cell; pts[i * 2 + 1] = (Math.floor(i / C) + 0.15 + rnd() * 0.7) * cell; }
      const hgt = new Float32Array(S * S), fine = lattice(64, 64);
      for (let y = 0; y < S; y++) for (let x = 0; x < S; x++) {
        const cx = Math.floor(x / cell), cy = Math.floor(y / cell); let f1 = 1e9, f2 = 1e9;
        for (let j = -1; j <= 1; j++) for (let i = -1; i <= 1; i++) {
          const gx = (cx + i + C) % C, gy = (cy + j + C) % C, k = (gy * C + gx) * 2;
          let dx = pts[k] - x, dy = pts[k + 1] - y;
          if (dx > S / 2) dx -= S; if (dx < -S / 2) dx += S; if (dy > S / 2) dy -= S; if (dy < -S / 2) dy += S;
          const d = Math.hypot(dx, dy); if (d < f1) { f2 = f1; f1 = d; } else if (d < f2) f2 = d;
        }
        hgt[y * S + x] = Math.min(1, (f2 - f1) / 3.2) + fine(x / 4, y / 4) * 0.12;
      }
      return paint(S, S, (x, y) => {
        const h = (xx, yy) => hgt[((yy + S) % S) * S + ((xx + S) % S)];
        const nx = h(x - 1, y) - h(x + 1, y), ny = h(x, y - 1) - h(x, y + 1);
        const lit = (nx * 0.7 + ny * 0.7) * 1.6 - (1 - h(x, y)) * 0.25;   // crevices a bit darker
        return over(lit, 0.2, 0.3);
      });
    },
    // fine glaze / frost grain
    noise() {
      seed = 3;
      return paint(128, 128, () => over(rnd() * 2 - 1, 0.055, 0.07));
    },
    // holographic glitter: sparse tiny flecks in rainbow colours
    glitter() {
      seed = 9;
      const S = 128, c = canvas(S, S), x = c.getContext('2d');
      for (let i = 0; i < 70; i++) {
        const h = Math.floor(rnd() * 360), px = rnd() * S, py = rnd() * S, r = 0.4 + rnd() * 0.6;
        x.fillStyle = `hsl(${h} 100% ${75 + rnd() * 20}% / ${0.25 + rnd() * 0.5})`;
        x.beginPath(); x.arc(px, py, r, 0, Math.PI * 2); x.fill();
      }
      return c;
    },
  };
  function carbonTex(hiOnly) {
    seed = 21;
    const T = 8, N = 8, S = T * N, fibre = lattice(S / 8, S), vary = new Float32Array(N * N);
    for (let i = 0; i < vary.length; i++) vary[i] = (rnd() - 0.5) * 0.18;
    return paint(S, S, (x, y) => {
      const i = Math.floor(x / T), j = Math.floor(y / T), fx = (x % T + 0.5) / T, fy = (y % T + 0.5) / T;
      const horiz = ((i - j) % 4 + 4) % 4 < 2;                         // which tow is on top in this cell
      // position along the float (2 cells) and across the tow
      const k = ((i - j) % 4 + 4) % 4;
      const along = horiz ? (k + fx) / 2 : (3 - k + fy) / 2;
      const across = horiz ? fy : fx;
      const round = Math.sin(Math.PI * across);                          // the tow is a flattened cylinder
      const dip = Math.pow(Math.sin(Math.PI * Math.min(1, Math.max(0, along))), 0.45); // dives under at the float ends
      const fib = horiz ? fibre(x / 8, y) : fibre(y / 8 + 5, x);  // strands run along the tow
      const gap = Math.min(1, Math.min(across, 1 - across) * 9);         // dark seam between tows
      if (hiOnly) {
        if (!horiz) return [0, 0, 0, 0];
        const s = Math.pow(round, 2.5) * dip * gap * (0.75 + fib * 0.35);
        return [225, 232, 242, clamp(s * 105)];
      }
      const base = (horiz ? 0.2 : 0.34) + vary[j * N + i];
      const l = (base * (0.45 + 0.55 * round) * (0.55 + 0.45 * dip) + fib * 0.04) * gap;
      const v = clamp(10 + l * 105);
      return [v, clamp(v + 2), clamp(v + 6), 255];
    });
  }
  const VAR = { brush: '--tex-brush', carbon: '--tex-carbon', carbonHi: '--tex-carbon-hi', wood: '--tex-wood', leather: '--tex-leather', noise: '--tex-noise', glitter: '--tex-glitter' };
  const made = {};
  function ensure(name) {
    if (made[name]) return;
    made[name] = true;
    try {
      const c = MAKE[name](), opaque = name === 'wood' || name === 'carbon';
      c.toBlob((b) => { if (b) root.style.setProperty(VAR[name], `url(${URL.createObjectURL(b)})`); }, opaque ? 'image/jpeg' : 'image/png', 0.92);
    } catch (e) { made[name] = false; console.warn('material texture', name, e); }
  }

  // ------------------------------------------------------------------ the moving light
  const L = { raf: 0, last: 0, x: 0.38, y: 0.16, on: false, sent: {}, presses: new Set() };
  const camv = (k) => { const v = parseFloat(root.style.getPropertyValue(k)); return Number.isFinite(v) ? v : 0; };
  function set(k, v) { if (L.sent[k] !== v) { L.sent[k] = v; root.style.setProperty(k, v); } }
  function lightTick(now) {
    const t = now / 1000;
    const moving = document.body.classList.contains('anim');
    // a slow wandering light, mostly above the panels; the 3D camera leans it
    let tx = 0.5 + (moving ? 0.3 * Math.sin(t * 0.16) + 0.08 * Math.sin(t * 0.43 + 1.3) : -0.12);
    let ty = 0.16 + (moving ? 0.1 * Math.sin(t * 0.11 + 0.7) + 0.04 * Math.sin(t * 0.37) : 0);
    tx += camv('--camx') * 0.22; ty -= camv('--camy') * 0.1;
    tx = Math.min(1, Math.max(0, tx)); ty = Math.min(0.8, Math.max(-0.1, ty));
    L.x += (tx - L.x) * 0.6; L.y += (ty - L.y) * 0.6;
    const dx = L.x - 0.5, dy = L.y - 0.5;
    const ang = Math.atan2(dx, -dy) * 180 / Math.PI;
    // quantised so the page only restyles when something visibly moved
    set('--lightx', L.x.toFixed(2));
    set('--lighty', L.y.toFixed(2));
    set('--lang', Math.round(ang).toString());
    set('--sx', (Math.round(-dx * 2 * 25) / 25).toFixed(2));
    set('--sy', (Math.round(Math.min(1, Math.max(0.2, -dy * 2)) * 25) / 25).toFixed(2));
    set('--lh', (0.5 + 0.5 * Math.sin((L.x * 1.6 + L.y) * Math.PI)).toFixed(2));
  }
  function frame(now) {
    L.raf = requestAnimationFrame(frame);
    // touch highlights fade out every frame; the light itself 4 times a second
    if (L.presses.size) fadePresses(now);
    if (now - L.last < 250 || document.hidden) return;  // 4 a second: each change repaints every panel
    L.last = now;
    lightTick(now);
  }
  function start() { if (!L.raf) { L.last = 0; L.raf = requestAnimationFrame(frame); } }
  function stop() {
    cancelAnimationFrame(L.raf); L.raf = 0;
    ['--lightx', '--lighty', '--lang', '--sx', '--sy', '--lh'].forEach((k) => root.style.removeProperty(k));
    L.sent = {};
  }

  // ------------------------------------------------------------------ touch highlight
  const PRESSABLE = '.btn, .round, .icon-btn, .key, .kk, .fav, .pitem, .tool-btn, .tab, .mtab, .chips button, .seg button, .glass';
  function fadePresses(now) {
    L.presses.forEach((el) => {
      if (el._matUp == null) return;                          // still held
      const a = Math.max(0, 1 - (now - el._matUp) / 550);
      el.style.setProperty('--pa', a.toFixed(2));
      if (!a) { el.style.removeProperty('--pa'); L.presses.delete(el); }
    });
  }
  document.addEventListener('pointerdown', (e) => {
    if (!L.on) return;
    const el = e.target.closest && e.target.closest(PRESSABLE);
    if (!el) return;
    const r = el.getBoundingClientRect();
    if (!r.width || !r.height) return;
    el.style.setProperty('--px', `${(((e.clientX - r.left) / r.width) * 100).toFixed(1)}%`);
    el.style.setProperty('--py', `${(((e.clientY - r.top) / r.height) * 100).toFixed(1)}%`);
    el.style.setProperty('--pa', '1');
    el._matUp = null;
    L.presses.add(el);
    const up = () => { el._matUp = performance.now(); removeEventListener('pointerup', up); removeEventListener('pointercancel', up); };
    addEventListener('pointerup', up); addEventListener('pointercancel', up);
  }, { passive: true });

  // ------------------------------------------------------------------ public
  function apply(id) {
    if (URL_MAT) id = URL_MAT;                                // ?mat=… wins (testing)
    const b = document.body;
    if (!id || id === 'auto' || !IDS.has(id)) {
      L.on = false;
      if (b.dataset.mat) delete b.dataset.mat;
      stop();
      return;
    }
    (NEEDS[id] || []).forEach(ensure);
    if (b.dataset.mat !== id) b.dataset.mat = id;
    L.on = true;
    lightTick(performance.now());
    start();
  }
  if (URL_MAT) {
    if (document.body) apply(URL_MAT); else addEventListener('DOMContentLoaded', () => apply(URL_MAT));
  }
  return apply;
})();
