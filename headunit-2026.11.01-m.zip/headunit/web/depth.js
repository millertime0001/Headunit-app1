/* Depth: the living camera and the interactive 3D Home layouts (carousel, deck).
   The camera drifts slowly so the Home scene always feels alive, and leans toward your finger when you press.
   It shares its drift with the 3D world (world3d.js) so the cards and the background move together. */
'use strict';

const DEPTH = { raf: 0, t: 0, last: 0, lean: [0, 0], leanT: [0, 0], varsAt: 0, rot: { carousel: 0, deck: 0 }, swipe: null, swallow: 0 };
const CAMERA_AMT = { off: 0, subtle: 1.4, float: 3.2 };

function depthOn() {
  return document.body.classList.contains('anim') && !document.body.classList.contains('flat') && (CAMERA_AMT[g('camera') || 'subtle'] || 0) > 0;
}
function depthHome() { return document.querySelector('#view > .screen.home:last-child'); }

function depthFrame(now) {
  DEPTH.raf = requestAnimationFrame(depthFrame);
  const dt = DEPTH.last ? Math.min(0.1, (now - DEPTH.last) / 1000) : 0.016;
  DEPTH.last = now;
  const home = depthHome();
  if (!home || !depthOn()) { if (home) { const sl = home.querySelector('.slots'); if (sl) sl.style.rotate = ''; } return; }
  DEPTH.t += dt;
  // same drift as the 3D world when one is running, so cards and background move as one
  const cam = (typeof WORLD !== 'undefined' && WORLD.scene && !WORLD.paused) ? WORLD.cam
    : [Math.sin(DEPTH.t * 0.21) * 0.8 + Math.sin(DEPTH.t * 0.07) * 0.4, Math.sin(DEPTH.t * 0.17 + 1) * 0.6];
  DEPTH.lean[0] += (DEPTH.leanT[0] - DEPTH.lean[0]) * Math.min(1, dt * 6);
  DEPTH.lean[1] += (DEPTH.leanT[1] - DEPTH.lean[1]) * Math.min(1, dt * 6);
  const d3 = home.classList.contains('d3');
  const amt = CAMERA_AMT[g('camera') || 'subtle'] * (d3 ? 1.6 : 1);
  const ry = cam[0] * amt + DEPTH.lean[0] * 5, rx = -cam[1] * amt * 0.6 - DEPTH.lean[1] * 4;
  const mag = Math.hypot(rx, ry);
  const sl = home.querySelector('.slots');
  if (sl && !home.classList.contains('editing')) sl.style.rotate = mag < 0.01 ? '' : `${(rx / mag).toFixed(3)} ${(ry / mag).toFixed(3)} 0 ${mag.toFixed(2)}deg`;
  // the light on the materials follows the camera (a few times a second is plenty)
  if (now > DEPTH.varsAt && !(typeof WORLD !== 'undefined' && WORLD.scene && !WORLD.paused)) {
    DEPTH.varsAt = now + 100;
    const r = document.documentElement.style;
    r.setProperty('--camx', cam[0].toFixed(3)); r.setProperty('--camy', cam[1].toFixed(3));
  }
}
function depthStart() { if (!DEPTH.raf) { DEPTH.last = 0; DEPTH.raf = requestAnimationFrame(depthFrame); } }

// ---------------------------------------------------------------- carousel and deck
const depthWrap = (i, n) => ((i % n) + n) % n;
function depthPlace(home) {
  home = home || depthHome();
  if (!home) return;
  const car = home.classList.contains('l-carousel'), deck = home.classList.contains('l-deck');
  if (!car && !deck) return;
  const cards = [...home.querySelectorAll('.slots > .card')], n = cards.length;
  if (!n) return;
  if (car) {
    const rot = DEPTH.rot.carousel, step = 360 / n, R = 30;  // ring radius in rem
    cards.forEach((c, i) => {
      let d = depthWrap(i - rot, n); if (d > n / 2) d -= n;
      const a = d * step * Math.PI / 180;
      c.style.transform = `translateX(${(Math.sin(a) * R * 1.05).toFixed(2)}rem) translateZ(${(Math.cos(a) * R - R).toFixed(2)}rem) rotateY(${(d * step * 0.75).toFixed(1)}deg)`;
      c.style.opacity = d === 0 ? '1' : Math.abs(d) === 1 ? '.9' : '.35';
      c.style.filter = d === 0 ? '' : `brightness(${Math.abs(d) === 1 ? 0.75 : 0.5})`;
      c.style.zIndex = String(10 - Math.abs(d));
      c.classList.toggle('front', d === 0); c.classList.toggle('side', Math.abs(d) === 1); c.classList.toggle('back', Math.abs(d) > 1);
      c.dataset.d = d;
    });
    let dots = home.querySelector('.carousel-dots');
    if (!dots) { dots = document.createElement('div'); dots.className = 'carousel-dots'; home.querySelector('.slots').after(dots); }
    dots.innerHTML = cards.map((_, i) => `<i class="${depthWrap(rot, n) === i ? 'on' : ''}"></i>`).join('');
  } else {
    const rot = DEPTH.rot.deck;
    cards.forEach((c, i) => {
      const d = depthWrap(i - rot, n);
      c.style.transform = `translateY(${(-d * 3.2).toFixed(1)}rem) translateZ(${(-d * 5).toFixed(1)}rem) rotateX(${(d * 3).toFixed(1)}deg)`;
      c.style.opacity = d > 2 ? '0' : String(1 - d * 0.18);
      c.style.filter = d ? `brightness(${1 - d * 0.22})` : '';
      c.style.zIndex = String(10 - d);
      c.classList.toggle('behind', d > 0);
      c.dataset.d = d;
    });
  }
}
function depthTurn(kind, by) {
  DEPTH.rot[kind] += by;
  depthPlace();
}

// swipes and taps on the 3D layouts (before the app's own tap handling)
document.addEventListener('pointerdown', (e) => {
  const home = e.target.closest && e.target.closest('.screen.home');
  if (!home) return;
  const r = home.getBoundingClientRect();
  DEPTH.leanT = [(e.clientX - r.left) / r.width - 0.5, (e.clientY - r.top) / r.height - 0.5];
  if (home.classList.contains('l-carousel') || home.classList.contains('l-deck')) DEPTH.swipe = { x: e.clientX, y: e.clientY, at: performance.now() };
}, true);
const depthUp = (e) => {
  DEPTH.leanT = [0, 0];
  const sw = DEPTH.swipe; DEPTH.swipe = null;
  if (!sw || !e) return;
  const home = depthHome();
  if (!home) return;
  const dx = e.clientX - sw.x, dy = e.clientY - sw.y;
  if (home.classList.contains('l-carousel') && Math.abs(dx) > 60 && Math.abs(dx) > Math.abs(dy)) { depthTurn('carousel', dx < 0 ? 1 : -1); DEPTH.swallow = performance.now(); }
  if (home.classList.contains('l-deck') && Math.abs(dy) > 50 && Math.abs(dy) > Math.abs(dx)) { depthTurn('deck', dy < 0 ? 1 : -1); DEPTH.swallow = performance.now(); }
};
document.addEventListener('pointerup', depthUp, true);
document.addEventListener('pointercancel', () => depthUp(null), true);
document.addEventListener('click', (e) => {
  if (performance.now() - DEPTH.swallow < 400) { e.stopPropagation(); e.preventDefault(); return; }  // that was a swipe
  const c = e.target.closest && e.target.closest('.l-carousel .card.side, .l-deck .card.behind');
  if (!c) return;
  e.stopPropagation(); e.preventDefault();
  const kind = c.closest('.l-carousel') ? 'carousel' : 'deck';
  depthTurn(kind, +c.dataset.d);  // bring the tapped card to the front
}, true);

// called after every render (app.js)
function depthApply() {
  const home = depthHome();
  if (home) depthPlace(home);
  depthStart();
}
