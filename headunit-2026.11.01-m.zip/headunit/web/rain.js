/* Rainy Window: looking out a wet car window at night.
   - Background effect "window" (Look > Motion > Background): out-of-focus street lights and passing cars
     outside, beads of water on the glass, and drops that grow, run down and leave a trail. Each running
     drop shows a small, sharp, upside-down view of the lights behind it, the way real water does.
   - #rainTop: the same kind of drops keep running down over the tiles and buttons: with the Rainy window
     background (setting rain_over), or over any theme and background (setting rain_glass). rain_amount = how hard.
     It never takes touches, and it hides on the full Maps / YouTube Music screens so the map stays clear.
   Loaded after fx.js (uses FXN, sprite, hexA). */
'use strict';
(function () {
  const R = (a, b) => a + Math.random() * (b - a);
  const TAU = Math.PI * 2;

  // ---------------------------------------------------------------- drop sprites (drawn once, scaled)
  // A water drop on glass: dark rim (light bends away at the edge), a bright crescent at the bottom
  // (light focused through it), and a small hard highlight near the top.
  const SP = {};
  function dropSprite(kind) {
    if (SP[kind]) return SP[kind];
    const S = 96, c = document.createElement('canvas');
    c.width = c.height = S;
    const x = c.getContext('2d'), r = S / 2;
    x.save(); x.beginPath(); x.arc(r, r, r - 1, 0, TAU); x.clip();
    if (kind === 'top') { // over the UI: a faint body so it reads on any background
      x.fillStyle = 'rgba(200,220,255,0.06)'; x.fillRect(0, 0, S, S);
    }
    let gr = x.createRadialGradient(r, r * 0.9, r * 0.45, r, r, r);
    gr.addColorStop(0, 'rgba(0,0,0,0)');
    gr.addColorStop(0.72, `rgba(0,0,0,${kind === 'top' ? 0.16 : 0.1})`);
    gr.addColorStop(0.93, `rgba(0,0,0,${kind === 'top' ? 0.5 : 0.42})`);
    gr.addColorStop(1, 'rgba(0,0,0,0.15)');
    x.fillStyle = gr; x.fillRect(0, 0, S, S);
    gr = x.createRadialGradient(r, r * 1.55, 0, r, r * 1.55, r * 0.95);
    gr.addColorStop(0, `rgba(255,255,255,${kind === 'top' ? 0.42 : 0.3})`);
    gr.addColorStop(0.55, 'rgba(255,255,255,0.08)');
    gr.addColorStop(1, 'rgba(255,255,255,0)');
    x.fillStyle = gr; x.fillRect(0, 0, S, S);
    x.restore();
    // thin bright edge along the bottom
    x.strokeStyle = `rgba(255,255,255,${kind === 'top' ? 0.35 : 0.22})`; x.lineWidth = 2.2;
    x.beginPath(); x.arc(r, r, r - 2.5, Math.PI * 0.18, Math.PI * 0.82); x.stroke();
    // specular highlight
    gr = x.createRadialGradient(r * 0.68, r * 0.55, 0, r * 0.68, r * 0.55, r * 0.26);
    gr.addColorStop(0, 'rgba(255,255,255,0.95)'); gr.addColorStop(0.35, 'rgba(255,255,255,0.45)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
    x.fillStyle = gr; x.fillRect(0, 0, S, S);
    return (SP[kind] = c);
  }

  // ---------------------------------------------------------------- the simulation (shared)
  // Units are canvas pixels. P holds the sizes and rates for that canvas.
  function Sim(W, H, P) {
    const beads = document.createElement('canvas');
    beads.width = W; beads.height = H;
    return { W, H, P, beads, bx: beads.getContext('2d'), runners: [], acc: 0, accB: 0, evap: 0 };
  }
  function bead(sim, x, y, r, a = 1) {
    const s = dropSprite(sim.P.sprite), b = sim.bx;
    b.globalAlpha = a;
    b.drawImage(s, x - r, y - r * 1.05, r * 2, r * 2.1);
    b.globalAlpha = 1;
  }
  function addRunner(sim, x, y, r) {
    sim.runners.push({ x, y, r, vy: 0, vx: 0, still: R(0.1, 1.6), dist: 0, wob: R(0, 6), snag: 0 });
  }
  function step(sim, dt, m, drive) {
    const { W, H, P, bx } = sim;
    // rain hitting the glass
    sim.acc += dt * P.rate * m;
    while (sim.acc > 1) {
      sim.acc -= 1;
      if (Math.random() < P.bigChance && sim.runners.length < P.maxRunners) addRunner(sim, R(0, W), R(-P.big[1], H * P.spawnTo), R(P.big[0], P.big[1]));
      else if (P.mist && Math.random() < 0.45) bead(sim, R(0, W), R(0, H), R(0.5, 1.0), P.beadA * 0.8);  // fine mist
      else bead(sim, R(0, W), R(0, H), R(P.bead[0], P.bead[1]) * (Math.random() < 0.15 ? 1.8 : 1), P.beadA);
    }
    // condensation slowly dries so the glass never fills up
    sim.evap += dt;
    if (sim.evap > 0.5) {
      sim.evap = 0;
      bx.globalCompositeOperation = 'destination-out';
      bx.fillStyle = `rgba(0,0,0,${P.dry})`; bx.fillRect(0, 0, W, H);
      bx.globalCompositeOperation = 'source-over';
    }
    const rs = sim.runners;
    for (let i = rs.length - 1; i >= 0; i--) {
      const d = rs[i];
      if (d.still > 0) { d.still -= dt; continue; }
      // bigger drops slide faster; now and then a drop snags on the glass and stops for a moment
      if (d.snag > 0) d.snag -= dt;
      else if (Math.random() < dt * 0.35) d.snag = R(0.1, 0.7);
      const target = d.snag > 0 ? 0 : P.fall * Math.pow(d.r / P.big[0], 1.3) * m;
      d.vy += (target - d.vy) * Math.min(1, dt * (d.snag > 0 ? 9 : 2.5));
      d.wob += dt * R(1, 4);
      d.vx = Math.sin(d.wob) * d.r * 0.9 - drive * P.drive; // drive: wind pushes drops back when moving
      const dy = d.vy * dt;
      d.x += d.vx * dt; d.y += dy;
      // wipe the beads the drop runs over (it swallows them)
      bx.globalCompositeOperation = 'destination-out';
      bx.beginPath(); bx.ellipse(d.x, d.y, d.r * 1.15, d.r * 1.35, 0, 0, TAU); bx.fill();
      bx.globalCompositeOperation = 'source-over';
      if (P.wet && dy > 0) {  // the glass it ran over stays wet for a while: a faint shiny track
        bx.strokeStyle = 'rgba(225,238,255,0.022)'; bx.lineWidth = d.r * 0.5; bx.lineCap = 'round';
        bx.beginPath(); bx.moveTo(d.x - d.vx * dt, d.y - dy - d.r); bx.lineTo(d.x, d.y - d.r); bx.stroke();
      }
      // leave a trail of tiny drops behind, losing a little water each time
      d.dist += Math.abs(dy) + Math.abs(d.vx * dt);
      if (d.dist > d.r * 1.3) {
        d.dist = 0;
        if (Math.random() < 0.8) bead(sim, d.x + R(-0.3, 0.3) * d.r, d.y - d.r * R(1.6, 2.4), d.r * R(0.18, 0.38), P.beadA);
        d.r *= 0.988;
      }
      if (d.y - d.r * 3 > H || d.x < -40 || d.x > W + 40 || d.r < P.big[0] * 0.45) rs.splice(i, 1);
    }
    // drops that touch join into one bigger drop
    for (let i = 0; i < rs.length; i++) for (let j = i + 1; j < rs.length; j++) {
      const a = rs[i], b = rs[j];
      if (Math.abs(a.x - b.x) < (a.r + b.r) * 0.75 && Math.abs(a.y - b.y) < (a.r + b.r) * 0.9) {
        const [big, small] = a.r >= b.r ? [a, b] : [b, a];
        big.r = Math.min(P.big[1] * 1.5, Math.hypot(big.r, small.r * 0.85));
        big.y = Math.max(big.y, small.y); big.still = 0;
        small.r = 0; small.y = H * 4; // removed next step
      }
    }
  }
  function warm(sim) { for (let i = 0; i < 120; i++) step(sim, 0.06, 1, 0); } // start with glass that's already wet
  function shapeOf(d) { // moving drops stretch: rounder head, a bit taller
    const st = Math.min(0.45, d.vy / 260);
    return [d.r * (1 - st * 0.25), d.r * (1 + st)];
  }

  // ---------------------------------------------------------------- the view outside (background)
  function lightsFor(W, H, col) {
    const warm = ['#FFB347', '#FFC870', '#FF9E3D'], cool = [col.a, col.c1, col.c3];
    const L = [];
    for (let i = 0; i < 14; i++) L.push({ x: R(0, W), y: R(H * 0.2, H * 0.62), r: R(14, 34), c: warm[i % 3], a: R(0.35, 0.75), f: R(0, 6) }); // street lamps
    for (let i = 0; i < 18; i++) L.push({ x: R(0, W), y: R(H * 0.35, H * 0.9), r: R(8, 22), c: cool[i % 3], a: R(0.25, 0.6), f: R(0, 6) }); // signs, windows
    for (let i = 0; i < 8; i++) L.push({ x: R(0, W), y: R(H * 0.6, H * 0.85), r: R(6, 14), c: '#FF2A2A', a: R(0.35, 0.7), f: R(0, 6) }); // tail lights
    for (let i = 0; i < 30; i++) L.push({ x: R(0, W), y: R(H * 0.15, H * 0.9), r: R(2, 6), c: [warm[0], col.a, '#FFFFFF'][i % 3], a: R(0.2, 0.5), f: R(0, 6) }); // far specks
    return L;
  }
  function paintScene(W, H, col, L, sharp) {
    const c = document.createElement('canvas');
    c.width = W; c.height = H;
    const x = c.getContext('2d');
    const sky = x.createLinearGradient(0, 0, 0, H);
    sky.addColorStop(0, col.base); sky.addColorStop(0.55, hexA(col.c2, 0.55)); sky.addColorStop(1, col.base);
    x.fillStyle = col.base; x.fillRect(0, 0, W, H);
    x.fillStyle = sky; x.fillRect(0, 0, W, H);
    x.globalCompositeOperation = 'lighter';
    for (const l of L) {
      const r = Math.max(2, Math.round(l.r * (sharp ? 0.32 : 1)));
      x.globalAlpha = Math.min(1, l.a * (sharp ? 1.3 : 1.25));
      x.drawImage(sprite(l.c, r, sharp ? 0.55 : 0.18), l.x - r, l.y - r);
    }
    // wet road reflection: streaks under the lamps
    if (!sharp) for (const l of L) if (l.r > 14 && l.y < H * 0.62) {
      const g = x.createLinearGradient(0, l.y, 0, H);
      g.addColorStop(0, hexA(l.c, 0)); g.addColorStop(0.5, hexA(l.c, l.a * 0.18)); g.addColorStop(1, hexA(l.c, 0));
      x.globalAlpha = 1; x.fillStyle = g; x.fillRect(l.x - l.r * 0.35, l.y, l.r * 0.7, H - l.y);
    }
    x.globalAlpha = 1; x.globalCompositeOperation = 'source-over';
    return c;
  }

  FXN.window = {
    init(W, H) {
      const col = fxColors(), L = lightsFor(W, H, col);
      const sim = Sim(W, H, { sprite: 'bg', rate: 26, bigChance: 0.05, maxRunners: 26, big: [2.6, 6.5], bead: [0.5, 1.6], beadA: 0.9,
        spawnTo: 0.75, fall: 55, drive: 9, dry: 0.012 });
      warm(sim);
      return {
        col, L, blur: paintScene(W, H, col, L, false), sharp: paintScene(W, H, col, L, true),
        sim,
        cars: [], nextCar: R(1, 4),
      };
    },
    frame(g, st, f) {
      const { W, H, dt, m, speed, beat } = f;
      const drive = Math.max(0, speed - 1); // 0 parked, up to 3 on the highway
      g.drawImage(st.blur, 0, 0);
      // lamps breathe a little; brighter on the beat
      g.globalCompositeOperation = 'lighter';
      for (let i = 0; i < st.L.length; i += 3) {
        const l = st.L[i], a = (0.05 + 0.05 * Math.sin(f.t * 0.7 + l.f)) + beat * 0.06;
        if (a > 0.01) { const r = Math.round(l.r); g.globalAlpha = a; g.drawImage(sprite(l.c, r, 0.18), l.x - r, l.y - r); }
      }
      // passing cars: a pair of soft headlights or tail lights sliding by
      st.nextCar -= dt * m;
      if (st.nextCar <= 0) {
        st.nextCar = R(2, 7) / (1 + drive * 0.5);
        const left = Math.random() < 0.5, head = Math.random() < 0.5;
        st.cars.push({ x: left ? -60 : W + 60, y: R(H * 0.62, H * 0.8), v: (left ? 1 : -1) * R(50, 110), c: head ? '#FFF4D6' : '#FF3030', r: R(9, 15) });
      }
      for (let i = st.cars.length - 1; i >= 0; i--) {
        const c = st.cars[i];
        c.x += c.v * dt * m;
        const r = Math.round(c.r);
        g.globalAlpha = 0.55;
        g.drawImage(sprite(c.c, r, 0.2), c.x - r, c.y - r);
        g.drawImage(sprite(c.c, r, 0.2), c.x - r + r * 2.6, c.y - r);
        if (c.x < -100 || c.x > W + 100) st.cars.splice(i, 1);
      }
      g.globalAlpha = 1; g.globalCompositeOperation = 'source-over';
      // a light mist on the glass
      g.fillStyle = 'rgba(150,170,200,0.05)'; g.fillRect(0, 0, W, H);

      step(st.sim, dt, m, drive);
      g.drawImage(st.sim.beads, 0, 0);
      // running drops: each one is a little upside-down lens of the lights behind it
      const spr = dropSprite('bg');
      for (const d of st.sim.runners) {
        const [rx, ry] = shapeOf(d);
        if (rx < 0.5) continue;
        g.save();
        g.beginPath(); g.ellipse(d.x, d.y, rx, ry, 0, 0, TAU); g.clip();
        g.translate(d.x, d.y); g.scale(1, -1);
        const sw = rx * 7, sh = ry * 7;
        const sx = Math.max(0, Math.min(W - sw, d.x - sw / 2)), sy = Math.max(0, Math.min(H - sh, d.y - sh / 2));
        g.drawImage(st.sharp, sx, sy, sw, sh, -rx, -ry, rx * 2, ry * 2);
        g.restore();
        g.drawImage(spr, d.x - rx, d.y - ry, rx * 2, ry * 2);
      }
    },
  };

  // ---------------------------------------------------------------- rain over the tiles
  const cv = document.createElement('canvas');
  cv.id = 'rainTop';
  cv.setAttribute('aria-hidden', 'true');
  document.body.appendChild(cv);
  const top = { on: false, sim: null, last: 0, raf: 0, x: cv.getContext('2d'), k: 1 };

  function topWanted() {
    if (typeof S === 'undefined' || !S.state) return false;
    const s = settings();
    const viaWindow = (s.effect || 'blobs') === 'window' && g('rain_over') !== false;
    if (s.animate === false || !(viaWindow || s.rain_glass === true)) return false;
    if (typeof effectiveBrightness === 'function' && effectiveBrightness() === 0) return false;
    return !(S.screen === 'maps' || S.screen === 'ytm'); // keep the live map clear
  }
  function topSize() {
    top.k = 0.7;  // drops are soft; a smaller canvas stretched to the screen is much less work for the Pi
    const W = cv.width = Math.round(innerWidth * top.k), H = cv.height = Math.round(innerHeight * top.k);
    const amt = settings().rain_amount || 'steady';
    const A = { light: [4, 0.1, 7, 0.04], steady: [9, 0.12, 14, 0.03], heavy: [17, 0.16, 22, 0.022] }[amt] || [9, 0.12, 14, 0.03];
    top.amount = amt;
    top.sim = Sim(W, H, { sprite: 'top', rate: A[0], bigChance: A[1], maxRunners: A[2], big: [6, 13], bead: [1.3, 3.6], beadA: 0.85,
      spawnTo: 0.6, fall: 85, drive: 18, dry: A[3], mist: true, wet: true });
    warm(top.sim);
  }
  // ---- lens drops: each running drop is a little piece of real "water" floating over the screen. It blurs,
  // brightens and saturates whatever is under it (tiles, text, album art), with a dark rim at the top,
  // a bright caustic at the bottom and a sharp highlight, the way a drop on a windshield looks.
  const lensBox = document.createElement('div');
  lensBox.id = 'rainLens';
  lensBox.setAttribute('aria-hidden', 'true');
  document.body.appendChild(lensBox);
  const lenses = [];
  function lensFor(i) {
    while (lenses.length <= i) { const el = document.createElement('i'); lensBox.appendChild(el); lenses.push(el); }
    return lenses[i];
  }
  const useLens = () => top.ema < 45 && settings().rain_lens !== false;
  function drawLenses(sim) {
    const on = useLens();
    lensBox.style.display = on ? 'block' : 'none';
    if (!on) return false;
    const k = top.k;
    let n = 0;
    for (const d of sim.runners) {
      const [rx, ry] = shapeOf(d);
      if (rx < 1.2) continue;
      const el = lensFor(n++), w = (rx * 2) / k, h = (ry * 2.15) / k;
      el.style.width = `${w.toFixed(1)}px`; el.style.height = `${h.toFixed(1)}px`;
      el.style.transform = `translate(${(d.x / k - w / 2).toFixed(1)}px, ${(d.y / k - h * 0.55).toFixed(1)}px)`;
      el.style.display = 'block';
    }
    for (let i = n; i < lenses.length; i++) lenses[i].style.display = 'none';
    return true;
  }

  function topFrame(now) {
    top.raf = requestAnimationFrame(topFrame);
    // if the Pi is struggling (frames arriving late), the rain over the tiles drops to 15 a second
    top.ema = (top.ema || 33) * 0.95 + (now - (top.prev || now)) * 0.05; top.prev = now;
    const fps = top.ema > 45 ? 15 : settings().motion === 'wild' ? 60 : 30;
    if (now - top.last < 1000 / fps - 2) return;
    const dt = Math.min(0.1, (now - top.last) / 1000);
    top.last = now;
    const m = MOTION[settings().motion] || 1;
    const sim = top.sim, x = top.x;
    step(sim, dt, m, Math.max(0, fxSpeed() - 1));
    x.clearRect(0, 0, sim.W, sim.H);
    x.drawImage(sim.beads, 0, 0);
    const spr = dropSprite('top'), lens = drawLenses(sim);
    for (const d of sim.runners) {
      const [rx, ry] = shapeOf(d);
      if (rx < 0.5) continue;
      // a faint wet streak above a moving drop
      if (d.vy > 20) {
        const gr = x.createLinearGradient(0, d.y - ry * 5, 0, d.y);
        gr.addColorStop(0, 'rgba(210,225,255,0)'); gr.addColorStop(1, 'rgba(210,225,255,0.07)');
        x.fillStyle = gr; x.fillRect(d.x - rx * 0.45, d.y - ry * 5, rx * 0.9, ry * 5);
      }
      if (!lens || rx < 1.2) x.drawImage(spr, d.x - rx, d.y - ry, rx * 2, ry * 2);
    }
  }
  function topCheck() {
    const want = topWanted();
    if (want && top.sim && top.amount !== (settings().rain_amount || 'steady')) topSize();
    if (want === top.on) return;
    top.on = want;
    cv.style.display = want ? 'block' : 'none';
    if (!want) lensBox.style.display = 'none';
    cancelAnimationFrame(top.raf);
    if (want) { if (!top.sim) topSize(); top.last = performance.now(); top.raf = requestAnimationFrame(topFrame); }
  }
  addEventListener('resize', () => { top.sim = null; if (top.on) topSize(); });
  setInterval(topCheck, 400);
})();
