// Gauges: draws every <canvas data-gauge="..."> on the screen (the Gauges screen and gauge tiles on Home).
// Readings come from the OBD adapter (speed falls back to the phone's GPS). Needles glide between readings
// at the screen's frame rate. Colors follow the theme. Loaded after app.js (uses S, OBDS, settings, g).
'use strict';
(function () {
  const TAU = Math.PI * 2, rad = (d) => (d * Math.PI) / 180, clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const A0 = rad(135), SWEEP = rad(270);   // dials open at the bottom

  // ---------------------------------------------------------------- readings
  const sm = {};   // smoothed values
  const trip = { mpgAvg: null, mpgN: 0, lastKmh: null, lastT: 0, accel: 0 };
  function raw() {
    const st = S.state || {}, d = ((st.obd || {}).data) || {}, cur = (typeof OBDS !== 'undefined' && OBDS.cur) || {};
    const kmh = cur.speed ?? d.speed ?? (st.speed ? st.speed.mps * 3.6 : null);
    const maf = d.maf;
    const mpg = kmh != null && maf ? (kmh > 4 ? clamp((7.107 * kmh) / maf, 0, 99) : 0) : null;
    return { rpm: cur.rpm ?? d.rpm, kmh, fuel: d.fuel, coolant: d.coolant, volts: d.volts, intake: d.intake, load: d.load, throttle: d.throttle, mpg };
  }
  function update(dt) {
    const r = raw();
    for (const [k, v] of Object.entries(r)) {
      if (v == null) { sm[k] = null; continue; }
      const rate = k === 'rpm' || k === 'kmh' ? 0.35 : 0.08;
      sm[k] = sm[k] == null ? v : sm[k] + (v - sm[k]) * Math.min(1, rate * dt * 60);
    }
    // trip average fuel economy and acceleration (the fuel tank sloshes with it)
    if (r.mpg != null && r.kmh > 4) {
      trip.mpgN = Math.min(trip.mpgN + dt, 600);
      trip.mpgAvg = trip.mpgAvg == null ? r.mpg : trip.mpgAvg + (r.mpg - trip.mpgAvg) * (dt / Math.max(30, trip.mpgN));
    }
    if (r.kmh != null) {
      if (trip.lastKmh != null) { const a = (r.kmh - trip.lastKmh) / Math.max(dt, 0.016); trip.accel += (clamp(a, -40, 40) - trip.accel) * Math.min(1, dt * 3); }
      trip.lastKmh = r.kmh;
    }
  }
  const metric = () => speedUnits(S.state || {}) === 'kmh';
  const tempF = () => tempUnits() === 'F';

  // ---------------------------------------------------------------- theme
  let T = null, themeKey = '';
  function theme() {
    const cs = getComputedStyle(document.body);
    const v = (n, d) => (cs.getPropertyValue(n).trim() || d);
    const key = v('--accent', '') + v('--b1', '') + v('--text', '');
    if (key !== themeKey || !T) {
      themeKey = key;
      T = { accent: v('--accent', '#5EEAD4'), b1: v('--b1', '#14B8A6'), b2: v('--b2', '#7C3AED'), b3: v('--b3', '#0EA5E9'),
        text: v('--text', '#F5F7FA'), sub: v('--sub', 'rgba(245,247,250,.65)'), faint: 'rgba(255,255,255,.09)',
        red: '#FF4D4D', amber: '#FFB020', green: '#34D399', blue: '#4FA3FF', font: cs.fontFamily || 'Inter, sans-serif' };
    }
    return T;
  }
  const F = (w, px) => `${w} ${Math.round(px)}px ${T.font}`;
  function text(g, s, x, y, w, px, col, align = 'center') { g.font = F(w, px); g.fillStyle = col; g.textAlign = align; g.textBaseline = 'middle'; g.fillText(s, x, y); }
  function arc(g, cx, cy, r, a0, a1, w, col, glow = 0, cap = 'round') {
    g.lineWidth = w; g.strokeStyle = col; g.lineCap = cap;
    if (glow) { g.shadowColor = typeof col === 'string' ? col : T.accent; g.shadowBlur = glow; }
    g.beginPath(); g.arc(cx, cy, r, a0, a1); g.stroke(); g.shadowBlur = 0;
  }
  function needle(g, cx, cy, len, a, col, w) {
    g.save(); g.translate(cx, cy); g.rotate(a);
    g.shadowColor = col; g.shadowBlur = w * 3; g.fillStyle = col;
    g.beginPath(); g.moveTo(-len * 0.16, -w); g.lineTo(len, -w * 0.18); g.lineTo(len, w * 0.18); g.lineTo(-len * 0.16, w); g.closePath(); g.fill();
    g.restore(); g.shadowBlur = 0;
    const hub = g.createRadialGradient(cx - w, cy - w, 1, cx, cy, w * 3.2);
    hub.addColorStop(0, '#666b74'); hub.addColorStop(1, '#0d0f12');
    g.fillStyle = hub; g.beginPath(); g.arc(cx, cy, w * 3, 0, TAU); g.fill();
  }
  const pulse = (t, speed = 4) => 0.5 + 0.5 * Math.sin(t * speed);
  const noData = (g, cx, cy, size, what) => text(g, what, cx, cy, 500, size * 0.07, T.sub);

  // a dial's frame: a value from 0..1 on a 270 degree sweep, ticks and labels
  function dial(g, cx, cy, r, opt) {
    const { f, labels, zones, col, segs } = opt;
    arc(g, cx, cy, r, A0, A0 + SWEEP, r * 0.075, T.faint);
    for (const [z0, z1, zc] of zones || []) arc(g, cx, cy, r + r * 0.07, A0 + SWEEP * z0, A0 + SWEEP * z1, r * 0.025, zc, 8, 'butt');
    if (segs) {   // lit segments
      const n = segs;
      for (let i = 0; i < n; i++) {
        const v = (i + 1) / n, on = v <= f + 1e-6, a = A0 + SWEEP * (i / n), b = A0 + SWEEP * ((i + 0.72) / n);
        const c = typeof col === 'function' ? col(v) : col;
        g.lineWidth = r * 0.075; g.lineCap = 'butt'; g.strokeStyle = on ? c : 'rgba(255,255,255,.06)';
        if (on) { g.shadowColor = c; g.shadowBlur = r * 0.08; }
        g.beginPath(); g.arc(cx, cy, r, a, b); g.stroke(); g.shadowBlur = 0;
      }
    } else if (f > 0.002) {
      const gr = g.createLinearGradient(cx - r, cy, cx + r, cy);
      gr.addColorStop(0, T.b3); gr.addColorStop(1, col);
      arc(g, cx, cy, r, A0, A0 + SWEEP * Math.min(1, f), r * 0.075, gr, r * 0.12);
    }
    const n = labels.length - 1;
    for (let i = 0; i <= n * 5; i++) {
      const a = A0 + (SWEEP * i) / (n * 5), major = i % 5 === 0;
      const r1 = r - r * 0.1, r2 = r1 - (major ? r * 0.1 : r * 0.05);
      const red = opt.redFrom != null && i / (n * 5) >= opt.redFrom;
      g.strokeStyle = red ? T.red : major ? T.text : 'rgba(255,255,255,.35)'; g.lineWidth = major ? Math.max(2, r * 0.018) : 1;
      g.beginPath(); g.moveTo(cx + r1 * Math.cos(a), cy + r1 * Math.sin(a)); g.lineTo(cx + r2 * Math.cos(a), cy + r2 * Math.sin(a)); g.stroke();
    }
    labels.forEach((l, i) => {
      const a = A0 + (SWEEP * i) / n, rr = r - r * 0.3;
      const red = opt.redFrom != null && i / n >= opt.redFrom;
      text(g, l, cx + rr * Math.cos(a), cy + rr * Math.sin(a), 600, r * 0.12, red ? T.red : 'rgba(255,255,255,.75)');
    });
  }

  // ---------------------------------------------------------------- wide, short tiles
  // A round dial in a wide, short tile is a tiny circle with empty glass either side. There every gauge
  // becomes a readout instead: a big number filling the height, its name, and a bar that fills the width.
  const isWide = (w, h) => w / h >= 1.8;
  function wide(g, w, h, t, o) {
    const p = clamp(h * 0.14, 6, 16), mid = h / 2;
    const col = o.col || T.text;
    // the number fills the height, but never takes more than about half the width (the bar needs room)
    let big = h * 0.62;
    const measure = () => {
      g.font = F(300, big); const vw = g.measureText(o.val).width;
      g.font = F(500, big * 0.3); const uw = o.unit ? g.measureText(o.unit).width + big * 0.1 : 0;
      return [vw, uw];
    };
    let [vw, uw] = measure();
    const room = w * 0.46 - p;
    if (vw + uw > room) { big *= room / (vw + uw); [vw, uw] = measure(); }
    const vy = mid + big * 0.04;
    text(g, o.val, p, vy, 300, big, col, 'left');
    if (o.unit) text(g, o.unit, p + vw + big * 0.08, vy + big * 0.2, 500, big * 0.3, T.sub, 'left');
    const bx = p + vw + uw + Math.max(p, w * 0.04), bw = Math.max(10, w - bx - p - 2);
    const fs = clamp(h * 0.16, 10, 18), bh = clamp(h * 0.13, 5, 14);
    const showNote = o.note && h > 44;
    const by = mid - bh / 2 + (showNote ? 0 : fs * 0.35);
    text(g, o.name, bx, by - fs * 0.85, 650, fs, T.sub, 'left');
    const rr = bh / 2, f = clamp(o.f || 0, 0, 1);
    const bar = (x, w2, c) => { g.beginPath(); g.roundRect ? g.roundRect(x, by, w2, bh, rr) : g.rect(x, by, w2, bh); g.fillStyle = c; g.fill(); };
    bar(bx, bw, T.faint);
    for (const [z0, z1, zc] of o.zones || []) {   // thin colored zones under the bar (redline, C/H bands)
      g.fillStyle = zc; g.fillRect(bx + bw * z0, by + bh + 3, bw * (z1 - z0), Math.max(2, bh * 0.25));
    }
    if (o.segs) {
      const n = o.segs, gap = Math.max(1.5, (bw / n) * 0.28), sw = bw / n - gap;
      for (let i = 0; i < n; i++) {
        const v = (i + 1) / n, on = v <= f + 1e-6, c = typeof o.segCol === 'function' ? o.segCol(v) : col;
        g.fillStyle = on ? c : 'rgba(255,255,255,.07)';
        if (on) { g.shadowColor = c; g.shadowBlur = bh * 0.8; }
        g.fillRect(bx + i * (sw + gap), by, sw, bh); g.shadowBlur = 0;
      }
    } else if (o.has) {
      const fc = o.barCol || col, gr = g.createLinearGradient(bx, 0, bx + bw, 0);
      gr.addColorStop(0, o.barCol ? fc : T.b3); gr.addColorStop(1, fc);
      g.save(); g.shadowColor = fc; g.shadowBlur = bh; bar(bx, Math.max(bh, bw * f), gr); g.restore();
      if (o.dot) { g.fillStyle = '#fff'; g.shadowColor = fc; g.shadowBlur = bh; g.beginPath(); g.arc(bx + Math.max(bh / 2, bw * f - bh / 2), by + bh / 2, bh * 0.75, 0, TAU); g.fill(); g.shadowBlur = 0; }
    }
    if (showNote) {
      g.save(); g.beginPath(); g.rect(bx, 0, w - bx - p * 0.5, h); g.clip();   // long notes fade off the edge, never over it
      text(g, o.note, bx, by + bh + (o.zones ? 5 : 2) + fs * 0.75, 600, fs * 0.9, o.noteCol || T.sub, 'left');
      g.restore();
    }
  }

  // ---------------------------------------------------------------- the gauges
  function fuelLeft(fuel, short) {
    const tank = (settings().tank || 185) / 10;
    if (trip.mpgAvg && trip.mpgN > 90) {
      const miles = (fuel / 100) * tank * trip.mpgAvg;
      if (short) return metric() ? `${Math.round(miles * 1.609)} km left` : `${Math.round(miles)} mi left`;
      return metric() ? `about ${Math.round(miles * 1.609)} km left` : `about ${Math.round(miles)} miles left`;
    }
    return short ? `${((fuel / 100) * tank).toFixed(1)} gal` : `about ${((fuel / 100) * tank).toFixed(1)} gallons`;
  }
  const G = {
    tach(g, w, h, t) {
      const rpm = sm.rpm, f = rpm == null ? 0 : clamp(rpm / 7000, 0, 1.02), red = 6000 / 7000;
      const hot = rpm != null && rpm > 6000;
      const segCol = (v) => (v > red ? T.red : v > 0.72 ? T.amber : T.accent);
      if (isWide(w, h)) return wide(g, w, h, t, { name: 'Tachometer', val: rpm == null ? '--' : String(Math.round(rpm / 10) * 10), unit: 'rpm',
        f, segs: Math.max(12, Math.round(w / 9)), segCol, col: hot ? T.red : T.text, zones: [[red, 1, 'rgba(255,77,77,.85)']],
        note: rpm == null ? 'No OBD adapter' : '' });
      const r = Math.min(w * 0.41, h * 0.5), cx = w / 2, cy = h / 2 + r * 0.13;
      if (hot) { const gl = g.createRadialGradient(cx, cy, r * 0.3, cx, cy, r * 1.3); gl.addColorStop(0, `rgba(255,60,60,${0.25 * pulse(t, 14)})`); gl.addColorStop(1, 'rgba(255,60,60,0)'); g.fillStyle = gl; g.fillRect(0, 0, w, h); }
      dial(g, cx, cy, r, { f, labels: ['0', '1', '2', '3', '4', '5', '6', '7'], redFrom: red, segs: 56,
        col: segCol, zones: [[red, 1, 'rgba(255,77,77,.8)']] });
      needle(g, cx, cy, r * 0.82, A0 + SWEEP * f, hot ? T.red : T.amber, Math.max(3, r * 0.03));
      text(g, rpm == null ? '--' : String(Math.round(rpm / 10) * 10), cx, cy + r * 0.42, 300, r * 0.26, hot ? T.red : T.text);
      text(g, 'rpm', cx, cy + r * 0.62, 500, r * 0.1, T.sub);
      if (rpm == null) noData(g, cx, cy - r * 0.35, r * 2, 'No OBD adapter');
    },
    speed(g, w, h, t) {
      const km = metric();
      const v = sm.kmh == null ? null : km ? sm.kmh : sm.kmh * 0.621371, max = km ? 220 : 140;
      if (isWide(w, h)) return wide(g, w, h, t, { name: 'Speed', val: v == null ? '--' : String(Math.round(v)), unit: km ? 'km/h' : 'mph',
        f: v == null ? 0 : v / max, has: v != null, barCol: T.accent, dot: true });
      const r = Math.min(w * 0.41, h * 0.5), cx = w / 2, cy = h / 2 + r * 0.13;
      dial(g, cx, cy, r, { f: v == null ? 0 : clamp(v / max, 0, 1), labels: (km ? [0, 40, 80, 120, 160, 200, 220] : [0, 20, 40, 60, 80, 100, 120, 140]).map(String), col: T.accent });
      if (v != null) {  // a bright marker riding the arc
        const a = A0 + SWEEP * clamp(v / max, 0, 1);
        g.fillStyle = '#fff'; g.shadowColor = T.accent; g.shadowBlur = r * 0.15;
        g.beginPath(); g.arc(cx + r * Math.cos(a), cy + r * Math.sin(a), r * 0.055, 0, TAU); g.fill(); g.shadowBlur = 0;
      }
      text(g, v == null ? '--' : String(Math.round(v)), cx, cy + r * 0.02, 200, r * 0.52, T.text);
      text(g, km ? 'km/h' : 'mph', cx, cy + r * 0.38, 500, r * 0.11, T.sub);
    },
    fuel(g, w, h, t) {
      const fuel = sm.fuel, low = fuel != null && fuel < 15, lowish = fuel != null && fuel < 25;
      if (isWide(w, h) && h < 150) {
        const c = low ? T.red : lowish ? T.amber : T.accent;
        return wide(g, w, h, t, { name: 'Fuel', val: fuel == null ? '--' : `${Math.round(fuel)}%`, f: (fuel || 0) / 100, has: fuel != null,
          barCol: c, col: low ? T.red : T.text, zones: [[0, 0.15, 'rgba(255,77,77,.8)']],
          note: fuel == null ? 'No OBD adapter' : low ? 'Low fuel' : fuelLeft(fuel, true), noteCol: low ? `rgba(255,77,77,${0.55 + 0.45 * pulse(t, 5)})` : T.sub });
      }
      // the tank: a rounded capsule, liquid inside sloshing with acceleration
      // tank on the left and the readout beside it, unless that leaves too little room for the words:
      // then the tank goes on top and the readout underneath
      const tall = w - (w * 0.12 + Math.min(w * 0.42, h * 0.5) + Math.max(w * 0.13, 56)) < 170;
      const tw = tall ? Math.min(w * 0.46, h * 0.36) : Math.min(w * 0.42, h * 0.56), th = tall ? h * 0.6 : h * 0.8;
      const tx = tall ? (w - tw) / 2 - w * 0.07 : w * 0.1, ty = tall ? h * 0.07 : (h - th) / 2 + h * 0.03, rr = tw * 0.32;
      const path = () => { g.beginPath(); g.moveTo(tx + rr, ty); g.arcTo(tx + tw, ty, tx + tw, ty + th, rr); g.arcTo(tx + tw, ty + th, tx, ty + th, rr); g.arcTo(tx, ty + th, tx, ty, rr); g.arcTo(tx, ty, tx + tw, ty, rr); g.closePath(); };
      path(); g.fillStyle = 'rgba(0,0,0,.25)'; g.fill();
      if (fuel != null) {
        g.save(); path(); g.clip();
        const lvl = ty + th - (th * clamp(fuel, 0, 100)) / 100, tilt = clamp(-trip.accel / 60, -0.25, 0.25);
        const c1 = low ? T.red : lowish ? T.amber : T.accent, c2 = low ? '#7a1010' : lowish ? '#7a4a05' : T.b2;
        const gr = g.createLinearGradient(0, lvl, 0, ty + th); gr.addColorStop(0, c1); gr.addColorStop(1, c2);
        g.beginPath(); g.moveTo(tx - 2, ty + th + 2);
        for (let x = 0; x <= tw + 4; x += 4) g.lineTo(tx + x - 2, lvl + tilt * (x - tw / 2) + Math.sin(t * 2.4 + x * 0.06) * tw * 0.02 + Math.sin(t * 3.7 - x * 0.04) * tw * 0.012);
        g.lineTo(tx + tw + 2, ty + th + 2); g.closePath();
        g.fillStyle = gr; g.shadowColor = c1; g.shadowBlur = low ? 20 + 20 * pulse(t, 5) : 16; g.fill(); g.shadowBlur = 0;
        g.strokeStyle = 'rgba(255,255,255,.55)'; g.lineWidth = 2; g.stroke();
        for (let i = 0; i < 6; i++) {  // bubbles
          const by = ty + th - ((t * (14 + i * 5) + i * 31) % Math.max(10, ty + th - lvl));
          if (by > lvl + 6) { g.strokeStyle = 'rgba(255,255,255,.5)'; g.lineWidth = 1; g.beginPath(); g.arc(tx + tw * (0.2 + (i * 0.13) % 0.6), by, 1.5 + (i % 3), 0, TAU); g.stroke(); }
        }
        g.restore();
      }
      path(); g.strokeStyle = 'rgba(255,255,255,.28)'; g.lineWidth = 2; g.stroke();
      const sh = g.createLinearGradient(tx, 0, tx + tw, 0); sh.addColorStop(0, 'rgba(255,255,255,.14)'); sh.addColorStop(0.3, 'rgba(255,255,255,0)');
      path(); g.fillStyle = sh; g.fill();
      // E . 1/4 . 1/2 . 3/4 . F marks
      ['E', '¼', '½', '¾', 'F'].forEach((l, i) => {
        const y = ty + th - (th * i) / 4;
        g.strokeStyle = 'rgba(255,255,255,.4)'; g.lineWidth = 2; g.beginPath(); g.moveTo(tx + tw + 6, y); g.lineTo(tx + tw + 16, y); g.stroke();
        text(g, l, tx + tw + 30, y, 600, Math.max(12, h * 0.05), i === 0 ? T.red : T.sub);
      });
      // readout
      const al = tall ? 'center' : 'left', rx = tall ? w / 2 : tx + tw + Math.max(w * 0.13, 56);
      const big = tall ? Math.min(w * 0.26, h * 0.13) : Math.min((w - rx) * 0.4, h * 0.28), small = Math.max(12, Math.min(h * 0.05, w * 0.05));
      const y1 = tall ? ty + th + big * 0.85 : h / 2 - h * 0.1, y2 = y1 + big * 0.62 + small * 0.4, y3 = y2 + small * 1.45;
      text(g, fuel == null ? '--' : `${Math.round(fuel)}%`, rx, y1, 200, big, low ? T.red : T.text, al);
      const sub = fuel == null ? 'Fuel' : fuelLeft(fuel);
      text(g, sub, rx, y2, 500, small, T.sub, al);
      if (low) text(g, 'Low fuel', rx, y3, 700, small * 1.1, `rgba(255,77,77,${0.55 + 0.45 * pulse(t, 5)})`, al);
      if (fuel == null) text(g, 'No OBD adapter', rx, y3, 500, small, T.sub, al);
    },
    coolant(g, w, h, t) {
      const c = sm.coolant, f = c == null ? null : c * 9 / 5 + 32;   // zones are worked out in °F
      const lo = 100, hi = 260, k = f == null ? 0 : clamp((f - lo) / (hi - lo), 0, 1);
      const state = f == null ? null : f < 160 ? 'cold' : f < 225 ? 'ok' : f < 240 ? 'warm' : 'hot';
      const zc = { cold: T.blue, ok: T.green, warm: T.amber, hot: T.red };
      // colored band C ... H
      const bands = [[0, (160 - lo) / (hi - lo), T.blue], [(160 - lo) / (hi - lo), (225 - lo) / (hi - lo), T.green], [(225 - lo) / (hi - lo), (240 - lo) / (hi - lo), T.amber], [(240 - lo) / (hi - lo), 1, T.red]];
      const shown = c == null ? '--' : tempF() ? `${Math.round(f)}°` : `${Math.round(c)}°`;
      const msg = { cold: 'Warming up', ok: 'Normal', warm: 'Running warm', hot: 'Overheating! Pull over' }[state] || 'No OBD adapter';
      const msgCol = state === 'hot' ? `rgba(255,77,77,${0.6 + 0.4 * pulse(t, 6)})` : state ? zc[state] : T.sub;
      if (isWide(w, h)) return wide(g, w, h, t, { name: 'Coolant', val: shown, f: k, has: f != null, barCol: state ? zc[state] : T.sub, dot: true,
        col: state === 'hot' ? T.red : T.text, zones: bands.map(([a, b, col]) => [a, b, col + '99']), note: msg, noteCol: msgCol });
      const r = Math.min(w * 0.45, h * 0.48), cx = w / 2, cy = h / 2 + r * 0.12;
      const a0 = rad(160), sw = rad(220);
      arc(g, cx, cy, r, a0, a0 + sw, r * 0.12, T.faint);
      for (const [z0, z1, col] of bands) arc(g, cx, cy, r, a0 + sw * z0, a0 + sw * z1, r * 0.12, col.replace(')', ',.35)').replace('rgb(', 'rgba(').startsWith('#') ? col + '55' : col, 0, 'butt');
      if (f != null) {
        const col = zc[state];
        arc(g, cx, cy, r, a0, a0 + sw * k, r * 0.12, col, state === 'hot' ? 18 + 18 * pulse(t, 6) : 14, 'butt');
        const a = a0 + sw * k;
        g.fillStyle = '#fff'; g.shadowColor = col; g.shadowBlur = 16;
        g.beginPath(); g.arc(cx + r * Math.cos(a), cy + r * Math.sin(a), r * 0.085, 0, TAU); g.fill(); g.shadowBlur = 0;
      }
      text(g, 'C', cx + (r + r * 0.18) * Math.cos(a0), cy + (r + r * 0.18) * Math.sin(a0), 700, r * 0.13, T.blue);
      text(g, 'H', cx + (r + r * 0.18) * Math.cos(a0 + sw), cy + (r + r * 0.18) * Math.sin(a0 + sw), 700, r * 0.13, T.red);
      // thermometer icon
      g.save(); g.translate(cx, cy - r * 0.58); const s = r * 0.0048;
      g.strokeStyle = f == null ? T.sub : zc[state]; g.lineWidth = 2.5; g.lineCap = 'round';
      g.beginPath(); g.arc(0, 18 * s * 2, 7 * s * 2, 0, TAU); g.moveTo(-3.5 * s * 2, 13 * s * 2); g.lineTo(-3.5 * s * 2, -16 * s * 2); g.arc(0, -16 * s * 2, 3.5 * s * 2, Math.PI, 0); g.lineTo(3.5 * s * 2, 13 * s * 2); g.stroke();
      g.restore();
      text(g, shown, cx, cy + r * 0.05, 200, r * 0.42, state === 'hot' ? T.red : T.text);
      text(g, msg, cx, cy + r * 0.42, 600, r * 0.12, msgCol);
      text(g, 'Coolant', cx, cy + r * 0.62, 500, r * 0.1, T.sub);
    },
    // ---- smaller arcs: battery, fuel economy, intake air, engine load, throttle
    volts(g, w, h, t) { small(g, w, h, t, sm.volts, 10, 16, (v) => `${v.toFixed(1)} V`, 'Battery', (v) => (v < 11.8 ? T.red : v < 12.6 ? T.amber : v > 15.2 ? T.red : T.green), (v) => (v >= 13.2 ? 'Charging' : v >= 12.4 ? 'Engine off' : 'Low')); },
    mpg(g, w, h, t) { small(g, w, h, t, sm.mpg, 0, 50, (v) => (metric() ? (v > 0.5 ? `${(235.2 / v).toFixed(1)}` : '--') : v.toFixed(0)), metric() ? 'L/100 km' : 'mpg now', () => T.accent, () => (trip.mpgAvg && trip.mpgN > 30 ? `Trip ${metric() ? (235.2 / trip.mpgAvg).toFixed(1) : trip.mpgAvg.toFixed(1)}` : '')); },
    intake(g, w, h, t) { small(g, w, h, t, sm.intake, -20, 80, (v) => (tempF() ? `${Math.round(v * 9 / 5 + 32)}°` : `${Math.round(v)}°`), 'Intake air', () => T.b3); },
    load(g, w, h, t) { small(g, w, h, t, sm.load, 0, 100, (v) => `${Math.round(v)}%`, 'Engine load', (v) => (v > 85 ? T.amber : T.accent)); },
    throttle(g, w, h, t) { small(g, w, h, t, sm.throttle, 0, 100, (v) => `${Math.round(v)}%`, 'Throttle', () => T.accent); },
  };
  function small(g, w, h, t, v, lo, hi, fmt, label, colFn, noteFn) {
    if (isWide(w, h)) {
      const col = v == null ? T.sub : colFn(v);
      return wide(g, w, h, t, { name: label, val: v == null ? '--' : fmt(v), f: v == null ? 0 : (v - lo) / (hi - lo), has: v != null,
        barCol: col, note: v == null ? 'No OBD adapter' : (noteFn ? noteFn(v) : ''), noteCol: col });
    }
    const r = Math.min(w * 0.43, h * 0.46), cx = w / 2, cy = h / 2 + r * 0.1;
    arc(g, cx, cy, r, A0, A0 + SWEEP, r * 0.12, T.faint);
    if (v != null) {
      const col = colFn(v), k = clamp((v - lo) / (hi - lo), 0, 1);
      arc(g, cx, cy, r, A0, A0 + SWEEP * Math.max(0.004, k), r * 0.12, col, 16);
    }
    text(g, v == null ? '--' : fmt(v), cx, cy, 300, r * 0.42, T.text);
    text(g, label, cx, cy + r * 0.45, 600, r * 0.15, T.sub);
    const note = v != null && noteFn ? noteFn(v) : '';
    if (note) text(g, note, cx, cy + r * 0.72, 500, r * 0.13, colFn(v));
    if (v == null) text(g, 'No OBD adapter', cx, cy + r * 0.72, 500, r * 0.12, T.sub);
  }
  window.GAUGE_LIST = [['tach', 'Tachometer', 'Engine rpm with a redline that glows'], ['speed', 'Speedometer', 'Big speed with a sweeping arc'],
    ['fuel', 'Fuel', 'A tank that sloshes as you drive, with range left'], ['coolant', 'Coolant temperature', 'Cold, normal and hot zones, warns if it overheats'],
    ['volts', 'Battery', 'Voltage and whether it’s charging'], ['mpg', 'Fuel economy', 'Right now and for the trip'],
    ['intake', 'Intake air', 'Air temperature going into the engine'], ['load', 'Engine load', 'How hard the engine is working'], ['throttle', 'Throttle', 'How far the pedal is pressed']];

  // ---------------------------------------------------------------- loop: only runs while gauges are on screen
  let last = performance.now(), lastDraw = 0;
  function frame(now) {
    const list = [...document.querySelectorAll('canvas[data-gauge]')].filter((c) => c.offsetParent !== null);
    const dt = Math.min(0.1, (now - last) / 1000); last = now;
    if (!list.length) { setTimeout(() => requestAnimationFrame(frame), 400); return; }
    requestAnimationFrame(frame);
    const fps = (settings().motion === 'wild') ? 60 : 30;
    if (now - lastDraw < 1000 / fps - 2) return;
    update(Math.max(dt, (now - lastDraw) / 1000)); lastDraw = now;
    theme();
    const t = settings().animate === false ? 0 : now / 1000;
    const dpr = Math.min(1.5, devicePixelRatio || 1);
    for (const c of list) {
      const w = c.clientWidth, h = c.clientHeight;
      if (!w || !h) continue;
      if (c.width !== Math.round(w * dpr) || c.height !== Math.round(h * dpr)) { c.width = Math.round(w * dpr); c.height = Math.round(h * dpr); }
      const g = c.getContext('2d');
      g.setTransform(dpr, 0, 0, dpr, 0, 0);
      g.clearRect(0, 0, w, h);
      (G[c.dataset.gauge] || G.speed)(g, w, h, t);
    }
  }
  requestAnimationFrame(frame);
})();
