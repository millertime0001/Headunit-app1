/* 3D worlds: abstract and luxury scenes (see world3d.js for the shared uniforms and helpers).
   Each scene: id: [name, description, cost 1-3, GLSL defining vec3 scene(vec2 fc)].
   Theme colors arrive in linear space and may be very dark, so scenes take their HUE with hue() and set the
   brightness themselves. Light themes (uBase near white) get a bright, airy variant instead of a dark one. */
'use strict';
Object.assign(WORLDS, {
  chrome: ['Liquid chrome', 'Mirror-chrome blobs merging and splitting in a studio, on a glossy black floor', 3, `
vec3 hue(vec3 c){ return c / max(max(c.r, c.g), max(c.b, .02)); }
float light(){ return smoothstep(.25, .7, dot(uBase, vec3(.2126, .7152, .0722))); }
float smin(float a, float b, float k){ float h = clamp(.5 + .5 * (b - a) / k, 0., 1.); return mix(b, a, h) - k * h * (1. - h); }
// five metaballs on slow Lissajous paths, smooth-unioned into one liquid body
float map(vec3 p){
  float t = T * .32; p.y += .3;
  float d = length(p - vec3(sin(t) * 1.1, sin(t * 1.3) * .3, cos(t * .7) * .6)) - .72;
  d = smin(d, length(p - vec3(cos(t * .8 + 1.) * 2., cos(t * 1.1) * .45 + .1, sin(t * .9) * .8)) - .5, .6);
  d = smin(d, length(p - vec3(sin(t * .6 + 2.) * 2.4, sin(t * .9 + 1.) * .5, cos(t * 1.2 + 2.) * .7)) - .42, .6);
  d = smin(d, length(p - vec3(cos(t * 1.2 + 4.) * 1.4, cos(t * .7 + 3.) * .6, sin(t * .5 + 1.) * .9)) - .36, .55);
  d = smin(d, length(p - vec3(sin(t * .45 + 5.) * 2.8, cos(t * .55 + 5.) * .4 - .1, cos(t * .4) * .5)) - .3, .55);
  return d;
}
vec3 nrm(vec3 p){ const vec2 e = vec2(.002, -.002);
  return normalize(e.xyy * map(p + e.xyy) + e.yyx * map(p + e.yyx) + e.yxy * map(p + e.yxy) + e.xxx * map(p + e.xxx)); }
const float FLOOR = -1.15;
// the studio the chrome reflects: long overhead strip boxes, a tall key panel behind the camera,
// tinted side strips and a bright horizon over a dark floor
vec3 env(vec3 d){
  float L = light();
  vec3 k1 = hue(uC1), k2 = hue(uC2), ka = hue(uAcc);
  // sky dome: dim at the zenith, brighter toward the horizon (gives chrome its body)
  vec3 c = mix(mix(vec3(.04), uBase * .4, L) + k2 * .12, mix(vec3(.4), mix(k1, k2, .4) * .5, .5) + uBase * .3, pow(1. - max(d.y, 0.), 1.6));
  c += mix(vec3(1.), k1, .35) * (.25 * exp(-abs(d.y) * 9.) + 1.2 * exp(-abs(d.y + .01) * 60.));   // horizon
  c = mix(c, mix(vec3(.004), uBase * .22, L), smoothstep(-.02, -.12, d.y));                       // floor
  float a = atan(d.x, d.z);
  // two long strips overhead (running front to back)
  vec2 o = d.xz / max(d.y, .05);
  float strips = smoothstep(.09, .05, abs(abs(o.x) - .55)) * smoothstep(3., 2., abs(o.y));
  c += mix(vec3(1.), k1, .2) * 3.5 * strips * step(0., d.y);
  // tall key panel behind the camera, brighter at the top
  vec2 kb = vec2(abs(a + .25) - 2.75, d.y - .35);
  c += mix(vec3(1.), k1, .1) * (1. + 1.8 * smoothstep(-.3, .5, d.y)) * smoothstep(.06, .0, max(abs(kb.x) - .22, abs(kb.y) - .4));
  c += ka * 3. * smoothstep(.06, .02, abs(a - 1.6)) * smoothstep(-.05, .1, d.y) * smoothstep(.8, .5, d.y);       // accent strip
  c += hue(uC3) * 2. * smoothstep(.07, .02, abs(a + 1.75)) * smoothstep(-.05, .1, d.y) * smoothstep(.8, .4, d.y); // second strip
  c += mix(vec3(1.), ka, .5) * 2.5 * smoothstep(.05, .0, length(vec2(a - 2.6, d.y - .6)) - .04);                 // small spot
  return c;
}
float march(vec3 ro, vec3 rd, float maxd, int n){
  float d = 0.;
  for (int i = 0; i < 64; i++) { if (i >= n) break; float h = map(ro + rd * d); if (h < .0015 * d + .001) return d; d += h; if (d > maxd) break; }
  return -1.;
}
vec3 chromeCol(vec3 p, vec3 rd, vec3 n){
  vec3 r = reflect(rd, n); float f = pow(1. - max(dot(-rd, n), 0.), 5.);
  vec3 metal = mix(vec3(.85), hue(uAcc), .12);
  return env(r) * mix(metal, vec3(1.), f) * (.6 + .4 * smoothstep(-.6, .6, n.y + 1.));
}
vec3 floorCol(vec3 p, vec3 rd){
  float L = light();
  vec3 c = mix(vec3(.004), uBase * .3, L) + hue(uC2) * .01;
  float b = map(vec3(p.x, FLOOR + .6, p.z)); c *= .3 + .7 * smoothstep(-.3, 1., b);                 // contact shadow
  c += hue(uAcc) * .05 * exp(-length(p.xz) * .6) * (1. + uBeat * .6);                            // soft glow pool
  return c;
}
vec3 scene(vec2 fc){
  vec2 uv = (fc - .5 * R) / R.y;
  float ang = uCam.x * .25;
  vec3 ro = vec3(sin(ang) * 7., 1.5 + uCam.y * .4, -cos(ang) * 7.);
  vec3 fw = normalize(vec3(0., -.6, 0.) - ro), rt = normalize(cross(vec3(0, 1, 0), fw)), up = cross(fw, rt);
  vec3 rd = normalize(fw * 1.6 + rt * uv.x + up * uv.y);
  vec3 col;
  float d = march(ro, rd, 14., 64);
  float fd = rd.y < 0. ? (FLOOR - ro.y) / rd.y : 1e9;
  if (d > 0. && d < fd) {
    vec3 p = ro + rd * d, n = nrm(p), r = reflect(rd, n);
    // one bounce: does the reflection hit another part of the liquid?
    float d2 = march(p + n * .02, r, 5., 24);
    if (d2 > 0.) { vec3 p2 = p + r * d2; col = chromeCol(p2, r, nrm(p2)) * .8; }
    else if (r.y < 0.) { vec3 fp = p + r * ((FLOOR - p.y) / r.y); col = floorCol(fp, r) + env(reflect(r, vec3(0, 1, 0))) * .2; }
    else col = env(r);
    float f = pow(1. - max(dot(-rd, n), 0.), 5.);
    col *= mix(mix(vec3(.85), hue(uAcc), .12), vec3(1.), f);
  } else if (fd < 40.) {
    // glossy black floor: mirror the blobs with a fresnel falloff
    vec3 p = ro + rd * fd, r = reflect(rd, vec3(0, 1, 0));
    col = floorCol(p, rd);
    float f = .2 + .8 * pow(1. - abs(rd.y), 5.);
    float d2 = march(p, r, 10., 32);
    vec3 refl = d2 > 0. ? chromeCol(p + r * d2, r, nrm(p + r * d2)) : env(r) * .15;
    col += refl * f * .9 * exp(-fd * .03);
  } else {
    // seamless dark backdrop with a soft glow behind the liquid (the bright studio is only seen in reflections)
    col = mix(vec3(.004), uBase * .35, light()) + hue(uC2) * .05 * exp(-abs(rd.y - .02) * 6.) + hue(uC1) * .02 * smoothstep(.3, -.1, rd.y);
  }
  return aces(col * 1.1);
}`],

  crystal: ['Crystals', 'Faceted gems slowly turning, refracting light with rainbow fringes', 3, `
vec3 hue(vec3 c){ return c / max(max(c.r, c.g), max(c.b, .02)); }
float light(){ return smoothstep(.25, .7, dot(uBase, vec3(.2126, .7152, .0722))); }
const float PHI = 1.618034;
// brilliant-looking gem: dodecahedron cut by an icosahedron (32 facets)
float gem(vec3 p, float r){
  vec3 q = abs(p);
  vec3 a = normalize(vec3(0., 1., PHI));                      // dodecahedron faces
  float dd = max(max(dot(q, a), dot(q, a.zxy)), dot(q, a.yzx));
  vec3 b = normalize(vec3(0., 1. / PHI, PHI));                // icosahedron faces
  float di = max(max(max(dot(q, b), dot(q, b.zxy)), dot(q, b.yzx)), dot(q, vec3(.57735)));
  return max(dd - r, di - r * 1.04);
}
// hexagonal quartz shard with pointed ends
float shard(vec3 p, float r, float h){
  vec2 q = abs(p.xz); float hx = max(q.x * .866 + q.y * .5, q.y);
  return max(hx - r, abs(p.y) * .45 + hx * .9 - h * .45) * .9;
}
float octa(vec3 p, float s){ p = abs(p); return (p.x + p.y + p.z - s) * .57735; }
mat3 rm(float a, float b){ float ca = cos(a), sa = sin(a), cb = cos(b), sb = sin(b);
  return mat3(ca, 0., sa, 0., 1., 0., -sa, 0., ca) * mat3(1., 0., 0., 0., cb, -sb, 0., sb, cb); }
mat3 M1, M2, M3;
vec3 P1, P2, P3;
float map(vec3 p){
  float d = gem(M1 * (p - P1), .9);
  d = min(d, shard(M2 * (p - P2), .32, 1.25));
  return min(d, octa(M3 * (p - P3), .55));
}
vec3 nrm(vec3 p){ const vec2 e = vec2(.0015, -.0015);
  return normalize(e.xyy * map(p + e.xyy) + e.yyx * map(p + e.yyx) + e.yxy * map(p + e.yxy) + e.xxx * map(p + e.xxx)); }
// dark jeweller's light box: a ring of colored panels, thin line lights and a top light.
// Refraction through the facets breaks this up into the gem's sparkle ("fire").
vec3 env(vec3 d){
  float L = light();
  vec3 k1 = hue(uC1), k2 = hue(uC2), k3 = hue(uC3), ka = hue(uAcc);
  vec3 c = mix(vec3(.004), uBase * .3, L) + k2 * .04 * smoothstep(-.5, .8, d.y);
  float a = atan(d.x, d.z), seg = a * 1.1141 + 3.5, id = floor(seg), fx = fract(seg) - .5;   // 7 panels around
  float pan = smoothstep(.16, .1, abs(fx)) * smoothstep(.45, .38, abs(d.y - .05));
  float m = mod(id, 4.);
  vec3 pc = mix(vec3(1.), m < 1. ? k1 : m < 2. ? vec3(1.) : m < 3. ? ka : k3, .6);
  c += pc * pan * (1.5 + 1.5 * smoothstep(.4, -.3, d.y)) * (.5 + .5 * h11(id));
  c += vec3(1.) * 1.5 * pow(abs(sin(d.y * 11. + a * 2.)), 200.) * smoothstep(.8, .2, abs(d.y));        // line lights
  c += mix(vec3(1.), k1, .2) * 6. * smoothstep(.93, .95, d.y);                                       // top light
  return c;
}
vec3 scene(vec2 fc){
  vec2 uv = (fc - .5 * R) / R.y;
  float t = T * .18;
  M1 = rm(t, .5 + sin(t * .7) * .3); P1 = vec3(-.15, .05 + sin(T * .4) * .08, 0.);
  M2 = rm(-t * 1.3 + 1., .45 + sin(t) * .15); P2 = vec3(1.95, .25 + sin(T * .33 + 1.) * .12, .9);
  M3 = rm(t * 1.6 + 2., t * .9); P3 = vec3(-2.05, -.35 + sin(T * .5 + 2.) * .1, .6);
  float ang = uCam.x * .22;
  vec3 ro = vec3(sin(ang) * 6.5, .5 + uCam.y * .4, -cos(ang) * 6.5);
  vec3 fw = normalize(vec3(0., 0., .2) - ro), rt = normalize(cross(vec3(0, 1, 0), fw)), up = cross(fw, rt);
  vec3 rd = normalize(fw * 1.9 + rt * uv.x + up * uv.y);
  float L = light();
  // backdrop: soft glow behind the gems, faint colored caustics on a dark sweep
  vec3 col = mix(vec3(.004), uBase * .55, L) + hue(uC2) * .05 * exp(-length(uv - vec2(0., .05)) * 2.5) * (1. + uBeat * .4);
  col += hue(uC3) * .03 * smoothstep(.2, -.4, uv.y);
  float d = 0., hit = 0.;
  for (int i = 0; i < 64; i++) { float h = map(ro + rd * d); if (h < .001) { hit = 1.; break; } d += h; if (d > 12.) break; }
  if (hit > .5) {
    vec3 p = ro + rd * d, n = nrm(p);
    float c = max(dot(-rd, n), 0.), F = .04 + .96 * pow(1. - c, 5.);
    vec3 refl = env(reflect(rd, n));
    // refract in, march to the far side (inside, -map is the distance to the surface)
    vec3 ri = refract(rd, n, 1. / 1.7), q = p - n * .01;
    float s = 0.;
    for (int i = 0; i < 20; i++) { float h = -map(q + ri * s); if (h < .001) break; s += max(h, .02); }
    vec3 q2 = q + ri * s, n2 = -nrm(q2);
    // exit with a slightly different index per color: dispersion fringes
    vec3 tr;
    vec3 er = refract(ri, n2, 1.62), eg = refract(ri, n2, 1.70), eb = refract(ri, n2, 1.80);
    vec3 tir = env(reflect(ri, n2)) * .7;    // total internal reflection fallback
    tr.r = dot(er, er) > 0. ? env(er).r : tir.r;
    tr.g = dot(eg, eg) > 0. ? env(eg).g : tir.g;
    tr.b = dot(eb, eb) > 0. ? env(eb).b : tir.b;
    tr = mix(dot(eg, eg) > 0. ? env(eg) : tir, tr, .6);    // keep the fringes, lose the harsh primaries
    vec3 tint = mix(vec3(1.), mix(hue(uC1), hue(uAcc), .5 + .5 * sin(p.y * 2.)), .35);
    tr *= tint * exp(-s * .25);
    col = mix(tr, refl, F) + refl * .08;
    // facet edges catch the light: screen-space change of the normal marks them (free on the GPU)
    float edge = smoothstep(.15, .8, length(fwidth(n)));
    col += mix(vec3(1.), hue(uAcc), .3) * edge * .25;
    // crisp glints off the facets from the top light
    col += vec3(1.) * 3. * pow(max(dot(reflect(rd, n), normalize(vec3(-.3, 1., -.2))), 0.), 120.);
  }
  return aces(col * 1.05);
}`],

  hyperspace: ['Hyperspace', 'Jump to lightspeed: stars stretch into streaks around a glowing vanishing point', 1, `
vec3 hue(vec3 c){ return c / max(max(c.r, c.g), max(c.b, .02)); }
float light(){ return smoothstep(.25, .7, dot(uBase, vec3(.2126, .7152, .0722))); }
// one ring of stars flying past at a FIXED speed (speed changes cross-fade between layers, so nothing jumps)
vec3 stars(vec2 p, float r, float a, float vel, float seed, float streak){
  float N = 70. + seed * 23.;
  float ai = (a / 6.2831853 + .5) * N, cell = floor(ai);
  vec3 h = vec3(h11(cell + seed * 113.), h11(cell * 1.7 + seed * 37.), h11(cell * .37 + seed * 71.));
  float z = fract(h.y - T * vel * (.6 + .4 * h.z));          // depth 1 far -> 0 at the camera
  float da = abs(ai - cell - (.25 + .5 * h.x)) / N * 6.2831853 * r;   // distance from the star's ray
  float k = .055;
  float head = k / max(z, .01), tail = k / (z + streak * (.7 + .6 * h.z));
  float along = smoothstep(tail * .95, tail, r) * smoothstep(head * 1.02, head, r);
  float w = .0012 + .0035 * (1. - z);
  float core = exp(-da * da / (w * w)) * along;
  float tipg = exp(-pow(length(vec2(da, (r - head) * .5)), 2.) / (w * w * 4.)) * .8;  // brighter head
  float fade = smoothstep(1., .7, z) * smoothstep(0., .08, z);
  vec3 tc = mix(vec3(.85, .92, 1.), mix(hue(uC1), hue(uAcc), h.x), .55 * h.z);
  float g = (r - tail) / max(head - tail, 1e-4);            // doppler: red tail, blue head
  vec3 dop = mix(vec3(1., .55, .45), vec3(.6, .8, 1.2), clamp(g, 0., 1.));
  return tc * mix(vec3(1.), dop, clamp(streak * 4., 0., .8)) * (core * (.6 + .9 * (1. - z)) + tipg) * fade * (.5 + h.z);
}
vec3 scene(vec2 fc){
  vec2 uv = (fc - .5 * R) / R.y;
  float sp = uSpeed;
  vec2 c = -uCam * vec2(.07, .05);                           // vanishing point drifts with the camera
  vec2 p = uv - c; float r = length(p), a = atan(p.y, p.x);
  vec3 k1 = hue(uC1), k2 = hue(uC2), k3 = hue(uC3), ka = hue(uAcc);
  // tunnel walls: faint streaking gas on a cylinder around us
  float tz = .25 / max(r, .02);
  float w1 = noise3(vec3(cos(a) * 2.5, sin(a) * 2.5, tz * 1.5 - T * 1.5));
  float w2 = noise3(vec3(cos(a) * 6., sin(a) * 6., tz * 4. - T * 3.));
  float gas = smoothstep(.35, .85, w1 * .7 + w2 * .3) * smoothstep(.05, .5, r);
  vec3 col = uBase * .2 + mix(k2, k3, w2) * gas * (.12 + .25 * sp);
  // glowing vanishing point
  col += ka * .5 * exp(-r * 7.) * (1. + uBeat * .5) + vec3(1.) * .5 * exp(-r * 40.) + mix(ka, k1, .5) * .08 * exp(-r * 2.);
  // star layers: slow ones fade out and fast ones fade in as the speed rises
  float s1 = 1. - smoothstep(.2, .7, sp), s2 = smoothstep(.15, .6, sp) * (1. - smoothstep(.75, 1., sp) * .5), s3 = smoothstep(.55, 1., sp);
  vec3 st = vec3(0.);
  st += stars(p, r, a, .05, 1., .01 + sp * .03) * (s1 + .3);
  st += stars(p, r, a, .07, 2., .012 + sp * .04) * (s1 + .3);
  st += stars(p, r, a, .1, 3., .02 + sp * .05) * (s1 + .2);
  st += stars(p, r, a, .35, 4., .08 + sp * .2) * s2;
  st += stars(p, r, a, .45, 5., .1 + sp * .25) * s2;
  st += stars(p, r, a, 1.1, 6., .3 + sp * .5) * s3;
  st += stars(p, r, a, 1.4, 7., .35 + sp * .6) * s3;
  col += st;
  // at full warp the whole frame washes with light from the center
  col += mix(ka, vec3(1.), .4) * .15 * s3 * exp(-r * 3.);
  float L = light();
  // light themes: the same jump in daylight (paper-colored space, ink-tinted streaks)
  vec3 lc = uBase * .85 * (1. - .6 * clamp(st, 0., 1.) * (1. - ka * .5)) + ka * .2 * exp(-r * 6.) + vec3(.3) * exp(-r * 30.);
  return mix(aces(col * 1.2), clamp(lc, 0., 1.), L);
}`],

  lava: ['Molten core', 'A flowing molten surface with glowing cracks, heat shimmer and rising embers', 2, `
vec3 hue(vec3 c){ return c / max(max(c.r, c.g), max(c.b, .02)); }
float light(){ return smoothstep(.25, .7, dot(uBase, vec3(.2126, .7152, .0722))); }
// cell noise: returns the distance to the nearest cell border (small = in a crack)
float cracks(vec2 p){
  vec2 i = floor(p), f = fract(p); float d1 = 8., d2 = 8.;
  for (int y = -1; y <= 1; y++) for (int x = -1; x <= 1; x++) {
    vec2 g = vec2(x, y), o = h22(i + g); o = .5 + .4 * sin(T * .15 + 6.2831 * o);
    float d = length(g + o - f);
    if (d < d1) { d2 = d1; d1 = d; } else if (d < d2) d2 = d;
  }
  return d2 - d1;
}
// heat to color: blackbody fire for warm themes, the theme's glow colors otherwise
vec3 heat(float x){
  vec3 ka = hue(uAcc), k1 = hue(uC1), k3 = hue(uC3);
  float warm = clamp(((ka.r - ka.b) + (k1.r - k1.b)) * .6, 0., 1.);
  warm = max(warm, smoothstep(.35, .15, max(k1.r, max(k1.g, k1.b)) - min(k1.r, min(k1.g, k1.b))));   // greyish themes: real fire
  vec3 fire = vec3(1.4, .32, .05) * x + vec3(1., .9, .4) * x * x * x * 1.5;
  vec3 th = mix(k1, ka, smoothstep(.2, .8, x)) * x * 1.3 + vec3(1.) * pow(x, 4.) * 1.2;
  return mix(th, fire, warm);
}
vec3 scene(vec2 fc){
  vec2 uv = (fc - .5 * R) / R.y;
  float L = light();
  // heat shimmer: wobble the view, stronger toward the horizon
  uv += (vec2(noise(uv * 18. + vec2(0., T * 2.)), noise(uv * 18. + vec2(5., T * 2.3))) - .5) * .006 * smoothstep(-.4, .1, uv.y);
  vec3 ro = vec3(uCam.x * .6, 2. + uCam.y * .25, 0.);
  vec3 rd = normalize(vec3(uv.x, uv.y - .32, 1.15));
  rd.xz *= rot(uCam.x * .06);
  // smoky sky lit from below by the glow
  vec3 haze = heat(.55) * .35;
  vec3 sky = mix(vec3(.004), uBase * .4, L) + haze * exp(-max(rd.y, 0.) * 9.);
  sky *= .6 + .5 * fbm(vec2(rd.x / (rd.y + .3) * 2. + T * .05, rd.y * 4. - T * .08));
  vec3 col = sky;
  {  // the ground is shaded for every pixel (no branch: the screen-space derivatives below stay valid)
    float d = -ro.y / min(rd.y, -.005); vec3 p = ro + rd * d;
    vec2 q = p.xz * .45 + vec2(0., T * .06);                               // the flow drifts toward us
    q += (vec2(fbm(q * .5 + T * .02), fbm(q * .5 + 7.)) - .5) * 1.6;        // fold the plates into irregular shapes
    float e = cracks(q * 1.4), e2 = cracks(q * 3.9 + 3.);                   // big plates + fine cracks
    float f = fbm(q * 3.);
    float hot = smoothstep(.5, .85, noise(q * .35 - T * .02));               // regions where the crust melted
    float aa = fwidth(e) * .7;
    float core = smoothstep(.045 + .15 * hot + aa, 0., e);                    // thin white-hot core
    float halo = exp(-e * 15.) * .22;                                        // glow spilling onto the crust
    float fine = smoothstep(.025 + aa, 0., e2) * .4 * smoothstep(.05, .3, e);
    float glow = clamp(core * (.6 + .4 * f) + fine * f + halo + hot * .45 * f * f, 0., 1.);
    glow *= .85 + .15 * sin(T * 1.5 + f * 9.) + uBeat * .1;
    float crack = core;
    // crust plates: raised basalt with a rough surface; bevels toward the cracks
    float hgt = f * .3 + smoothstep(0., .25, e) * .25;
    vec3 n = normalize(vec3(-dFdx(hgt), 0., -dFdy(hgt)) * R.y * .06 + vec3(0., 1., 0.));
    vec3 rock = mix(vec3(.025, .022, .02), uBase * .3, L) * (.5 + f);
    vec3 ldir = normalize(vec3(-.5, .6, .6));
    vec3 lit = rock * (.2 + .8 * max(dot(n, ldir), 0.)) * (heat(.5) * .3 + .05);
    lit += rock * heat(.6) * 2. * smoothstep(.2, .02, e) * (.5 + .5 * f);   // plate edges lit by the cracks
    lit += heat(.7) * .2 * pow(max(dot(reflect(rd, n), ldir), 0.), 40.) * (1. - crack);   // glossy glints
    col = lit + heat(glow) * (1.3 + hot);
    col = mix(col, sky, 1. - exp(-d * .07));                  // smoky distance
    col = mix(col, sky, smoothstep(-.012, -.004, rd.y));                    // above the horizon: sky
  }
  // embers drifting up
  for (int i = 0; i < 3; i++) {
    float fi = float(i), sc = 10. + fi * 7.;
    vec2 eq = (uv + uCam * .03 * (fi + 1.)) * sc + vec2(sin(T * .3 + fi) * 1.5, -T * (1.2 + fi * .5));
    vec2 id = floor(eq), o = h22(id + fi * 31.);
    vec2 gp = fract(eq) - .5 - (o - .5) * .7;
    float life = fract(o.x * 7. + T * .3);
    float e = exp(-dot(gp, gp) * (500. - fi * 120.)) * step(.9, o.y) * sin(life * 3.14);
    col += heat(.85) * e * 2. * smoothstep(.45, -.1, uv.y);
  }
  return aces(col * .9);
}`],

  nebula: ['Deep space', 'Drifting through a colorful nebula, stars passing at different depths', 2, `
vec3 hue(vec3 c){ return c / max(max(c.r, c.g), max(c.b, .02)); }
float light(){ return smoothstep(.25, .7, dot(uBase, vec3(.2126, .7152, .0722))); }
vec3 scene(vec2 fc){
  vec2 uv = (fc - .5 * R) / R.y;
  float L = light();
  vec3 k1 = hue(uC1), k2 = hue(uC2), k3 = hue(uC3), ka = hue(uAcc);
  float t = T * .035;
  vec3 neb = vec3(0.); float dust = 0., dens = 0.;
  // four cloud layers coming toward us; each fades in far away and out as we pass through it
  for (int i = 0; i < 4; i++) {
    float fi = float(i), ph = fi / 4. - t, z = fract(ph), cyc = floor(ph);
    float a = smoothstep(1., .65, z) * smoothstep(0., .3, z);
    vec2 p = uv * (.6 + z * 2.2) + uCam * .25 * (1. - z) + h22(vec2(cyc, fi)) * 50.;
    p *= rot(fi * 1.3 + cyc);
    vec2 w = vec2(noise(p * 1.3), noise(p * 1.3 + 9.));
    float n = fbm(p * 1.1 + w * 1.6);
    float c = smoothstep(.47, .88, n) * a;
    vec3 cc = mix(mix(k1, k2, w.x), mix(k3, ka, .5), smoothstep(.55, .9, n));
    neb += cc * c * (.45 + .45 * n) + mix(cc, vec3(1.), .3) * pow(c, 3.) * .6;   // soft gas + brighter filaments
    dust += smoothstep(.5, .3, n) * smoothstep(.3, .5, w.y) * a * .35;    // dark lanes
    dens += c;
  }
  vec3 col = mix(vec3(.002, .002, .004), uBase * .5, L) + k2 * .015;
  col += neb * .6 * (1. + uBeat * .15);
  col *= 1. - clamp(dust, 0., .7);
  // stars: three depths; near ones are bigger, drift faster and shift more with the camera
  for (int i = 0; i < 3; i++) {
    float fi = float(i), sc = 34. - fi * 11.;
    vec2 sp = (uv + uCam * .015 * (fi + 1.) + vec2(t * .15 * (fi + 1.), 0.)) * sc;
    vec2 id = floor(sp), o = h22(id + fi * 17.);
    vec2 gp = (fract(sp) - .15 - .7 * o) / sc;                              // offset from the star, in screen units
    float b = h21(id * 1.3 + fi);
    float lum = pow(max(b - .55, 0.) / .45, 3.) * (.7 + fi * .5);
    float tw = .75 + .25 * sin(T * (1. + o.x * 3.) + o.y * 20.);
    float w = .0011 + fi * .0005, r2 = dot(gp, gp);
    float s = (exp(-r2 / (w * w)) * 1.5 + lum * w * w * .25 / (r2 + w * w * .3)) * lum * tw;
    col += mix(vec3(1.), mix(k1, ka, o.x), .35) * s * (1. - clamp(dust, 0., .8) * (1. - fi * .4));
  }
  // a distant bright core
  vec2 cp = uv - vec2(.35, .12) + uCam * .01;
  col += mix(ka, vec3(1.), .3) * .12 * exp(-length(cp) * 5.) + vec3(1.) * .2 * exp(-length(cp) * 40.);
  vec3 dark = aces(col * 1.3);
  // light themes: watercolor nebula on paper
  vec3 lc = uBase * .9 * mix(vec3(1.), neb / max(dens, .1) * .7 + .2, clamp(dens * .7, 0., .8)) * (1. - clamp(dust, 0., .5) * .3);
  return mix(dark, lc, L);
}`],

  studio: ['Studio', 'Glossy and matte objects floating in a soft-lit infinite studio, like a product render', 3, `
vec3 hue(vec3 c){ return c / max(max(c.r, c.g), max(c.b, .02)); }
float light(){ return smoothstep(.25, .7, dot(uBase, vec3(.2126, .7152, .0722))); }
float sdRBox(vec3 p, vec3 b, float r){ vec3 q = abs(p) - b; return length(max(q, 0.)) + min(max(q.x, max(q.y, q.z)), 0.) - r; }
float sdTorus(vec3 p, vec2 t){ return length(vec2(length(p.xz) - t.x, p.y)) - t.y; }
const float FLOOR = -1.2;
vec3 P1, P2, P3, P4; mat2 Ra, Rb;
// material ids: 0 floor, 1 glossy lacquer, 2 polished metal, 3 matte ceramic, 4 chrome
vec2 map(vec3 p){
  vec2 r = vec2(p.y - FLOOR, 0.);
  float d = length(p - P1) - .85; if (d < r.x) r = vec2(d, 1.);
  vec3 q = p - P2; q.xy *= Ra; q.yz *= Rb;
  d = sdTorus(q, vec2(.62, .22)); if (d < r.x) r = vec2(d, 2.);
  q = p - P3; q.xz *= Rb; q.xy *= Ra;
  d = sdRBox(q, vec3(.42), .14); if (d < r.x) r = vec2(d, 3.);
  d = length(p - P4) - .38; if (d < r.x) r = vec2(d, 4.);
  return r;
}
vec3 nrm(vec3 p){ const vec2 e = vec2(.002, -.002);
  return normalize(e.xyy * map(p + e.xyy).x + e.yyx * map(p + e.yyx).x + e.yxy * map(p + e.yxy).x + e.xxx * map(p + e.xxx).x); }
float shadow(vec3 p, vec3 l){
  float s = 1., d = .03;
  for (int i = 0; i < 16; i++) { float h = map(p + l * d).x; s = min(s, 10. * h / d); d += clamp(h, .05, .5); if (s < .01 || d > 8.) break; }
  return clamp(s, 0., 1.);
}
float ao(vec3 p, vec3 n){
  float o = 0., w = 1.;
  for (int i = 1; i <= 4; i++) { float h = .08 * float(i) * float(i); o += (h - map(p + n * h).x) * w; w *= .6; }
  return clamp(1. - o * 1.1, 0., 1.);
}
vec3 KEY = vec3(0.);
// studio color: dark grey in dark themes (lightly tinted), the paper color in light themes
vec3 cyc(){ return mix(vec3(.11) * mix(vec3(1.), hue(uC2), .3), uBase * .62, light()); }
// what glossy surfaces reflect: the big overhead softbox, a tinted rim strip, the cyclorama
vec3 env(vec3 d){
  vec3 c = cyc() * (.6 + .5 * smoothstep(-.3, .3, d.y)) * mix(1., .55, smoothstep(.2, 1., d.y));
  c += mix(vec3(1.), hue(uC1), .3) * .35 * exp(-abs(d.y - .05) * 8.);           // bright band around the horizon
  vec3 ld = d - KEY; c += vec3(1., .98, .95) * 6. * smoothstep(.22, .18, max(abs(ld.x), abs(ld.z) * 1.4)) * step(.3, d.y);
  float a = atan(d.x, d.z);
  c += hue(uAcc) * 1.8 * smoothstep(.1, .04, abs(a - 2.3)) * smoothstep(-.1, .15, d.y) * smoothstep(.7, .4, d.y);
  c += mix(vec3(1.), hue(uC1), .4) * .8 * smoothstep(.15, .05, abs(a + 2.5)) * smoothstep(-.1, .2, d.y) * smoothstep(.6, .3, d.y);
  return c;
}
vec3 scene(vec2 fc){
  vec2 uv = (fc - .5 * R) / R.y;
  float t = T * .25, L = light();
  P1 = vec3(-1.75, -.15 + sin(T * .5) * .12, .5);
  P2 = vec3(.05, .25 + sin(T * .45 + 1.) * .14, -.2);
  P3 = vec3(1.85, -.2 + sin(T * .4 + 2.) * .12, .8);
  P4 = vec3(.95, -.72 + sin(T * .6 + 3.) * .07, -1.35);
  Ra = rot(t * .9); Rb = rot(.6 + t * .6);
  KEY = normalize(vec3(-.35, 1., -.25));
  float ang = uCam.x * .2;
  vec3 ro = vec3(sin(ang) * 6.6, .9 + uCam.y * .35, -cos(ang) * 6.6);
  vec3 fw = normalize(vec3(0., -.25, 0.) - ro), rt = normalize(cross(vec3(0, 1, 0), fw)), up = cross(fw, rt);
  vec3 rd = normalize(fw * 1.8 + rt * uv.x + up * uv.y);
  // infinite cyclorama: no visible horizon, just light falling off with distance
  vec3 bg = cyc() * (.55 + .35 * smoothstep(.4, -.2, rd.y));
  vec3 col = bg;
  float d = 0.; vec2 h = vec2(1., 0.);
  for (int i = 0; i < 64; i++) { h = map(ro + rd * d); if (h.x < .001 * d) break; d += h.x; if (d > 30.) break; }
  if (d < 30.) {
    vec3 p = ro + rd * d, n = nrm(p), r = reflect(rd, n);
    float sh = shadow(p + n * .01, KEY), oc = ao(p, n);
    float dif = max(dot(n, KEY), 0.);
    float fr = pow(1. - max(dot(-rd, n), 0.), 5.);
    float skyl = .5 + .5 * n.y;
    // the softbox highlight, shaped like the box
    float spec = smoothstep(.95, .985, dot(r, KEY)) * sh;
    float m = h.y;
    vec3 c;
    if (m < .5) {
      // floor: soft key light pool + contact shadows, fading into the backdrop
      c = cyc() * (.45 + .6 * dif * sh) * (.4 + .6 * oc) * (1. + .25 * exp(-length(p.xz) * .3));
      c = mix(c, bg, smoothstep(6., 22., d));
    } else if (m < 1.5) {          // lacquered accent sphere: colored base + clear coat
      vec3 alb = hue(uAcc) * .55;
      c = alb * (.08 + dif * sh * 1.1 + skyl * .2) * oc + env(r) * mix(.05, 1., fr) * (.5 + .5 * oc) + spec * 3.;
    } else if (m < 2.5) {          // polished metal torus in the theme's first color
      vec3 alb = mix(hue(uC1), vec3(1.), .25) * .9;
      c = env(r) * alb * (.4 + .6 * oc) * mix(1., sh, .3 * step(.3, dot(r, KEY))) + spec * alb * 2.;
    } else if (m < 3.5) {          // matte ceramic box: diffuse with a broad sheen
      vec3 alb = mix(vec3(.85), hue(uC3), .3) * .75;
      c = alb * (.06 + dif * sh * .95 + skyl * .22 * cyc() * 3.) * oc + env(r) * .04 * (1. + fr * 4.);
    } else {                       // chrome ball
      c = env(r) * mix(vec3(.75), vec3(1.), fr) * (.5 + .5 * oc);
    }
    col = c;
  }
  col *= 1. + uBeat * .04;
  return aces(col * mix(1.3, 1., L));
}`],
});
