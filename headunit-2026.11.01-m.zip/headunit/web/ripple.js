// Knob ripple: turning the knob sends an effect across the screen from where the knob is mounted.
// Styles: Waves, Shockwave, Aurora bloom, Sparks, Edge only, Raindrops, Liquid level, Light curtain, Level bars. The volume can trace the screen's
// edge (starting at the knob) and a glass readout can pop up. Pressing fires one bright burst.
(function () {
  const cv = document.createElement('canvas');
  cv.id = 'rippleFx';
  document.body.appendChild(cv);
  const x = cv.getContext('2d');
  const hud = document.createElement('div');
  hud.className = 'vol-hud glass';
  hud.innerHTML = '<span class="vh-ic"></span><b class="vh-num"></b><i class="vh-bar"><i></i></i>';
  document.body.appendChild(hud);
  let W = 0, H = 0, DPR = 1, fx = [], vol = 0, shown = 0, edgeA = 0, lastTurn = 0, running = false, hudTimer;

  function size() { DPR = Math.min(devicePixelRatio || 1, 1.5); W = cv.width = innerWidth * DPR; H = cv.height = innerHeight * DPR; }
  size(); addEventListener('resize', size);
  const css = (k, d) => getComputedStyle(document.documentElement).getPropertyValue(k).trim() || d;
  const style = () => (g('knob_ripple') === false ? 'off' : g('ripple_style') || 'waves');
  const amt = () => (g('ripple_power') ?? 60) / 60; // 1 = normal
  function origin() {
    const o = g('ripple_from') || 'bottom';
    const kx = (g('knob_x') ?? 50) / 100;
    return o === 'left' ? [0, H * 0.6] : o === 'right' ? [W, H * 0.6] : o === 'center' ? [W / 2, H / 2] : [W * kx, H];
  }

  function hitPanels(ox, oy, strong, speed) {
    $$('.screen:last-child .glass, .nav').forEach((el) => {
      const r = el.getBoundingClientRect();
      if (!r.width) return;
      const d = Math.hypot((r.left + r.width / 2) * DPR - ox, (r.top + r.height / 2) * DPR - oy) / DPR;
      setTimeout(() => {
        el.classList.remove('rip-hit', 'rip-hit2');
        void el.offsetWidth;
        el.classList.add(strong ? 'rip-hit2' : 'rip-hit');
      }, d * speed);
    });
  }

  // volume traced around the screen edge, starting where the knob is
  function edge(frac, alpha, accent) {
    if (alpha <= 0.01 || frac <= 0) return;
    const m = 3 * DPR;
    const [ox] = origin();
    const sx = (g('ripple_from') || 'bottom') === 'bottom' ? Math.min(W - m, Math.max(m, ox)) : W / 2;
    const pts = [[sx, H - m], [m, H - m], [m, m], [W - m, m], [W - m, H - m], [sx, H - m]];
    let per = 0;
    for (let i = 1; i < pts.length; i++) per += Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]);
    let left = per * frac, end = pts[0];
    x.save();
    x.globalAlpha = alpha;
    x.strokeStyle = accent; x.shadowColor = accent; x.shadowBlur = 24 * DPR; x.lineWidth = 5 * DPR; x.lineCap = 'round';
    x.beginPath(); x.moveTo(pts[0][0], pts[0][1]);
    for (let i = 1; i < pts.length && left > 0; i++) {
      const [ax, ay] = pts[i - 1], [bx, by] = pts[i], seg = Math.hypot(bx - ax, by - ay), k = Math.min(1, left / seg);
      end = [ax + (bx - ax) * k, ay + (by - ay) * k];
      x.lineTo(end[0], end[1]);
      left -= seg;
    }
    x.stroke();
    x.fillStyle = '#fff'; x.shadowBlur = 30 * DPR;
    x.beginPath(); x.arc(end[0], end[1], 5 * DPR, 0, 6.283); x.fill();
    x.restore();
  }


  // ---------------------------------------------------------------- the newer effects: Raindrops, Liquid level,
  // Light curtain, Level bars. Drawn in 1024 x 600 screen units (k scales to the canvas), from the knob's spot.
  const R = (a, b) => a + Math.random() * (b - a);
  const hexA = (hex, a) => { const h = hex.replace('#', ''); const n = parseInt(h.length === 3 ? h.replace(/./g, '$&$&') : h.slice(0, 6), 16);
    return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`; };
  const neo = {
    drops: [], rings: [], bits: [], cols: null, rays: [], I: 0, alpha: 0, kick: 0, wide: 0, last: 0,
    k() { return H / 600; },
    busy() { return this.drops.length || this.rings.length || this.bits.length || this.I > 0.01 || this.alpha > 0.01 || (this.cols && this.cols.some((c) => Math.abs(c.v) > 0.05)); },
    level() { return 22 + (shown / 100) * 120; },
    turn(st, ox, oy, dir, press) {
      const k = this.k(), x = ox / k, y = oy / k, p = amt();
      this.last = performance.now();
      if (st === 'rain') {
        for (let i = 0; i < (press ? 16 : 1); i++) this.drops.push({ x: x + R(-30, 30), y: Math.min(y, 596), vx: R(-7.5, 7.5) * (press ? 1.4 : 1) * p, vy: -R(10, 15.5) * Math.sqrt(p), land: R(330, 560), r: R(3, 5.5) });
        if (press) this.splash(x, Math.min(y, 590), 2.2);
      } else if (st === 'liquid') {
        if (!this.cols) this.cols = [...Array(97)].map(() => ({ h: 0, v: 0 }));
        const c = Math.round((x / (W / k)) * 96);
        for (let d = -2; d <= 2; d++) { const col = this.cols[c + d]; if (col) col.v -= (press ? 26 : 9) * p * (dir >= 0 ? 1 : 0.6) * (1 - Math.abs(d) * 0.2); }
        if (press) for (let i = 0; i < 14; i++) this.bits.push({ x: x + R(-40, 40), y: 600 - this.level(), vx: R(-5, 5), vy: -R(5, 11), a: 1 });
      } else if (st === 'curtain') {
        this.I = Math.min(press ? 1.6 : 1.15, this.I + (press ? 1.2 : 0.3) * p);
        if (!this.rays.length) for (let i = 0; i < 34; i++) this.rays.push({ u: R(-1, 1), w: R(10, 34), p: R(0, 6), c: i % 4, a: R(0.5, 1) });
        this.ox = x; this.wide = press ? 1 : this.wide;
      } else if (st === 'bars') {
        this.I = Math.min(1.5, this.I + (press ? 1 : 0.35)); this.kick = press ? 1 : Math.max(this.kick, 0.5 * p); this.ox = x;
      }
    },
    splash(x, y, big = 1) {
      for (let j = 0; j < 3; j++) this.rings.push({ x, y, r: 2, v: (2.2 - j * 0.45) * big, a: 0.9 - j * 0.2, d: j * 6 });
      for (let i = 0; i < 4 * big; i++) this.bits.push({ x, y, vx: R(-2.5, 2.5) * big, vy: -R(2, 5) * big, a: 0.9, small: true });
    },
    bead(x0, y0, r, a = 1) {
      x.save(); x.globalAlpha = a;
      const gr = x.createRadialGradient(x0, y0 + r * 0.3, 0, x0, y0, r);
      gr.addColorStop(0, 'rgba(255,255,255,.25)'); gr.addColorStop(0.7, 'rgba(160,190,230,.18)'); gr.addColorStop(1, 'rgba(0,0,0,.45)');
      x.fillStyle = gr; x.beginPath(); x.arc(x0, y0, r, 0, 6.283); x.fill();
      x.fillStyle = 'rgba(255,255,255,.95)'; x.beginPath(); x.arc(x0 - r * 0.3, y0 - r * 0.35, r * 0.28, 0, 6.283); x.fill();
      x.restore();
    },
    frame(st, t, accent, cols) {
      const k = this.k(), SW = W / k, SH = 600;
      x.save(); x.scale(k, k);
      const idle = (performance.now() - this.last) / 1000;
      if (st === 'rain') {
        for (let i = this.drops.length - 1; i >= 0; i--) {
          const d = this.drops[i];
          d.vy += 0.42; d.x += d.vx; d.y += d.vy;
          x.strokeStyle = 'rgba(200,225,255,.35)'; x.lineWidth = d.r * 0.8; x.lineCap = 'round';
          x.beginPath(); x.moveTo(d.x - d.vx * 1.6, d.y - d.vy * 1.6); x.lineTo(d.x, d.y); x.stroke();
          this.bead(d.x, d.y, d.r);
          if (d.vy > 0 && d.y >= d.land) { this.splash(d.x, d.y); this.drops.splice(i, 1); }
        }
        for (let i = this.rings.length - 1; i >= 0; i--) {
          const r = this.rings[i];
          if (r.d > 0) { r.d--; continue; }
          r.r += r.v * 2.2; r.v *= 0.985; r.a *= 0.955;
          if (r.a < 0.02) { this.rings.splice(i, 1); continue; }
          x.lineWidth = 2;
          x.strokeStyle = `rgba(235,245,255,${r.a * 0.75})`;
          x.beginPath(); x.ellipse(r.x, r.y, r.r, r.r * 0.32, 0, Math.PI, 6.283); x.stroke();
          x.strokeStyle = hexA(accent, r.a * 0.9); x.shadowColor = accent; x.shadowBlur = 10;
          x.beginPath(); x.ellipse(r.x, r.y, r.r, r.r * 0.32, 0, 0, Math.PI); x.stroke(); x.shadowBlur = 0;
        }
      } else if (st === 'liquid' && this.cols) {
        const on = idle < 1.6 ? 1 : 0;
        this.alpha += (on - this.alpha) * (on ? 0.2 : 0.05);
        const cs = this.cols, n = cs.length;
        for (let it = 0; it < 2; it++) {
          for (const c of cs) { c.v += -c.h * 0.02; c.v *= 0.985; c.h += c.v * 0.5; }
          for (let j = 0; j < n; j++) { const l = cs[j - 1] || cs[j], r = cs[j + 1] || cs[j]; cs[j].v += (l.h + r.h - 2 * cs[j].h) * 0.18; }
        }
        if (this.alpha > 0.01) {
          const base = SH - this.level(), step = SW / (n - 1), a = this.alpha;
          const ys = cs.map((c, j) => base + c.h + Math.sin(t * 2 + j * 0.25) * 2.5);
          const path = () => { x.beginPath(); x.moveTo(0, ys[0]); for (let j = 1; j < n; j++) x.quadraticCurveTo((j - 1) * step, ys[j - 1], (j - 0.5) * step, (ys[j - 1] + ys[j]) / 2); x.lineTo(SW, ys[n - 1]); };
          path(); x.lineTo(SW, SH); x.lineTo(0, SH); x.closePath();
          const gr = x.createLinearGradient(0, base - 30, 0, SH);
          gr.addColorStop(0, hexA(accent, 0.42 * a)); gr.addColorStop(0.5, hexA(cols[1], 0.22 * a)); gr.addColorStop(1, hexA(cols[0], 0.35 * a));
          x.fillStyle = gr; x.fill();
          path(); x.strokeStyle = `rgba(240,248,255,${0.85 * a})`; x.lineWidth = 2.5; x.shadowColor = accent; x.shadowBlur = 18; x.stroke(); x.shadowBlur = 0;
          if (Math.random() < 0.3 * a) this.bits.push({ x: R(0, SW), y: SH - 4, vx: 0, vy: -R(0.6, 1.6), a: 0.7, bubble: true, r: R(1.5, 4) });
        }
      } else if (st === 'curtain') {
        this.I *= 0.955;
        if (this.I > 0.01) {
          x.globalCompositeOperation = 'lighter';
          const ox = this.ox ?? SW / 2, spread = this.wide ? 520 : 170 + shown * 3.2;
          const top = SH - SH * (0.22 + 0.6 * shown / 100) * Math.min(1, 0.4 + this.I), I = Math.min(1, this.I);
          for (const r of this.rays) {
            const x0 = ox + r.u * spread, sway = Math.sin(t * 1.4 + r.p) * 26, c = [accent, cols[1], cols[2], accent][r.c];
            const gr = x.createLinearGradient(0, SH, 0, top);
            gr.addColorStop(0, hexA(c, I * 0.3 * r.a)); gr.addColorStop(0.55, hexA(c, I * 0.1 * r.a)); gr.addColorStop(1, hexA(c, 0));
            x.fillStyle = gr;
            x.beginPath(); x.moveTo(x0 - r.w / 2, SH); x.lineTo(x0 + r.w / 2, SH); x.lineTo(x0 + sway + r.w * 0.9, top); x.lineTo(x0 + sway - r.w * 0.9, top); x.closePath(); x.fill();
          }
          const glow = x.createRadialGradient(ox, SH, 0, ox, SH, 260);
          glow.addColorStop(0, hexA(accent, 0.35 * I)); glow.addColorStop(1, hexA(accent, 0));
          x.fillStyle = glow; x.fillRect(0, SH - 260, SW, 260);
          x.globalCompositeOperation = 'source-over';
        } else this.wide = 0;
      } else if (st === 'bars') {
        this.I *= idle < 1.4 ? 0.985 : 0.93;
        this.kick *= 0.9;
        if (this.I > 0.01) {
          const ox = this.ox ?? SW / 2, nb = 40, bw = SW / (nb * 2), lit = (shown / 100) * nb;
          x.globalAlpha = Math.min(1, this.I);
          for (let i = 0; i < nb; i++) for (const side of [-1, 1]) {
            const bx = ox + side * (i + 0.5) * bw - bw * 0.35, on = i < lit;
            const h = 10 + (on ? (18 + Math.sin(t * 9 + i * 0.7) * 6 + this.kick * 60 * Math.max(0, 1 - i / nb)) * (1 - i / nb * 0.5) : 0);
            x.fillStyle = on ? (i / nb > 0.8 ? cols[2] : accent) : 'rgba(255,255,255,.12)';
            if (on) { x.shadowColor = x.fillStyle; x.shadowBlur = 12; }
            x.beginPath(); x.roundRect ? x.roundRect(bx, SH - 10 - h, bw * 0.7, h, 3) : x.rect(bx, SH - 10 - h, bw * 0.7, h); x.fill(); x.shadowBlur = 0;
          }
          x.globalAlpha = 1;
        }
      }
      const surface = SH - this.level();
      for (let i = this.bits.length - 1; i >= 0; i--) {
        const b = this.bits[i];
        b.x += b.vx; b.y += b.vy;
        if (b.bubble) { b.x += Math.sin(b.y * 0.05) * 0.3; if (b.y < surface + 4 || st !== 'liquid') b.a = 0; x.strokeStyle = `rgba(240,248,255,${b.a * this.alpha})`; x.lineWidth = 1.2; x.beginPath(); x.arc(b.x, b.y, b.r, 0, 6.283); x.stroke(); }
        else { b.vy += 0.35; b.a *= 0.96; this.bead(b.x, b.y, b.small ? 1.6 : 3, b.a); }
        if (b.a < 0.03 || b.y > SH + 10) this.bits.splice(i, 1);
      }
      x.restore();
    },
  };
  const NEO = new Set(['rain', 'liquid', 'curtain', 'bars']);

  function draw(f, accent, b2) {
    f.age++;
    x.save();
    if (f.kind === 'ring') {
      f.r += f.v * DPR; f.a *= f.fade;
      x.globalAlpha = f.a; x.strokeStyle = f.white ? '#fff' : accent; x.shadowColor = accent; x.shadowBlur = 18 * DPR;
      x.lineWidth = f.w * DPR * (0.4 + f.a);
      x.beginPath(); x.arc(f.x, f.y, f.r, 0, 6.283); x.stroke();
    } else if (f.kind === 'bloom') {
      f.r += f.v * DPR; f.a *= f.fade;
      const gr = x.createRadialGradient(f.x, f.y, 0, f.x, f.y, f.r);
      gr.addColorStop(0, accent); gr.addColorStop(0.45, b2); gr.addColorStop(1, 'rgba(0,0,0,0)');
      x.globalAlpha = f.a * 0.55; x.globalCompositeOperation = 'lighter';
      x.fillStyle = gr; x.beginPath(); x.arc(f.x, f.y, f.r, 0, 6.283); x.fill();
    } else if (f.kind === 'spark') {
      f.x += f.vx * DPR; f.y += f.vy * DPR; f.vy += 0.06; f.vx *= 0.985; f.vy *= 0.985; f.a *= 0.965;
      x.globalAlpha = f.a; x.globalCompositeOperation = 'lighter';
      x.strokeStyle = f.white ? '#fff' : accent; x.lineWidth = 2.2 * DPR; x.lineCap = 'round';
      x.shadowColor = accent; x.shadowBlur = 10 * DPR;
      x.beginPath(); x.moveTo(f.x, f.y); x.lineTo(f.x - f.vx * 3 * DPR, f.y - f.vy * 3 * DPR); x.stroke();
    } else if (f.kind === 'flash') {
      f.a *= 0.88;
      x.globalAlpha = f.a; x.fillStyle = f.col; x.fillRect(0, 0, W, H);
    }
    x.restore();
  }

  function frame(now) {
    x.clearRect(0, 0, W, H);
    const accent = css('--accent', '#5EEAD4'), b2 = css('--b2', '#7C3AED');
    shown += (vol - shown) * 0.22;
    const idle = (now - lastTurn) / 1000;
    edgeA = idle < 1.2 && g('ripple_edge') !== false ? Math.min(1, edgeA + 0.15) : Math.max(0, edgeA - 0.04);
    edge(shown / 100, edgeA, accent);
    fx = fx.filter((f) => f.a > 0.01);
    fx.forEach((f) => draw(f, accent, b2));
    const st = style();
    if (NEO.has(st)) neo.frame(st, now / 1000, accent, [b2, css('--b3', '#0EA5E9'), css('--b1', '#14B8A6')]);
    if (fx.length || edgeA > 0.01 || (NEO.has(st) && neo.busy())) requestAnimationFrame(frame); else { running = false; x.clearRect(0, 0, W, H); }
  }
  function kick() { if (!running) { running = true; requestAnimationFrame(frame); } }

  function sparks(ox, oy, n, speed, white) {
    for (let i = 0; i < n; i++) {
      // fan out away from the edge the knob sits on
      const up = oy >= H - 2 ? -1 : 0;
      const a = up ? -Math.PI / 2 + (Math.random() - 0.5) * 2.4 : Math.random() * 6.283;
      const v = speed * (0.5 + Math.random());
      fx.push({ kind: 'spark', x: ox, y: oy, vx: Math.cos(a) * v, vy: Math.sin(a) * v, a: 1, age: 0, white: white && i % 3 === 0 });
    }
  }

  function burst(ox, oy, up, press) {
    const st = style(), p = amt();
    if (st === 'off') return;
    if (st === 'waves') {
      fx.push({ kind: 'ring', x: ox, y: oy, r: press ? 10 : 0, v: (press ? 26 : up ? 16 : 11) * p, a: press ? 1 : up ? 0.85 : 0.6, fade: 0.958, w: press ? 10 : up ? 6 : 4, white: press, age: 0 });
      if (press) fx.push({ kind: 'ring', x: ox, y: oy, r: 0, v: 18 * p, a: 0.8, fade: 0.95, w: 5, age: 0 });
    } else if (st === 'shock') {
      if (press || fx.filter((f) => f.kind === 'ring').length < 2) {
        fx.push({ kind: 'ring', x: ox, y: oy, r: 0, v: 34 * p, a: 1, fade: 0.94, w: press ? 16 : 11, white: press, age: 0 });
        fx.push({ kind: 'flash', a: press ? 0.22 : 0.1, col: press ? '#ffffff' : css('--accent', '#5EEAD4') });
      }
    } else if (st === 'aurora') {
      fx.push({ kind: 'bloom', x: ox, y: oy, r: 40, v: (press ? 30 : 18) * p, a: press ? 1 : 0.7, fade: 0.965, age: 0 });
    } else if (st === 'sparks') {
      sparks(ox, oy, Math.round((press ? 70 : up ? 22 : 12) * p), press ? 14 : 9, press);
    } else if (NEO.has(st)) {
      neo.turn(st, ox, oy, up ? 1 : -1, press);
    }
    // panels only react to a press, never to turning the volume (that made every panel flash)
    if (press && st !== 'edge') hitPanels(ox, oy, press, st === 'shock' ? 0.3 : 0.55);
    kick();
  }

  window.knobFx = function (m) {
    if (style() === 'off') return;
    const [ox, oy] = origin();
    if (m.act === 'press') return burst(ox, oy, true, true);
    vol = m.vol; lastTurn = performance.now();
    if (shown === 0) shown = vol;
    burst(ox, oy, m.dir > 0, false);
    if (g('ripple_hud') !== false) {
      hud.querySelector('.vh-num').textContent = vol;
      hud.querySelector('.vh-ic').innerHTML = ico('vol', 30);
      hud.querySelector('.vh-bar i').style.width = `${vol}%`;
      hud.dataset.kind = m.kind || 'volume';
      hud.classList.add('show');
      clearTimeout(hudTimer);
      hudTimer = setTimeout(() => hud.classList.remove('show'), 1300);
    }
    kick();
  };
})();
