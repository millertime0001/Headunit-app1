/* 3D worlds: driving and city scenes (see world3d.js for the shared uniforms and helpers).
   All scenes light in linear space, tone-map with aces() and gamma-encode at the end.
   Theme colors are used through hue() (full-brightness version of a theme color) so dark and light themes
   both give usable light colors; lightTheme() switches scenes to a soft daylight/dawn look. */
'use strict';

// Shared helpers for this file (prepended to every scene below).
const DRV_LIB = `
float lum(vec3 c){ return dot(c, vec3(.2126, .7152, .0722)); }
vec3 hue(vec3 c){ return c / max(max(c.r, max(c.g, c.b)), 1e-3); }      // theme color at full brightness
vec3 desat(vec3 c, float s){ return mix(vec3(lum(c)), c, s); }
float lightTheme(){ return smoothstep(.25, .55, lum(uBase)); }
vec3 finish(vec3 c){ return pow(aces(c), vec3(.4545)); }                   // tone map + gamma
// pinhole camera: forward f, right r, up u, focal length fl
struct Cam { vec3 o, f, r, u; float fl; };
Cam lookCam(vec3 o, vec3 f, float fl){ Cam c; c.o = o; c.f = normalize(f); c.r = normalize(cross(vec3(0, 1, 0), c.f));
  c.u = cross(c.f, c.r); c.fl = fl; return c; }
vec3 camRay(Cam c, vec2 uv){ return normalize(c.f * c.fl + c.r * uv.x + c.u * uv.y); }
// world point -> screen uv (same units as uv); z = depth along the view axis
vec2 proj(Cam c, vec3 p, out float z){ vec3 q = p - c.o; z = dot(q, c.f); return vec2(dot(q, c.r), dot(q, c.u)) / max(z, 1e-3) * c.fl; }
// GGX highlight of a point light (returns the specular factor, light color applied by the caller)
float ggx(vec3 n, vec3 v, vec3 l, float a){ vec3 h = normalize(l + v); float nh = max(dot(n, h), 0.), a2 = a * a;
  float d = nh * nh * (a2 - 1.) + 1.; return a2 / (PI * d * d) * max(dot(n, l), 0.) / (4. * max(dot(n, v), .08) * max(dot(n, l), .08)); }
// ray vs axis-aligned box (center c, half size b): returns t (or -1) and the normal
float boxHit(vec3 ro, vec3 rd, vec3 c, vec3 b, out vec3 n){ vec3 m = 1. / rd, k = abs(m) * b, q = m * (ro - c);
  vec3 t1 = -q - k, t2 = -q + k; float tn = max(max(t1.x, t1.y), t1.z), tf = min(min(t2.x, t2.y), t2.z);
  if (tn > tf || tf < 0.) return -1.; n = -sign(rd) * step(t1.yzx, t1.xyz) * step(t1.zxy, t1.xyz); return tn; }
`;

Object.assign(WORLDS, {
  nightdrive: ['Night drive', 'Wet highway at night, street lights rushing past, a city on the horizon', 2, DRV_LIB + `
float roadX(float z){ return 16. * sin(z * .0021) + 7. * sin(z * .0053 + 1.3); }   // the highway bends gently
const float SP = 34., LH = 8., LX = 6.9;          // lamp spacing, height, head offset from the road center
float rbox(vec3 p, vec3 b, float r){ vec3 q = abs(p) - b + r; return length(max(q, 0.)) + min(max(q.x, max(q.y, q.z)), 0.) - r; }
float carSd(vec3 p){                         // a sedan: rounded body + cabin, local coords (rear bumper at z=0)
  float body = rbox(p - vec3(0., .6, 2.25), vec3(.9, .32, 2.25), .16);
  vec3 q = p - vec3(0., 1.12, 2.45); q.x *= 1. + q.y * .9; q.z *= 1. + q.y * 1.2;
  float cab = rbox(q, vec3(.72, .2, 1.15), .2);
  float k = .12, h = clamp(.5 + .5 * (cab - body) / k, 0., 1.);
  return mix(cab, body, h) - k * h * (1. - h); }
vec3 lampCol(){ return mix(vec3(1., .62, .32), hue(uAcc), .55); }
// sky + distant city, by view direction
vec3 skyCol(vec3 rd, float lt){
  vec3 glow = mix(vec3(1., .55, .3), hue(uC1), .5);
  float hz = exp(-max(rd.y, 0.) * 9.);
  vec3 c = mix(vec3(.0015, .002, .004) + hue(uC2) * .003, glow * .035 + hue(uC2) * .008, hz);
  vec3 day = mix(desat(uBase, .6) * .55, hue(uC2) * .12 + uBase * .25, smoothstep(.0, .5, rd.y));
  return mix(c, day, lt);
}
vec3 scene(vec2 fc){
  vec2 uv = (fc - .5 * R) / R.y;
  float lt = lightTheme(), on = 1. - .75 * lt;     // lamps are dimmer in the daylight variant
  float v = 22. + 26. * uSpeed, zc = T * v;
  vec3 ro = vec3(roadX(zc) + .25 * uCam.x, 1.25 + .08 * uCam.y, zc);
  Cam cam = lookCam(ro, vec3(roadX(zc + 30.) - roadX(zc) + uCam.x * .8, -.55 + uCam.y * .4, 30.), 1.45);
  vec3 rd = camRay(cam, uv), lc = lampCol() * on;
  vec3 col = skyCol(rd, lt);
  float px = 1. / R.y;

  // low clouds lit from below by the city
  if (rd.y > 0.) {
    vec2 cp = rd.xz / (rd.y + .06) * .5 + vec2(0., zc * .0006);
    float cl = noise(cp) * .65 + noise(cp * 2.3) * .35;
    col += mix(vec3(1., .55, .3), hue(uC1), .5) * .03 * smoothstep(.35, .85, cl) * exp(-rd.y * 5.) * (1. - lt * .7);
  }
  // skyline far ahead: two layers of towers with lit windows
  float ax = atan(rd.x, rd.z);
  for (int L = 0; L < 2; L++) {
    float fl = float(L), k = 60. - fl * 22.;
    float a = ax * k + fl * 13.3, id = floor(a), f = fract(a);
    float env = exp(-pow((ax - .05) * (2.4 - fl * .6), 2.));             // downtown is straight ahead
    float hb = (.004 + .05 * pow(h11(id * 1.37 + fl), 2.2) * env) * (1. + fl * .6);
    float w = .2 + .25 * h11(id * 3.1 + 7.);
    if (env > .02 && rd.y < hb && rd.y > -.02 && abs(f - .5) < .5 - w * .5) {
      vec3 bc = mix(col, vec3(.004, .005, .008) + hue(uC2) * .003, .85 - fl * .1) * (1. - lt * .3);
      if (lt > .5) bc = mix(col, desat(uBase, .4) * .32, .7 - fl * .2);
      vec2 wc = vec2(a * 6., rd.y * k * 7.);
      vec2 wi = floor(wc), wf = fract(wc);
      float lit = step(.62, h21(wi + id * 9.1)) * step(.25, wf.x) * step(.3, wf.y) * step(wf.x, .8) * step(wf.y, .8);
      vec3 wcol = mix(vec3(1., .7, .4), hue(h21(wi) > .5 ? uC1 : uC3), .5);
      bc += wcol * lit * .08 * (1. - fl * .3) * on;
      // red aircraft lights on the tallest towers
      if (hb > .045 && h11(id) > .4) bc += vec3(1., .05, .02) * smoothstep(.006, .0, length(vec2((f - .5) / k, rd.y - hb + .002))) * (.5 + .5 * sin(T * 3. + id)) * .6;
      col = bc;
    }
  }

  float t = 1e9;
  if (rd.y < 0.) {
    t = -ro.y / rd.y;
    vec3 p = ro + rd * t;
    float rx = p.x - roadX(p.z);
    // ---- surface: asphalt, puddles, lane paint
    float wet = smoothstep(.36, .6, noise(p.xz * vec2(.35, .12)) * .7 + noise(p.xz * 1.3) * .3);
    float grain = noise(p.xz * 6.);
    vec3 alb = vec3(.035 + .02 * grain) * (1. + lt);
    float rough = mix(.5, .07, wet);
    float fw = max(fwidth(rx), .002);
    float dash = smoothstep(.5, .47, abs(fract(p.z / 12.) - .5) * 2. - .3);
    float paint = smoothstep(.09 + fw, .09 - fw, abs(abs(rx) - 1.8)) * dash
                + smoothstep(.1 + fw, .1 - fw, abs(abs(rx) - 5.5));
    paint *= smoothstep(260., 40., t) * (.6 + .4 * grain);                // worn, and fades in the distance
    alb = mix(alb, vec3(.55, .53, .48), paint);
    rough = mix(rough, .45, paint);
    float verge = smoothstep(6.3, 7., abs(rx));                           // dark ground beside the road
    alb = mix(alb, vec3(.02, .025, .02) * (1. + 3. * lt), verge);
    rough = mix(rough, .7, verge);
    // drizzle ripples tilt the normal a little where it's wet
    vec2 rp = vec2(noise(p.xz * 3. + T * 2.), noise(p.xz * 3. - T * 2. + 9.)) - .5;
    vec3 n = normalize(vec3(rp.x * .06, 1., rp.y * .06));
    vec3 vv = -rd, c = alb * .015;
    // ---- street lights (two rows, staggered): diffuse pools + glossy reflections
    float zr = zc + (p.z - zc) * (ro.y + LH) / ro.y;                       // where the mirror image lamp lives
    for (int s = 0; s < 2; s++) {
      float sd = float(s) * 2. - 1., off = float(s) * SP * .5;
      float fd = (p.z - off) / SP, fs = (zr - off) / SP;
      for (int j = 0; j < 6; j++) {
        // 3 lamps around the point (pools) and 3 around its mirror spot (reflections), tent-weighted: no seams
        float f = j < 3 ? fd : fs, kz = floor(f + .5) + float(j - (j < 3 ? 1 : 4));
        float wt = clamp(1.5 - abs(kz - f), 0., 1.);
        float lz = kz * SP + off;
        vec3 lp = vec3(roadX(lz) + sd * LX, LH, lz);
        vec3 ld = lp - p; float d2 = dot(ld, ld); vec3 l = ld * inversesqrt(d2);
        float att = 140. / d2 * wt;
        if (j < 3) c += alb * lc * att * max(dot(n, l), 0.) * .25;        // light pool
        else c += lc * att * ggx(n, vv, l, rough) * .35 * (1. - paint * .7) * mix(.25, 1., wet); // reflection streak
      }
    }
    // ---- sky / city glow reflected by the wet road (Fresnel)
    vec3 rr = reflect(rd, n);
    float fr = .04 + .96 * pow(1. - max(dot(n, vv), 0.), 5.);
    c += skyCol(rr, lt) * fr * mix(.6, 1.3, wet) * (1. - verge * .8);
    col = c;
    // dark tyre-shadow under the car ahead is added below with the car
  }

  // ---- car ahead (same lane, drifting a little), modern tail-light bar
  float zcar = zc + 24. + 5. * sin(T * .11), xcar = roadX(zcar) + .35 * sin(T * .23);
  vec3 cb = vec3(xcar, 0., zcar);
  vec3 tl1 = cb + vec3(-.68, .82, -.02), tl2 = cb + vec3(.68, .82, -.02);
  if (rd.y < 0.) {                                                         // its contact shadow + tail light reflections
    vec3 p = ro + rd * t;
    vec2 q = abs(p.xz - cb.xz - vec2(0., 2.2)) - vec2(.85, 2.2);
    col *= mix(1., smoothstep(-.4, .5, length(max(q, 0.)) + min(max(q.x, q.y), 0.)), .9);
    vec3 n = vec3(0, 1, 0);
    for (int i = 0; i < 2; i++) { vec3 ld = (i == 0 ? tl1 : tl2) - p; float d2 = dot(ld, ld);
      col += vec3(1., .04, .02) * 9. / d2 * ggx(n, -rd, ld * inversesqrt(d2), .13); }
  }
  {
    vec3 n1;
    float t1 = boxHit(ro, rd, cb + vec3(0., .75, 2.25), vec3(1., .75, 2.4), n1);    // bounding box, then trace the shape
    if (t1 > 0. && t1 < t) {
      float tt = t1; t1 = -1.;
      for (int i = 0; i < 28; i++) { float d = carSd(ro + rd * tt - cb); if (d < .004) { t1 = tt; break; } tt += d; if (tt > t) break; }
      if (t1 > 0.) { vec3 p = ro + rd * t1 - cb; vec2 e = vec2(.01, -.01);
        n1 = normalize(e.xyy * carSd(p + e.xyy) + e.yyx * carSd(p + e.yyx) + e.yxy * carSd(p + e.yxy) + e.xxx * carSd(p + e.xxx)); }
    }
    if (t1 > 0. && t1 < t) {
      t = t1;
      vec3 p = ro + rd * t1, lp = p - cb;
      float fr = .05 + .95 * pow(1. - abs(dot(n1, rd)), 5.);
      vec3 c = vec3(.004) + skyCol(reflect(rd, n1), lt) * fr * .8;
      c += lc * .02 * max(n1.y, 0.);                                       // lamp sheen on roof
      if (n1.z < -.3) {                                                    // rear face
        float glass = smoothstep(.98, 1.02, lp.y);
        c = mix(c, vec3(.01) + skyCol(reflect(rd, n1), lt) * .25, glass);
        float bar = smoothstep(.06, .04, abs(lp.y - .82)) * smoothstep(.88, .84, abs(lp.x));
        float lamp = smoothstep(.1, .07, abs(lp.y - .82)) * smoothstep(.88, .84, abs(lp.x)) * step(.5, abs(lp.x));
        c += vec3(1., .05, .02) * (bar * 2.5 + lamp * 5.) * (.9 + .2 * uBeat);
        c += vec3(.8, .75, .6) * .3 * step(abs(lp.x), .25) * step(abs(lp.y - .5), .08);   // plate
      }
      col = c;
    }
    // bloom around the tail lights
    float z1, z2; vec2 s1 = proj(cam, tl1, z1), s2 = proj(cam, tl2, z2);
    float g = .0009 / (dot(uv - s1, uv - s1) + .0006) + .0009 / (dot(uv - s2, uv - s2) + .0006);
    col += vec3(1., .06, .03) * g * .12 * step(0., z1) * on;
  }

  // ---- lamp posts and their glowing heads (drawn over the scene, nearest last doesn't matter: additive glow)
  for (int s = 0; s < 2; s++) {
    float sd = float(s) * 2. - 1., off = float(s) * SP * .5;
    float k0 = floor((zc - off) / SP) + 1.;
    for (int j = 0; j < 11; j++) {
      float lz = (k0 + float(j)) * SP + off;
      float rx0 = roadX(lz);
      vec3 head = vec3(rx0 + sd * LX, LH, lz), top = vec3(rx0 + sd * (LX + 1.6), LH + .35, lz), base = vec3(top.x, 0., lz);
      float zh, zt, zb;
      vec2 sh = proj(cam, head, zh), st = proj(cam, top, zt), sb = proj(cam, base, zb);
      if (zh < 1.) continue;
      float fog = exp(-zh * .006);
      float pw = max(.12 * cam.fl / zt, px * .6);
      // pole (vertical) + arm (segment from pole top to the head)
      vec2 pa = uv - st, ba = sb - st; float hh = clamp(dot(pa, ba) / dot(ba, ba), 0., 1.);
      float dp = length(pa - ba * hh);
      vec2 pa2 = uv - st, ba2 = sh - st; float h2 = clamp(dot(pa2, ba2) / dot(ba2, ba2), 0., 1.);
      float da = length(pa2 - ba2 * h2);
      float pole = smoothstep(pw + px, pw - px * .5, min(dp, da * 1.4));
      if (zt < t) col = mix(col, mix(skyCol(rd, lt), vec3(.006 + lt * .1) + lc * .004, fog), pole);
      // glowing head: small hot core + soft halo in the drizzle
      float r2 = dot(uv - sh, uv - sh), sz = 1. / zh;
      float core = smoothstep(.45 * sz * sz, 0., r2 * 6.) * 4.;
      float halo = sz * .02 / (r2 + sz * .002) + .0006 / (r2 + .0035);
      col += lc * (core + halo * .5) * fog * step(zh, t + 2.);
    }
  }
  // haze: distance fog towards the city glow
  if (t < 1e8) col = mix(col, skyCol(vec3(rd.x, .03, rd.z), lt) * .8, 1. - exp(-t * .0035));
  return finish(col * (1. + .15 * uBeat * on));
}`],
  canyon: ['Synthwave canyon', 'Flying low through a neon wireframe canyon toward a striped retro sun', 2, DRV_LIB + `
float pathX(float z){ return 9. * sin(z * .011) + 4. * sin(z * .027 + 2.); }
float ridge(vec2 p){ float n = noise(p); return 1. - abs(2. * n - 1.); }
float hgt(vec2 p){                                   // wide flat valley floor between ridged mountains
  float ax = abs(p.x - pathX(p.y));
  float wall = smoothstep(7., 30., ax);
  float r = ridge(p * .045) * .6 + ridge(p * .11 + 3.1) * .3 + noise(p * .4) * .1;
  return wall * (1.5 + 15. * r * r);
}
const vec3 SUN = vec3(0., .14, 1.);
vec3 skyCol(vec3 rd, float lt, bool sun){
  vec3 hz = mix(hue(uC1), hue(uAcc), .25), top = hue(uC2);
  float y = rd.y;
  vec3 c = mix(hz * .07, top * .006, smoothstep(-.02, .35, y)) + hz * .12 * exp(-abs(y) * 25.);
  vec3 day = mix(mix(uBase, hue(uC1), .25) * .75, mix(uBase, hue(uC2), .35) * .5, smoothstep(0., .5, y));
  c = mix(c, day, lt);
  vec2 sp = rd.xy / rd.z - SUN.xy / SUN.z;            // the sun, in screen-ish units
  float r = length(sp);
  c += hz * (.08 * exp(-r * 5.) + .025 * exp(-r * 1.5)) * (1. + .5 * uBeat) * (1. - .6 * lt);
  if (sun) {
    float aa = 1.5 / R.y;
    float disc = smoothstep(.18 + aa, .18 - aa, r);
    float yy = (sp.y + .18) / .36;                      // 0 at the bottom of the sun, 1 at the top
    float gap = .01 + .05 * (1. - yy);               // stripe gaps grow towards the bottom
    float st = fract(yy * 8. + T * .12);
    disc *= yy > .6 ? 1. : smoothstep(gap * 8. - aa * 8., gap * 8. + aa * 8., st);
    vec3 sc = mix(hue(uC1) * .7, hue(uAcc) * 1.3, smoothstep(.0, 1., yy));
    c = mix(c, mix(sc, sc * .6 + uBase * .5, lt), disc);
  }
  return c;
}
vec3 scene(vec2 fc){
  vec2 uv = (fc - .5 * R) / R.y;
  float lt = lightTheme();
  float z = T * (9. + 22. * uSpeed);
  float roll = (pathX(z + 12.) - 2. * pathX(z) + pathX(z - 12.)) * .06;
  uv *= rot(roll);
  vec3 ro = vec3(pathX(z) + uCam.x * 1.5, 1.7 + uCam.y * .35, z);
  Cam cam = lookCam(ro, vec3((pathX(z + 30.) - pathX(z)) / 30. - uCam.x * .02, -.03 + uCam.y * .02, 1.), 1.3);
  vec3 rd = camRay(cam, uv);
  vec3 col = skyCol(rd, lt, true);
  // stars, fading out near the horizon glow
  vec2 sg = rd.xy / (rd.z + 1.) * 70.;
  vec2 si = floor(sg), sf = fract(sg) - .5; float sh = h21(si);
  vec2 so = (h22(si) - .5) * .6;
  col += vec3(.9, .9, 1.) * step(.93, sh) * smoothstep(.14, 0., length(sf - so)) * smoothstep(.08, .4, rd.y)
       * (.5 + .5 * sin(T * 2. + sh * 60.)) * .9 * (1. - lt);
  // far mountain range (2D silhouette on the horizon) with a glowing rim
  float ang = atan(rd.x, rd.z), va = atan(pathX(z + 220.) - ro.x, 220.);   // va: where the valley heads
  float mh = .01 + .06 * (noise(vec2(ang * 7., 0.)) * .7 + noise(vec2(ang * 19., 3.)) * .3) * smoothstep(.03, .4, abs(ang - va));
  if (rd.y < mh) {
    vec3 mc = mix(hue(uC2) * .004, mix(uBase, hue(uC2), .3) * .6, lt);
    col = mix(mc, skyCol(rd, lt, false), .5) + mix(hue(uC1), hue(uC3), .3) * .25 * smoothstep(.004, 0., mh - rd.y) * (1. - lt * .5);
  }
  // terrain: march the height field
  float d = .5, dp = .5, hit = 0.;
  for (int i = 0; i < 50; i++) {
    vec3 p = ro + rd * d; float h = p.y - hgt(p.xz);
    if (h < 0.) { hit = 1.; break; }
    if (p.y > 17.5 && rd.y > 0.) break;                                  // above the highest peak
    dp = d; d += max(h * .75, .006 * d); if (d > 160.) break;
  }
  if (hit > .5) for (int i = 0; i < 5; i++) {                              // bisect for a stable hit (clean lines)
    float m = .5 * (d + dp); vec3 p = ro + rd * m;
    if (p.y < hgt(p.xz)) d = m; else dp = m;
  }
  else if (rd.y < 0.) { d = -ro.y / rd.y; hit = 1.; }                     // floor beyond the march range
  if (hit > .5) {
    vec3 p = ro + rd * d;
    vec2 e = vec2(.08, 0.);
    vec3 n = normalize(vec3(hgt(p.xz - e.xy) - hgt(p.xz + e.xy), 2. * e.x, hgt(p.xz - e.yx) - hgt(p.xz + e.yx)));
    // grid lines: anti-aliased, fade to their average brightness when they get thinner than a pixel
    vec2 q = p.xz / 2.5; vec2 fw = fwidth(q) + 1e-4;
    vec2 dpx = (.5 - abs(fract(q) - .5)) / fw;          // distance to the nearest line, in pixels
    float lw = .016, wpx = max(lw / max(fw.x, fw.y), .7);
    vec2 ln = (1. - smoothstep(wpx - .5, wpx + .7, dpx)) * min(lw / fw * 1.5, 1.);
    float line = max(ln.x, ln.y);
    float glow = (exp(-dpx.x * .35) * min(.03 / fw.x, 1.) + exp(-dpx.y * .35) * min(.03 / fw.y, 1.)) * .22;
    float up = smoothstep(.5, 8., p.y);
    vec3 nc = mix(hue(uC3), hue(uC1), up) * (1.6 + .8 * uBeat);
    vec3 face = mix(hue(uC2) * .004 + hue(uC1) * .003 * up, mix(uBase, hue(uC2), .25) * (.7 + .25 * n.y), lt);
    face += hue(uC1) * .02 * pow(max(dot(n, normalize(vec3(0., .3, 1.))), 0.), 2.) * (1. - lt);  // sunlit rims
    // glossy floor reflects the sun and sky
    float fl = 1. - smoothstep(.05, .8, p.y);
    vec3 rr = reflect(rd, n);
    face += skyCol(rr, lt, false) * fl * (.1 + .6 * pow(1. - max(dot(n, -rd), 0.), 4.)) * (1. - .6 * lt);
    vec3 tc = face + nc * (line + glow) * (1. - lt);
    tc = mix(tc, mix(uAcc, nc * .25, .3), line * lt);
    float fog = 1. - exp(-pow(d / 140., 2.) * 3.);
    col = mix(tc, skyCol(rd, lt, false), fog);
  }
  return finish(col);
}`],
  neoncity: ['Neon city', 'Gliding between skyscrapers at night: lit windows, neon signs, fog', 3, DRV_LIB + `
const float C = 20.;                                 // city block size; the avenue is the four blocks around x = 0
vec3 neon(float k){ return k < .33 ? hue(uC1) : k < .66 ? hue(uC3) : hue(uAcc); }
vec3 fogCol(vec3 rd, float lt){
  vec3 g = mix(hue(uC2) * .014, hue(uC1) * .02, .4) + vec3(.003, .002, .004);
  vec3 c = mix(g * 1.6, g * .25, smoothstep(-.3, .5, rd.y));
  return mix(c, mix(uBase, hue(uC2), .2) * mix(.85, .45, smoothstep(-.3, .6, rd.y)), lt);
}
// building in a cell: lower block + slimmer tower; returns hit t, normal, local hit info
void bldg(vec2 cell, vec3 ro, vec3 rd, inout float tb, inout vec3 nb, inout vec4 info){
  float h1 = h21(cell), h2 = h21(cell + 31.7), h3 = h21(cell + 7.3);
  vec2 cc = (cell + .5) * C;
  float hw = C * .5 - 2. - 2.5 * h1;
  float H = 25. + 190. * h2 * h2 * h2 + 30. * h3;
  vec3 n; float t;
  t = boxHit(ro, rd, vec3(cc.x, H * .3, cc.y), vec3(hw, H * .3, hw), n);
  if (t > 0. && t < tb) { tb = t; nb = n; info = vec4(cell, H * .6, hw); }
  float hw2 = hw * (.55 + .3 * h3);
  t = boxHit(ro, rd, vec3(cc.x, H * .5, cc.y), vec3(hw2, H * .5, hw2), n);
  if (t > 0. && t < tb) { tb = t; nb = n; info = vec4(cell, H, hw2); }
}
vec3 scene(vec2 fc){
  vec2 uv = (fc - .5 * R) / R.y;
  float lt = lightTheme(), on = 1. - .7 * lt;
  float z = T * (5. + 16. * uSpeed);
  vec3 ro = vec3(uCam.x * 6. + 8. * sin(z * .011), 48. + uCam.y * 6. + 6. * sin(z * .02), z);
  Cam cam = lookCam(ro, vec3(-uCam.x * .08 + .06 * sin(z * .009), -.05 + uCam.y * .04, 1.), 1.2);
  vec3 rd = camRay(cam, uv);
  float px = 1. / (R.y * cam.fl);                    // pixel angle
  // ---- walk the block grid (2D DDA), test the buildings in each block
  vec2 cell = floor(ro.xz / C), sg = sign(rd.xz), tD = abs(C / rd.xz);
  vec2 tM = ((cell + max(sg, 0.)) * C - ro.xz) / rd.xz;
  float tb = 1e9; vec3 nb = vec3(0); vec4 info = vec4(0);
  for (int i = 0; i < 44; i++) {
    if (abs(cell.x + .5) > 2.) bldg(cell, ro, rd, tb, nb, info);
    float tn = min(tM.x, tM.y);
    if (tb < tn) break;
    if (ro.y + rd.y * tn < 0. || ro.y + rd.y * tn > 260. || tn > 900.) break;
    if (tM.x < tM.y) { tM.x += tD.x; cell.x += sg.x; } else { tM.y += tD.y; cell.y += sg.y; }
  }
  vec3 col; float t = tb;
  if (tb < 1e8) {
    vec3 p = ro + rd * tb;
    vec2 bc = info.xy, cc = (bc + .5) * C;
    float u = dot(p.xz - cc, nb.zx * vec2(1., -1.)) ;   // across the facade
    float bh = h21(bc + 3.3);
    // windows: floors 3.4 m, columns 1.8 m; whole floors tend to be lit or dark (offices)
    vec2 wc = vec2(u / 1.8, p.y / 3.4), wi = floor(wc), wf = fract(wc);
    float foot = tb * px / 1.8;
    float frame = smoothstep(.04, .12, wf.x) * smoothstep(.96, .88, wf.x) * smoothstep(.18, .28, wf.y) * smoothstep(.9, .8, wf.y);
    float floorOn = step(.6, h21(vec2(wi.y, bc.x * 7. + bc.y)));
    float lit = step(mix(.9, .35, floorOn), h21(wi + bc * 13.1 + nb.xz * 5.));
    float curtain = step(bh, .3);                              // glass towers: lit bands per floor instead of windows
    frame = mix(frame, smoothstep(.2, .35, wf.y) * smoothstep(.95, .8, wf.y), curtain);
    lit = mix(lit, floorOn * (.4 + .6 * h21(vec2(wi.y, bc.y))), curtain);
    float flick = step(.997, h21(wi + floor(T * 2.)));
    float win = mix(frame * lit, .45 * (.5 - .25 * bh), smoothstep(.3, .8, foot));
    win *= .15 + 1.2 * pow(h21(wi.yx + bc), 2.);
    vec3 wcol = mix(vec3(1., .74, .45), vec3(.65, .82, 1.), step(.55, h21(vec2(wi.y, bc.x + bc.y * 3.))));
    wcol = mix(wcol, neon(h21(bc + 9.)), .3);
    vec3 glass = fogCol(reflect(rd, nb), lt) * (.3 + 1.2 * pow(1. - abs(dot(rd, nb)), 3.));
    vec3 wall = mix(vec3(.006, .006, .009) + hue(uC2) * .003, mix(uBase, hue(uC2), .2) * (.22 + .1 * nb.x), lt);
    col = wall * (nb.y > .5 ? 1.6 : 1.) * (1. + 2. * exp(-p.y * .03)) + glass;
    col += wcol * win * .35 * on * (1. - flick);
    col = mix(col, col * .35 + glass * .3, frame * smoothstep(.8, .3, foot) * lt);   // daylight: dark window glass
    // neon: corner strips and a crown band on some towers, a few big signs facing the avenue
    vec3 nc = neon(h21(bc + 5.1));
    float edge = info.w - abs(u);
    float ew = max(.35, tb * px * 1.2);
    if (bh > .72) col += nc * 2. * smoothstep(ew, ew * .3, edge) * on;
    col += nc * 1.6 * step(.55, h21(bc + 2.)) * smoothstep(.7, .3, abs(p.y - info.z + 2.)) * on;
    float facing = step(.5, -sign(cc.x) * nb.x);
    col += vec3(1., .05, .02) * 3. * step(info.z - p.y, .6) * step(edge, .6) * step(.5, sin(T * 2.5 + bh * 20.)) * step(120., info.z);           // facade facing the avenue
    vec2 sp = vec2((u - (h21(bc + 8.) - .5) * info.w) / 2.6, (p.y - 18. - 60. * bh) / 12.);
    if (facing > .5 && abs(sp.x) < .6 && abs(sp.y) < 1. && h21(bc + 4.4) > .35) {
      vec3 scol = neon(h21(bc + 6.6));
      vec2 gi = floor(sp * vec2(3., 8.) + vec2(0., floor(T * 1.5 + bh * 9.)));       // scrolling "glyphs"
      float gly = step(.45, h21(gi + bc));
      float border = 1. - step(abs(sp.x), .52) * step(abs(sp.y), .93);
      col = mix(col, scol * (.25 + 2.2 * max(gly * .8, border)) * (.85 + .3 * uBeat), on * .95);
    }
  } else if (rd.y < 0.) {
    // streets far below: the avenue with streams of head and tail lights
    t = -ro.y / rd.y; vec3 p = ro + rd * t;
    col = vec3(.004, .004, .005) * (1. + lt * 60.);
    float lane = fract(abs(p.x) / 3.2), side = sign(p.x);
    float car = step(.6, h21(vec2(floor(abs(p.x) / 3.2) + side * 9., floor((p.z - side * T * 14.) / 7.))));
    float dash = smoothstep(.5, .2, abs(fract((p.z - side * T * 14.) / 7.) - .5)) * smoothstep(.3, .1, abs(lane - .5));
    vec3 lc = side > 0. ? vec3(1., .08, .03) : vec3(1., .85, .6);
    col += lc * car * dash * step(abs(p.x), 13.) * .6 * on;
    col += hue(uC1) * .05 * smoothstep(1., 0., abs(abs(p.x) - 15.)) * on;     // sidewalk glow
  } else {
    // sky: city glow on low clouds
    vec2 cp = rd.xz / (rd.y + .15) * .6 + vec2(0., z * .002);
    float cl = noise(cp) * .6 + noise(cp * 2.5) * .4;
    col = fogCol(rd, lt) * (.6 + .9 * smoothstep(.3, .8, cl));
  }
  // ---- height fog: thicker towards the ground, lit by the streets
  float fd = min(t, 900.);
  float fogA = 1. - exp(-fd * (.0045 - .002 * lt) * (1. + 2. * exp(-max(ro.y + rd.y * fd * .5, 0.) * .02)));
  col = mix(col, fogCol(rd, lt), fogA);
  // ---- flying cars along the avenue (light points with soft glow)
  for (int i = 0; i < 6; i++) {
    float fi = float(i), lane = fi < 3. ? 1. : -1.;
    float cz = mod(fi * 61. + T * (14. + 10. * h11(fi)) * lane, 360.) - 60.;
    vec3 cp = vec3(lane * (5. + 4. * h11(fi + 3.)), 26. + 26. * h11(fi + 7.), floor(z / 360.) * 360. + cz);
    if (cp.z < z) cp.z += 360.;
    float zz; vec2 sp = proj(cam, cp, zz);
    if (zz > 1. && zz < t) {
      float r2 = dot(uv - sp, uv - sp);
      vec3 lc = lane > 0. ? vec3(1., .12, .06) : mix(vec3(1.), hue(uAcc), .3);
      col += lc * (.6 / zz * .00003 / (r2 + .00003) + .00004 / (r2 + .0006)) * exp(-zz * .006) * on;
    }
  }
  return finish(col * 1.1);
}`],
  tunnel: ['Highway tunnel', 'Driving through a long road tunnel, lights streaming overhead, daylight at the exit', 1, DRV_LIB + `
const float RAD = 6.3, YC = 1.1;                     // tunnel arch: circle radius and center height (road at y = 0)
const float SPC = 7., AL = .62;                      // light fixture spacing (m), angle of the two light rows
vec3 lampC(){ return mix(vec3(1., .6, .28), hue(uAcc), .5); }
vec3 exitC(float lt){ return mix(mix(vec3(1., .97, .9), hue(uC2), .3) * 3., mix(uBase, hue(uC2), .2) * 3., lt); }
vec2 rowPos(float s){ return vec2(0., YC) + (RAD - .15) * vec2(sin(s * AL), cos(s * AL)); }
// light from the two fixture rows seen along a ray: closest approach to each row -> glow (k = sharpness)
vec3 rowsGlow(vec3 o, vec3 d, float k, float blur, float tmax){
  vec3 acc = vec3(0);
  for (int i = 0; i < 2; i++) {
    vec2 L = rowPos(float(i) * 2. - 1.);
    vec2 w = o.xy - L; float dd = dot(d.xy, d.xy);
    float tr = clamp(-dot(w, d.xy) / max(dd, 1e-4), 0., tmax);   // ray parameter at the closest approach
    vec3 q = o + d * tr; float dist = length(q.xy - L);
    float f = abs(fract(q.z / SPC) - .5) * 2.;                     // 0 at a fixture center
    float on = smoothstep(.45 + blur, .45 - blur, f);
    acc += exp(-dist * k) * on * k;
  }
  return acc;
}
vec3 scene(vec2 fc){
  vec2 uv = (fc - .5 * R) / R.y;
  float lt = lightTheme();
  float v = 22. + 28. * uSpeed, zc = T * v;
  vec3 ro = vec3(1.85 + .3 * uCam.x, 1.3 + .08 * uCam.y, zc);
  Cam cam = lookCam(ro, vec3(-.03 * uCam.x - .04, -.02 + .02 * uCam.y, 1.), 1.3);
  vec3 rd = camRay(cam, uv);
  vec3 lc = lampC(), ec = exitC(lt);
  float blur = .02 + .25 * uSpeed;                                  // motion smear of the fixtures
  // ---- hit: road plane or the arch (inside of a circle in the xy plane)
  vec2 oc = ro.xy - vec2(0., YC);
  float a = dot(rd.xy, rd.xy), b = dot(oc, rd.xy), c = dot(oc, oc) - RAD * RAD;
  float t = (-b + sqrt(max(b * b - a * c, 0.))) / max(a, 1e-5);
  bool road = false;
  if (rd.y < 0.) { float tf = -ro.y / rd.y; if (tf < t) { t = tf; road = true; } }
  float zexit = zc + 300.;
  vec3 col;
  float te = (zexit - ro.z) / rd.z;
  if (te < t) {
    // the exit: bright daylight, slightly overexposed
    col = ec * (1. + .3 * smoothstep(.0, .3, rd.y));
    t = te;
  } else {
    vec3 p = ro + rd * t;
    vec3 n = road ? vec3(0., 1., 0.) : normalize(vec3(-p.x, YC - p.y, 0.));
    float ang = atan(p.x, p.y - YC);                                // 0 at the top of the arch
    float rough; vec3 alb; float emit = 0.;
    if (road) {
      float fw = fwidth(p.x) + .002;
      float dash = step(.5, fract(p.z / 9.));
      float paint = smoothstep(.08 + fw, .08 - fw, abs(p.x)) * dash + smoothstep(.09 + fw, .09 - fw, abs(abs(p.x) - 3.9));
      float grain = noise(p.xz * vec2(5., 2.));
      alb = mix(vec3(.04 + .02 * grain), vec3(.5, .48, .4), paint * smoothstep(300., 30., t));
      rough = mix(.2, .5, paint) + .1 * grain;
      // reflective road studs along the edge lines
      vec2 st = vec2(abs(abs(p.x) - 4.1), abs(fract(p.z / 12.) - .5) * 12.);
      emit = smoothstep(.12, .0, length(st)) * 2.;
      n = normalize(vec3((noise(p.xz * vec2(2., .5)) - .5) * .015, 1., 0.));
    } else {
      float aa = abs(ang);
      // glazed tiles on the lower walls, a dark soot band, painted concrete above
      float tile = step(p.y, 3.4);
      vec2 tq = vec2(p.z / .5, p.y / .25), tg = abs(fract(tq) - .5), tw = fwidth(tq);
      float joint = max(smoothstep(.45 - tw.x, .49, tg.x) * (1. - smoothstep(.06, .2, tw.x)),
                        smoothstep(.45 - tw.y, .49, tg.y) * (1. - smoothstep(.06, .2, tw.y)));
      vec3 tc = desat(mix(vec3(.75, .72, .62), hue(uC3), .3), .6) * (p.y < .9 ? .35 : 1.);   // darker kick band at the bottom
      alb = tile > .5 ? mix(tc, vec3(.12), joint)
                      : vec3(.1, .1, .105) * (.6 + .7 * noise(vec2(p.z * .04, aa * 4.)));
      alb *= 1. - .6 * smoothstep(3.3, 3.6, p.y) * smoothstep(4.4, 3.9, p.y);
      rough = tile > .5 ? .18 : .7;
      // fixtures: emissive panels on the light rows
      float fz = abs(fract(p.z / SPC) - .5) * 2.;
      float fx = min(abs(ang - AL), abs(ang + AL));
      emit = smoothstep(.06, .04, fx) * smoothstep(.47 + blur, .43 - blur, fz) * 12.;
    }
    // diffuse light from the two light rows (line lights, ~1/r), stronger near a fixture
    vec3 c = vec3(0);
    for (int i = 0; i < 2; i++) {
      vec2 L = rowPos(float(i) * 2. - 1.), dv = L - p.xy; float r = length(dv);
      float fz = abs(fract(p.z / SPC) - .5) * 2.;
      c += alb * lc * max(dot(n.xy, dv / r), 0.) / r * (.5 + .8 * smoothstep(.9, .2, fz) * smoothstep(5., 1., r)) * 1.4;
    }
    c += alb * ec * .03 * exp(-(zexit - p.z) * .01);                // daylight spilling in near the exit
    // glossy reflection of the light rows (and the exit)
    vec3 rr = reflect(rd, n);
    float fr = .04 + .96 * pow(1. - max(dot(n, -rd), 0.), 5.);
    float k = mix(40., 2.5, rough);
    vec3 refl = lc * rowsGlow(p, rr, k * .6, blur + rough * .3, 60.) * .35;
    refl += ec * exp((rr.z - 1.) * mix(900., 60., rough)) * .25;
    c += refl * mix(fr, 1., .25) * (road ? .8 : .6) * (road ? 1. - .8 * smoothstep(.3, .45, rough) : 1.);
    c += lc * emit;
    if (!road && abs(ang) > 2.2) {                                  // green LED markers along the walls
      float m = smoothstep(.12, .0, length(vec2(abs(fract(p.z / 25.) - .5) * 25., p.y - 1.)));
      c += mix(vec3(.1, 1., .4), hue(uC3), .3) * m * 3.;
    }
    col = c;
  }
  // ---- air: fixture glow in the haze, exit bloom, distance fog
  col += lc * rowsGlow(ro, rd, 3.5, blur, t) * .025;
  vec3 fogc = lc * .03 + ec * .02;
  col = mix(col, fogc, (1. - exp(-t * .006)) * .8);
  vec2 ep; float ez; ep = proj(cam, vec3(0., 3., zexit), ez);
  float er = length(uv - ep);
  col += ec * (.05 * exp(-er * 14.) + .00006 / (er * er + .0004)) * .6;
  // tail lights of a car ahead (two glows + their streaks on the road)
  vec3 tlp = vec3(1.9 + .2 * sin(T * .3), .8, zc + 45. + 8. * sin(T * .09));
  for (int i = 0; i < 2; i++) {
    vec3 q = tlp + vec3(float(i) * 1.4 - .7, 0., 0.);
    float z1; vec2 s1 = proj(cam, q, z1); vec2 d = uv - s1;
    col += vec3(1., .05, .02) * (.0005 / (dot(d, d) + .00012)) * .25;
    float z2; vec2 s2 = proj(cam, q * vec3(1., -1., 1.), z2); vec2 d2 = uv - s2;
    col += vec3(1., .05, .02) * .25 * exp(-abs(d2.x) * 300.) * smoothstep(.0, -.12, d2.y) * exp(d2.y * 8.) * step(uv.y, s1.y - .004);
  }
  return finish(col * .9);
}`],
  dusk: ['Desert dusk', 'Open desert highway at twilight: mesas, the last glow of sunset, first stars', 1, DRV_LIB + `
const vec2 SUND = vec2(.32, -.035);                  // sun direction (x, y per unit z): just set, right of the road
vec3 horizC(){ return mix(vec3(1., .42, .14), hue(uC1), .35); }
vec3 skyCol(vec3 rd, float lt){
  float y = rd.y, sx = rd.x / max(rd.z, .05) - SUND.x;
  float sun = exp(-length(vec2(sx, (y - SUND.y) * 1.6)) * 3.);        // glow around the hidden sun
  vec3 zen = hue(uC2) * .008 + vec3(.0015, .002, .006);
  vec3 mid = mix(vec3(.25, .08, .2), hue(uC2), .45) * .06;
  vec3 c = mix(mid, zen, smoothstep(.02, .45, y));
  c = mix(horizC() * .35, c, smoothstep(-.02, .14, y - sun * .05));
  c += horizC() * .55 * sun * exp(-max(y, 0.) * 10.);
  // daylight variant: soft hazy afternoon
  vec3 day = mix(mix(uBase, vec3(1., .85, .7), .25) * .9, mix(uBase, hue(uC2), .35) * .6, smoothstep(0., .5, y));
  return mix(c, day + horizC() * .1 * sun, lt);
}
// mesa skyline for one layer: flat tops, steep cliffs, talus slopes
float mesa(float a, float seed){
  float n = noise(vec2(a, seed)) * .75 + noise(vec2(a * 3.1, seed + 4.)) * .25;
  float top = smoothstep(.5, .53, n) * .55 + smoothstep(.67, .69, n) * .35;     // two tiers with cliffs
  return top + max(n - .3, 0.) * .45 + .02 * noise(vec2(a * 25., seed));             // talus slopes, a little erosion
}
vec3 scene(vec2 fc){
  vec2 uv = (fc - .5 * R) / R.y;
  float lt = lightTheme(), on = 1. - .8 * lt;
  float v = 24. + 26. * uSpeed, zc = T * v;
  vec3 ro = vec3(1.9 + .25 * uCam.x, 1.35 + .06 * uCam.y, zc);
  Cam cam = lookCam(ro, vec3(-.035 - .03 * uCam.x, -.035 + .025 * uCam.y, 1.), 1.35);
  vec3 rd = camRay(cam, uv);
  vec3 col = skyCol(rd, lt);
  float ang = atan(rd.x, rd.z);
  // stars and a thin layer of high clouds catching the last light
  if (rd.y > 0.) {
    vec2 sg = vec2(ang, rd.y) * 160.; vec2 si = floor(sg), sf = fract(sg) - .5;
    float sh = h21(si);
    col += vec3(.9, .92, 1.) * step(.95, sh) * smoothstep(.2, .0, length(sf - (h22(si) - .5) * .5))
         * smoothstep(.12, .45, rd.y) * (.6 + .4 * sin(T * 1.5 + sh * 50.)) * .5 * (1. - lt);
    vec2 cp = vec2(ang * 3., rd.y * 22.) + vec2(T * .004, 0.);
    float cl = smoothstep(.5, .85, noise(cp * vec2(1., 2.5)) * .7 + noise(cp * vec2(2.3, 6.)) * .3) * smoothstep(.02, .08, rd.y) * smoothstep(.35, .12, rd.y);
    vec3 ccol = mix(horizC() * .25, vec3(.04, .02, .05), smoothstep(.05, .3, rd.y)) * (1. + 3. * exp(-abs(rd.x / rd.z - SUND.x) * 2.));
    col = mix(col, mix(ccol, col * 1.2, lt), cl * .8);
  }
  // three mesa ranges, far to near: hazier and lighter with distance (aerial perspective)
  for (int L = 0; L < 3; L++) {
    float fl = float(L), D = 5000. / (1. + fl * 2.2);             // distances 5000, 1560, 900 m
    float a = ang * (5. + fl * 4.) + ro.x / D * 6. + fl * 7.3;
    float h = mesa(a, fl * 11.) * (.035 + fl * .022) - .006;
    if (rd.y < h) {
      vec3 mc = mix(vec3(.012, .008, .014) + hue(uC2) * .004, skyCol(vec3(rd.x, .01, rd.z), lt) * .8, .65 - fl * .27);
      mc = mix(mc, mix(uBase, hue(uC2), .3) * (.62 - fl * .1), lt);
      mc += horizC() * .08 * smoothstep(.004, .0, h - rd.y) * on;   // sunset rim on the tops
      col = mc;
    }
  }
  float t = 1e9;
  if (rd.y < 0.) {
    t = -ro.y / rd.y; vec3 p = ro + rd * t;
    float fw = max(fwidth(p.x), .003);
    // desert floor: sand with scattered dark scrub
    vec2 ci = floor(p.xz / 3.), cf = fract(p.xz / 3.) - .5 - (h22(ci) - .5) * .6;
    float bush = smoothstep(.12, .05, length(cf)) * step(.7, h21(ci)) * smoothstep(120., 30., t);
    vec3 sand = mix(vec3(.11, .06, .045), hue(uC1) * .05, .25) * (.7 + .5 * noise(p.xz * .15)) * (1. - .7 * bush);
    vec3 amb = skyCol(vec3(0., .3, 1.), lt) * 1.6 + horizC() * .03 * on;
    vec3 c = sand * amb * 3.;
    // the road
    float ax = abs(p.x);
    float road = smoothstep(4.2 + fw, 4.2 - fw, ax);
    if (road > 0.) {
      float grain = noise(p.xz * vec2(4., 1.));
      vec3 asph = vec3(.03 + .015 * grain);
      float yel = smoothstep(.06 + fw, .06 - fw, abs(ax - .12)) * step(.45, fract(p.z / 10.));
      float wht = smoothstep(.07 + fw, .07 - fw, abs(ax - 3.9));
      asph = mix(asph, vec3(.8, .55, .1), yel * .8);
      asph = mix(asph, vec3(.6), wht * .8);
      vec3 rc = asph * amb * 3.;
      // grazing sky reflection: the heat-shimmer mirage near the horizon
      float fr = pow(1. - max(-rd.y, 0.), 60.);
      vec3 rr = vec3(rd.x, -rd.y, rd.z) + vec3(0., (noise(vec2(p.x * .3, p.z * .02 - T * .5)) - .5) * .004, 0.);
      rc += skyCol(rr, lt) * fr * .9;
      c = mix(c, rc, road);
    }
    // our headlights on the road ahead
    float hl = exp(-pow((p.x - ro.x) / (1.5 + (p.z - zc) * .12), 2.)) * smoothstep(4., 14., p.z - zc) * 9. / (p.z - zc + 6.);
    c += vec3(1., .9, .75) * hl * .35 * on * (.15 + .85 * c * 30.);
    col = c;
    col = mix(col, skyCol(vec3(rd.x, .005, rd.z), lt), 1. - exp(-t * .0012));   // haze
  }
  // telephone poles along the right shoulder, with sagging wires
  float SPp = 50., PX = 9.5, PH = 8.5;
  for (int j = 0; j < 9; j++) {
    float pz = (floor(zc / SPp) + 1. + float(j)) * SPp;
    float zt, zb; vec2 st = proj(cam, vec3(PX, PH, pz), zt), sb = proj(cam, vec3(PX, 0., pz), zb);
    float w = max(.22 * cam.fl / zt, .6 / R.y);
    float pole = smoothstep(w + .8 / R.y, w, abs(uv.x - st.x)) * step(sb.y, uv.y) * step(uv.y, st.y);
    float bar = smoothstep(w * .8 + .8 / R.y, w * .8, abs(uv.y - st.y + 1. * cam.fl / zt)) * step(abs(uv.x - st.x), 1.2 * cam.fl / zt);
    if (zt < t) col = mix(col, mix(vec3(.004, .003, .004), mix(uBase, vec3(.2), .5) * .3, lt), max(pole, bar) * exp(-zt * .0012));
  }
  {
    // wires: intersect the ray with the vertical plane of the pole line, compare with the catenary height
    float tw = (PX - ro.x) / rd.x;
    if (tw > 0. && tw < t) {
      vec3 q = ro + rd * tw; float f = fract(q.z / SPp);
      float wd = 2. / R.y * tw / cam.fl;                            // one pixel at that distance
      for (int k = 0; k < 2; k++) {
        float wy = PH - 1. - float(k) * .6 - 1.4 * 4. * f * (1. - f);
        col = mix(col, vec3(.004), smoothstep(wd, 0., abs(q.y - wy)) * .8 * (1. - lt * .5) * step(q.z, zc + 400.));
      }
    }
  }
  // an oncoming car far ahead
  float oz = zc + mod(-T * (v + 25.) * 1., 900.) + 40.;
  for (int i = 0; i < 2; i++) {
    float zz; vec2 sp = proj(cam, vec3(-1.4 + float(i) * 1.5, .7, oz), zz);
    vec2 d = uv - sp;
    col += vec3(1., .92, .8) * (.00002 + .0002 * 30. / zz) / (dot(d, d) + .00004 + 2e-6 * zz * .01) * .02 * exp(-zz * .002) * on;
  }
  return finish(col * 1.05);
}`],
});
