/* 3D worlds: live GPU-rendered scenes behind the UI (WebGL2 fragment shaders).
   Every scene gets the theme colors, driving speed, a music beat and a slowly floating camera.
   The resolution adapts by itself to keep the frame rate up on the Pi. */
'use strict';

const WORLD = { gl: null, canvas: null, progs: {}, scene: null, raf: 0, t: 0, last: 0, scale: 0.5, slow: 0, fast: 0,
  frames: 0, frameMs: 0, reportAt: 0, buf: null, cam: [0, 0], paused: false };

// Shared GLSL: noise, fbm, rotations, theme colors. Scenes write  vec3 scene(vec2 fragCoord)
const WORLD_PRELUDE = `#version 300 es
precision highp float;
uniform vec2 R; uniform float T; uniform vec3 uBase, uC1, uC2, uC3, uAcc, uText;
uniform float uSpeed, uBeat, uMotion; uniform vec2 uCam;
out vec4 outColor;
#define PI 3.14159265
float h11(float p){ p = fract(p * .1031); p *= p + 33.33; p *= p + p; return fract(p); }
float h21(vec2 p){ vec3 p3 = fract(vec3(p.xyx) * .1031); p3 += dot(p3, p3.yzx + 33.33); return fract((p3.x + p3.y) * p3.z); }
vec2 h22(vec2 p){ vec3 p3 = fract(vec3(p.xyx) * vec3(.1031, .1030, .0973)); p3 += dot(p3, p3.yzx + 33.33); return fract((p3.xx + p3.yz) * p3.zy); }
float noise(vec2 p){ vec2 i = floor(p), f = fract(p); f = f * f * (3. - 2. * f);
  return mix(mix(h21(i), h21(i + vec2(1, 0)), f.x), mix(h21(i + vec2(0, 1)), h21(i + vec2(1, 1)), f.x), f.y); }
float fbm(vec2 p){ float v = 0., a = .5; for (int i = 0; i < 5; i++) { v += a * noise(p); p = p * 2.03 + 17.1; a *= .5; } return v; }
float noise3(vec3 p){ vec3 i = floor(p), f = fract(p); f = f * f * (3. - 2. * f); float n = i.x + i.y * 57. + i.z * 113.;
  return mix(mix(mix(h11(n), h11(n + 1.), f.x), mix(h11(n + 57.), h11(n + 58.), f.x), f.y),
             mix(mix(h11(n + 113.), h11(n + 114.), f.x), mix(h11(n + 170.), h11(n + 171.), f.x), f.y), f.z); }
mat2 rot(float a){ float c = cos(a), s = sin(a); return mat2(c, -s, s, c); }
vec3 aces(vec3 x){ return clamp((x * (2.51 * x + .03)) / (x * (2.43 * x + .59) + .14), 0., 1.); }
vec3 sky(vec3 rd){ return mix(uBase, mix(uC2, uBase, .6), pow(max(rd.y, 0.), .5)); }
`;
const WORLD_MAIN = `
void main(){ vec3 c = scene(gl_FragCoord.xy);
  vec2 q = gl_FragCoord.xy / R; c *= .55 + .45 * pow(16. * q.x * q.y * (1. - q.x) * (1. - q.y), .25);  // vignette
  c += (h21(gl_FragCoord.xy + fract(T)) - .5) / 128.;  // dither: no color banding
  outColor = vec4(c, 1.); }`;
const WORLD_VERT = `#version 300 es
in vec2 p; void main(){ gl_Position = vec4(p, 0., 1.); }`;

// Scenes are added by the worlds_*.js files: id: [name, description, cost 1-3, GLSL defining vec3 scene(vec2 fc)]
const WORLDS = {};

function worldSettings() {
  const s = (typeof settings === 'function') ? settings() : {};
  return { id: s.animate === false ? 'off' : (s.world || 'off'), quality: s.world_quality || 'auto' };
}

function worldInit() {
  if (WORLD.gl) return true;
  const c = document.getElementById('world');
  if (!c) return false;
  const gl = c.getContext('webgl2', { antialias: false, alpha: false, depth: false, powerPreference: 'high-performance', preserveDrawingBuffer: true });
  if (!gl) { console.warn('world: no WebGL2'); return false; }
  WORLD.gl = gl; WORLD.canvas = c;
  WORLD.buf = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, WORLD.buf);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
  c.addEventListener('webglcontextlost', (e) => { e.preventDefault(); WORLD.progs = {}; });
  return true;
}

function worldProgram(id) {
  const gl = WORLD.gl;
  if (WORLD.progs[id]) return WORLD.progs[id];
  const mk = (type, src) => { const sh = gl.createShader(type); gl.shaderSource(sh, src); gl.compileShader(sh);
    if (!gl.getShaderParameter(sh, gl.COMPILE_STATUS)) { const err = gl.getShaderInfoLog(sh); console.warn(`world ${id}: ${err}`); worldReport({ error: `${id}: ${err}`.slice(0, 400) }); return null; } return sh; };
  const vs = mk(gl.VERTEX_SHADER, WORLD_VERT), fs = mk(gl.FRAGMENT_SHADER, WORLD_PRELUDE + WORLDS[id][3] + WORLD_MAIN);
  if (!vs || !fs) return null;
  const p = gl.createProgram(); gl.attachShader(p, vs); gl.attachShader(p, fs); gl.linkProgram(p);
  if (!gl.getProgramParameter(p, gl.LINK_STATUS)) { worldReport({ error: `${id}: link ${gl.getProgramInfoLog(p)}` }); return null; }
  const u = {}; ['R', 'T', 'uBase', 'uC1', 'uC2', 'uC3', 'uAcc', 'uText', 'uSpeed', 'uBeat', 'uMotion', 'uCam'].forEach((n) => { u[n] = gl.getUniformLocation(p, n); });
  WORLD.progs[id] = { p, u, loc: gl.getAttribLocation(p, 'p') };
  return WORLD.progs[id];
}

function worldReport(o) {
  try { if (typeof LAB !== 'undefined' && LAB) return; if (typeof ws !== 'undefined' && ws && ws.readyState === 1) ws.send(JSON.stringify(Object.assign({ cmd: 'perf', what: 'world', scene: WORLD.scene }, o))); } catch (e) { /* not connected */ }
}

const hex3 = (h) => { const n = parseInt((h || '#000000').slice(1), 16); return [((n >> 16) & 255) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255]; };
// Theme colors are sRGB; the shaders light in linear space and tone-map at the end.
const lin3 = (h) => hex3(h).map((v) => (v <= 0.04045 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4));

function worldSize() {
  const c = WORLD.canvas, w = Math.max(64, Math.round(innerWidth * WORLD.scale)), h = Math.max(36, Math.round(innerHeight * WORLD.scale));
  if (c.width !== w || c.height !== h) { c.width = w; c.height = h; }
}

const QMAX = { low: 0.4, medium: 0.6, high: 0.85, auto: 0.62 };
function worldFrame(now) {
  WORLD.raf = requestAnimationFrame(worldFrame);
  if (WORLD.paused || !WORLD.scene) return;
  // 30 fps is plenty for a background, and leaves the graphics chip time for the frosted panels on top
  if (WORLD.last && now - WORLD.last < 30) return;
  const dt = WORLD.last ? Math.min(0.1, (now - WORLD.last) / 1000) : 0.016;
  WORLD.last = now;
  const s = (typeof settings === 'function') ? settings() : {};
  const m = { calm: 0.55, lively: 1, wild: 1.8 }[s.motion] || 1;
  WORLD.t += dt * m;
  // the camera floats gently, like you're really moving through the scene
  WORLD.cam = [Math.sin(WORLD.t * 0.21) * 0.8 + Math.sin(WORLD.t * 0.07) * 0.4, Math.sin(WORLD.t * 0.17 + 1) * 0.6];
  // adaptive resolution: aim for a steady ~30 fps
  const q = worldSettings().quality;
  WORLD.frameMs = WORLD.frameMs * 0.92 + dt * 1000 * 0.08;
  if (q === 'auto') {
    if (WORLD.frameMs > 40) { if (++WORLD.slow > 30) { WORLD.scale = Math.max(0.33, WORLD.scale * 0.88); WORLD.slow = 0; WORLD.frameMs = 33; } } else WORLD.slow = 0;
    if (WORLD.frameMs < 36) { if (++WORLD.fast > 150) { WORLD.scale = Math.min(QMAX.auto, WORLD.scale * 1.1); WORLD.fast = 0; } } else WORLD.fast = 0;
  } else WORLD.scale = QMAX[q] || 0.6;
  worldSize();
  const gl = WORLD.gl, pr = worldProgram(WORLD.scene);
  if (!pr) return;
  const t = (typeof S !== 'undefined' && S.theme) || {};
  gl.viewport(0, 0, WORLD.canvas.width, WORLD.canvas.height);
  gl.useProgram(pr.p);
  gl.bindBuffer(gl.ARRAY_BUFFER, WORLD.buf);
  gl.enableVertexAttribArray(pr.loc); gl.vertexAttribPointer(pr.loc, 2, gl.FLOAT, false, 0, 0);
  const u = pr.u;
  gl.uniform2f(u.R, WORLD.canvas.width, WORLD.canvas.height);
  gl.uniform1f(u.T, WORLD.t);
  gl.uniform3fv(u.uBase, lin3(t.base)); gl.uniform3fv(u.uC1, lin3(t.b1)); gl.uniform3fv(u.uC2, lin3(t.b2)); gl.uniform3fv(u.uC3, lin3(t.b3));
  gl.uniform3fv(u.uAcc, lin3(t.accent)); gl.uniform3fv(u.uText, t.light ? [0.02, 0.03, 0.05] : [0.9, 0.92, 0.95]);
  const sp = typeof fxSpeed === 'function' ? (fxSpeed() - 1) / 3 : 0;
  gl.uniform1f(u.uSpeed, Math.max(0, Math.min(1, sp)));
  gl.uniform1f(u.uBeat, typeof fxBeat === 'function' ? fxBeat(now / 1000) : 0);
  gl.uniform1f(u.uMotion, m);
  gl.uniform2f(u.uCam, WORLD.cam[0], WORLD.cam[1]);
  gl.drawArrays(gl.TRIANGLES, 0, 3);
  WORLD.frames++;
  if (now > (WORLD.varsAt || 0)) {  // the panels' light follows the camera; 10 times a second is plenty
    WORLD.varsAt = now + 100;
    document.documentElement.style.setProperty('--camx', WORLD.cam[0].toFixed(3));
    document.documentElement.style.setProperty('--camy', WORLD.cam[1].toFixed(3));
  }
  if (now > WORLD.reportAt) { WORLD.reportAt = now + 30000; worldReport({ fps: Math.round(1000 / WORLD.frameMs), scale: +WORLD.scale.toFixed(2), w: WORLD.canvas.width, h: WORLD.canvas.height }); }
}

// Called whenever the look changes (from applyLook) and when the screen changes.
function worldApply() {
  const { id } = worldSettings();
  const on = id !== 'off' && WORLDS[id];
  document.body.classList.toggle('world', !!on);
  if (!on) { WORLD.scene = null; cancelAnimationFrame(WORLD.raf); WORLD.raf = 0; return; }
  if (!worldInit()) { document.body.classList.remove('world'); return; }
  if (WORLD.scene !== id) { WORLD.scene = id; WORLD.reportAt = performance.now() + 8000; WORLD.scale = Math.min(0.55, QMAX[worldSettings().quality] || 0.6); WORLD.slow = WORLD.fast = 0; }
  // the phone's app stream needs the GPU for video: rest while Maps or YouTube Music fills the screen
  const scr = typeof S !== 'undefined' ? S.screen : 'home';
  WORLD.paused = scr === 'maps' || scr === 'ytm' || (typeof g === 'function' && g('map_bg'));
  if (!WORLD.raf) { WORLD.last = 0; WORLD.raf = requestAnimationFrame(worldFrame); }
}
