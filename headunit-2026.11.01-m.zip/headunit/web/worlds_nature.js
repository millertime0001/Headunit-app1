/* 3D worlds: nature scenes (see world3d.js for the shared uniforms and helpers).
   Shared idioms used below:
     lum(c)  luminance of a linear color      hue(c)  the theme color pushed to full brightness (keeps its hue)
     lt      0 = dark theme, 1 = light theme (a softer daytime variant is drawn for light themes) */
'use strict';
Object.assign(WORLDS, {
  ocean: ['Ocean', 'Open sea at dusk: rolling swell and a glittering path of light on the water', 2, `
float lum(vec3 c){ return dot(c, vec3(.2126, .7152, .0722)); }
vec3 hue(vec3 c){ return c / max(max(c.r, max(c.g, c.b)), .03); }
const mat2 OM = mat2(1.6, 1.2, -1.2, 1.6);
float LT;
vec3 SUNC, SUND, HOR, ZEN, MID;
float GL;   // broad sun glow (weaker around the moon)
// one octave of choppy swell: sharp crests, round troughs
float swell(vec2 uv, float ch){ uv += noise(uv); vec2 w = 1. - abs(sin(uv)), s = abs(cos(uv)); w = mix(w, s, w); return pow(1. - pow(w.x * w.y, .65), ch); }
float seaH(vec2 p, int n){
  float f = .16, a = .6, ch = 4., h = 0., t = 1. + T * .7; vec2 uv = p; uv.x *= .75;
  for (int i = 0; i < 5; i++) { if (i >= n) break;
    h += (swell((uv + t) * f, ch) + swell((uv - t) * f, ch)) * a;
    uv *= OM; f *= 1.9; a *= .22; ch = mix(ch, 1., .2); }
  return h;
}
vec3 skyCol(vec3 rd, float disc){
  float y = max(rd.y, 0.), sd = max(dot(rd, SUND), 0.);
  float side = pow(max(dot(normalize(rd.xz + 1e-4), normalize(SUND.xz)), 0.), 3.);       // horizon brighter toward the sun
  vec3 c = mix(HOR * (.3 + .7 * side), MID, smoothstep(.0, .1, y));   // horizon glow, then the dusk band, then the zenith
  c = mix(c, ZEN, smoothstep(.04, .5, y));
  c += SUNC * (pow(sd, 5.) * .18 * GL + pow(sd, 40.) * .35 * GL + pow(sd, 400.) * .6);              // glow around the sun
  c += SUNC * 6. * disc * smoothstep(.99975, .99985, sd) * (.8 + .2 * noise((rd.xy - SUND.xy) * 400.));                                   // the disc itself
  // a few soft cloud streaks lit from below
  vec2 cp = rd.xz / (rd.y + .06) * .8 + vec2(T * .01, 0.);
  float cl = smoothstep(.45, .8, noise(cp * vec2(.6, 2.2)) * .65 + noise(cp * vec2(1.4, 5.)) * .35) * smoothstep(.0, .12, rd.y) * smoothstep(.6, .15, rd.y);
  c = mix(c, HOR * .5 + SUNC * .35 * (.3 + side), cl * .55);
  // stars come out high up on dark themes
  vec2 sg = rd.xz / (rd.y + .2) * 60.; float st = h21(floor(sg));
  c += vec3(.8, .85, 1.) * step(.992, st) * smoothstep(.15, .5, rd.y) * (1. - LT) * .5 * (.6 + .4 * sin(T * 2. + st * 90.));
  return c;
}
float trace(vec3 ro, vec3 rd, out vec3 p){   // secant search for the wave surface
  float tm = 0., tx = 600.;
  p = ro + rd * tx; float hx = p.y - seaH(p.xz, 3);
  if (hx > 0.) return tx;
  float hm = ro.y - seaH(ro.xz, 3), tmid = 0.;
  for (int i = 0; i < 6; i++) {
    tmid = mix(tm, tx, hm / (hm - hx)); p = ro + rd * tmid; float hmid = p.y - seaH(p.xz, 3);
    if (hmid < 0.) { tx = tmid; hx = hmid; } else { tm = tmid; hm = hmid; }
  }
  return tmid;
}
vec3 scene(vec2 fc){
  vec2 uv = (fc - .5 * R) / R.y;
  LT = smoothstep(.3, .7, lum(uBase));
  // light: warm accents give a dusk sun, cool accents a moonlit night; light themes get a hazy afternoon sun
  vec3 ac = hue(uAcc); float W = clamp((ac.r - ac.b) * 1.5 + .5, 0., 1.);
  SUNC = mix(mix(vec3(.75, .85, 1.) * .9, ac, .2), mix(vec3(1., .45, .18), ac, .15) * 1.6, W);
  SUNC = mix(SUNC, vec3(1.2, 1.08, .9), LT);
  GL = mix(mix(.45, 1., W), 1., LT);
  SUND = normalize(vec3(.25 + uCam.x * .02, mix(mix(.12, .045, W), .2, LT), 1.));
  HOR = mix(mix(mix(vec3(.04, .07, .12), hue(uC1) * .06, .35), mix(vec3(.55, .22, .12), hue(uC1) * .35, .35), W), vec3(.8, .78, .75), LT);
  ZEN = mix(mix(vec3(.004, .008, .025), hue(uC2) * .02, .4) * mix(.6, 1., W), mix(vec3(.25, .4, .65), hue(uC2) * .5, .3), LT);
  MID = mix(mix(mix(vec3(.02, .04, .09), hue(uC2) * .04, .4), mix(vec3(.16, .06, .14), hue(uC2) * .08, .5), W), vec3(.5, .6, .75), LT);
  // camera: low over the water, bobbing and rolling with the swell
  float t = T * (1. + uSpeed * 2.);
  uv *= rot(sin(T * .45) * .035 + uCam.x * .01);
  vec3 ro = vec3(uCam.x * .8, 3.3 + sin(T * .6) * .25 + uCam.y * .25, t * 2.5);
  vec3 rd = normalize(vec3(uv.x, uv.y - .07 + sin(T * .6 + .7) * .015, 1.7));
  vec3 sky = skyCol(rd, 1.);
  vec3 col = sky;
  if (rd.y < .02) {
    vec3 p; float d = trace(ro, rd, p);
    vec3 dist = p - ro;
    float eps = max(dot(dist, dist) * .4 / R.x, .002);
    float h0 = seaH(p.xz, 5);
    vec3 n = normalize(vec3(h0 - seaH(p.xz + vec2(eps, 0), 5), eps, h0 - seaH(p.xz + vec2(0, eps), 5)));
    n = normalize(mix(n, vec3(0, 1, 0), smoothstep(80., 400., d)));        // calm the far field (no aliasing)
    float fr = pow(clamp(1. - dot(n, -rd), 0., 1.), 3.) * .65;
    vec3 refl = skyCol(reflect(rd, n), 0.);
    vec3 deep = mix(mix(vec3(.004, .018, .03), hue(uC3) * .012, .4), vec3(.1, .2, .24), LT);
    vec3 wat = mix(mix(vec3(.05, .16, .14), hue(uC3) * .12, .4), vec3(.3, .5, .5), LT);
    float dif = pow(dot(n, SUND) * .4 + .6, 60.);
    vec3 refr = deep + wat * dif * .1 * SUNC;
    vec3 c = mix(refr, refl, fr);
    c += wat * SUNC * max(h0 - .7, 0.) * .3 * max(1. - d * .01, 0.);    // light through the crests
    // the glitter path: sharp sun highlights on every facet
    float sp = max(dot(reflect(rd, n), SUND), 0.);
    c += SUNC * (pow(sp, 700.) * 9. + pow(sp, 90.) * .5) * (1. - LT * .5);
    float haze = smoothstep(0., -.06, rd.y);
    col = mix(sky, c, pow(haze, .35));
  }
  col *= 1. + uBeat * .06;
  return aces(col * mix(1.1, .9, LT));
}`],
  northern: ['Northern lights', 'Aurora curtains over snowy peaks, mirrored in a still lake', 3, `
float lum(vec3 c){ return dot(c, vec3(.2126, .7152, .0722)); }
vec3 hue(vec3 c){ return c / max(max(c.r, max(c.g, c.b)), .03); }
float LT, PAN;
vec3 AB, AT;   // aurora colors: lower edge, upper fringe
// mountains: ridged noise heightfield that rises out of the lake (water level y = 0) from 14 units away
float terr(vec2 p, int n){
  vec2 q = p * .06; float v = 0., a = .62;
  for (int i = 0; i < 5; i++) { if (i >= n) break; float r = 1. - abs(noise(q) * 2. - 1.); v += a * r * r; q = rot(.6) * q * 2.05 + 5.3; a *= .42; }
  return v * 13. * smoothstep(14., 48., p.y) - 2.;
}
// aurora: vertical curtains z = c(x) hanging over the land. The ray/curtain hit is found by fixed-point iteration;
// curtains glow brightest where we look along them (folds) and have a sharp lower edge with rays rising from it.
float cz(float x, float z0, float s){ return z0 + 1.8 * sin(x * .45 + s + T * .05) + 1.4 * noise(vec2(x * .6 + T * .04, s)); }
vec3 curtain(vec3 rd, float z0, float s, float amp){
  // walk the ray through the curtain's depth range and add every crossing (curtains are see-through)
  vec3 acc = vec3(0);
  float t0 = (z0 - 3.5) / rd.z, dt = 7. / rd.z / 10.;
  float tp = t0, fp = rd.z * tp - cz(rd.x * tp, z0, s);
  for (int i = 1; i <= 10; i++) {
    float t = t0 + dt * float(i), f = rd.z * t - cz(rd.x * t, z0, s);
    if (f * fp < 0.) {
      float th = mix(tp, t, fp / (fp - f));
      float x = rd.x * th, hgt = rd.y * th;
      float sl = (cz(x + .05, z0, s) - cz(x - .05, z0, s)) * 10.;               // curtain slope dz/dx
      float face = abs(dot(normalize(rd.xz), normalize(vec2(-sl, 1.))));
      float fold = mix(1., 2.2, smoothstep(.6, .15, face)) * smoothstep(.0, .12, face);   // brighter folds, no seam at tangents                                  // bright where we look along it
      float z = hgt - (.35 + .55 * noise(vec2(x * .35, s + T * .03)));              // height above the lower edge
      float rays = .3 + .7 * pow(noise(vec2(x * 6., T * .4 + s)), 2.) * (.5 + .5 * noise(vec2(x * 1.3 - T * .25, s)));
      float prof = smoothstep(-.06, .05, z) * (exp(-z * 1.5) + .1 * exp(-z * .5)) * smoothstep(4., 1.5, z) + .12 * exp(min(z, 0.) * 2.5) * step(z, 0.);   // soft glow below the edge
      acc += mix(AB, AT, smoothstep(.2, 1.8, z)) * prof * rays * fold * smoothstep(.25, .7, noise(vec2(x * .3 + T * .03, s * 2.)));
    }
    tp = t; fp = f;
  }
  return acc * amp;
}
vec3 aurora(vec3 rd){
  if (rd.y <= .0) return vec3(0);
  rd.x += PAN * .3;
  vec3 a = curtain(rd, 5., 1.3, 1.) + curtain(rd, 9., 5.7, .6);
  return a * .55 * (1. + uBeat * .15);
}
vec3 skyN(vec3 rd){
  float y = max(rd.y, 0.);
  vec3 zen = mix(mix(vec3(.002, .004, .012), hue(uC2) * .006, .4), mix(vec3(.3, .45, .7), hue(uC2) * .5, .3), LT);
  vec3 hor = mix(mix(vec3(.012, .02, .04), hue(uC3) * .02, .4), vec3(.8, .78, .82), LT);
  vec3 col = mix(hor, zen, pow(y, .5));
  // stars with a faint milky way band
  vec2 sp = rd.xy / (rd.z + .3) * 110.; vec2 id = floor(sp); float r = h21(id);
  float star = smoothstep(.15, .0, length(fract(sp) - .5 - (h22(id) - .5) * .6)) * step(.972, r);
  float mw = smoothstep(.3, .0, abs(rd.y - rd.x * .4 - .3)) * fbm(rd.xy * 5. + 3.);
  col += (vec3(.9, .9, 1.) * star * (.55 + .45 * sin(T * 3. + r * 70.)) * (.5 + mw) + vec3(.015, .015, .03) * mw) * (1. - LT) * smoothstep(0., .1, rd.y);
  col += (AB * .006 + AT * .003) * exp(-y * 5.) * (1. - LT);                      // faint auroral airglow low in the sky
  return col + aurora(rd) * (1. - LT * .85);
}
// march the mountains; returns lit color, or -1 when the ray misses
vec4 mountains(vec3 ro, vec3 rd){
  if (rd.y > .34 || rd.z < .2) return vec4(-1);
  float t = (13. - ro.z) / rd.z, hit = 0.;
  for (int i = 0; i < 36; i++) {
    vec3 p = ro + rd * t; float d = p.y - terr(p.xz, 3);
    if (d < .002 * t) { hit = 1.; break; }
    t += max(d * .68, .014 * t);
    if (t > 90. || p.y > 12.) break;
  }
  if (hit < .5) return vec4(-1);
  for (int i = 0; i < 3; i++) { vec3 q = ro + rd * t; t += (q.y - terr(q.xz, 3)) * .6; }   // refine the hit (no terraces)
  vec3 p = ro + rd * t; float e = .005 * t, h = terr(p.xz, 4);
  vec3 n = normalize(vec3(h - terr(p.xz + vec2(e, 0), 4), e, h - terr(p.xz + vec2(0, e), 4)));
  vec3 L = normalize(vec3(-.7, mix(.35, .6, LT), -.3));                            // moon (sun on light themes), from the left
  float dif = max(dot(n, L), 0.);
  float snow = smoothstep(.5, .8, n.y + (noise(p.xz * 2.) + noise(p.xz * 7.) * .5) * .25 - .1) * smoothstep(.5, 2.5, p.y);
  vec3 alb = mix(mix(vec3(.04, .045, .05), vec3(.1, .12, .1), LT), mix(vec3(.85, .9, 1.), vec3(1.), LT), snow);
  alb = mix(alb, vec3(.01, .02, .015), smoothstep(1.2, .2, p.y) * (1. - snow));    // dark forest low on the slopes
  vec3 moon = mix(mix(vec3(.35, .42, .6), hue(uC3) * .4, .2), vec3(1.6, 1.5, 1.35), LT);
  vec3 amb = mix(vec3(.01, .015, .03) + AB * .025 + AT * .01, vec3(.25, .3, .4), LT);
  vec3 c = alb * (moon * dif + amb * (.5 + .5 * n.y));
  vec3 hz = mix(mix(vec3(.012, .02, .04), hue(uC3) * .02, .4) + AB * .012, vec3(.8, .78, .82), LT);
  c = mix(c, hz, 1. - exp(-t * mix(.012, .018, LT)));   // haze
  return vec4(c, t);
}
vec3 scene(vec2 fc){
  vec2 uv = (fc - .5 * R) / R.y;
  LT = smoothstep(.3, .7, lum(uBase));
  AB = mix(vec3(.15, 1., .45), hue(uC1), .55);
  AT = mix(vec3(.7, .2, 1.), hue(uC3 + uC2 * .5), .55);
  PAN = T * (.004 + uSpeed * .01) + uCam.x * .01;
  vec3 ro = vec3(PAN * 40., .45 + uCam.y * .05, 0.);
  vec3 rd = normalize(vec3(uv.x, uv.y + .07, 1.));
  vec3 col;
  if (rd.y >= 0.) {
    vec4 m = mountains(ro, rd);
    col = m.w < 0. ? skyN(rd) : m.rgb;
  } else {
    // the lake: still water with a slow ripple, reflecting mountains, sky and aurora
    float tw = -ro.y / rd.y; vec3 p = ro + rd * tw;
    vec4 m = vec4(-1);
    if (tw > 13. / rd.z) m = mountains(ro, rd);                                  // the far shore pokes out of the water
    if (m.w > 0. && m.w < tw) col = m.rgb;
    else {
      vec2 w = vec2(noise(p.xz * vec2(.6, 1.6) + vec2(0, T * .3)), noise(p.xz * vec2(.7, 1.9) - vec2(T * .25, 0))) - .5;
      vec3 n = normalize(vec3(w.x * .015, 1., w.y * .05));
      vec3 rr = reflect(rd, n); rr.y = max(rr.y, .001);
      vec4 mr = mountains(p, rr);
      vec3 rc = mr.w < 0. ? skyN(rr) : mr.rgb;
      float fr = .3 + .7 * pow(1. - max(-rd.y, 0.), 6.);
      col = rc * fr * mix(.7, .8, LT) + mix(vec3(.002, .004, .006), vec3(.05, .07, .08), LT);
      col = mix(col, skyN(vec3(rd.x, .01, rd.z)) * .5, 1. - exp(-tw * .006));
    }
  }
  return aces(col * mix(1.3, .95, LT));
}`],
  clouds: ['Above the clouds', 'Flying over a sea of clouds at golden hour, the sun low on the horizon', 2, `
float lum(vec3 c){ return dot(c, vec3(.2126, .7152, .0722)); }
vec3 hue(vec3 c){ return c / max(max(c.r, max(c.g, c.b)), .03); }
float LT;
vec3 SUNC, SUND, ZEN, HOR;
// height of the cloud deck (0 .. ~.8): billow noise gives round cauliflower tops with creases between them
float tops(vec2 p, int n){
  p += vec2(T * .02, 0.);
  float v = 0., a = .55;
  for (int i = 0; i < 4; i++) { if (i >= n) break; v += a * abs(noise(p) * 2. - 1.); p = rot(.5) * p * 2.1 + 7.3; a *= .45; }
  return v;
}
vec3 skyC(vec3 rd){
  float y = max(rd.y, 0.), sd = max(dot(rd, SUND), 0.);
  float side = pow(max(dot(normalize(rd.xz), normalize(SUND.xz)), 0.), 2.);
  vec3 c = mix(HOR * (.45 + .55 * side), ZEN, pow(y, .45));
  c += SUNC * (pow(sd, 6.) * .22 + pow(sd, 50.) * .35);
  c += SUNC * 5. * smoothstep(.9996, .9998, sd);
  // thin high cirrus, lit from below by the low sun
  vec2 cp = rd.xz / (rd.y + .03) * .5 + vec2(T * .004, T * .02);
  float ci = smoothstep(.5, .9, noise(cp * vec2(.5, 3.)) * .6 + noise(cp * vec2(1.3, 7.)) * .4) * smoothstep(.0, .15, rd.y);
  c = mix(c, HOR * .5 + SUNC * .45 * (.25 + pow(sd, 3.)), ci * .45);
  return c;
}
vec3 scene(vec2 fc){
  vec2 uv = (fc - .5 * R) / R.y;
  LT = smoothstep(.3, .7, lum(uBase));
  // warm accents: golden hour. cool accents: blue hour with the sun just set. light themes: bright afternoon.
  vec3 ac = hue(uAcc); float W = clamp((ac.r - ac.b) * 1.5 + .5, 0., 1.);
  SUND = normalize(vec3(-.35 + uCam.x * .02, mix(mix(.0, .05, W), .22, LT), 1.));
  SUNC = mix(mix(vec3(1., .5, .45) * .9, mix(vec3(1., .55, .22), ac, .15) * 1.6, W), vec3(1.3, 1.22, 1.1), LT);
  HOR = mix(mix(mix(vec3(.25, .12, .2), hue(uC1) * .2, .3), mix(vec3(.45, .2, .1), hue(uC1) * .25, .3), W), vec3(.75, .8, .88), LT);
  ZEN = mix(mix(mix(vec3(.015, .03, .09), hue(uC2) * .04, .4), mix(vec3(.03, .05, .13), hue(uC2) * .05, .4), W), mix(vec3(.2, .35, .65), hue(uC2) * .4, .2), LT);
  vec3 shad = mix(mix(vec3(.05, .05, .11), hue(uC2) * .05, .35) * mix(.6, 1., W), vec3(.45, .5, .62), LT);   // shaded cloud color
  // camera: cruising forward, banking gently
  float t = T * (.5 + uSpeed * 1.5);
  uv *= rot(uCam.x * .04);
  vec3 ro = vec3(uCam.x * .4, 2.2 + uCam.y * .1 + sin(T * .23) * .05, t * 1.5);
  vec3 rd = normalize(vec3(uv.x, uv.y - .1, 1.3));
  vec3 sky = skyC(rd), col = sky;
  if (rd.y < .0) {
    // march the cloud deck heightfield
    float t = (ro.y - .85) / -rd.y, hit = 0.;
    for (int i = 0; i < 40; i++) {
      vec3 p = ro + rd * t; float d = p.y - tops(p.xz * .7, 3);
      if (d < .004 * t) { hit = 1.; break; }
      t += max(d * .6, .02 * t);
      if (t > 80.) break;
    }
    for (int i = 0; i < 3; i++) { vec3 q = ro + rd * t; t += (q.y - tops(q.xz * .7, 3)) * .7; }   // refine the hit (no terraces)
    vec3 p = ro + rd * t;
    int oc = t > 25. ? 2 : 4;
    float e = .06 + .01 * t, h = tops(p.xz * .7, oc);
    vec3 n = normalize(vec3(h - tops((p.xz + vec2(e, 0)) * .7, oc), e * 1.6, h - tops((p.xz + vec2(0, e)) * .7, oc)));
    float sd = max(dot(rd, SUND), 0.);
    float dif = pow(clamp(dot(n, SUND) * .6 + .4, 0., 1.), 1.5);                  // wrapped light: soft like vapour
    float ht = smoothstep(.05, .7, h);                                              // creases between the billows stay dark
    vec3 c = shad * (.4 + .6 * ht) + SUNC * .8 * dif * (.15 + .85 * ht * ht) * mix(1., .7, LT);
    c += SUNC * .12 * smoothstep(.3, .9, h) * (1. - dif);                          // light scattered inside the vapour
    c += SUNC * pow(sd, 6.) * (1. - n.y) * .8;                                      // light glowing through the edges
    c += ZEN * .25 * n.y;
    col = mix(c, mix(HOR * .9, sky, .3) + SUNC * pow(sd, 8.) * .25, 1. - exp(-t * .03));   // aerial haze
    col = mix(sky, col, smoothstep(.0, -.025, rd.y));
  }
  col *= 1. + uBeat * .05;
  return aces(col * mix(1.15, .85, LT));
}`],
  planet: ['Planet', 'A living world seen from orbit: oceans, clouds, city lights and a glowing atmosphere', 2, `
float lum(vec3 c){ return dot(c, vec3(.2126, .7152, .0722)); }
vec3 hue(vec3 c){ return c / max(max(c.r, max(c.g, c.b)), .03); }
float fbm3(vec3 p, int n){ float v = 0., a = .5; for (int i = 0; i < 5; i++) { if (i >= n) break; v += a * noise3(p); p = p * 2.03 + 3.1; a *= .5; } return v; }
vec2 sph(vec3 ro, vec3 rd, vec3 c, float r){   // ray/sphere: (near, far) or (-1)
  vec3 oc = ro - c; float b = dot(oc, rd), h = b * b - dot(oc, oc) + r * r;
  if (h < 0.) return vec2(-1); h = sqrt(h); return vec2(-b - h, -b + h); }
vec3 stars(vec3 rd, float LT){
  vec2 sp = vec2(atan(rd.x, rd.z), rd.y) * 160.; vec2 id = floor(sp); float r = h21(id);
  float st = smoothstep(.14, .0, length(fract(sp) - .5 - (h22(id) - .5) * .6)) * step(.985, r) * (.4 + 2.5 * pow(h11(r * 91.), 6.));
  vec3 c = vec3(.9, .92, 1.) * st * (.75 + .25 * sin(T * 2. + r * 60.));
  // a faint nebula / galactic band tinted by the theme
  float neb = fbm(rd.xy * 2.5 + 7.) * smoothstep(.5, 0., abs(rd.y + rd.x * .5 - .25));
  c += (hue(uC2) * .012 + hue(uC1) * .006) * neb * neb * 3.;
  return c * (1. - LT);
}
vec3 scene(vec2 fc){
  vec2 uv = (fc - .5 * R) / R.y;
  float LT = smoothstep(.3, .7, lum(uBase));
  vec3 ro = vec3(uCam.x * .08, uCam.y * .05, -3.4);
  vec3 rd = normalize(vec3(uv, 1.55));
  vec3 L = normalize(vec3(-1., .3, .2));                                       // the sun, off to the left
  vec3 SC = vec3(1.25, 1.18, 1.05);
  vec3 atm = mix(vec3(.25, .55, 1.), hue(uAcc), .38);                              // atmosphere color
  vec3 bg = mix(vec3(0.), mix(uBase, vec3(.75, .78, .85), .3) * (.7 + .2 * uv.y + .1 * fbm(uv * 3.)), LT);
  vec3 col = bg + stars(rd, LT);
  col += SC * .05 * pow(max(dot(rd, L), 0.), 12.) * (1. - LT * .5);               // sun glare from off-screen
  vec3 C = vec3(.95, -.45, 0.); float RAD = 1.;
  // small moon, behind the planet on the right
  vec3 MC = vec3(-1.25, .62, 3.); vec2 mh = sph(ro, rd, MC, .13);
  if (mh.x > 0.) {
    vec3 mp = ro + rd * mh.x, mn = normalize(mp - MC);
    float cr = fbm3(mn * 6., 3);
    col = vec3(.5, .48, .46) * (.65 + .5 * cr) * smoothstep(-.05, .3, dot(mn, L)) * mix(1., .8, LT) + bg * .1;
  }
  // atmosphere halo outside the disc
  vec3 oc = C - ro; float tb = dot(oc, rd), b = length(oc - rd * tb);
  vec2 hit = sph(ro, rd, C, RAD);
  if (hit.x < 0. && tb > 0.) {
    vec3 cp = normalize(ro + rd * tb - C);
    float sunside = smoothstep(-.35, .6, dot(cp, L));
    float x = (b - RAD) / .09;
    col += atm * exp(-x * 2.2) * smoothstep(-.02, .0, b - RAD) * (.03 + 1.6 * sunside) * .5;
  }
  if (hit.x > 0.) {
    vec3 p = ro + rd * hit.x, n = normalize(p - C);
    float spin = T * .012 + uSpeed * T * .01;
    vec3 q = n; q.xz *= rot(spin); q.xy *= rot(.35);                                // surface coords: tilted axis, slow spin
    float h = fbm3(q * 2.4 + 1.7, 5);
    float land = smoothstep(.545, .555, h);
    float lat = abs(q.y);
    float ice = smoothstep(.78, .84, lat + (h - .5) * .5);
    vec3 cq = n; cq.xz *= rot(spin * 1.6 + 1.); cq.xy *= rot(.35);                 // clouds drift a little faster
    vec3 wq = cq * vec3(2.5, 5., 2.5);
    wq += (vec3(noise3(wq * .9), noise3(wq * .9 + 9.), noise3(wq * .9 + 4.)) - .5) * 1.6;   // swirl the clouds
    float cl = fbm3(wq + vec3(T * .004, 0, 0), 4);
    cl = smoothstep(.46, .76, cl + .06 * sin(cq.y * 12.));
    float dl = dot(n, L);
    float day = smoothstep(-.08, .25, dl);
    float mu = max(dot(n, -rd), 0.);
    // ground: oceans (theme-tinted), forests, deserts, ice
    vec3 ocean = mix(mix(vec3(.004, .02, .06), hue(uC3) * .02, .35), mix(vec3(.01, .06, .1), hue(uC3) * .05, .35), smoothstep(.47, .545, h));
    float dry = smoothstep(.45, .75, fbm3(q * 5., 3) + .25 * (1. - lat * 2.5));
    vec3 grd = mix(vec3(.03, .06, .02), vec3(.22, .15, .08), dry) * (.8 + .4 * noise3(q * 30.));
    vec3 alb = mix(ocean, grd, land);
    alb = mix(alb, vec3(.7, .75, .8), ice);
    vec3 c = alb * SC * max(dl, 0.) * 1.4;
    // sun glint on the oceans
    c += SC * pow(max(dot(reflect(rd, n), L), 0.), 60.) * .6 * (1. - land) * (1. - ice) * (1. - cl) * day;
    // city lights on the night side, in clusters along the coasts
    float city = pow(noise3(q * 160.), 4.) * 2.5 * smoothstep(.35, .75, noise3(q * 18.)) * smoothstep(.3, .6, noise3(q * 5.)) * land * (1. - ice) * smoothstep(.66, .56, h);
    vec3 lights = mix(vec3(1., .6, .25), hue(uAcc), .12) * city * (1. - day) * (1. - cl * .85) * 1.3;
    c += lights * (1. - LT * .4);
    // clouds, with a reddish terminator
    vec3 sunT = mix(vec3(1., .45, .25), SC, smoothstep(.0, .3, dl));
    c = mix(c, vec3(.9) * sunT * max(dl + .05, 0.) * 1.2, cl * .9);
    // atmosphere: thin blue haze over the day side, strongest at the limb
    float rim = pow(1. - mu, 3.);
    c = mix(c, atm * (smoothstep(-.2, .5, dl)) * .9, rim * .85);
    c += atm * .08 * day * (1. - mu * .6);
    c += atm * .02 * (1. - day) * rim;                                             // airglow on the night side
    col = c + mix(vec3(0.), bg * .15, LT);
  }
  col *= 1. + uBeat * .05;
  return aces(col * mix(1.1, .9, LT));
}`],
  windshield: ['Rain on the windshield', 'Raindrops trickling down the glass in front of a blurry city at night', 1, `
float lum(vec3 c){ return dot(c, vec3(.2126, .7152, .0722)); }
vec3 hue(vec3 c){ return c / max(max(c.r, max(c.g, c.b)), .03); }
float LT;
// one layer of out-of-focus lights: at most one disc per cell. b = blur (1 = fully defocused, 0 = seen through a drop)
vec3 bk(vec2 uv, float sc, float b, float seed, float dens, float lo, float hi, vec3 c1, vec3 c2, float sz){
  vec2 p = uv * sc, id = floor(p), f = fract(p) - .5;
  float r = h21(id + seed), y = (id.y + .5) / sc;
  if (r > dens || y < lo || y > hi) return vec3(0);
  vec2 o = (h22(id + seed + 3.7) - .5) * .2;
  float rad = mix(.08, .4, b) * sz * (.7 + .3 * h11(r * 71.));
  float px = sc / R.y * 1.5, d = length(f - o);
  float disk = smoothstep(rad + px, rad - px - b * .08, d) * (.75 + .25 * smoothstep(rad * .4, rad, d));   // brighter rim, like real bokeh
  vec3 c = mix(c1, c2, step(.5, h11(r * 13.)));
  return c * disk * (.4 + .9 * h11(r * 5.)) * mix(2., .55, b);
}
vec3 signal(vec2 uv, vec2 at, float ph, float b){       // a traffic light: red, green, amber
  float m = mod(T + ph, 22.);
  vec3 c = m < 9. ? vec3(1., .06, .03) : m < 19. ? vec3(.1, 1., .45) : vec3(1., .5, .02);
  float rad = mix(.012, .055, b), d = length(uv - at);
  return c * smoothstep(rad + .004, rad - .004 - b * .015, d) * mix(2.2, .8, b);
}
vec3 city(vec2 uv, float b){
  vec3 sky = mix(mix(vec3(.012, .015, .03), hue(uC2) * .012, .4), vec3(.45, .48, .52), LT);
  vec3 glow = mix(mix(vec3(.3, .14, .06), hue(uAcc) * .12, .35), vec3(.3, .3, .3), LT);
  vec3 c = sky + glow * exp(-abs(uv.y + .03) * 4.) * .7;
  c *= 1. - .5 * smoothstep(.0, .3, uv.y) * step(.4, noise(vec2(uv.x * 3., 1.)));             // dark building masses
  c = mix(c, mix(vec3(.01, .01, .015), vec3(.25, .26, .28), LT), smoothstep(-.12, -.2, uv.y));   // wet street
  float k = mix(1., .45, LT);
  vec3 sod = vec3(1., .5, .15), wht = vec3(.9, .9, 1.);
  c += bk(uv + vec2(T * .002, 0), 4., b, 1., .45, .12, .5, sod, wht * .8, 1.) * .4 * k;                       // street lamps
  c += bk(uv + vec2(T * .003 + 5.3, .3), 5.5, b, 9., .4, .02, .45, sod * .8, vec3(1., .8, .5), .8) * .35 * k;
  c += bk(uv, 10., b, 7., .6, -.05, .4, vec3(1., .75, .4) * .3, vec3(.5, .7, 1.) * .25, .8) * k;              // windows
  c += bk(uv + 3.1, 15., b, 4., .5, -.08, .3, vec3(1., .85, .6) * .2, hue(uC3) * .15, .7) * k;
  c += bk(uv + vec2(T * (.025 + uSpeed * .06), 0), 7., b, 3., .5, -.24, -.06, vec3(1., .05, .03), vec3(1., .2, .05), 1.);   // tail lights
  c += bk(uv - vec2(T * (.03 + uSpeed * .06), 0), 7., b, 11., .25, -.2, -.1, wht, vec3(1., .9, .7), .9) * .8 * k;          // oncoming headlights
  c += bk(uv + vec2(17.3, 0), 3., b, 5., .4, -.05, .45, hue(uAcc) * .4, hue(uC1) * .35, 1.) * k;              // neon signs
  c += (signal(uv, vec2(-.33, .2), 0., b) + signal(uv, vec2(.56, .16), 0., b)) * k;
  // reflections of the lights in the wet street
  vec2 rv = vec2(uv.x, -.24 - (uv.y + .24) * .35);
  if (uv.y < -.12) c += bk(rv + vec2(T * (.025 + uSpeed * .06), 0), 7., 1., 3., .5, -.24, -.06, vec3(1., .05, .03), vec3(1., .2, .05), 1.) * .35;
  return c;
}
// one layer of drops sliding down in jerks, leaving a trail of tiny droplets. returns (offset.xy, drop mask, trail)
vec4 slide(vec2 uv, float sc, float t){
  vec2 q = uv * sc;
  q.x += uv.y * uSpeed * 1.5;                                                       // wind pushes the drops sideways when driving
  float cx = floor(q.x), cr = h11(cx * 7.31 + sc);
  vec2 st = vec2(q.x, q.y / 3. + t * .05 + cr);
  vec2 id = floor(st), f = fract(st) - .5;
  float n = h21(id + sc);
  float pr = fract(t * (.12 + .1 * n) + n * 7.) * 4.;                              // stick-slip progress down the cell
  pr = (floor(pr) + smoothstep(.2, .8, fract(pr))) / 4.;
  float y = .42 - pr * .84, x = (n - .5) * .5 + sin(y * 9. + n * 20.) * .05;
  vec2 dp = vec2(f.x - x, (f.y - y) * 3.);
  dp.y *= dp.y > 0. ? .8 : 1.15;
  float r = .16 + .06 * h11(n * 9.), dl = length(dp);
  float m = smoothstep(r, r * .8, dl) * step(.15, n);
  // the trail: droplets left behind above the drop
  float ty = (f.y - y) * 3.;
  vec2 td = vec2(f.x - x, (fract(f.y * 3. * 4.) - .5) / 4.);
  float tf = smoothstep(.0, .2, ty) * smoothstep(2.4, .3, ty) * step(.15, n);
  float r2 = .06 * tf * (.5 + .5 * h11(floor(f.y * 12.) + n));
  float tm = smoothstep(r2, r2 * .5, length(td)) * step(.004, r2);   // (equal smoothstep edges are undefined: guard)
  float trail = smoothstep(.2, .0, abs(f.x - x)) * tf;
  vec2 off = dp / r * m + td / max(r2, .004) * tm * .6;
  return vec4(off, max(m, tm), trail);
}
vec3 staticDrops(vec2 uv, float sc, float t){
  vec2 p = uv * sc, id = floor(p), f = fract(p) - .5;
  float n = h21(id + 2.3);
  vec2 o = (h22(id + 5.1) - .5) * .6;
  float life = fract(t * .06 + n * 5.);
  float r = (.08 + .14 * h11(n * 3.)) * smoothstep(0., .05, life) * smoothstep(1., .7, life);
  float m = smoothstep(r, r * .75, length(f - o)) * step(.55, n) * step(.01, r);
  return vec3((f - o) / max(r, .01) * m, m);
}
vec3 scene(vec2 fc){
  vec2 uv = (fc - .5 * R) / R.y;
  LT = smoothstep(.3, .7, lum(uBase));
  float t = T * (1. + uSpeed * .8);
  vec4 a = slide(uv, 5., t), b2 = slide(uv * 1.3 + 3.7, 9., t * 1.1);
  vec3 s = staticDrops(uv, 24., t), s2 = staticDrops(uv + .51, 40., t * 1.3);
  vec2 off = a.xy + b2.xy * .7 + s.xy * .5 + s2.xy * .3;
  float m = max(max(a.z, b2.z), max(s.z, s2.z));
  float tr = max(a.w, b2.w);
  // through a drop the city is flipped and sharper; elsewhere it's a soft blur behind misted glass
  vec2 cuv = uv + uCam * .012 - off * .018;
  vec3 col = city(cuv, mix(1., .55, m));
  vec3 mist = mix(mix(vec3(.04, .03, .03), hue(uAcc) * .015, .3), vec3(.6, .62, .65), LT);
  col = mix(col, mist + col * .5, .45 * (1. - max(m, tr * .7)) );
  // drop shading: dark refraction rim and a small highlight
  float e = length(off);
  col *= 1. - mix(.3, .12, LT) * smoothstep(.7, 1., e) * m;
  col += mix(vec3(.03, .025, .03), vec3(.1), LT) * m * (.5 + .5 * e);                // drops catch the ambient city glow
  col += mix(vec3(.25), vec3(.5), LT) * pow(max(dot(normalize(vec3(off, .7)), normalize(vec3(-.5, .6, .6))), 0.), 24.) * m;
  col *= 1. + uBeat * .05;
  return aces(col * mix(1.2, .9, LT));
}`],
});
