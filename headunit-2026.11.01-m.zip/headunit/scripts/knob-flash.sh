#!/bin/bash
# Builds the knob firmware (knob/HeadUnitKnob) and flashes it to the knob over USB.
# The first run downloads the ESP32 tools (a few hundred MB, needs internet). Later runs take about a minute.
set -e -o pipefail
CLI="$HOME/.local/bin/arduino-cli"
FQBN="esp32:esp32:esp32s3:CDCOnBoot=cdc,PSRAM=opi"
SKETCH="$(cd "$(dirname "$0")/.." && pwd)/knob/HeadUnitKnob"
BUILD="$HOME/.cache/headunit/knob-build"

if [[ ! -x $CLI ]]; then
  echo "Installing the firmware tools (first time only)…"
  mkdir -p "$HOME/.local/bin"
  curl -fsSL https://downloads.arduino.cc/arduino-cli/arduino-cli_latest_Linux_ARM64.tar.gz | tar xz -C "$HOME/.local/bin" arduino-cli
fi
if ! "$CLI" core list 2>/dev/null | grep -q '^esp32:esp32'; then
  echo "Downloading the ESP32 tools (first time only, a few minutes)…"
  "$CLI" config init --overwrite >/dev/null
  "$CLI" config add board_manager.additional_urls https://espressif.github.io/arduino-esp32/package_esp32_index.json
  "$CLI" core update-index >/dev/null
  "$CLI" core install esp32:esp32 >/dev/null
fi
"$CLI" lib list 2>/dev/null | grep -q 'GFX Library for Arduino' || "$CLI" lib install "GFX Library for Arduino" >/dev/null

echo "Building the knob firmware…"
mkdir -p "$BUILD"
rm -f "$BUILD/HeadUnitKnob.ino.bin"
"$CLI" compile -b "$FQBN" --output-dir "$BUILD" "$SKETCH" 2>&1 | grep -E "error|Sketch uses" || true
# (a failed build is caught by the check below)
[[ -f $BUILD/HeadUnitKnob.ino.bin ]] || { echo "The build failed."; exit 1; }

PORT="$(ls /dev/serial/by-id/*Espressif* /dev/serial/by-id/*ESP32* 2>/dev/null | head -1 || true)"
[[ -n $PORT ]] || PORT="$(ls /dev/ttyACM* 2>/dev/null | head -1 || true)"
[[ -n $PORT ]] || { echo "The knob isn't plugged in (no USB serial port found)."; exit 1; }

echo "Flashing the knob on $PORT…"
for try in 1 2; do
  if "$CLI" upload -b "$FQBN" -p "$PORT" --input-dir "$BUILD" "$SKETCH" 2>&1 | tail -3; then
    echo "Knob updated. It restarts by itself."; exit 0
  fi
  echo "Retrying…"; sleep 3
done
echo "Flashing didn't work. Hold the knob's BOOT button while plugging it in, then try again."
exit 1
