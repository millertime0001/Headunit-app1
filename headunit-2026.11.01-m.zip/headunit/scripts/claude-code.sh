#!/bin/bash
# Gets everything ready to work with Claude Code from the phone, in one go:
#   1. SSH on the Pi is running
#   2. the USB tunnel is open, so ConnectBot on the phone reaches the Pi at ryan@127.0.0.1:2222
#   3. Claude Code is running in a tmux session called "claude" (and Remote Control is switched on)
# Run from Settings > Tools > "Start Claude Code", or in the phone terminal: bash ~/headunit/scripts/claude-code.sh

echo "— SSH —"
if systemctl is-active --quiet ssh; then
  echo "SSH is running."
else
  sudo -n systemctl enable --now ssh 2>&1 | tail -n 2 && echo "SSH started."
fi

echo
echo "— Tunnel to the phone —"
found=0
for s in $(adb devices 2>/dev/null | awk 'NR>1 && $2=="device" {print $1}'); do
  if adb -s "$s" reverse tcp:2222 tcp:22 >/dev/null 2>&1; then
    echo "Open: the phone reaches the Pi at 127.0.0.1:2222 ($s)"
    found=1
  fi
done
[ "$found" = 1 ] || echo "The phone isn't connected over ADB. Plug it into the Pi and tap this again."

echo
echo "— Claude Code —"
CLAUDE="$HOME/.local/bin/claude"
if [ ! -x "$CLAUDE" ]; then
  CLAUDE="$(command -v claude || true)"
fi
if [ -z "$CLAUDE" ]; then
  echo "Claude Code isn't installed yet. With USB tethering on, run in the phone terminal:"
  echo "  curl -fsSL https://claude.ai/install.sh | bash"
  exit 1
fi
if ! command -v tmux >/dev/null; then
  echo "Installing tmux…"
  sudo -n apt-get install -y tmux >/dev/null 2>&1 || { echo "Couldn't install tmux. Run: sudo apt install -y tmux"; exit 1; }
fi
if tmux has-session -t claude 2>/dev/null; then
  echo "Already running."
else
  tmux new-session -d -s claude -c "$HOME/headunit" "$CLAUDE"
  echo "Started."
  sleep 8   # give it a moment to start, then turn on Remote Control for the Claude app
  tmux send-keys -t claude "/remote-control" Enter
  echo "Remote Control switched on."
fi

echo
echo "Next: in the Claude app tap Code, or in ConnectBot connect to ryan@127.0.0.1:2222 and type:"
echo "  tmux attach -t claude"
echo "(If it's the first time, it asks you to log in there.)"
