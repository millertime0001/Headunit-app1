#!/usr/bin/env bash
# Pi Head Unit installer for Raspberry Pi OS LITE (64-bit, no desktop).
# There is no desktop, taskbar or file manager: the Pi boots straight into the head unit.
#   cd ~/headunit && ./install-lite.sh
set -euo pipefail

HU_DIR="$(cd "$(dirname "$0")" && pwd)"
SCRCPY_TAG="v3.1"
say() { printf '\n\033[1;36m==> %s\033[0m\n' "$*"; }

if [[ $EUID -eq 0 ]]; then
  echo "Run this as your normal user, not with sudo:  ./install-lite.sh"
  exit 1
fi
if [[ "$(uname -m)" != "aarch64" ]]; then
  echo "This needs 64-bit Raspberry Pi OS on a Pi 5."
  exit 1
fi

say "Installing system packages (this takes a few minutes)"
sudo apt-get update
sudo apt-get install -y \
  python3-venv curl git ofono bluez bluez-tools \
  pipewire pipewire-bin pipewire-pulse wireplumber libspa-0.2-bluetooth \
  adb ffmpeg libsdl2-2.0-0 libusb-1.0-0 \
  labwc xwayland wlr-randr fonts-dejavu-core plymouth plymouth-themes \
  gcc pkg-config meson ninja-build wget \
  libsdl2-dev libavcodec-dev libavdevice-dev libavformat-dev libavutil-dev libswresample-dev libusb-1.0-0-dev
sudo apt-get install -y chromium || sudo apt-get install -y chromium-browser
for optional in fonts-inter fonts-noto-color-emoji rpd-plymouth-splash ddcutil android-sdk-platform-tools-common; do
  sudo apt-get install -y "$optional" || echo "(skipped optional package $optional)"
done

say "Installing scrcpy $SCRCPY_TAG (streams Google Maps and YouTube Music from your phone)"
need_scrcpy=1
if command -v scrcpy >/dev/null; then
  major="$(scrcpy --version 2>/dev/null | head -1 | sed -E 's/^scrcpy ([0-9]+).*/\1/')"
  [[ "${major:-0}" =~ ^[0-9]+$ ]] && (( major >= 3 )) && need_scrcpy=0
fi
if (( need_scrcpy )); then
  rm -rf /tmp/scrcpy-src
  git clone --depth 1 --branch "$SCRCPY_TAG" https://github.com/Genymobile/scrcpy /tmp/scrcpy-src
  (cd /tmp/scrcpy-src && ./install_release.sh)
else
  echo "scrcpy $(scrcpy --version | head -1) already installed"
fi

say "Setting up the backend"
python3 -m venv "$HU_DIR/venv"
"$HU_DIR/venv/bin/pip" install --upgrade pip >/dev/null
"$HU_DIR/venv/bin/pip" install aiohttp dbus-next pyserial
chmod +x "$HU_DIR/scripts/"*.sh

say "Audio: DAC8x + 5-channel processor"
CONFIG_TXT=/boot/firmware/config.txt
[[ -f $CONFIG_TXT ]] || CONFIG_TXT=/boot/config.txt
sudo cp -n "$CONFIG_TXT" "$CONFIG_TXT.before-headunit" || true
grep -q '^dtoverlay=hifiberry-dac8x' "$CONFIG_TXT" || echo 'dtoverlay=hifiberry-dac8x' | sudo tee -a "$CONFIG_TXT" >/dev/null
grep -q '^disable_splash=' "$CONFIG_TXT" || echo 'disable_splash=1' | sudo tee -a "$CONFIG_TXT" >/dev/null
# 5V/5A buck converters can't tell the Pi they're 5A (no USB-PD), so the Pi would limit the USB
# ports to 600 mA total — starving the phone, knob and mic. This tells it the supply is 5A.
grep -q '^usb_max_current_enable=' "$CONFIG_TXT" || echo 'usb_max_current_enable=1' | sudo tee -a "$CONFIG_TXT" >/dev/null
mkdir -p ~/.config/pipewire/pipewire.conf.d
cp "$HU_DIR/config/pipewire/hu-dsp.conf" ~/.config/pipewire/pipewire.conf.d/
mkdir -p ~/.config/wireplumber/wireplumber.conf.d ~/.config/wireplumber/bluetooth.lua.d
cp "$HU_DIR/config/wireplumber/51-headunit.conf" ~/.config/wireplumber/wireplumber.conf.d/
cp "$HU_DIR/config/wireplumber/51-headunit.lua" ~/.config/wireplumber/bluetooth.lua.d/

say "Bluetooth: car stereo mode, auto-accept pairing, hands-free calls"
sudo python3 - <<'PY'
import re
path = "/etc/bluetooth/main.conf"
want = {"Name": "Pi Head Unit", "Class": "0x240420", "DiscoverableTimeout": "180", "FastConnectable": "true"}
lines = open(path).read().splitlines()
out, in_general, done = [], False, set()
for line in lines:
    sec = re.match(r"^\s*\[(.+)\]", line)
    if sec:
        if in_general:
            out += [f"{k} = {v}" for k, v in want.items() if k not in done]
            done.update(want)
        in_general = sec.group(1) == "General"
        out.append(line)
        continue
    m = re.match(r"^\s*#?\s*(\w+)\s*=", line)
    if in_general and m and m.group(1) in want and m.group(1) not in done:
        out.append(f"{m.group(1)} = {want[m.group(1)]}")
        done.add(m.group(1))
        continue
    out.append(line)
if in_general:
    out += [f"{k} = {v}" for k, v in want.items() if k not in done]
open(path, "w").write("\n".join(out) + "\n")
PY
sed "s/HU_USER/$USER/" "$HU_DIR/config/headunit-dbus.conf" | sudo tee /etc/dbus-1/system.d/headunit.conf >/dev/null
# Pairing is handled by the head unit itself; the old helper prompts on a terminal that isn't there
sudo systemctl disable --now bt-agent 2>/dev/null || true
sudo systemctl enable bluetooth ofono
sudo systemctl disable ModemManager 2>/dev/null || true
echo "$USER ALL=(root) NOPASSWD: /usr/bin/date" | sudo tee /etc/sudoers.d/headunit-clock >/dev/null
sudo chmod 440 /etc/sudoers.d/headunit-clock
sudo usermod -aG bluetooth,audio,video,input,plugdev,dialout "$USER"

bash "$HU_DIR/scripts/enable-tools.sh" || true

say "Screen: boot straight into the head unit (no desktop)"
# Log in automatically on the first console...
sudo mkdir -p /etc/systemd/system/getty@tty1.service.d
sudo tee /etc/systemd/system/getty@tty1.service.d/autologin.conf >/dev/null <<EOF
[Service]
ExecStart=
ExecStart=-/sbin/agetty --autologin $USER --noclear --skip-login --nohostname %I \$TERM
EOF
sudo systemctl set-default multi-user.target
# ...then start labwc, which runs only the head unit (its autostart is below)
touch ~/.profile
if ! grep -q "head unit: start labwc" ~/.profile; then
  cat >> ~/.profile <<'EOF'

# head unit: start labwc on the first console (SSH logins are unaffected)
if [ -z "$WAYLAND_DISPLAY" ] && [ "$(tty)" = /dev/tty1 ]; then
  exec labwc >"$HOME/.config/headunit/logs/labwc.log" 2>&1
fi
EOF
fi
mkdir -p ~/.config/headunit/logs
mkdir -p ~/.config/labwc
[[ -f ~/.config/labwc/autostart ]] && cp ~/.config/labwc/autostart ~/.config/labwc/autostart.before-headunit
sed "s#HU_DIR#$HU_DIR#" "$HU_DIR/config/labwc/autostart" > ~/.config/labwc/autostart
python3 - <<'PY'
import pathlib, re, shutil
user = pathlib.Path.home() / ".config/labwc/rc.xml"
system = pathlib.Path("/etc/xdg/labwc/rc.xml")
rules = """
    <windowRule title="HU-App" serverDecoration="no" skipTaskbar="yes" skipWindowSwitcher="yes">
      <action name="MoveTo" x="96" y="0" />
      <action name="ResizeTo" width="1184" height="800" />
      <action name="ToggleAlwaysOnTop" />
    </windowRule>
    <windowRule identifier="chrom*" serverDecoration="no">
      <action name="Maximize" />
    </windowRule>
"""
if not user.exists() and system.exists():
    shutil.copy(system, user)
if user.exists():
    s = user.read_text()
    if "HU-App" not in s:
        shutil.copy(user, user.with_suffix(".xml.before-headunit"))
        if "<windowRules>" in s:
            s = s.replace("<windowRules>", "<windowRules>" + rules, 1)
        else:
            s = re.sub(r"(</(labwc_config|openbox_config)>\s*)$", "  <windowRules>" + rules + "  </windowRules>\n\\1", s)
        user.write_text(s)
else:
    user.write_text('<?xml version="1.0"?>\n<labwc_config>\n  <windowRules>' + rules + '  </windowRules>\n</labwc_config>\n')
PY
# Chromium: use the window manager's (removable) title bar instead of drawing its own
PREFS=~/.config/headunit/chromium/Default
mkdir -p "$PREFS"
[[ -f "$PREFS/Preferences" ]] || echo '{"browser":{"custom_chrome_frame":false},"profile":{"exit_type":"Normal","exited_cleanly":true}}' > "$PREFS/Preferences"

say "Wi-Fi: the Pi makes its own network for your phone (no phone hotspot needed)"
"$HU_DIR/scripts/setup-hotspot.sh"

say "Clean startup: no boot text, your own splash, no desktop flash"
CMDLINE=/boot/firmware/cmdline.txt
[[ -f $CMDLINE ]] || CMDLINE=/boot/cmdline.txt
sudo cp -n "$CMDLINE" "$CMDLINE.before-headunit" || true
for opt in quiet splash loglevel=3 logo.nologo vt.global_cursor_default=0 consoleblank=0; do
  grep -qw -- "$opt" "$CMDLINE" || sudo sed -i "1 s/\$/ $opt/" "$CMDLINE"
done
bash "$HU_DIR/scripts/set-splash.sh" || echo "The boot splash didn't install. Run scripts/set-splash.sh again later."
bash "$HU_DIR/scripts/fix-boot-flash.sh" || echo "Couldn't hide the boot screen flashes. Run scripts/fix-boot-flash.sh again later."

say "Trimming boot time"
for svc in NetworkManager-wait-online cups cups-browsed triggerhappy; do
  sudo systemctl disable "$svc" 2>/dev/null || true
done

say "Done!"
cat <<EOF

Next:
  1. Reboot:  sudo reboot
  2. On the Pi screen, open Settings and tap "Pair a phone", then pair "Pi Head Unit"
     from your phone's Bluetooth menu. Allow contacts/calls when the phone asks.
  3. For Maps and YouTube Music: turn on USB debugging on your phone, plug it into
     the Pi by USB, and tap "Allow" on the phone.
  4. On your phone, join the Wi-Fi "Pi Head Unit" (password shown in Settings on the
     Pi screen and in ~/.config/headunit/hotspot.json). When Android says it has no
     internet, choose to stay connected. Turn OFF any "switch to mobile data" or
     "auto network switch" option for this network.

Note: after reboot the Pi's Wi-Fi becomes the hotspot, so it stops joining your home
Wi-Fi. For updates, run scripts/hotspot-off.sh, then scripts/hotspot-on.sh after.

Logs live in ~/.config/headunit/logs if anything misbehaves.
SSH still works as normal for fixing things.

Later, once pairing and settings are how you want them, you can protect the Pi from
sudden power cuts:  sudo raspi-config nonint do_overlayfs 0
(Changes then vanish at every reboot, including new pairings. Undo with 1 instead of 0.)
EOF
read -r -p "Reboot now? [Y/n] " ans
[[ "${ans:-Y}" =~ ^[Yy]$ ]] && sudo reboot
