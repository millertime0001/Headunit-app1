package com.headunit.link

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.io.InputStream
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

/**
 * The Design Studio: the head unit's own screen code running in a WebView, with an editor around it.
 * Pages are served from https://studio.local/ out of this app: first from files fetched from the
 * head unit (so a head unit update also updates the Studio), otherwise from the copy built into the app.
 */
class StudioActivity : Activity() {
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var web: WebView
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var pendingImport: String? = null
    private val synced by lazy { File(filesDir, "hu") }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WebView.setWebContentsDebuggingEnabled(true)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = false
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.addJavascriptInterface(Bridge(), "HUApp")
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                val url = request.url
                if (url.host != HOST) return null
                return serve(url.path ?: "/")
            }
            override fun onPageFinished(view: WebView, url: String) {
                pendingImport?.let { text ->
                    pendingImport = null
                    ui.postDelayed({ web.evaluateJavascript("studioImport(${JSONObject.quote(text)})", null) }, 600)
                }
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(view: WebView, callback: ValueCallback<Array<Uri>>, params: WebChromeClient.FileChooserParams): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                return try {
                    startActivityForResult(params.createIntent(), PICK_FILE); true
                } catch (e: Exception) {
                    fileCallback = null; false
                }
            }
        }
        setContentView(web)
        readOpenedFile(intent)
        web.loadUrl("https://$HOST/studio")
        Thread { syncFromHeadUnit() }.start()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        readOpenedFile(intent)?.let { web.evaluateJavascript("studioImport(${JSONObject.quote(it)})", null); pendingImport = null }
    }

    /** A design file opened with this app (from Files, Downloads or a chat) gets added to the library. */
    private fun readOpenedFile(intent: Intent?): String? {
        if (intent == null) return null
        val uri: Uri? = when (intent.action) {
            Intent.ACTION_VIEW -> intent.data
            Intent.ACTION_SEND -> intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
            else -> null
        }
        var text: String? = null
        if (uri != null) {
            text = try {
                contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) }
            } catch (_: Exception) {
                null
            }
        }
        if (text == null) text = intent.getStringExtra(Intent.EXTRA_TEXT)?.takeIf { it.contains("headunit-design") }
        if (text != null) pendingImport = text
        return text
    }

    @Deprecated("Kept simple on purpose")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_FILE) {
            fileCallback?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
            fileCallback = null
        }
    }

    @Deprecated("Kept simple on purpose")
    override fun onBackPressed() { if (web.canGoBack()) web.goBack() else super.onBackPressed() }

    // ------------------------------------------------------------------ serving the pages
    private fun serve(path: String): WebResourceResponse {
        val rel = when {
            path == "/" || path.isEmpty() -> "index.html"
            path == "/studio" -> "studio.html"
            path.startsWith("/static/") -> path.removePrefix("/static/")
            else -> path.trimStart('/')
        }
        if (rel.contains("..")) return notFound()
        val stream: InputStream? = File(synced, rel).takeIf { it.isFile }?.inputStream()
            ?: try { assets.open("hu/$rel") } catch (_: Exception) { null }
        stream ?: return notFound()
        val type = when (rel.substringAfterLast('.')) {
            "html" -> "text/html"; "js" -> "application/javascript"; "css" -> "text/css"; "json" -> "application/json"
            "svg" -> "image/svg+xml"; "png" -> "image/png"; "woff2" -> "font/woff2"; "ttf" -> "font/ttf"
            else -> "application/octet-stream"
        }
        return WebResourceResponse(type, "utf-8", stream).apply { responseHeaders = mapOf("Cache-Control" to "no-cache") }
    }
    private fun notFound() = WebResourceResponse("text/plain", "utf-8", 404, "Not found", emptyMap(), "".byteInputStream())

    // ------------------------------------------------------------------ talking to the head unit
    /** USB tunnel first, then the Pi's Wi-Fi (bound to it, because that network has no internet). */
    private fun piRoutes(): List<Pair<OkHttpClient, String>> {
        val base = OkHttpClient.Builder().connectTimeout(3, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).build()
        val out = mutableListOf(base to "http://127.0.0.1:8080")
        val cm = getSystemService(ConnectivityManager::class.java)
        for (net in cm.allNetworks) {
            val caps = cm.getNetworkCapabilities(net) ?: continue
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) out += base.newBuilder().socketFactory(net.socketFactory).build() to "http://10.42.0.1:8080"
        }
        return out
    }

    private fun sendDesign(json: String): String {
        val body = json.toRequestBody("application/json".toMediaType())
        val last = "Couldn’t reach the head unit. Join the “Pi Head Unit” Wi-Fi or plug into the Pi."
        for ((client, base) in piRoutes()) {
            try {
                client.newCall(Request.Builder().url("$base/design").post(body).build()).execute().use { r ->
                    val text = r.body?.string().orEmpty()
                    return if (r.isSuccessful) text.ifBlank { "Sent." } else text.ifBlank { "The head unit refused it (${r.code})." }
                }
            } catch (_: Exception) { }
        }
        return last
    }

    /** Fetches any screen files that changed on the head unit, so previews match the car exactly. */
    private fun syncFromHeadUnit() {
        for ((client, base) in piRoutes()) {
            try {
                val manifest = client.newCall(Request.Builder().url("$base/studio/manifest").build()).execute().use { r ->
                    if (!r.isSuccessful) null else JSONObject(r.body!!.string())
                } ?: continue
                val files = manifest.getJSONObject("files")
                var changed = 0
                for (name in files.keys()) {
                    if (name.contains("..")) continue
                    val want = files.getString(name)
                    if (want == localHash(name)) continue
                    val bytes = client.newCall(Request.Builder().url("$base/static/$name").build()).execute().use { r ->
                        if (r.isSuccessful) r.body?.bytes() else null
                    } ?: continue
                    File(synced, name).apply { parentFile?.mkdirs(); writeBytes(bytes) }
                    changed++
                }
                if (changed > 0) ui.post {
                    Toast.makeText(this, "Studio updated to match the head unit (${manifest.optString("version")})", Toast.LENGTH_SHORT).show()
                    web.reload()
                }
                return
            } catch (_: Exception) { }
        }
    }

    private fun localHash(name: String): String? {
        val bytes = File(synced, name).takeIf { it.isFile }?.readBytes()
            ?: try { assets.open("hu/$name").use { it.readBytes() } } catch (_: Exception) { return null }
        return MessageDigest.getInstance("SHA-1").digest(bytes).joinToString("") { "%02x".format(it) }
    }

    // ------------------------------------------------------------------ what the page can call
    inner class Bridge {
        private val lib get() = File(filesDir, "designs.json")

        @JavascriptInterface fun loadLib(): String = if (lib.isFile) lib.readText() else "[]"

        @JavascriptInterface fun saveLib(json: String) {
            val tmp = File(filesDir, "designs.tmp"); tmp.writeText(json); tmp.renameTo(lib)
        }

        @JavascriptInterface fun send(json: String) {
            Thread {
                val msg = try { sendDesign(json) } catch (e: Exception) { "Sending failed: ${e.message}" }
                ui.post { web.evaluateJavascript("studioSent(${JSONObject.quote(msg)})", null) }
            }.start()
        }

        /** Saves the design file to Downloads, where you can attach it in a chat or share it. */
        @JavascriptInterface fun share(name: String, json: String) {
            ui.post {
                try {
                    val values = ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, name)
                        put(MediaStore.Downloads.MIME_TYPE, "application/json")
                    }
                    val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)!!
                    contentResolver.openOutputStream(uri)!!.use { it.write(json.toByteArray()) }
                    Toast.makeText(this@StudioActivity, "Saved to Downloads: $name", Toast.LENGTH_LONG).show()
                } catch (e: Exception) {
                    Toast.makeText(this@StudioActivity, "Couldn’t save the file: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    companion object {
        private const val HOST = "studio.local"
        private const val PICK_FILE = 21
    }
}
