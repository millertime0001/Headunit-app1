package com.headunit.link

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.util.Base64
import java.io.ByteArrayOutputStream
import kotlin.math.max
import kotlin.math.min

object Images {
    fun drawableToPngBase64(d: Drawable, size: Int): String {
        val b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        d.setBounds(0, 0, size, size)
        d.draw(Canvas(b))
        return encode(b, Bitmap.CompressFormat.PNG, 100)
    }

    fun bitmapToJpegBase64(src: Bitmap, maxSide: Int): String {
        val soft = if (src.config == Bitmap.Config.HARDWARE) src.copy(Bitmap.Config.ARGB_8888, false) else src
        val scale = min(1f, maxSide.toFloat() / max(soft.width, soft.height))
        val b = if (scale < 1f) {
            Bitmap.createScaledBitmap(soft, (soft.width * scale).toInt().coerceAtLeast(1),
                (soft.height * scale).toInt().coerceAtLeast(1), true)
        } else soft
        return encode(b, Bitmap.CompressFormat.JPEG, 82)
    }

    private fun encode(b: Bitmap, fmt: Bitmap.CompressFormat, q: Int): String {
        val out = ByteArrayOutputStream()
        b.compress(fmt, q, out)
        return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }
}
