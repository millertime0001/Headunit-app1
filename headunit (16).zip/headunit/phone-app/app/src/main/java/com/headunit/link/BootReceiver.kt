package com.headunit.link

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Starts the link again after the phone restarts or the app is updated. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (context.getSharedPreferences("link", Context.MODE_PRIVATE).getBoolean("enabled", true)) {
            try {
                context.startForegroundService(Intent(context, LinkService::class.java))
            } catch (_: Exception) { }
        }
    }
}
