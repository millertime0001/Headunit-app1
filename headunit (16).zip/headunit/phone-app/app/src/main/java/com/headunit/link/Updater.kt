package com.headunit.link

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.provider.OpenableColumns
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

/**
 * Sends an update (headunit.zip, or the phone app's .apk) to the Pi, which installs it and restarts.
 * Tries the USB tunnel first, then the Pi's Wi-Fi (bound to that network, since it has no internet).
 */
object Updater {
    fun send(context: Context, uri: Uri): String {
        val cr = context.contentResolver
        var name = "headunit.zip"
        cr.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0)?.let { name = it }
        }
        val lower = name.lowercase()
        if (!lower.endsWith(".zip") && !lower.endsWith(".apk")) return "Pick headunit.zip or an .apk file."
        val bytes = cr.openInputStream(uri)?.use { it.readBytes() } ?: return "Couldn't read that file."

        val body = MultipartBody.Builder().setType(MultipartBody.FORM)
            .addFormDataPart("file", name, bytes.toRequestBody("application/octet-stream".toMediaType()))
            .build()
        val base = OkHttpClient.Builder()
            .connectTimeout(4, TimeUnit.SECONDS)
            .writeTimeout(120, TimeUnit.SECONDS)
            .readTimeout(120, TimeUnit.SECONDS)
            .build()

        val tries = mutableListOf<Pair<OkHttpClient, String>>(base to "http://127.0.0.1:8080/update")
        val cm = context.getSystemService(ConnectivityManager::class.java)
        for (net in cm.allNetworks) {
            val caps = cm.getNetworkCapabilities(net) ?: continue
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                tries += base.newBuilder().socketFactory(net.socketFactory).build() to "http://10.42.0.1:8080/update"
            }
        }
        var last = "Couldn't reach the head unit. Join the “Pi Head Unit” Wi-Fi or plug into the Pi by USB."
        for ((client, url) in tries) {
            try {
                client.newCall(Request.Builder().url(url).post(body).build()).execute().use { r ->
                    val text = r.body?.string().orEmpty()
                    return if (r.isSuccessful) text.ifBlank { "Update sent." } else text.ifBlank { "The head unit refused it (${r.code})." }
                }
            } catch (e: Exception) {
                last = "Couldn't reach the head unit (${e.javaClass.simpleName}). Check you're on the “Pi Head Unit” Wi-Fi."
            }
        }
        return last
    }
}
