package com.headunit.link

import android.app.Notification
import android.content.ComponentName
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Handler
import android.os.Looper
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Reads Google Maps' navigation notification (next turn) and the playing song's details
 * and album art. Needs "Notification access", which the Pi grants automatically over USB.
 */
class NotifListener : NotificationListenerService() {

    private var sessions: MediaSessionManager? = null
    private var current: MediaController? = null
    private val main = Handler(Looper.getMainLooper())

    private val sessionsListener =
        MediaSessionManager.OnActiveSessionsChangedListener { list -> pickSession(list) }

    private val callback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) = publish(metadata)
        override fun onQueueChanged(queue: MutableList<android.media.session.MediaSession.QueueItem>?) = Music.publishQueue()
        override fun onPlaybackStateChanged(state: PlaybackState?) {
            Music.onPlayback()
            val list = try {
                sessions?.getActiveSessions(ComponentName(this@NotifListener, NotifListener::class.java))
            } catch (e: SecurityException) { null }
            pickSession(list)
        }
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        Music.init(this)
        try {
            activeNotifications?.forEach { handle(it) }
        } catch (_: Exception) { }
        sessions = getSystemService(MediaSessionManager::class.java)
        val me = ComponentName(this, NotifListener::class.java)
        try {
            sessions?.addOnActiveSessionsChangedListener(sessionsListener, me, main)
            pickSession(sessions?.getActiveSessions(me))
        } catch (_: SecurityException) { }
    }

    override fun onListenerDisconnected() {
        try { sessions?.removeOnActiveSessionsChangedListener(sessionsListener) } catch (_: Exception) { }
        current?.unregisterCallback(callback)
        current = null
        super.onListenerDisconnected()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) = handle(sbn)

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        if (sbn.packageName == MAPS && sbn.isOngoing) Bus.nav.value = NavInfo(false)
    }

    private fun handle(sbn: StatusBarNotification) {
        if (sbn.packageName != MAPS || !sbn.isOngoing) return
        val ex = sbn.notification.extras
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = ex.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        val sub = ex.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString().orEmpty()
        if (title.isBlank() && text.isBlank()) return
        val icon = try {
            sbn.notification.getLargeIcon()?.loadDrawable(this)?.let { Images.drawableToPngBase64(it, 96) }
        } catch (_: Exception) { null }
        Bus.nav.value = NavInfo(true, title, text, sub, icon)
    }

    private fun pickSession(list: List<MediaController>?) {
        val pick = list?.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: list?.firstOrNull()
        if (pick?.sessionToken == current?.sessionToken) return
        current?.unregisterCallback(callback)
        current = pick
        pick?.registerCallback(callback, main)
        Music.onController(pick)
        publish(pick?.metadata)
    }

    private fun publish(m: MediaMetadata?) {
        m ?: return
        val title = m.getString(MediaMetadata.METADATA_KEY_TITLE) ?: return
        val artist = m.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: ""
        if (Bus.media.value?.title == title && Bus.media.value?.art != null) return
        val bmp = m.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: m.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: m.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        val art = try { bmp?.let { Images.bitmapToJpegBase64(it, 320) } } catch (_: Exception) { null }
        Bus.media.value = MediaInfo(title, artist, art)
    }

    companion object {
        const val MAPS = "com.google.android.apps.maps"
    }
}
