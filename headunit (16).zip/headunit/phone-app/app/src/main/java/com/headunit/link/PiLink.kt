package com.headunit.link

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.wifi.WifiNetworkSpecifier
import android.os.Build
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Keeps a connection to the head unit. Tries the USB tunnel first (127.0.0.1, set up by the Pi),
 * then the Pi's own Wi-Fi (10.42.0.1). Sockets for the Pi's Wi-Fi are bound to that network on
 * purpose: it has no internet, so Android would otherwise send them over mobile data.
 * The network is also requested (held), so Android doesn't drop it for having no internet.
 */
class PiLink(private val context: Context, private val scope: CoroutineScope) {
    private val cm = context.getSystemService(ConnectivityManager::class.java)
    private val base = OkHttpClient.Builder()
        .connectTimeout(3, TimeUnit.SECONDS)
        .pingInterval(15, TimeUnit.SECONDS)
        .build()

    @Volatile private var wifi: Network? = null
    @Volatile private var socket: WebSocket? = null
    @Volatile var connected = false
        private set
    var onConnected: (() -> Unit)? = null
    var onDisconnected: (() -> Unit)? = null

    private val netCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) { wifi = network }
        override fun onLost(network: Network) { if (wifi == network) wifi = null }
    }

    // ---- Holding the Pi's Wi-Fi like a smart-home or dashcam app does: ask Android for that exact
    // network (name + password). Android connects to it for this app and keeps it while the request
    // is held, even with no internet, and mobile data stays the phone's internet. The first time,
    // Android shows a one-time "Allow Head Unit Link to connect?" prompt. The Pi sends the name and
    // password whenever the app connects to it.
    private var heldSsid: String? = null
    private val specCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) { wifi = network }
        override fun onLost(network: Network) { if (wifi == network) wifi = null }
    }

    private fun holdPiWifi() {
        val prefs = context.getSharedPreferences("link", Context.MODE_PRIVATE)
        val ssid = prefs.getString("hotspot_ssid", null) ?: return
        val pass = prefs.getString("hotspot_pass", null) ?: return
        if (Build.VERSION.SDK_INT < 29 || ssid == heldSsid) return
        if (heldSsid != null) try { cm.unregisterNetworkCallback(specCallback) } catch (_: Exception) { }
        try {
            val spec = WifiNetworkSpecifier.Builder().setSsid(ssid).setWpa2Passphrase(pass).build()
            val req = NetworkRequest.Builder()
                .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .setNetworkSpecifier(spec)
                .build()
            cm.requestNetwork(req, specCallback)
            heldSsid = ssid
        } catch (_: Exception) { }
    }

    private fun saveHotspot(text: String) {
        try {
            val o = JSONObject(text)
            val ssid = o.getString("ssid"); val pass = o.getString("password")
            val prefs = context.getSharedPreferences("link", Context.MODE_PRIVATE)
            if (prefs.getString("hotspot_ssid", null) != ssid || prefs.getString("hotspot_pass", null) != pass) {
                prefs.edit().putString("hotspot_ssid", ssid).putString("hotspot_pass", pass).apply()
                if (heldSsid != null) {
                    try { cm.unregisterNetworkCallback(specCallback) } catch (_: Exception) { }
                    heldSsid = null
                }
            }
            holdPiWifi()
        } catch (_: Exception) { }
    }

    fun start() {
        holdPiWifi()
        val request = NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
            .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()
        // requestNetwork (not just a listener) tells Android this app needs the Pi's Wi-Fi, so it
        // stays connected even though that network has no internet. Mobile data stays the default.
        try { cm.requestNetwork(request, netCallback) } catch (_: Exception) {
            try { cm.registerNetworkCallback(request, netCallback) } catch (_: Exception) { }
        }
        scope.launch {
            Bus.status.value = "Looking for the head unit…"
            while (isActive) {
                if (!connected) connectOnce()
                delay(3000)
            }
        }
    }

    fun stop() {
        try { cm.unregisterNetworkCallback(netCallback) } catch (_: Exception) { }
        if (heldSsid != null) try { cm.unregisterNetworkCallback(specCallback) } catch (_: Exception) { }
        heldSsid = null
        socket?.close(1000, null)
    }

    fun send(obj: JSONObject): Boolean = socket?.send(obj.toString()) ?: false

    private suspend fun connectOnce() {
        val candidates = mutableListOf<Triple<String, OkHttpClient, String>>()
        candidates += Triple("ws://127.0.0.1:8080/ws", base, "Connected by USB")
        wifi?.let { net ->
            candidates += Triple("ws://10.42.0.1:8080/ws",
                base.newBuilder().socketFactory(net.socketFactory).build(), "Connected over the Pi's Wi-Fi")
        }
        for ((url, client, label) in candidates) {
            if (attempt(url, client, label)) return
        }
    }

    private suspend fun attempt(url: String, client: OkHttpClient, label: String): Boolean {
        val opened = CompletableDeferred<Boolean>()
        val ws = client.newWebSocket(Request.Builder().url(url).build(), object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                socket = webSocket
                connected = true
                Bus.status.value = label
                opened.complete(true)
                onConnected?.invoke()
            }
            override fun onMessage(webSocket: WebSocket, text: String) {
                // The Pi's state broadcasts aren't needed here; only its music commands are.
                if (text.startsWith("{\"type\": \"phone_cmd\"")) {
                    try { Music.handle(JSONObject(text)) } catch (_: Exception) { }
                } else if (text.startsWith("{\"type\": \"hotspot\"")) {
                    saveHotspot(text)
                }
            }
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                if (!opened.isCompleted) opened.complete(false) else dropped(webSocket)
            }
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) = dropped(webSocket)
        })
        val ok = withTimeoutOrNull(5000) { opened.await() } ?: false
        if (!ok) ws.cancel()
        return ok
    }

    private fun dropped(ws: WebSocket) {
        if (socket == ws) {
            socket = null
            connected = false
            Bus.status.value = "Looking for the head unit…"
            onDisconnected?.invoke()
        }
    }
}
