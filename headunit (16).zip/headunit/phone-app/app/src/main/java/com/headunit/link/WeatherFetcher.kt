package com.headunit.link

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume

/** Gets the weather on the phone (mobile data + phone location) so the Pi needs no internet. */
class WeatherFetcher(private val ctx: Context) {
    private val http = OkHttpClient.Builder().callTimeout(20, TimeUnit.SECONDS).build()

    suspend fun fetch(): JSONObject? {
        val loc = location() ?: return null
        return withContext(Dispatchers.IO) {
            val fahrenheit = Locale.getDefault().country in setOf("US", "LR", "MM", "BS", "BZ", "KY", "PW")
            val url = "https://api.open-meteo.com/v1/forecast?latitude=${loc.latitude}&longitude=${loc.longitude}" +
                "&current=temperature_2m,weather_code,is_day&daily=temperature_2m_max,temperature_2m_min" +
                "&temperature_unit=${if (fahrenheit) "fahrenheit" else "celsius"}&timezone=auto&forecast_days=1"
            http.newCall(Request.Builder().url(url).build()).execute().use { r ->
                if (!r.isSuccessful) return@withContext null
                val j = JSONObject(r.body?.string() ?: return@withContext null)
                val cur = j.getJSONObject("current")
                val daily = j.getJSONObject("daily")
                JSONObject()
                    .put("temp", cur.getDouble("temperature_2m"))
                    .put("code", cur.getInt("weather_code"))
                    .put("day", cur.optInt("is_day", 1) == 1)
                    .put("hi", daily.getJSONArray("temperature_2m_max").getDouble(0))
                    .put("lo", daily.getJSONArray("temperature_2m_min").getDouble(0))
                    .put("city", city(loc) ?: JSONObject.NULL)
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun city(loc: Location): String? = try {
        Geocoder(ctx, Locale.getDefault()).getFromLocation(loc.latitude, loc.longitude, 1)?.firstOrNull()?.locality
    } catch (_: Exception) { null }

    @SuppressLint("MissingPermission")
    private suspend fun location(): Location? {
        val granted = ctx.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!granted) return null
        val lm = ctx.getSystemService(LocationManager::class.java)
        val last = lm.getProviders(true).mapNotNull {
            try { lm.getLastKnownLocation(it) } catch (_: Exception) { null }
        }.maxByOrNull { it.time }
        if (last != null && System.currentTimeMillis() - last.time < 30 * 60_000L) return last
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val provider = when {
                lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
                lm.isProviderEnabled(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
                else -> null
            }
            if (provider != null) {
                val fresh = withTimeoutOrNull(20_000L) {
                    suspendCancellableCoroutine<Location?> { cont ->
                        lm.getCurrentLocation(provider, null, ctx.mainExecutor) { l -> if (cont.isActive) cont.resume(l) }
                    }
                }
                if (fresh != null) return fresh
            }
        }
        return last
    }
}
