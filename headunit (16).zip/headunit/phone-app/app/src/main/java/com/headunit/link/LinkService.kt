package com.headunit.link

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Looper
import android.os.Build
import android.os.IBinder
import android.provider.ContactsContract
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.text.DateFormat
import java.util.Date

/** Runs in the background and keeps the head unit up to date. */
class LinkService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private lateinit var link: PiLink
    private lateinit var weather: WeatherFetcher
    @Volatile private var lastWeather: JSONObject? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        goForeground()
        getSharedPreferences("link", MODE_PRIVATE).edit().putBoolean("enabled", true).apply()
        weather = WeatherFetcher(this)
        link = PiLink(this, scope)
        link.onConnected = { scope.launch { greet() }; startSpeed() }
        link.onDisconnected = { stopSpeed() }
        link.start()
        scope.launch { weatherLoop() }
        scope.launch { Bus.nav.collect { sendNav(it) } }
        scope.launch { Bus.media.collect { m -> m?.let { sendMedia(it) } } }
        scope.launch { Bus.queue.collect { q -> q?.let { link.send(JSONObject().put("cmd", "queue_push").put("queue", it)) } } }
        scope.launch { Bus.queueActive.collect { id -> id?.let { link.send(JSONObject().put("cmd", "queue_active").put("id", it)) } } }
        scope.launch { Bus.library.collect { l -> l?.let { link.send(JSONObject().put("cmd", "library_push").put("library", it)) } } }
        Music.init(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        stopSpeed()
        link.stop()
        scope.cancel()
        Bus.status.value = "Not running"
        super.onDestroy()
    }

    private fun goForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Head unit connection", NotificationManager.IMPORTANCE_MIN))
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
            .setContentTitle("Head Unit Link")
            .setContentText("Sharing weather, turns and album art with your car")
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        val hasLocation = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        try {
            val types = ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE or
                (if (hasLocation) ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION else 0)
            startForeground(1, n, types)
        } catch (_: Exception) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
        }
    }

    private suspend fun weatherLoop() {
        while (scope.isActive) {
            val w = try { weather.fetch() } catch (_: Exception) { null }
            if (w != null) {
                lastWeather = w
                Bus.weather.value = "Weather updated ${DateFormat.getTimeInstance(DateFormat.SHORT).format(Date())}"
                link.send(JSONObject().put("cmd", "weather_push").put("weather", w))
            } else if (lastWeather == null) {
                Bus.weather.value = "Waiting for location and mobile data…"
            }
            delay(if (w != null) 15 * 60_000L else 60_000L)
        }
    }

    private fun greet() {
        link.send(JSONObject().put("cmd", "phone_hello").put("name", Build.MODEL))
        link.send(JSONObject().put("cmd", "time_push").put("epoch", System.currentTimeMillis() / 1000.0))
        lastWeather?.let { link.send(JSONObject().put("cmd", "weather_push").put("weather", it)) }
        sendNav(Bus.nav.value)
        Bus.media.value?.let { sendMedia(it) }
        Music.publishQueue()
        sendFavorites()
        // keep the Pi's "phone app connected" status fresh
        scope.launch {
            while (link.connected) {
                delay(60_000L)
                link.send(JSONObject().put("cmd", "phone_hello").put("name", Build.MODEL))
            }
        }
    }

    private fun sendNav(n: NavInfo) {
        link.send(JSONObject().put("cmd", "nav_push").put("nav", JSONObject()
            .put("active", n.active).put("title", n.title).put("text", n.text).put("sub", n.sub)
            .put("icon", n.icon ?: JSONObject.NULL)))
    }

    private fun sendMedia(m: MediaInfo) {
        link.send(JSONObject().put("cmd", "media_art").put("title", m.title).put("artist", m.artist)
            .put("art", m.art ?: JSONObject.NULL))
    }

    /** Starred contacts become the favorites on the Pi's Home and Phone screens. */
    private fun sendFavorites() {
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return
        val list = JSONArray()
        val seen = HashSet<String>()
        try {
            contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
                "${ContactsContract.CommonDataKinds.Phone.STARRED} = 1", null,
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} ASC"
            )?.use { c ->
                while (c.moveToNext()) {
                    val name = c.getString(0) ?: continue
                    val number = c.getString(1) ?: continue
                    if (seen.add(name)) list.put(JSONObject().put("name", name).put("number", number))
                }
            }
        } catch (_: Exception) { }
        if (list.length() > 0) link.send(JSONObject().put("cmd", "favorites_push").put("favorites", list))
    }

    // ---- speed: GPS once a second, only while connected to the head unit
    private var speedOn = false
    private var lastFix: Location? = null
    // Full object (not a lambda) so Android 10 doesn't crash on the older listener methods
    private val speedListener = object : LocationListener {
        override fun onLocationChanged(loc: Location) {
            val prev = lastFix
            val mps = when {
                loc.hasSpeed() -> loc.speed.toDouble()
                prev != null && loc.time > prev.time -> loc.distanceTo(prev) / ((loc.time - prev.time) / 1000.0)
                else -> 0.0
            }
            lastFix = loc
            link.send(JSONObject().put("cmd", "speed_push").put("mps", if (mps < 0.5) 0.0 else mps))
        }
        @Deprecated("Deprecated in Android")
        override fun onStatusChanged(provider: String?, status: Int, extras: android.os.Bundle?) {}
        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}
    }

    @Suppress("MissingPermission")
    private fun startSpeed() {
        if (speedOn) return
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return
        val lm = getSystemService(LocationManager::class.java)
        try {
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, speedListener, Looper.getMainLooper())
            speedOn = true
        } catch (_: Exception) { }
    }

    private fun stopSpeed() {
        if (!speedOn) return
        try { getSystemService(LocationManager::class.java).removeUpdates(speedListener) } catch (_: Exception) { }
        speedOn = false
        lastFix = null
    }

    companion object {
        const val CHANNEL = "link"
    }
}
