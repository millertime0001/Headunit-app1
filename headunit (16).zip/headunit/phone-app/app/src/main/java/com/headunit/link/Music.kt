package com.headunit.link

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaDescription
import android.media.browse.MediaBrowser
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.service.media.MediaBrowserService
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/**
 * Music control for the head unit:
 *  - the queue ("Up next") of whatever is playing, read from its media session
 *  - browsing YouTube Music's library (playlists, albums) through its media browser,
 *    if YouTube Music allows it
 *  - playing a queue item, a library item, or a search ("my driving playlist")
 * The Pi sends commands as {"type": "phone_cmd", "do": ...}; results go out through Bus.
 */
object Music {
    const val YTM = "com.google.android.apps.youtube.music"

    @Volatile var controller: MediaController? = null
    private val main = Handler(Looper.getMainLooper())
    private val work = Executors.newSingleThreadExecutor()
    private var app: Context? = null
    private var browser: MediaBrowser? = null
    private var lastActive = Long.MIN_VALUE
    @Volatile private var sentIds: List<Long> = emptyList()   // the queue items the Pi has right now
    @Volatile private var sentSig = 0                          // fingerprint of the whole queue when sent
    private val iconCache = object : LinkedHashMap<String, String>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?) = size > 300
    }

    fun init(ctx: Context) { if (app == null) app = ctx.applicationContext }

    // ------------------------------------------------------------------ queue
    fun onController(c: MediaController?) {
        controller = c
        lastActive = Long.MIN_VALUE
        publishQueue()
    }

    /** Called when the playback state changes: republish only when the song in the queue changed. */
    fun onPlayback() {
        val c = controller ?: return
        val active = c.playbackState?.activeQueueItemId ?: return
        if (active == lastActive) return
        // Usually only the playing song moved within the same list: send just its id (a few bytes)
        // instead of the whole list with album art, which lagged badly over Wi-Fi.
        val q = c.queue ?: emptyList()
        val at = sentIds.indexOf(active)
        if (queueSig(q) == sentSig && at >= 0 && at < sentIds.size - 10) {
            lastActive = active
            Bus.queueActive.value = active
        } else {
            publishQueue()
        }
    }

    private fun queueSig(q: List<android.media.session.MediaSession.QueueItem>): Int {
        var h = q.size
        for (item in q) h = h * 31 + item.queueId.hashCode()
        return h
    }

    fun publishQueue() {
        val c = controller ?: return
        work.execute {
            try {
                val q = c.queue ?: emptyList()
                val active = c.playbackState?.activeQueueItemId ?: -1L
                lastActive = active
                val idx = q.indexOfFirst { it.queueId == active }.coerceAtLeast(0)
                val from = (idx - 5).coerceAtLeast(0)
                val to = minOf(q.size, from + 80)
                val items = JSONArray()
                for (i in from until to) {
                    val item = q[i]
                    val d = item.description
                    val o = JSONObject()
                        .put("id", item.queueId)
                        .put("title", d.title?.toString().orEmpty())
                        .put("artist", d.subtitle?.toString().orEmpty())
                    if (i - idx in -2..30) icon(d)?.let { o.put("art", it) }
                    items.put(o)
                }
                sentIds = (from until to).map { q[it].queueId }
                Bus.queueActive.value = null   // so the next "just the song changed" is always sent
                sentSig = queueSig(q)
                Bus.queue.value = JSONObject()
                    .put("app", c.packageName)
                    .put("title", c.queueTitle?.toString().orEmpty())
                    .put("active", active)
                    .put("items", items)
                    .put("at", System.currentTimeMillis())
            } catch (_: Exception) { }
        }
    }

    // ------------------------------------------------------------------ commands from the Pi
    fun handle(cmd: JSONObject) = main.post {
        try {
            when (cmd.optString("do")) {
                "queue_play" -> controller?.transportControls?.skipToQueueItem(cmd.optLong("id"))
                "queue_refresh" -> publishQueue()
                "browse" -> browse(cmd.optString("id", ""))
                "play_media" -> playMedia(cmd.optString("id"))
                "search" -> search(cmd.optString("query"))
            }
        } catch (_: Exception) { }
    }

    private fun ytmController(): MediaController? = try {
        val ctx = app ?: return null
        ctx.getSystemService(MediaSessionManager::class.java)
            ?.getActiveSessions(ComponentName(ctx, NotifListener::class.java))
            ?.firstOrNull { it.packageName == YTM }
    } catch (_: SecurityException) { null }

    private fun search(query: String) {
        if (query.isBlank()) return
        val live = ytmController()
        if (live != null) { live.transportControls.playFromSearch(query, Bundle()); return }
        withBrowser({ b -> MediaController(app!!, b.sessionToken).transportControls.playFromSearch(query, Bundle()) }) {
            controller?.transportControls?.playFromSearch(query, Bundle())
        }
    }

    private fun playMedia(id: String) {
        if (id.isEmpty()) return
        withBrowser({ b -> MediaController(app!!, b.sessionToken).transportControls.playFromMediaId(id, Bundle()) }) { msg ->
            Bus.library.value = JSONObject().put("status", "unavailable").put("message", msg)
        }
    }

    // ------------------------------------------------------------------ library (media browser)
    private fun findService(): ComponentName? {
        val ctx = app ?: return null
        val i = Intent(MediaBrowserService.SERVICE_INTERFACE).setPackage(YTM)
        val info = ctx.packageManager.queryIntentServices(i, 0).firstOrNull()?.serviceInfo ?: return null
        return ComponentName(info.packageName, info.name)
    }

    private fun withBrowser(then: (MediaBrowser) -> Unit, fail: (String) -> Unit) {
        main.post {
            val existing = browser
            if (existing != null && existing.isConnected) { then(existing); return@post }
            val ctx = app ?: return@post fail("The phone app isn't ready yet.")
            val comp = findService() ?: return@post fail("YouTube Music isn't installed on the phone.")
            var done = false
            lateinit var b: MediaBrowser
            b = MediaBrowser(ctx, comp, object : MediaBrowser.ConnectionCallback() {
                override fun onConnected() {
                    if (done) return
                    done = true
                    browser = b
                    try { then(b) } catch (e: Exception) { fail("YouTube Music didn't respond.") }
                }
                override fun onConnectionFailed() {
                    if (done) return
                    done = true
                    browser = null
                    fail("YouTube Music doesn't share its library with other apps. Search by name still works.")
                }
                override fun onConnectionSuspended() { browser = null }
            }, Bundle())
            b.connect()
            main.postDelayed({
                if (!done) { done = true; try { b.disconnect() } catch (_: Exception) { }; fail("YouTube Music didn't answer. Open it once, then try again.") }
            }, 9000)
        }
    }

    private fun browse(id: String) {
        Bus.library.value = JSONObject().put("status", "loading").put("parent", id)
        withBrowser({ b ->
            val parent = id.ifEmpty { b.root }
            b.subscribe(parent, object : MediaBrowser.SubscriptionCallback() {
                override fun onChildrenLoaded(parentId: String, children: MutableList<MediaBrowser.MediaItem>) {
                    try { b.unsubscribe(parentId) } catch (_: Exception) { }
                    val list = children.toList()
                    work.execute { publishLibrary(id, list) }
                }
                override fun onError(parentId: String) {
                    Bus.library.value = JSONObject().put("status", "unavailable").put("parent", id)
                        .put("message", "YouTube Music wouldn't open that list.")
                }
            })
        }) { msg -> Bus.library.value = JSONObject().put("status", "unavailable").put("parent", id).put("message", msg) }
    }

    private fun publishLibrary(parent: String, children: List<MediaBrowser.MediaItem>) {
        val items = JSONArray()
        children.take(100).forEachIndexed { i, item ->
            val d = item.description
            val o = JSONObject()
                .put("id", item.mediaId ?: "")
                .put("title", d.title?.toString().orEmpty())
                .put("subtitle", d.subtitle?.toString().orEmpty())
                .put("browsable", item.isBrowsable)
                .put("playable", item.isPlayable)
            if (i < 48) icon(d)?.let { o.put("art", it) }
            items.put(o)
        }
        Bus.library.value = JSONObject().put("status", "ok").put("parent", parent).put("items", items)
            .put("at", System.currentTimeMillis())
    }

    // ------------------------------------------------------------------ small pictures
    private fun icon(d: MediaDescription): String? {
        val key = d.iconUri?.toString() ?: d.mediaId ?: d.title?.toString() ?: return null
        iconCache[key]?.let { return it }
        val bmp: Bitmap? = d.iconBitmap ?: d.iconUri?.let { load(it) }
        val out = try { bmp?.let { Images.bitmapToJpegBase64(it, 112) } } catch (_: Exception) { null } ?: return null
        iconCache[key] = out
        return out
    }

    private fun load(uri: Uri): Bitmap? = try {
        when (uri.scheme) {
            "content", "android.resource", "file" ->
                app?.contentResolver?.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
            "http", "https" -> (URL(uri.toString()).openConnection() as HttpURLConnection).run {
                connectTimeout = 3000; readTimeout = 4000
                try { inputStream.use { BitmapFactory.decodeStream(it) } } finally { disconnect() }
            }
            else -> null
        }
    } catch (_: Exception) { null }
}
