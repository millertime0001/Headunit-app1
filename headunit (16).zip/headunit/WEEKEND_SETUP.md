# Weekend setup checklist

Everything is done in this order. Total hands-on time is about an hour.

## Before the weekend (on your PC, ~20 min)

**1. Build the phone app (pick one):**
- **GitHub (no installs):** make a new private repository, upload the *contents* of the
  `phone-app` folder (include the hidden `.github` folder). Open the **Actions** tab, wait for
  "Build APK" to finish (about 5 minutes), open the run, and download **HeadUnitLink**.
  Unzip it to get `HeadUnitLink.apk`.
- **Android Studio:** File → Open → `phone-app`. When it finishes syncing, choose
  Build → Build App Bundle(s) / APK(s) → Build APK(s). The APK lands in
  `app/build/outputs/apk/debug/app-debug.apk`; rename it to `HeadUnitLink.apk`.

Copy `HeadUnitLink.apk` into the `headunit/phone/` folder.

**2. Flash the knob:**
1. Install the Arduino IDE. In Boards Manager install **esp32 by Espressif** (latest 3.x).
2. In Library Manager install **GFX Library for Arduino** (by Moon On Our Nation).
3. Open `knob/HeadUnitKnob/HeadUnitKnob.ino`.
4. Tools → Board: **ESP32S3 Dev Module**, USB CDC On Boot: **Enabled**, PSRAM: **OPI PSRAM**.
5. Plug in the knob, pick its port, click Upload. It should say "Head unit / Connecting...".

**3. Flash the SD card:** Raspberry Pi Imager → Raspberry Pi OS (other) → **Raspberry Pi OS Lite (64-bit)**
(recommended: no desktop, so no taskbar; use `./install-lite.sh` in step 4). The full desktop
version with `./install.sh` still works too. In settings set
your username, password, **your country**, and your **home Wi-Fi** (only used for installing).

## At the car / on the bench (~30 min)

**4. Install:** boot the Pi, copy the `headunit` folder to your home folder, then:
```
cd ~/headunit && ./install-lite.sh
```
(Use `./install.sh` instead if you flashed the desktop version.)
Say yes to reboot. It boots straight into the head unit.

**5. Plug things into the Pi's 4 USB ports:** touchscreen touch cable, knob, USB microphone, phone cable.

**6. Phone, one time:**
1. Settings → About phone → tap Build number 7 times. In Developer options turn on
   **USB debugging** and **Disable adb authorization timeout**.
2. Plug into the Pi, tap **Allow** (tick *Always allow*). The Pi now installs the phone app,
   grants its permissions, and switches the phone to wireless mode for later.
3. On the Pi: Settings → **Pair a phone**. On the phone, pair with **Pi Head Unit** and allow
   calls and contacts.
4. On the phone, join the Wi-Fi **Pi Head Unit** (password is on the Pi's Settings screen).
   Choose to stay connected when it says "no internet", and turn off switching to mobile data
   for this network.
5. Star the contacts you want as favorites — they show up on the Pi automatically.

**7. Sound:** Sound → **Test speakers** with amp gains low. Swap RCA cables if a tone comes
from the wrong speaker.

## If something's off
Send me: `tail -50 ~/.config/headunit/logs/backend.log`
