#!/usr/bin/env bash
# Fewer screen flashes at startup:
#  1) the bootloader stops drawing its own screen (DISABLE_HDMI=1)
#  2) Linux starts straight at the screen's resolution, so it doesn't switch modes again
# Undo 1: run this script with "undo". Undo 2: remove video=... from cmdline.txt.
set -eu
CONF=/tmp/hu-eeprom.conf
sudo rpi-eeprom-config > "$CONF"
sed -i '/^DISABLE_HDMI=/d' "$CONF"
if [[ "${1:-}" == undo ]]; then echo "DISABLE_HDMI=0" >> "$CONF"; else echo "DISABLE_HDMI=1" >> "$CONF"; fi
sudo rpi-eeprom-config --apply "$CONF"

if [[ "${1:-}" != undo ]]; then
  CMDLINE=/boot/firmware/cmdline.txt
  [[ -f $CMDLINE ]] || CMDLINE=/boot/cmdline.txt
  grep -q "video=HDMI-A-1:" "$CMDLINE" || sudo sed -i '1 s/$/ video=HDMI-A-1:1024x600@60/' "$CMDLINE"
fi
echo "Done. Restart to use it: sudo reboot"
