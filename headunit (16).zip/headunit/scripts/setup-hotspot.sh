#!/usr/bin/env bash
# Makes the Pi broadcast its own Wi-Fi network for your phone to join.
# The phone keeps using mobile data for the internet; this network is only Pi <-> phone.
set -eu  # no pipefail: "tr | head" below would end the script early
CONF="$HOME/.config/headunit/hotspot.json"
mkdir -p "$(dirname "$CONF")"
SSID="Pi Head Unit"
if [[ -f "$CONF" ]]; then
  PASS="$(python3 -c "import json;print(json.load(open('$CONF'))['password'])")"
else
  PASS="$(tr -dc 'a-hjkmnp-z2-9' </dev/urandom | head -c 10)"
fi
COUNTRY="$(sudo raspi-config nonint get_wifi_country 2>/dev/null || true)"
if [[ -n "$COUNTRY" && "$COUNTRY" != "00" ]]; then BAND=a; CHANNEL=36; else BAND=bg; CHANNEL=6; fi
sudo nmcli connection delete HeadUnitHotspot >/dev/null 2>&1 || true
sudo nmcli connection add type wifi ifname wlan0 con-name HeadUnitHotspot ssid "$SSID" \
  802-11-wireless.mode ap 802-11-wireless.band "$BAND" 802-11-wireless.channel "$CHANNEL" \
  ipv4.method shared ipv4.addresses 10.42.0.1/24 ipv6.method disabled \
  wifi-sec.key-mgmt wpa-psk wifi-sec.psk "$PASS" \
  connection.autoconnect yes connection.autoconnect-priority 100 >/dev/null
"$(dirname "$0")/fix-phone-internet.sh" >/dev/null || true  # keep the phone on mobile data for internet
printf '{"ssid": "%s", "password": "%s", "ip": "10.42.0.1"}\n' "$SSID" "$PASS" > "$CONF"
[[ $BAND == a ]] || echo "Note: Wi-Fi country isn't set, so the hotspot uses 2.4 GHz. Set it with: sudo raspi-config (Localisation > WLAN Country), then rerun this script for faster 5 GHz."
echo "Hotspot \"$SSID\" ready (password: $PASS). It starts on the next boot."
