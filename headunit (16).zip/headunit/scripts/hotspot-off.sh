#!/usr/bin/env bash
# Temporarily switch the Pi back to normal Wi-Fi (for updates). Reboot or run hotspot-on.sh to undo.
sudo nmcli connection down HeadUnitHotspot || true
sudo nmcli connection modify HeadUnitHotspot connection.autoconnect no
echo "Hotspot off. The Pi will join your normal Wi-Fi now. Run hotspot-on.sh when done."
