#!/usr/bin/env bash
# Installs the head unit's own boot splash (a Plymouth theme called "headunit") and rebuilds the
# boot image so it shows from the very start. Safe to run again any time, for example after
# replacing config/splash.png with your own picture.
#   bash ~/headunit/scripts/set-splash.sh
set -e
HU_DIR="$(cd "$(dirname "$0")/.." && pwd)"
THEME=/usr/share/plymouth/themes/headunit

if ! command -v plymouth-set-default-theme >/dev/null; then
  echo "Installing the boot splash program..."
  sudo apt-get install -y plymouth plymouth-themes
fi

sudo mkdir -p "$THEME"
sudo cp "$HU_DIR/config/splash.png" "$THEME/splash.png"
sudo tee "$THEME/headunit.plymouth" >/dev/null <<EOT
[Plymouth Theme]
Name=Head Unit
Description=Pi Head Unit boot splash
ModuleName=script

[script]
ImageDir=$THEME
ScriptFile=$THEME/headunit.script
EOT
# Black screen, the picture fitted to the screen and fading in, nothing else.
sudo tee "$THEME/headunit.script" >/dev/null <<'EOT'
Window.SetBackgroundTopColor(0, 0, 0);
Window.SetBackgroundBottomColor(0, 0, 0);
img = Image("splash.png");
sw = Window.GetWidth(); sh = Window.GetHeight();
scale = Math.Min(sw / img.GetWidth(), sh / img.GetHeight());
img = img.Scale(img.GetWidth() * scale, img.GetHeight() * scale);
logo = Sprite(img);
logo.SetX(Window.GetX() + sw / 2 - img.GetWidth() / 2);
logo.SetY(Window.GetY() + sh / 2 - img.GetHeight() / 2);
logo.SetOpacity(0);
fade = 0;
tick = 0;
fun refresh() {
  tick = tick + 1;
  if (fade < 1) { fade = fade + 0.04; logo.SetOpacity(Math.Min(fade, 1)); }
  else { logo.SetOpacity(0.8 + 0.2 * Math.Cos(tick / 22)); }
}
Plymouth.SetRefreshFunction(refresh);
EOT

# The kernel line needs "splash" (show it) and "quiet" (no text over it).
CMDLINE=/boot/firmware/cmdline.txt
[[ -f $CMDLINE ]] || CMDLINE=/boot/cmdline.txt
for opt in quiet splash plymouth.ignore-serial-consoles loglevel=3 logo.nologo vt.global_cursor_default=0; do
  grep -qw -- "$opt" "$CMDLINE" || sudo sed -i "1 s/\$/ $opt/" "$CMDLINE"
done
# The boot image must be used (Pi OS normally has this on; older setups may not).
CONFIG_TXT=/boot/firmware/config.txt
[[ -f $CONFIG_TXT ]] || CONFIG_TXT=/boot/config.txt
grep -qE '^(auto_initramfs=1|initramfs )' "$CONFIG_TXT" || echo 'auto_initramfs=1' | sudo tee -a "$CONFIG_TXT" >/dev/null
grep -q '^disable_splash=' "$CONFIG_TXT" || echo 'disable_splash=1' | sudo tee -a "$CONFIG_TXT" >/dev/null

echo "Setting the splash and rebuilding the boot image (about a minute)..."
sudo plymouth-set-default-theme -R headunit

if lsinitramfs "/boot/initrd.img-$(uname -r)" 2>/dev/null | grep -q "themes/headunit/splash.png" ||
   lsinitramfs /boot/firmware/initramfs_2712 2>/dev/null | grep -q "themes/headunit/splash.png"; then
  echo "Done: the head unit splash is in the boot image. Restart to see it."
else
  echo "The theme is set, but I couldn't confirm it's in the boot image."
  echo "Run: sudo update-initramfs -u   then restart."
fi
