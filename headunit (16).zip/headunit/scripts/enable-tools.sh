#!/usr/bin/env bash
# One-time setup so the Tools buttons and the phone terminal can run commands that need sudo
# (mounting a USB stick, rebooting, the fix scripts) without asking for your password.
# The Pi is only reachable on its own password-protected Wi-Fi or by USB, and the phone
# terminal also needs a secret key that's only handed out over the phone's ADB connection.
set -eu
echo "$USER ALL=(ALL) NOPASSWD: ALL" | sudo tee /etc/sudoers.d/010-headunit-tools >/dev/null
sudo chmod 440 /etc/sudoers.d/010-headunit-tools
sudo visudo -cf /etc/sudoers.d/010-headunit-tools >/dev/null && echo "Done. Tools and the phone terminal can now use sudo."
