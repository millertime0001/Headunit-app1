#!/usr/bin/env bash
# Puts back the version from before the last update, then restarts the head unit.
set -eu
HU_DIR="$(cd "$(dirname "$0")/.." && pwd)"
PREV="$(dirname "$HU_DIR")/headunit-previous"
[[ -d "$PREV" ]] || { echo "No previous version saved."; exit 1; }
cp -a "$PREV/." "$HU_DIR/"
pkill -f "backend/server.py" || true
echo "Back to $(cat "$HU_DIR/VERSION" 2>/dev/null || echo the previous version)."
