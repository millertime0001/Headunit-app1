#!/usr/bin/env bash
# Starts the backend and the full-screen UI, restarting either if it crashes.
HU_DIR="$(cd "$(dirname "$0")/.." && pwd)"
LOGS="$HOME/.config/headunit/logs"
mkdir -p "$LOGS"

# Hide the desktop's taskbar and icons (only on full Pi OS; Lite has no desktop)
command -v wf-panel-pi >/dev/null && ( for _ in $(seq 1 30); do
    pkill -f lwrespawn; pkill -x wf-panel-pi; pkill -f "pcmanfm --desktop"
    sleep 1
  done ) >/dev/null 2>&1 &

# The UI sizes itself to the screen, and the resolution can be changed from Settings > Display.
MODE="$(wlr-randr 2>/dev/null | grep -m1 current | grep -oE '[0-9]+x[0-9]+')"
export HU_SCREEN="${MODE:-1280x800}"

( while true; do
    "$HU_DIR/venv/bin/python" "$HU_DIR/backend/server.py" >>"$LOGS/backend.log" 2>&1
    sleep 2
  done ) &


BROWSER="$(command -v chromium || command -v chromium-browser)"
while true; do
  "$BROWSER" --app="file://$HU_DIR/web/splash.html" --allow-file-access-from-files \
    --start-maximized --window-position=0,0 --force-device-scale-factor=1 --ozone-platform-hint=auto --lang=en-US \
    --user-data-dir="$HOME/.config/headunit/chromium" \
    --noerrdialogs --disable-infobars --no-first-run --disable-session-crashed-bubble \
    --disable-features=Translate,TranslateUI --disable-pinch --overscroll-history-navigation=0 \
    --password-store=basic --check-for-update-interval=31536000 \
    --enable-gpu-rasterization --ignore-gpu-blocklist \
    >>"$LOGS/ui.log" 2>&1
  sleep 1
done
