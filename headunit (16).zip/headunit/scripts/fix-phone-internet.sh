#!/usr/bin/env bash
# Stops the Pi's Wi-Fi from claiming to be a way to the internet. The Pi now hands the phone
# an address with no gateway and no DNS, so Android keeps using mobile data for the internet
# (voice assistant, Maps traffic, music) while still talking to the Pi over this Wi-Fi.
set -eu
sudo mkdir -p /etc/NetworkManager/dnsmasq-shared.d
sudo tee /etc/NetworkManager/dnsmasq-shared.d/headunit-local-only.conf >/dev/null <<'CONF'
# Pi Head Unit: local-only network. Send no router (3) and no DNS server (6).
dhcp-option=3
dhcp-option=6
CONF
sudo nmcli connection down HeadUnitHotspot >/dev/null 2>&1 || true
sudo nmcli connection up HeadUnitHotspot >/dev/null 2>&1 || true
echo "Done. On the phone, forget “Pi Head Unit” and join it again."
