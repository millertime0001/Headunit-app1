#!/usr/bin/env bash
sudo nmcli connection modify HeadUnitHotspot connection.autoconnect yes
sudo nmcli connection up HeadUnitHotspot
