#!/usr/bin/env bash
# Installs an update from a USB stick: finds the headunit folder (or headunit*.zip) on the stick,
# copies it over this install, and unmounts the stick. Used by the "Install update from USB" button.
set -eu
HU_DIR="$(cd "$(dirname "$0")/.." && pwd)"
MNT=/mnt/hu-usb
sudo mkdir -p "$MNT"
sudo umount "$MNT" 2>/dev/null || true
DEV=""
for d in /dev/sd?1 /dev/sd?; do
  [[ -b "$d" ]] || continue
  if sudo mount -o ro "$d" "$MNT" 2>/dev/null; then DEV="$d"; break; fi
done
[[ -n "$DEV" ]] || { echo "No USB stick found. Plug it in and try again."; exit 1; }
trap 'sudo umount "$MNT" 2>/dev/null || true' EXIT
SRC="$(find "$MNT" -maxdepth 4 -path '*/backend/server.py' 2>/dev/null | head -1)"
if [[ -n "$SRC" ]]; then
  SRC="$(dirname "$(dirname "$SRC")")"
else
  ZIP="$(find "$MNT" -maxdepth 2 -iname 'headunit*.zip' 2>/dev/null | sort | tail -1)"
  [[ -n "$ZIP" ]] || { echo "The stick has no headunit folder or headunit.zip on it."; exit 1; }
  rm -rf /tmp/hu-usb-update && mkdir -p /tmp/hu-usb-update
  unzip -q -o "$ZIP" -d /tmp/hu-usb-update
  SRC="$(dirname "$(dirname "$(find /tmp/hu-usb-update -maxdepth 4 -path '*/backend/server.py' | head -1)")")"
fi
python3 -m py_compile "$SRC/backend/server.py" || { echo "That update has an error in it, so nothing was changed."; exit 1; }
rm -rf "$(dirname "$HU_DIR")/headunit-previous"
cp -a "$HU_DIR" "$(dirname "$HU_DIR")/headunit-previous" 2>/dev/null || true
rm -rf "$(dirname "$HU_DIR")/headunit-previous/venv"
cp -r "$SRC/." "$HU_DIR/"
chmod +x "$HU_DIR"/scripts/*.sh
echo "Installed $(cat "$HU_DIR/VERSION" 2>/dev/null || echo the update) from $DEV."
