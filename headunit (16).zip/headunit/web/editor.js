// Freeform Home, take two: a 6 x 4 grid of big tiles.
// - Drag a panel anywhere: it follows your finger and a ghost shows where it will land
//   (green = fits, red = something's in the way, so it springs back).
// - Resize with the big corner handle. Every panel type has a minimum size, so nothing gets cramped.
// - Panels never overlap. "Tidy up" packs everything neatly.
// - Tap a panel to style it in a side drawer that opens away from the panel, so it's never covered.
const FREE_COLS = 6, FREE_ROWS = 4;
const FREE_DEF = [
  { t: 'music', x: 0, y: 0, w: 4, h: 2 }, { t: 'nav', x: 4, y: 0, w: 2, h: 2 },
  { t: 'clock', x: 0, y: 2, w: 2, h: 2 }, { t: 'speed', x: 2, y: 2, w: 2, h: 2 }, { t: 'weather', x: 4, y: 2, w: 2, h: 2 },
];
const FE_MIN = { music: [3, 2], nav: [2, 2], speed: [2, 2], weather: [2, 1], clock: [2, 1], favs: [2, 1], controls: [2, 1], viz: [2, 1], art: [2, 2], maps: [3, 2] };
const FE_ROUND = [['sharp', 'Sharp'], ['soft', 'Soft'], ['round', 'Round'], ['pill', 'Extra']];
const FE_GLASS = [['clear', 'Clear'], ['light', 'Light'], ['normal', 'Normal'], ['heavy', 'Frosted']];
const FE_EDGE = [['none', 'None'], ['glow', 'Glow'], ['holo', 'Holo'], ['pulse', 'Pulse']];
const PENCIL = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 20h4L19 9l-4-4L4 16z"/><path d="M13.5 6.5l4 4"/></svg>';
const RESIZE = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"><path d="M20 10v10H10M20 20L11 11"/></svg>';
const clone = (a) => JSON.parse(JSON.stringify(a));
const feMin = (t) => FE_MIN[t] || [2, 1];

function freeCards() {
  if (S.edit) return S.draft;
  const f = settings().home_tiles;
  return Array.isArray(f) && f.length ? f : FREE_DEF;
}

// does panel c (index i) fit without leaving the grid or covering another panel?
function feFits(c, i, list = S.draft) {
  if (c.x < 0 || c.y < 0 || c.x + c.w > FREE_COLS || c.y + c.h > FREE_ROWS) return false;
  return !list.some((o, j) => j !== i && c.x < o.x + o.w && c.x + c.w > o.x && c.y < o.y + o.h && c.y + c.h > o.y);
}
function feSpot(w, h, list = S.draft) {
  for (let y = 0; y + h <= FREE_ROWS; y++) for (let x = 0; x + w <= FREE_COLS; x++) if (feFits({ x, y, w, h }, -1, list)) return { x, y };
  return null;
}
// pack panels top-left, biggest first; shrink to minimum size if they don't all fit
function feTidy() {
  const order = S.draft.map((c, i) => i).sort((a, b) => S.draft[b].w * S.draft[b].h - S.draft[a].w * S.draft[a].h);
  const placed = [];
  order.forEach((i) => {
    const c = S.draft[i];
    let at = feSpot(c.w, c.h, placed);
    if (!at) { const [mw, mh] = feMin(c.t); c.w = mw; c.h = mh; at = feSpot(c.w, c.h, placed); }
    if (at) { c.x = at.x; c.y = at.y; placed.push(c); } else c.drop = true;
  });
  const lost = S.draft.filter((c) => c.drop).length;
  S.draft = S.draft.filter((c) => !c.drop);
  if (lost) toast(`${lost} panel${lost > 1 ? 's' : ''} didn’t fit and ${lost > 1 ? 'were' : 'was'} removed.`);
}

const area = (c) => `${c.y + 1} / ${c.x + 1} / span ${c.h} / span ${c.w}`;

function freeCardHtml(c, i) {
  const go = !S.edit && CARD_TAP[c.t] ? ` data-go-card="${CARD_TAP[c.t]}"` : '';
  const cls = `r-${c.r || 'soft'} gl-${c.g || 'normal'} edge-${c.e || 'none'}${S.edit && S.sel === i ? ' sel' : ''}`;
  const extra = S.edit ? `<span class="fe-tag">${esc(CARD_NAMES[c.t] || c.t)}</span><span class="fe-handle" data-fh="${i}">${RESIZE}</span>` : '';
  return `<div class="card glass tilt c-${c.t} ${cls}" data-fi="${i}" style="grid-area:${area(c)}"${go}>${(CARDS[c.t] || CARDS.music)()}${extra}</div>`;
}

function feSeg(key, opts, cur) {
  return `<div class="fe-seg">${opts.map(([k, l]) => `<button class="sink ${cur === k ? 'on' : ''}" data-fe="${key}:${k}">${l}</button>`).join('')}</div>`;
}

function feDrawer() {
  if (S.sel == null || !S.draft[S.sel]) return '';
  const c = S.draft[S.sel];
  const side = c.x + c.w / 2 < FREE_COLS / 2 ? 'right' : 'left'; // open away from the panel
  return `<aside class="fe-drawer glass ${side}">
    <div class="fe-dhead"><b>${esc(CARD_NAMES[c.t] || c.t)}</b><button class="icon-btn sink" data-fe="close" aria-label="Close">✕</button></div>
    <div class="fe-dbody">
      <div class="fe-lbl">Shows</div>
      <div class="fe-types">${Object.entries(CARD_NAMES).map(([id, l]) => `<button class="sink ${c.t === id ? 'on' : ''}" data-fe="t:${id}">${ico(CARD_ICONS[id], 22)}<span>${l}</span></button>`).join('')}</div>
      <div class="fe-lbl">Corners</div>${feSeg('r', FE_ROUND, c.r || 'soft')}
      <div class="fe-lbl">Glass</div>${feSeg('g', FE_GLASS, c.g || 'normal')}
      <div class="fe-lbl">Edge</div>${feSeg('e', FE_EDGE, c.e || 'none')}
      <button class="btn sink fe-del" data-fe="del">Remove this panel</button>
    </div></aside>`;
}

function freeHtml() {
  const cards = freeCards();
  if (!S.edit) {
    return `<div class="free" id="freeGrid">${cards.map(freeCardHtml).join('')}</div>
      <button class="free-edit glass sink" data-fe="start" aria-label="Edit the Home layout">${PENCIL}</button>`;
  }
  return `<div class="fe-strip glass">
      <b>Editing Home</b><span class="fe-hint">Drag to move · corner to resize · tap to style</span><span style="flex:1"></span>
      <button class="btn sink" data-fe="add">+ Add</button>
      <button class="btn sink" data-fe="tidy">Tidy up</button>
      <button class="btn sink" data-fe="reset">Start over</button>
      <button class="btn sink" data-fe="cancel">Cancel</button>
      <button class="btn primary sink" data-fe="done">Done</button>
    </div>
    <div class="free editing" id="freeGrid">${cards.map(freeCardHtml).join('')}<div class="fe-ghost" id="feGhost"></div></div>
    ${feDrawer()}`;
}

document.addEventListener('click', (e) => {
  const b = e.target.closest('[data-fe]');
  if (!b) {
    if (S.edit && (feJustDragged || e.target.closest('#freeGrid') || !e.target.isConnected)) { e.stopPropagation(); e.preventDefault(); }
    return;
  }
  e.stopPropagation();
  const [k, v] = b.dataset.fe.split(':');
  const app = (S.state && S.state.app) || {};
  if (k === 'start') {
    S.draft = clone(freeCards()); S.edit = true; S.sel = null;
    if (app.current) send('close_app'); // the live Maps stream would cover the editor
  } else if (k === 'done') {
    setSetting({ home_tiles: S.draft }); S.edit = false; S.sel = null;
  } else if (k === 'cancel') {
    S.edit = false; S.sel = null;
  } else if (k === 'reset') {
    S.draft = clone(FREE_DEF); S.sel = null;
  } else if (k === 'tidy') {
    feTidy(); S.sel = null;
  } else if (k === 'close') {
    S.sel = null;
  } else if (k === 'add') {
    const at = feSpot(2, 1);
    if (!at) return toast('No room left. Make a panel smaller or remove one first.');
    S.draft.push({ t: 'clock', x: at.x, y: at.y, w: 2, h: 1 }); S.sel = S.draft.length - 1;
  } else if (k === 'del' && S.sel != null) {
    S.draft.splice(S.sel, 1); S.sel = null;
  } else if (k === 't' && S.sel != null) {
    // a new panel type may need more room: grow it if there's space
    const c = S.draft[S.sel], [mw, mh] = feMin(v);
    const grown = { ...c, w: Math.max(c.w, mw), h: Math.max(c.h, mh) };
    if (!feFits(grown, S.sel)) return toast(`${CARD_NAMES[v]} needs at least ${mw} × ${mh} squares. Make room around this panel first.`);
    Object.assign(c, grown, { t: v });
  } else if (S.sel != null && ['r', 'g', 'e'].includes(k)) {
    S.draft[S.sel][k] = v;
  }
  render(true);
}, true);

// dragging and resizing
let feDrag = null, feJustDragged = false;
function feGhost(c, ok) {
  const gh = $('#feGhost');
  if (!gh) return;
  if (!c) { gh.style.display = 'none'; return; }
  gh.style.display = 'block';
  gh.style.gridArea = area(c);
  gh.classList.toggle('bad', !ok);
}
document.addEventListener('pointerdown', (e) => {
  if (!S.edit || e.target.closest('.fe-strip, .fe-drawer')) return;
  const card = e.target.closest('[data-fi]');
  const grid = $('#freeGrid');
  if (!card || !grid) return;
  const r = grid.getBoundingClientRect();
  const i = +card.dataset.fi;
  feDrag = { i, card, size: !!e.target.closest('[data-fh]'), sx: e.clientX, sy: e.clientY, c0: { ...S.draft[i] },
    cw: r.width / FREE_COLS, ch: r.height / FREE_ROWS, moved: false, target: null };
  card.setPointerCapture(e.pointerId);
  e.preventDefault();
});
document.addEventListener('pointermove', (e) => {
  if (!feDrag) return;
  const px = e.clientX - feDrag.sx, py = e.clientY - feDrag.sy;
  if (!feDrag.moved && Math.hypot(px, py) < 12) return; // small wobble = still a tap
  if (!feDrag.moved) { feDrag.moved = true; feDrag.card.classList.add('dragging'); S.sel = null; $$('.fe-drawer').forEach((d) => d.remove()); }
  const c0 = feDrag.c0, [mw, mh] = feMin(c0.t);
  let t;
  if (feDrag.size) {
    t = { ...c0, w: Math.max(mw, Math.min(FREE_COLS - c0.x, c0.w + Math.round(px / feDrag.cw))),
      h: Math.max(mh, Math.min(FREE_ROWS - c0.y, c0.h + Math.round(py / feDrag.ch))) };
    feDrag.card.style.width = `${Math.max(mw * feDrag.cw, c0.w * feDrag.cw + px) - 12}px`;
    feDrag.card.style.height = `${Math.max(mh * feDrag.ch, c0.h * feDrag.ch + py) - 12}px`;
  } else {
    t = { ...c0, x: Math.max(0, Math.min(FREE_COLS - c0.w, c0.x + Math.round(px / feDrag.cw))),
      y: Math.max(0, Math.min(FREE_ROWS - c0.h, c0.y + Math.round(py / feDrag.ch))) };
    feDrag.card.style.transform = `translate(${px}px, ${py}px) scale(1.03)`;
  }
  feDrag.target = t;
  feGhost(t, feFits(t, feDrag.i));
});
const feEnd = () => {
  if (!feDrag) return;
  const { i, moved, target } = feDrag;
  feDrag = null;
  feJustDragged = true;
  setTimeout(() => { feJustDragged = false; }, 350);
  if (!moved) S.sel = S.sel === i ? null : i;
  else if (target && feFits(target, i)) Object.assign(S.draft[i], target);
  else toast('Something’s in the way there.');
  render(true);
};
document.addEventListener('pointerup', feEnd);
document.addEventListener('pointercancel', feEnd);
