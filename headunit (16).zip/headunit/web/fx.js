/* Pi Head Unit — animated backgrounds, 3D touch effects, page wipes and the visualizer card.
   Backgrounds draw at half resolution (soft, and a quarter of the work), react to your driving
   speed, and pulse while music plays. */
'use strict';

const FX = { kind: null, items: [], w: 0, h: 0, ctx: null, last: 0, t: 0, raf: 0, sprites: {}, extra: null };
const MOTION = { calm: 0.55, lively: 1, wild: 1.8 };

function fxColors() {
  const t = S.theme || {};
  return { base: t.base || '#05070B', a: t.accent || '#5EEAD4', c1: t.b1 || '#14B8A6', c2: t.b2 || '#7C3AED', c3: t.b3 || '#0EA5E9' };
}
function fxSpeed() { // 1 when parked, up to 4 at highway speed
  const sp = S.state && S.state.speed ? S.state.speed.mps * 2.23694 : 0;
  return 1 + Math.min(sp, 90) / 30;
}
function fxBeat(t) { // soft pulse while music plays (about 120 bpm)
  const playing = S.state && S.state.media && S.state.media.status === 'playing';
  return playing ? Math.pow(0.5 + 0.5 * Math.sin(t * Math.PI * 4), 6) : 0;
}
function hexA(hex, a) {
  const n = parseInt(hex.slice(1), 16);
  return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`;
}
function sprite(color, r, hard = 0.25) { // pre-rendered glow dot (cheap to draw many of)
  const key = color + r + hard;
  if (FX.sprites[key]) return FX.sprites[key];
  const c = document.createElement('canvas');
  c.width = c.height = r * 2;
  const g2 = c.getContext('2d');
  const grd = g2.createRadialGradient(r, r, 0, r, r, r);
  grd.addColorStop(0, hexA(color, 1));
  grd.addColorStop(hard, hexA(color, 0.55));
  grd.addColorStop(1, hexA(color, 0));
  g2.fillStyle = grd;
  g2.fillRect(0, 0, r * 2, r * 2);
  return (FX.sprites[key] = c);
}
const rnd = (a, b) => a + Math.random() * (b - a);

function fxApply() {
  const s = settings();
  const kind = s.animate === false ? 'off' : (s.effect || 'blobs');
  const canvas = $('#fx');
  document.body.dataset.effect = kind;
  const themeKey = (S.theme && S.theme.id) || '';
  if (kind === FX.kind && FX.ctx && FX.themeKey === themeKey) return;
  FX.kind = kind;
  FX.themeKey = themeKey;
  FX.sprites = {};
  cancelAnimationFrame(FX.raf);
  if (kind === 'blobs' || kind === 'off') { canvas.style.display = 'none'; FX.ctx = null; return; }
  canvas.style.display = 'block';
  FX.w = canvas.width = Math.round(innerWidth / 2);
  FX.h = canvas.height = Math.round(innerHeight / 2);
  FX.ctx = canvas.getContext('2d');
  FX.items = [];
  FX.extra = null;
  const W = FX.w, H = FX.h, it = FX.items;
  if (kind === 'warp') for (let i = 0; i < 260; i++) it.push({ x: rnd(-1, 1), y: rnd(-1, 1), z: Math.random(), c: i % 3 });
  if (kind === 'particles') for (let i = 0; i < 70; i++) it.push({ x: rnd(0, W), y: rnd(0, H), r: rnd(1, 3.5), v: rnd(6, 20), p: rnd(0, 6), c: i % 3 });
  if (kind === 'liquid') for (let i = 0; i < 7; i++) it.push({ fx: rnd(0.1, 0.35), fy: rnd(0.1, 0.35), p: rnd(0, 6), r: rnd(0.22, 0.4), c: i % 4 });
  if (kind === 'fireflies') for (let i = 0; i < 55; i++) it.push({ x: rnd(0, W), y: rnd(0, H), a: rnd(0, 6.28), s: rnd(6, 18), p: rnd(0, 6), c: i % 3 });
  if (kind === 'bokeh') for (let i = 0; i < 46; i++) it.push({ x: rnd(0, W), y: rnd(H * 0.15, H * 0.95), r: rnd(6, 30), v: rnd(4, 18), a: rnd(0.15, 0.55), c: i % 5 });
  if (kind === 'rain') {
    for (let i = 0; i < 70; i++) it.push({ x: rnd(0, W), y: rnd(0, H), r: rnd(1.2, 4.2), v: 0, still: rnd(0, 4) });
    FX.extra = [...Array(9)].map((_, i) => ({ x: rnd(0, W), y: rnd(0, H), r: rnd(30, 70), c: i % 4 }));
  }
  if (kind === 'matrix') {
    const cols = Math.ceil(W / 9);
    for (let i = 0; i < cols; i++) it.push({ y: rnd(-H, 0), v: rnd(40, 110) });
  }
  if (kind === 'tunnel') for (let i = 0; i < 26; i++) it.push({ z: i / 26, c: i % 4 });
  if (kind === 'road') for (let i = 0; i < 40; i++) it.push({ x: rnd(0, W), y: rnd(0, H * 0.42), r: rnd(0.6, 2), c: i % 3 });
  if (kind === 'nebula') {
    const col = fxColors();
    FX.extra = [col.c1, col.c2, col.c3, col.a].map((c, i) => {
      const cv = document.createElement('canvas');
      cv.width = cv.height = 256;
      const g2 = cv.getContext('2d');
      for (let k = 0; k < 26; k++) {
        const x = rnd(40, 216), y = rnd(40, 216), r = rnd(20, 90);
        const grd = g2.createRadialGradient(x, y, 0, x, y, r);
        grd.addColorStop(0, hexA(c, 0.22)); grd.addColorStop(1, hexA(c, 0));
        g2.fillStyle = grd; g2.fillRect(0, 0, 256, 256);
      }
      return { cv, p: i * 1.7, s: 0.9 + i * 0.25 };
    });
    for (let i = 0; i < 90; i++) it.push({ x: rnd(0, W), y: rnd(0, H), r: rnd(0.4, 1.4), p: rnd(0, 6) });
  }
  FX.st = FXN[kind] ? FXN[kind].init(W, H) : null;
  FX.last = performance.now();
  FX.raf = requestAnimationFrame(fxFrame);
}

function fxFrame(now) {
  FX.raf = requestAnimationFrame(fxFrame);
  const s = settings();
  const fps = s.motion === 'wild' ? 60 : 30;
  if (now - FX.last < 1000 / fps - 2) return;
  const dt = Math.min(0.1, (now - FX.last) / 1000);
  FX.last = now;
  const m = MOTION[s.motion] || 1;
  FX.t += dt * m;
  const g = FX.ctx, W = FX.w, H = FX.h, t = FX.t, col = fxColors();
  const speed = fxSpeed(), beat = fxBeat(now / 1000);
  const pick = (i) => [col.a, col.c1, col.c3, col.c2][i % 4];
  const K = FX.kind;
  if (FXN[K]) { FXN[K].frame(g, FX.st, { W, H, t, dt, col, speed, beat, m, pick }); return; }

  if (K === 'warp') {
    g.fillStyle = hexA(col.base, 0.55);
    g.fillRect(0, 0, W, H);
    const v = dt * 0.18 * speed * m;
    g.lineCap = 'round';
    for (const st of FX.items) {
      const z0 = st.z;
      st.z -= v;
      if (st.z <= 0.02) { st.x = rnd(-1, 1); st.y = rnd(-1, 1); st.z = 1; continue; }
      const k = W * 0.5;
      const x1 = W / 2 + (st.x / st.z) * k, y1 = H / 2 + (st.y / st.z) * k;
      const x0 = W / 2 + (st.x / (z0 + v * 2)) * k, y0 = H / 2 + (st.y / (z0 + v * 2)) * k;
      g.strokeStyle = hexA(pick(st.c), Math.min(1, (1 - st.z) * 1.3));
      g.lineWidth = (1 - st.z) * (2.2 + beat * 1.5);
      g.beginPath(); g.moveTo(x0, y0); g.lineTo(x1, y1); g.stroke();
    }
  } else if (K === 'grid') {
    const hz = H * 0.56;
    const sky = g.createLinearGradient(0, 0, 0, hz);
    sky.addColorStop(0, col.base); sky.addColorStop(1, hexA(col.c3, 0.55));
    g.fillStyle = sky; g.fillRect(0, 0, W, hz);
    g.fillStyle = col.base; g.fillRect(0, hz, W, H - hz);
    const r = H * 0.26 * (1 + beat * 0.04), cx = W / 2, cy = hz - r * 0.45;
    const sun = g.createLinearGradient(0, cy - r, 0, cy + r);
    sun.addColorStop(0, col.a); sun.addColorStop(1, col.c1);
    g.save();
    g.beginPath(); g.rect(0, 0, W, hz); g.clip();
    g.shadowColor = col.c1; g.shadowBlur = 30;
    g.fillStyle = sun; g.beginPath(); g.arc(cx, cy, r, 0, Math.PI * 2); g.fill();
    g.shadowBlur = 0;
    g.fillStyle = col.base;
    for (let i = 0; i < 6; i++) { const y = cy + r * (0.1 + i * 0.16); g.fillRect(cx - r, y, r * 2, 2 + i * 1.6); }
    g.restore();
    g.strokeStyle = hexA(col.a, 0.75); g.lineWidth = 1.2;
    g.shadowColor = col.a; g.shadowBlur = 6;
    for (let i = -14; i <= 14; i++) { g.beginPath(); g.moveTo(cx + i * 6, hz); g.lineTo(cx + i * W * 0.11, H); g.stroke(); }
    const off = (t * 0.6 * speed) % 1;
    for (let k = 0; k < 14; k++) {
      const p = Math.pow((k + off) / 14, 2.3);
      const y = hz + (H - hz) * p;
      g.globalAlpha = Math.min(1, p * 2.5);
      g.beginPath(); g.moveTo(0, y); g.lineTo(W, y); g.stroke();
    }
    g.globalAlpha = 1; g.shadowBlur = 0;
    g.strokeStyle = hexA(col.a, 1); g.lineWidth = 2;
    g.beginPath(); g.moveTo(0, hz); g.lineTo(W, hz); g.stroke();
  } else if (K === 'particles') {
    g.fillStyle = col.base; g.fillRect(0, 0, W, H);
    const pts = FX.items;
    for (const p of pts) {
      p.y -= p.v * dt * m * (0.6 + speed * 0.4);
      p.x += Math.sin(t * 0.8 + p.p) * 0.25;
      if (p.y < -10) { p.y = H + 10; p.x = rnd(0, W); }
    }
    g.lineWidth = 0.8;
    for (let i = 0; i < pts.length; i++) for (let j = i + 1; j < pts.length; j++) {
      const dx = pts[i].x - pts[j].x, dy = pts[i].y - pts[j].y, d = dx * dx + dy * dy;
      if (d < 4200) { g.strokeStyle = hexA(col.a, (1 - d / 4200) * (0.35 + beat * 0.4)); g.beginPath(); g.moveTo(pts[i].x, pts[i].y); g.lineTo(pts[j].x, pts[j].y); g.stroke(); }
    }
    g.globalCompositeOperation = 'lighter';
    for (const p of pts) { const r = Math.round(p.r * 5 * (1 + beat * 0.5)); g.drawImage(sprite(pick(p.c), r), p.x - r, p.y - r); }
    g.globalCompositeOperation = 'source-over';
  } else if (K === 'aurora') {
    g.fillStyle = col.base; g.fillRect(0, 0, W, H);
    g.globalCompositeOperation = 'lighter';
    [col.c1, col.c2, col.c3, col.a].forEach((c, i) => {
      g.strokeStyle = hexA(c, 0.22 + beat * 0.12);
      g.lineWidth = H * (0.16 + i * 0.03);
      g.beginPath();
      for (let x = -20; x <= W + 20; x += 12) {
        const y = H * (0.3 + i * 0.13) + Math.sin(x * 0.012 + t * (0.5 + i * 0.17) * speed + i * 1.7) * H * 0.09 + Math.sin(x * 0.027 - t * 0.4 + i) * H * 0.04;
        x < 0 ? g.moveTo(x, y) : g.lineTo(x, y);
      }
      g.stroke();
    });
    g.globalCompositeOperation = 'source-over';
  } else if (K === 'liquid') {
    g.fillStyle = col.base; g.fillRect(0, 0, W, H);
    g.globalCompositeOperation = 'lighter';
    for (const b of FX.items) {
      const x = W * (0.5 + 0.42 * Math.sin(t * b.fx * speed + b.p)), y = H * (0.5 + 0.42 * Math.cos(t * b.fy * speed + b.p * 1.3));
      const r = Math.min(W, H) * b.r * (1 + beat * 0.08 + 0.1 * Math.sin(t * 0.7 + b.p));
      const grd = g.createRadialGradient(x, y, 0, x, y, r);
      grd.addColorStop(0, hexA(pick(b.c), 0.55)); grd.addColorStop(0.55, hexA(pick(b.c), 0.32)); grd.addColorStop(1, hexA(pick(b.c), 0));
      g.fillStyle = grd; g.beginPath(); g.arc(x, y, r, 0, 6.283); g.fill();
    }
    g.globalCompositeOperation = 'source-over';
  } else if (K === 'nebula') {
    g.fillStyle = col.base; g.fillRect(0, 0, W, H);
    for (const p of FX.items) { g.fillStyle = `rgba(255,255,255,${0.25 + 0.35 * Math.abs(Math.sin(t * 0.7 + p.p))})`; g.fillRect(p.x, p.y, p.r, p.r); }
    g.globalCompositeOperation = 'lighter';
    FX.extra.forEach((n, i) => {
      g.save();
      g.translate(W * (0.5 + 0.25 * Math.sin(t * 0.05 * n.s + n.p)), H * (0.5 + 0.2 * Math.cos(t * 0.04 * n.s + n.p)));
      g.rotate(t * 0.03 * (i % 2 ? 1 : -1) + n.p);
      const sz = Math.max(W, H) * (1.1 + beat * 0.05);
      g.drawImage(n.cv, -sz / 2, -sz / 2, sz, sz);
      g.restore();
    });
    g.globalCompositeOperation = 'source-over';
  } else if (K === 'road') {
    const hz = H * 0.45;
    const sky = g.createLinearGradient(0, 0, 0, hz);
    sky.addColorStop(0, col.base); sky.addColorStop(1, hexA(col.c2, 0.45));
    g.fillStyle = sky; g.fillRect(0, 0, W, hz);
    for (const p of FX.items) { g.fillStyle = hexA(pick(p.c), 0.6); g.fillRect(p.x, p.y, p.r, p.r); }
    // distant city glow
    g.globalCompositeOperation = 'lighter';
    for (let i = 0; i < 14; i++) { const x = (i * 53 + 20) % W, h = 6 + ((i * 37) % 22); g.fillStyle = hexA(i % 2 ? col.c1 : col.a, 0.25); g.fillRect(x, hz - h, 10, h); }
    g.globalCompositeOperation = 'source-over';
    g.fillStyle = col.base; g.fillRect(0, hz, W, H - hz);
    const cx = W / 2;
    g.fillStyle = hexA('#000000', 0.35);
    g.beginPath(); g.moveTo(cx - 6, hz); g.lineTo(cx + 6, hz); g.lineTo(W * 1.05, H); g.lineTo(-W * 0.05, H); g.closePath(); g.fill();
    const off = (t * 0.9 * speed) % 1;
    g.shadowColor = col.a; g.shadowBlur = 8;
    for (let k = 0; k < 12; k++) {
      const p0 = Math.pow((k + off) / 12, 2.4), p1 = Math.pow((k + off + 0.45) / 12, 2.4);
      const y0 = hz + (H - hz) * p0, y1 = hz + (H - hz) * Math.min(1, p1);
      const w0 = 1 + p0 * 7, w1 = 1 + p1 * 7;
      g.fillStyle = hexA(col.a, Math.min(1, p0 * 3));
      g.beginPath(); g.moveTo(cx - w0 / 2, y0); g.lineTo(cx + w0 / 2, y0); g.lineTo(cx + w1 / 2, y1); g.lineTo(cx - w1 / 2, y1); g.fill();
      for (const side of [-1, 1]) { // reflector posts
        const x = cx + side * (8 + p0 * W * 0.62);
        g.fillStyle = hexA(side < 0 ? col.c1 : '#ff5050', Math.min(1, p0 * 2.5));
        g.fillRect(x - p0 * 2, y0 - p0 * 16, 1 + p0 * 4, 1 + p0 * 10);
      }
    }
    g.shadowBlur = 0;
    g.strokeStyle = hexA(col.c1, 0.5); g.lineWidth = 1.5;
    for (const side of [-1, 1]) { g.beginPath(); g.moveTo(cx + side * 4, hz); g.lineTo(cx + side * W * 0.58, H); g.stroke(); }
  } else if (K === 'tunnel') {
    g.fillStyle = hexA(col.base, 0.4); g.fillRect(0, 0, W, H);
    const cx = W / 2 + Math.sin(t * 0.4) * W * 0.06, cy = H / 2 + Math.cos(t * 0.3) * H * 0.06;
    g.lineWidth = 2;
    for (const r of FX.items) {
      r.z -= dt * 0.12 * speed * m;
      if (r.z <= 0.02) r.z += 1;
      const s2 = 0.06 / r.z;
      const rw = W * s2, rh = H * s2;
      g.strokeStyle = hexA(pick(r.c), Math.min(1, (1 - r.z) * 1.2) * (0.6 + beat * 0.4));
      g.beginPath();
      const sides = 6, rot = t * 0.15 + r.z * 2;
      for (let i = 0; i <= sides; i++) { const a = rot + (i / sides) * 6.283; const x = cx + Math.cos(a) * rw, y = cy + Math.sin(a) * rh; i ? g.lineTo(x, y) : g.moveTo(x, y); }
      g.stroke();
    }
  } else if (K === 'rain') {
    g.fillStyle = col.base; g.fillRect(0, 0, W, H);
    g.globalCompositeOperation = 'lighter';
    for (const b of FX.extra) { const r = b.r * (1 + beat * 0.05); g.drawImage(sprite(pick(b.c), Math.round(r), 0.5), b.x - r, b.y - r); b.x -= dt * 6 * speed; if (b.x < -80) b.x = W + 80; }
    g.globalCompositeOperation = 'source-over';
    for (const d of FX.items) {
      if (d.still > 0) d.still -= dt * m; else d.v = Math.min(60, d.v + dt * 40 * d.r);
      d.y += d.v * dt * m;
      if (d.v > 0 && Math.random() < 0.02) { d.v = 0; d.still = rnd(0.3, 2); }
      if (d.y > H + 10) { d.y = -10; d.x = rnd(0, W); d.v = 0; d.still = rnd(0, 3); }
      const grd = g.createRadialGradient(d.x - d.r * 0.3, d.y - d.r * 0.3, 0, d.x, d.y, d.r);
      grd.addColorStop(0, 'rgba(255,255,255,.55)'); grd.addColorStop(0.6, hexA(col.a, 0.12)); grd.addColorStop(1, 'rgba(255,255,255,.25)');
      g.fillStyle = grd; g.beginPath(); g.ellipse(d.x, d.y, d.r * 0.85, d.r, 0, 0, 6.283); g.fill();
      if (d.v > 5) { g.fillStyle = 'rgba(255,255,255,.12)'; g.fillRect(d.x - 0.5, d.y - d.r * 6, 1, d.r * 5); }
    }
  } else if (K === 'bokeh') {
    g.fillStyle = col.base; g.fillRect(0, 0, W, H);
    g.globalCompositeOperation = 'lighter';
    const cols = [col.a, col.c1, col.c3, '#FFD9A0', '#FF8A65'];
    for (const b of FX.items) {
      b.x -= b.v * dt * m * speed * 0.6;
      if (b.x < -b.r * 2) { b.x = W + b.r * 2; b.y = rnd(H * 0.15, H * 0.95); }
      const r = Math.round(b.r * (1 + beat * 0.1));
      g.globalAlpha = b.a;
      g.drawImage(sprite(cols[b.c], r, 0.75), b.x - r, b.y - r);
    }
    g.globalAlpha = 1;
    g.globalCompositeOperation = 'source-over';
  } else if (K === 'fireflies') {
    g.fillStyle = hexA(col.base, 0.35); g.fillRect(0, 0, W, H);
    g.globalCompositeOperation = 'lighter';
    for (const f of FX.items) {
      f.a += (Math.sin(t * 0.9 + f.p) * 1.2) * dt;
      f.x += Math.cos(f.a) * f.s * dt * m; f.y += Math.sin(f.a) * f.s * dt * m - dt * 2;
      if (f.x < -10) f.x = W + 10; if (f.x > W + 10) f.x = -10; if (f.y < -10) f.y = H + 10; if (f.y > H + 10) f.y = -10;
      const glow = 0.3 + 0.7 * Math.pow(0.5 + 0.5 * Math.sin(t * 2.3 + f.p * 3), 3);
      g.globalAlpha = glow;
      const r = Math.round(7 + beat * 3);
      g.drawImage(sprite(pick(f.c), r), f.x - r, f.y - r);
    }
    g.globalAlpha = 1;
    g.globalCompositeOperation = 'source-over';
  } else if (K === 'waves') {
    const sky = g.createLinearGradient(0, 0, 0, H);
    sky.addColorStop(0, col.base); sky.addColorStop(1, hexA(col.c2, 0.35));
    g.fillStyle = sky; g.fillRect(0, 0, W, H);
    [col.c1, col.c3, col.c2, col.a].forEach((c, i) => {
      const base = H * (0.5 + i * 0.12), amp = H * (0.05 + i * 0.012) * (1 + beat * 0.2);
      const grd = g.createLinearGradient(0, base - amp, 0, H);
      grd.addColorStop(0, hexA(c, 0.5)); grd.addColorStop(1, hexA(c, 0.05));
      g.fillStyle = grd;
      g.beginPath(); g.moveTo(0, H);
      for (let x = 0; x <= W; x += 8) g.lineTo(x, base + Math.sin(x * (0.012 + i * 0.003) + t * (0.6 + i * 0.25) * speed + i) * amp);
      g.lineTo(W, H); g.closePath(); g.fill();
    });
  } else if (K === 'hex') {
    g.fillStyle = col.base; g.fillRect(0, 0, W, H);
    const R = 16, hw = R * Math.sqrt(3);
    const cx = W / 2, cy = H / 2;
    g.lineWidth = 1.2;
    for (let row = -1; row * R * 1.5 < H + R; row++) {
      for (let c = -1; c * hw < W + hw; c++) {
        const x = c * hw + (row % 2 ? hw / 2 : 0), y = row * R * 1.5;
        const d = Math.hypot(x - cx, y - cy);
        const wave = Math.pow(0.5 + 0.5 * Math.sin(d * 0.045 - t * 2.2 * speed), 6);
        const a = 0.08 + wave * (0.55 + beat * 0.4);
        g.strokeStyle = hexA(wave > 0.5 ? col.a : col.c1, a);
        g.beginPath();
        for (let i = 0; i <= 6; i++) { const an = Math.PI / 6 + (i * Math.PI) / 3; const px = x + Math.cos(an) * (R - 2), py = y + Math.sin(an) * (R - 2); i ? g.lineTo(px, py) : g.moveTo(px, py); }
        g.stroke();
        if (wave > 0.85) { g.fillStyle = hexA(col.a, 0.12 * wave); g.fill(); }
      }
    }
  } else if (K === 'matrix') {
    g.fillStyle = hexA(col.base, 0.18); g.fillRect(0, 0, W, H);
    g.font = '9px "DejaVu Sans Mono", monospace';
    const chars = 'アイウエオカキクケコサシスセソタチツテト0123456789ABCDEF';
    FX.items.forEach((c, i) => {
      c.y += c.v * dt * m * (0.7 + speed * 0.3);
      const ch = chars[(Math.random() * chars.length) | 0];
      g.fillStyle = '#E8FFE8'; g.fillText(ch, i * 9, c.y);
      g.fillStyle = hexA(col.a, 0.85); g.fillText(chars[(Math.random() * chars.length) | 0], i * 9, c.y - 10);
      if (c.y > H + rnd(0, 200)) { c.y = rnd(-60, 0); c.v = rnd(40, 110); }
    });
  }
}
addEventListener('resize', () => { FX.kind = null; if (S.state) fxApply(); });

// ---- touch: ripple, 3D tilt toward the finger, and the glass catching the light where you press
document.addEventListener('pointerdown', (e) => {
  if (settings().animate === false) return;
  const btn = e.target.closest('button, .card, .chip, .pitem, .fav');
  if (btn) {
    const r = btn.getBoundingClientRect();
    const size = Math.max(r.width, r.height) * 2.2;
    const span = document.createElement('span');
    span.className = 'ripple';
    span.style.cssText = `width:${size}px;height:${size}px;left:${e.clientX - r.left - size / 2}px;top:${e.clientY - r.top - size / 2}px`;
    if (getComputedStyle(btn).position === 'static') btn.style.position = 'relative';
    btn.appendChild(span);
    setTimeout(() => span.remove(), 700);
  }
  const gl = e.target.closest('.glass');
  if (gl) {
    const r = gl.getBoundingClientRect();
    gl.style.setProperty('--lx', `${((e.clientX - r.left) / r.width) * 100}%`);
    gl.style.setProperty('--ly', `${((e.clientY - r.top) / r.height) * 100}%`);
  }
  const tilt = e.target.closest('.tilt');
  if (tilt && !document.body.classList.contains('flat') && !e.target.closest('input')) {
    const r = tilt.getBoundingClientRect();
    const x = (e.clientX - r.left) / r.width - 0.5, y = (e.clientY - r.top) / r.height - 0.5;
    const depth = parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--depth')) || 0.7;
    const k = 5 + depth * 6;
    tilt.classList.add('pressed');
    tilt.style.transform = `perspective(60rem) rotateX(${(-y * k).toFixed(2)}deg) rotateY(${(x * k).toFixed(2)}deg) scale(.985)`;
    const release = () => { tilt.classList.remove('pressed'); tilt.style.transform = ''; removeEventListener('pointerup', release); removeEventListener('pointercancel', release); };
    addEventListener('pointerup', release);
    addEventListener('pointercancel', release);
  }
}, true);

// ---- theme change: the new theme ripples out from where you tapped
function themeWipe(apply, x, y) {
  if (!document.startViewTransition || settings().animate === false) return apply();
  const r = Math.hypot(Math.max(x, innerWidth - x), Math.max(y, innerHeight - y));
  const vt = document.startViewTransition(apply);
  vt.ready.then(() => document.documentElement.animate(
    { clipPath: [`circle(0px at ${x}px ${y}px)`, `circle(${r}px at ${x}px ${y}px)`] },
    { duration: 750, easing: 'cubic-bezier(.65,0,.25,1)', pseudoElement: '::view-transition-new(root)' })).catch(() => {});
}

// ---- visualizer card: a spectrum that dances while music plays (shape only, not real audio)
(function viz() {
  let last = 0;
  const bars = new Array(28).fill(0);
  function frame(now) {
    requestAnimationFrame(frame);
    const cv = document.querySelector('.viz-canvas');
    if (!cv || now - last < 33) return;
    last = now;
    const r = cv.getBoundingClientRect();
    if (!r.width) return;
    if (cv.width !== Math.round(r.width) || cv.height !== Math.round(r.height)) { cv.width = Math.round(r.width); cv.height = Math.round(r.height); }
    const g = cv.getContext('2d'), W = cv.width, H = cv.height, col = fxColors();
    const playing = S.state && S.state.media && S.state.media.status === 'playing' && settings().animate !== false;
    const t = now / 1000;
    g.clearRect(0, 0, W, H);
    const n = bars.length, gap = W * 0.012, bw = (W - gap * (n + 1)) / n;
    const grd = g.createLinearGradient(0, H, 0, H * 0.2);
    grd.addColorStop(0, col.c1); grd.addColorStop(1, col.a);
    for (let i = 0; i < n; i++) {
      const target = playing ? (0.25 + 0.75 * Math.abs(Math.sin(t * (2.1 + (i % 5) * 0.7) + i * 0.9)) * Math.pow(1 - Math.abs(i / n - 0.35), 1.2)) : 0.04;
      bars[i] += (target - bars[i]) * 0.25;
      const h = Math.max(4, bars[i] * H * 0.7);
      const x = gap + i * (bw + gap);
      g.fillStyle = grd;
      g.beginPath(); g.roundRect(x, H - h - H * 0.08, bw, h, bw / 2); g.fill();
      g.fillStyle = hexA(col.a, 0.15);
      g.beginPath(); g.roundRect(x, H - H * 0.06, bw, Math.min(h * 0.25, H * 0.05), bw / 2); g.fill();
    }
  }
  requestAnimationFrame(frame);
})();

// ======================================================================== more backgrounds
// Each one is { init(W, H) -> state, frame(g, st, f) } where f = { W, H, t, dt, col, speed, beat, m, pick }.
// Drawn at half resolution like the others, so they stay light on the Pi.
const clamp01 = (v) => (v < 0 ? 0 : v > 1 ? 1 : v);
const rgbOf = (hex) => { const n = parseInt(hex.slice(1), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; };
const smooth = (a, b, v) => { const x = clamp01((v - a) / (b - a)); return x * x * (3 - 2 * x); };

// ---- metaball goo: a scalar field on a coarse grid, shaded like glossy jelly, then scaled up smooth
function gooSetup(W, H, div) {
  const gw = Math.ceil(W / div), gh = Math.ceil(H / div);
  const cv = document.createElement('canvas');
  cv.width = gw; cv.height = gh;
  const cx = cv.getContext('2d');
  return { gw, gh, cv, cx, img: cx.createImageData(gw, gh), v: new Float32Array(gw * gh) };
}
// balls: [x, y, r²]; segs: [x, y0, y1, r²] (vertical); top(x)/bottom(x): surface heights or null
function gooDraw(g, W, H, G, balls, segs, top, bottom, rowColor, light, dark) {
  const { gw, gh, v, img } = G;
  const d = img.data;
  const tops = top ? new Float32Array(gw) : null, bots = bottom ? new Float32Array(gw) : null;
  for (let x = 0; x < gw; x++) { if (tops) tops[x] = top(x); if (bots) bots[x] = bottom(x); }
  const nb = balls.length, ns = segs.length;
  for (let y = 0; y < gh; y++) {
    for (let x = 0; x < gw; x++) {
      let s = 0;
      if (tops) { const dy = y - tops[x]; s += dy <= 0 ? 3 : 2.25 / (dy * dy + 0.35); }
      if (bots) { const dy = bots[x] - y; s += dy <= 0 ? 3 : 2.25 / (dy * dy + 0.35); }
      for (let i = 0; i < nb; i++) { const b = balls[i], dx = x - b[0], dy = y - b[1]; s += b[2] / (dx * dx + dy * dy + 0.2); }
      for (let i = 0; i < ns; i++) {
        const q = segs[i], dx = x - q[0], cy = y < q[1] ? q[1] : y > q[2] ? q[2] : y, dy = y - cy;
        s += q[3] / (dx * dx + dy * dy + 0.2);
      }
      v[y * gw + x] = s;
    }
  }
  for (let y = 0; y < gh; y++) {
    const mid = rowColor(y / gh);
    for (let x = 0; x < gw; x++) {
      const i = y * gw + x, s = v[i], o = i * 4;
      if (s < 0.5) { d[o + 3] = 0; continue; }
      const gx = (v[i + (x < gw - 1 ? 1 : 0)] - v[i - (x > 0 ? 1 : 0)]);
      const gy = (v[i + (y < gh - 1 ? gw : 0)] - v[i - (y > 0 ? gw : 0)]);
      // anti-aliased edge: exactly one grid cell wide however steep the field is, so it scales up smooth
      const a = clamp01((s - 1) / Math.max(0.04, Math.hypot(gx, gy) * 0.5) + 0.5);
      if (a <= 0) { d[o + 3] = 0; continue; }
      const gl = Math.hypot(gx, gy) + 0.6;                 // normalised, so big and small blobs shade alike
      const facing = Math.max(-1, Math.min(1, ((gy * 0.8 + gx * 0.45) / gl) * 1.1)); // surfaces facing up-left catch the light
      const depth = clamp01((s - 1) * 0.45);
      const k = 0.55 + depth * 0.35 + facing * 0.3;
      let r = dark[0] + (mid[0] - dark[0]) * k, gg = dark[1] + (mid[1] - dark[1]) * k, b = dark[2] + (mid[2] - dark[2]) * k;
      const rim = 1 - smooth(1, 1.7, s);                 // light glowing through the thin edge
      r += (light[0] - r) * rim * 0.45; gg += (light[1] - gg) * rim * 0.45; b += (light[2] - b) * rim * 0.45;
      const spec = facing > 0.45 ? (facing - 0.45) * 1.6 : 0; // wet highlight
      r += (255 - r) * spec; gg += (255 - gg) * spec; b += (255 - b) * spec;
      d[o] = r; d[o + 1] = gg; d[o + 2] = b; d[o + 3] = a * 240;
    }
  }
  G.cx.putImageData(img, 0, 0);
  g.imageSmoothingEnabled = true;
  g.drawImage(G.cv, 0, 0, W, H);
}

const FXN = {
  // Oozing slime: goo hangs from the top, drips stretch, neck and let go, and splat into a pool
  slime: {
    init(W, H) {
      const G = gooSetup(W, H, 3);
      const n = Math.max(5, Math.round(G.gw / 17));
      const drips = [...Array(n)].map((_, i) => ({ x: (i + 0.5 + rnd(-0.3, 0.3)) * (G.gw / n), len: rnd(0, 10), max: rnd(10, 26), rate: rnd(2, 5), back: 0 }));
      return { G, drips, drops: [], bumps: [], bloops: [...Array(3)].map(() => ({ x: rnd(0, G.gw), p: rnd(0, 6), f: rnd(0.25, 0.5), r: rnd(3, 6) })), bubbles: [] };
    },
    frame(g, st, f) {
      const { W, H, t, dt, col, speed, beat, m } = f, G = st.G, gh = G.gh;
      const bg = g.createLinearGradient(0, 0, 0, H);
      bg.addColorStop(0, col.base); bg.addColorStop(1, hexA(col.c2, 0.35));
      g.fillStyle = bg; g.fillRect(0, 0, W, H);
      const top = (x) => 2.5 + 1.4 * Math.sin(x * 0.13 + t * 0.4) + 0.9 * Math.sin(x * 0.31 - t * 0.7);
      const poolY = gh * 0.86;
      const bottom = (x) => {
        let y = poolY + 1.2 * Math.sin(x * 0.09 + t * 0.6) + 0.7 * Math.sin(x * 0.23 - t * 0.9);
        for (const b of st.bumps) y -= b.amp * Math.exp(-(((x - b.x) / 2.6) ** 2)) * Math.cos(b.age * 7) * Math.exp(-b.age * 2.2);
        return y;
      };
      const balls = [], segs = [];
      const go = dt * m * (0.8 + speed * 0.25);
      for (const d of st.drips) {
        const y0 = top(d.x);
        if (d.back > 0) { d.len -= go * 14; d.back -= go; if (d.len < 1) { d.len = 1; d.back = 0; } }
        else d.len += go * d.rate * (1 + beat * 0.8) * (0.4 + d.len / d.max); // starts slow, then the weight pulls it
        if (d.len >= d.max && d.back <= 0) {
          st.drops.push({ x: d.x, y: y0 + d.len, vy: d.rate * 3, r2: 2.6 + d.max * 0.06 });
          d.len *= 0.6; d.back = 0.5; d.max = rnd(10, 26); d.rate = rnd(2, 5);
        }
        const w = 0.6 + 0.5 * (1 - d.len / d.max);         // thins as it stretches
        segs.push([d.x, y0, y0 + d.len, w]);
        balls.push([d.x, y0 + d.len, 1.4 + d.len * 0.07]);  // heavy bulb at the tip
      }
      for (let i = st.drops.length - 1; i >= 0; i--) {
        const p = st.drops[i];
        p.vy += 90 * dt * m; p.y += p.vy * dt * m;
        balls.push([p.x, p.y, p.r2]);
        if (p.y > bottom(p.x) - 0.5) {
          st.bumps.push({ x: p.x, amp: 2.2 + p.r2 * 0.4, age: 0 });
          for (let k = 0; k < 3; k++) st.bubbles.push({ x: (p.x + rnd(-2, 2)) * (W / G.gw), y: H * rnd(0.9, 0.98), r: rnd(1.5, 3.5), v: rnd(6, 14) });
          st.drops.splice(i, 1);
        }
      }
      for (let i = st.bumps.length - 1; i >= 0; i--) { st.bumps[i].age += dt * m; if (st.bumps[i].age > 2.2) st.bumps.splice(i, 1); }
      for (const b of st.bloops) { // the pool bulges up into blobs that sink back
        const up = Math.max(0, Math.sin(t * b.f + b.p)) * (5 + beat * 3);
        balls.push([b.x + Math.sin(t * 0.2 + b.p) * 4, poolY - up + 1, b.r]);
        if (up < 0.05) b.x = rnd(0, G.gw);
      }
      const mid = rgbOf(col.c1), light = rgbOf(col.a), dark = rgbOf(col.c2);
      gooDraw(g, W, H, G, balls, segs, top, bottom, () => mid, light, dark);
      g.strokeStyle = hexA(col.a, 0.5); g.lineWidth = 1;
      for (let i = st.bubbles.length - 1; i >= 0; i--) { // bubbles rising through the pool
        const b = st.bubbles[i]; b.y -= b.v * dt * m; b.x += Math.sin(t * 3 + i) * 0.2;
        g.beginPath(); g.arc(b.x, b.y, b.r, 0, 6.283); g.stroke();
        if (b.y < H * 0.85) st.bubbles.splice(i, 1);
      }
      if (st.bubbles.length < 6 && Math.random() < dt * 2) st.bubbles.push({ x: rnd(0, W), y: H, r: rnd(1.5, 3), v: rnd(5, 10) });
    },
  },

  // Goo lamp: big blobs rise and fall, stretching into each other and splitting apart
  goo: {
    init(W, H) {
      const G = gooSetup(W, H, 4);
      return { G, blobs: [...Array(8)].map((_, i) => ({ x: (i + 0.5) / 8, p: rnd(0, 6), f: rnd(0.08, 0.16), r: rnd(40, 110), w: rnd(0.15, 0.35) })) };
    },
    frame(g, st, f) {
      const { W, H, t, col, speed, beat } = f, G = st.G;
      g.fillStyle = col.base; g.fillRect(0, 0, W, H);
      const balls = st.blobs.map((b) => [G.gw * (b.x + 0.08 * Math.sin(t * b.w + b.p)),
        G.gh * (0.5 - 0.42 * Math.sin(t * b.f * (0.8 + speed * 0.2) + b.p)), b.r * (1 + beat * 0.15)]);
      const c1 = rgbOf(col.c1), c3 = rgbOf(col.c3), light = rgbOf(col.a), dark = rgbOf(col.c2);
      const row = (yy) => [c3[0] + (c1[0] - c3[0]) * yy, c3[1] + (c1[1] - c3[1]) * yy, c3[2] + (c1[2] - c3[2]) * yy];
      gooDraw(g, W, H, G, balls, [], null, (x) => G.gh - 2 + Math.sin(x * 0.1 + t * 0.5), row, light, dark);
    },
  },

  plasma: {
    init() {
      const cv = document.createElement('canvas'); cv.width = 80; cv.height = 45;
      const cx = cv.getContext('2d');
      return { cv, cx, img: cx.createImageData(80, 45), pal: null, key: '' };
    },
    frame(g, st, f) {
      const { W, H, t, col, speed, beat } = f;
      const key = col.a + col.c1 + col.c2 + col.c3;
      if (st.key !== key) { // 256-step palette looping through the theme colors
        const cs = [col.c1, col.c3, col.a, col.c2].map(rgbOf);
        st.pal = new Uint8Array(256 * 3);
        for (let i = 0; i < 256; i++) {
          const p = (i / 256) * 4, k = Math.floor(p), fr = p - k, a = cs[k % 4], b = cs[(k + 1) % 4], e = fr * fr * (3 - 2 * fr);
          for (let c = 0; c < 3; c++) st.pal[i * 3 + c] = a[c] + (b[c] - a[c]) * e;
        }
        st.key = key;
      }
      const d = st.img.data, tt = t * 0.6 * (0.7 + speed * 0.3);
      for (let y = 0; y < 45; y++) for (let x = 0; x < 80; x++) {
        const cx = x - 40 + Math.sin(tt * 0.7) * 20, cy = y - 22 + Math.cos(tt * 0.5) * 12;
        const v = Math.sin(x * 0.09 + tt) + Math.sin(y * 0.11 - tt * 1.3) + Math.sin((x + y) * 0.06 + tt * 0.7) + Math.sin(Math.sqrt(cx * cx + cy * cy) * 0.15 - tt * 1.6);
        const i = ((v * 0.125 + 0.5) * 255 + t * 20) & 255, o = (y * 80 + x) * 4;
        const dim = 0.55 + beat * 0.25;
        d[o] = st.pal[i * 3] * dim; d[o + 1] = st.pal[i * 3 + 1] * dim; d[o + 2] = st.pal[i * 3 + 2] * dim; d[o + 3] = 255;
      }
      st.cx.putImageData(st.img, 0, 0);
      g.imageSmoothingEnabled = true; g.drawImage(st.cv, 0, 0, W, H);
    },
  },

  embers: {
    init(W, H) { return { p: [...Array(90)].map(() => ({ x: rnd(0, W), y: rnd(0, H), v: rnd(12, 40), s: rnd(0.6, 2.4), ph: rnd(0, 6), c: (Math.random() * 3) | 0 })) }; },
    frame(g, st, f) {
      const { W, H, t, dt, col, speed, beat, m, pick } = f;
      g.fillStyle = col.base; g.fillRect(0, 0, W, H);
      const glow = g.createRadialGradient(W / 2, H * 1.15, 0, W / 2, H * 1.15, H * (0.9 + beat * 0.1 + 0.05 * Math.sin(t * 3)));
      glow.addColorStop(0, hexA(col.c1, 0.55)); glow.addColorStop(1, hexA(col.c1, 0));
      g.fillStyle = glow; g.fillRect(0, 0, W, H);
      g.globalCompositeOperation = 'lighter';
      for (const e of st.p) {
        e.y -= e.v * dt * m * (0.7 + speed * 0.3); e.x += Math.sin(t * 1.3 + e.ph) * 0.5;
        if (e.y < -8) { e.y = H + 8; e.x = rnd(0, W); }
        const life = clamp01(e.y / H);
        g.globalAlpha = life * (0.5 + 0.5 * Math.sin(t * 9 + e.ph * 5));
        const r = Math.round(4 + e.s * 2.5);
        g.drawImage(sprite(pick(e.c), r, 0.55), e.x - r, e.y - r);
      }
      g.globalAlpha = 1; g.globalCompositeOperation = 'source-over';
    },
  },

  snow: {
    init(W, H) { return { p: [...Array(130)].map(() => ({ x: rnd(0, W), y: rnd(0, H), z: rnd(0.3, 1), ph: rnd(0, 6) })) }; },
    frame(g, st, f) {
      const { W, H, t, dt, col, speed, m } = f;
      const sky = g.createLinearGradient(0, 0, 0, H);
      sky.addColorStop(0, col.base); sky.addColorStop(1, hexA(col.c3, 0.3));
      g.fillStyle = sky; g.fillRect(0, 0, W, H);
      const wind = (Math.sin(t * 0.25) * 14 + 6) * speed;
      for (const s of st.p) {
        s.y += (10 + s.z * 26) * dt * m; s.x += (wind * s.z + Math.sin(t + s.ph) * 6) * dt * m;
        if (s.y > H + 4) { s.y = -4; s.x = rnd(-20, W); }
        if (s.x > W + 6) s.x = -6; if (s.x < -6) s.x = W + 6;
        g.fillStyle = `rgba(255,255,255,${0.35 + s.z * 0.55})`;
        g.beginPath(); g.arc(s.x, s.y, 0.6 + s.z * 1.6, 0, 6.283); g.fill();
      }
    },
  },

  storm: {
    init(W, H) {
      return { drops: [...Array(140)].map(() => ({ x: rnd(0, W), y: rnd(0, H), v: rnd(160, 260) })),
        clouds: [...Array(7)].map((_, i) => ({ x: rnd(0, W), y: rnd(0, H * 0.3), r: rnd(50, 110), v: rnd(3, 9) })), next: 2, flash: 0, bolt: null };
    },
    frame(g, st, f) {
      const { W, H, dt, col, speed, beat, m } = f;
      g.fillStyle = col.base; g.fillRect(0, 0, W, H);
      for (const c of st.clouds) {
        c.x += c.v * dt * m; if (c.x - c.r > W) c.x = -c.r;
        const r = Math.round(c.r);
        g.globalAlpha = 0.5; g.drawImage(sprite(col.c2, r, 0.5), c.x - r, c.y - r);
      }
      g.globalAlpha = 1;
      st.next -= dt * m * (1 + beat);
      if (st.next <= 0) { // midpoint-displaced bolt
        let pts = [[rnd(W * 0.15, W * 0.85), 0], [rnd(W * 0.15, W * 0.85), H * rnd(0.6, 0.95)]];
        for (let k = 0; k < 6; k++) {
          const nx = [];
          for (let i = 0; i < pts.length - 1; i++) { const a = pts[i], b = pts[i + 1]; nx.push(a, [(a[0] + b[0]) / 2 + rnd(-1, 1) * Math.abs(b[1] - a[1]) * 0.35, (a[1] + b[1]) / 2]); }
          nx.push(pts[pts.length - 1]); pts = nx;
        }
        st.bolt = pts; st.flash = 1; st.next = rnd(2.5, 7);
      }
      if (st.flash > 0) {
        g.fillStyle = hexA(col.a, st.flash * 0.22); g.fillRect(0, 0, W, H);
        if (st.bolt && st.flash > 0.4) {
          g.strokeStyle = `rgba(255,255,255,${st.flash})`; g.lineWidth = 1.6; g.shadowColor = col.a; g.shadowBlur = 14;
          g.beginPath(); st.bolt.forEach(([x, y], i) => (i ? g.lineTo(x, y) : g.moveTo(x, y))); g.stroke(); g.shadowBlur = 0;
        }
        st.flash -= dt * 2.2 * (st.flash > 0.7 ? 0.6 : 1.4);
      }
      g.strokeStyle = hexA(col.c3, 0.35); g.lineWidth = 1;
      g.beginPath();
      for (const d of st.drops) {
        d.y += d.v * dt * m; d.x -= d.v * 0.18 * dt * m * speed * 0.5;
        if (d.y > H) { d.y = rnd(-20, 0); d.x = rnd(0, W + 40); }
        g.moveTo(d.x, d.y); g.lineTo(d.x + 2, d.y - 9);
      }
      g.stroke();
    },
  },

  pond: {
    init() { return { rings: [], next: 0 }; },
    frame(g, st, f) {
      const { W, H, dt, col, speed, beat, m, pick } = f;
      const sky = g.createLinearGradient(0, 0, 0, H);
      sky.addColorStop(0, col.base); sky.addColorStop(1, hexA(col.c2, 0.4));
      g.fillStyle = sky; g.fillRect(0, 0, W, H);
      st.next -= dt * m * (0.8 + speed * 0.3 + beat);
      if (st.next <= 0) { st.rings.push({ x: rnd(0, W), y: rnd(H * 0.1, H), r: 0, c: (Math.random() * 4) | 0 }); st.next = rnd(0.15, 0.5); }
      g.lineWidth = 1.2;
      for (let i = st.rings.length - 1; i >= 0; i--) {
        const r = st.rings[i]; r.r += 26 * dt * m;
        const a = 1 - r.r / 70;
        if (a <= 0) { st.rings.splice(i, 1); continue; }
        const persp = 0.35 + (r.y / H) * 0.25;
        for (let k = 0; k < 3; k++) {
          const rr = r.r - k * 7; if (rr <= 0) continue;
          g.strokeStyle = hexA(pick(r.c), a * (0.7 - k * 0.2));
          g.beginPath(); g.ellipse(r.x, r.y, rr, rr * persp, 0, 0, 6.283); g.stroke();
        }
      }
    },
  },

  circuit: {
    init(W, H) {
      const step = 14, paths = [];
      for (let i = 0; i < 28; i++) {
        let x = Math.round(rnd(0, W) / step) * step, y = Math.round(rnd(0, H) / step) * step, dir = (Math.random() * 4) | 0;
        const pts = [[x, y]];
        for (let k = 0; k < 9; k++) {
          if (Math.random() < 0.45) dir = (dir + (Math.random() < 0.5 ? 1 : 3)) % 4;
          const n = 1 + ((Math.random() * 4) | 0);
          x += [step, 0, -step, 0][dir] * n; y += [0, step, 0, -step][dir] * n;
          pts.push([x, y]);
        }
        const lens = [0]; for (let k = 1; k < pts.length; k++) lens.push(lens[k - 1] + Math.hypot(pts[k][0] - pts[k - 1][0], pts[k][1] - pts[k - 1][1]));
        paths.push({ pts, lens, s: rnd(0, lens[lens.length - 1]), v: rnd(40, 90), c: i % 4 });
      }
      return { paths };
    },
    frame(g, st, f) {
      const { W, H, dt, col, speed, beat, m, pick } = f;
      g.fillStyle = col.base; g.fillRect(0, 0, W, H);
      g.lineWidth = 1.2; g.strokeStyle = hexA(col.c1, 0.18);
      for (const p of st.paths) {
        g.beginPath(); p.pts.forEach(([x, y], i) => (i ? g.lineTo(x, y) : g.moveTo(x, y))); g.stroke();
        g.fillStyle = hexA(col.c1, 0.35);
        const e = p.pts[p.pts.length - 1]; g.fillRect(e[0] - 2, e[1] - 2, 4, 4);
      }
      g.globalCompositeOperation = 'lighter';
      for (const p of st.paths) {
        const total = p.lens[p.lens.length - 1];
        p.s = (p.s + p.v * dt * m * (0.6 + speed * 0.4) * (1 + beat)) % total;
        let k = 1; while (k < p.lens.length - 1 && p.lens[k] < p.s) k++;
        const a = p.pts[k - 1], b = p.pts[k], fr = (p.s - p.lens[k - 1]) / Math.max(1, p.lens[k] - p.lens[k - 1]);
        const x = a[0] + (b[0] - a[0]) * fr, y = a[1] + (b[1] - a[1]) * fr;
        g.drawImage(sprite(pick(p.c), 9, 0.3), x - 9, y - 9);
      }
      g.globalCompositeOperation = 'source-over';
    },
  },

  galaxy: {
    init() { return { s: [...Array(520)].map((_, i) => ({ r: Math.pow(Math.random(), 0.7), arm: i % 3, j: rnd(-0.35, 0.35), z: rnd(0.4, 1.6) })) }; },
    frame(g, st, f) {
      const { W, H, t, col, speed, beat, pick } = f;
      g.fillStyle = hexA(col.base, 0.5); g.fillRect(0, 0, W, H);
      const cx = W / 2, cy = H / 2, R = Math.min(W, H) * 0.62;
      g.globalCompositeOperation = 'lighter';
      const core = Math.round(R * 0.3 * (1 + beat * 0.15));
      g.globalAlpha = 0.45; g.drawImage(sprite(col.a, core, 0.08), cx - core, cy - core); g.globalAlpha = 1;
      for (const s of st.s) {
        const a = s.arm * 2.094 + s.r * 5.2 + s.j + t * 0.12 * speed / (0.25 + s.r);
        const x = cx + Math.cos(a) * s.r * R, y = cy + Math.sin(a) * s.r * R * 0.5;
        g.fillStyle = hexA(pick(s.arm + (s.r > 0.5 ? 1 : 0)), 0.35 + (1 - s.r) * 0.6);
        g.fillRect(x, y, s.z, s.z);
      }
      g.globalCompositeOperation = 'source-over';
    },
  },

  smoke: {
    init(W, H) { return { p: [...Array(18)].map((_, i) => ({ x: rnd(0, W), y: rnd(0, H), r: rnd(40, 90), v: rnd(6, 14), c: i % 4, ph: rnd(0, 6) })) }; },
    frame(g, st, f) {
      const { W, H, t, dt, col, speed, beat, m, pick } = f;
      g.fillStyle = col.base; g.fillRect(0, 0, W, H);
      for (const p of st.p) {
        p.y -= p.v * dt * m * (0.6 + speed * 0.4); p.x += Math.sin(t * 0.3 + p.ph) * 0.4; p.r += dt * 4;
        if (p.y + p.r < 0) { p.y = H + 60; p.x = rnd(0, W); p.r = rnd(40, 80); }
        const r = Math.round(p.r);
        g.globalAlpha = 0.22 + beat * 0.1;
        g.drawImage(sprite(pick(p.c), r, 0.1), p.x - r, p.y - r);
      }
      g.globalAlpha = 1;
    },
  },

  petals: {
    init(W, H) { return { p: [...Array(46)].map((_, i) => ({ x: rnd(0, W), y: rnd(0, H), a: rnd(0, 6), va: rnd(-2, 2), s: rnd(3, 7), v: rnd(14, 30), ph: rnd(0, 6), c: i % 4 })) }; },
    frame(g, st, f) {
      const { W, H, t, dt, col, speed, m, pick } = f;
      const sky = g.createLinearGradient(0, 0, 0, H);
      sky.addColorStop(0, col.base); sky.addColorStop(1, hexA(col.c2, 0.3));
      g.fillStyle = sky; g.fillRect(0, 0, W, H);
      for (const p of st.p) {
        p.y += p.v * dt * m; p.x += (Math.sin(t * 1.1 + p.ph) * 18 + 8 * speed) * dt * m; p.a += p.va * dt * m;
        if (p.y > H + 10) { p.y = -10; p.x = rnd(-30, W); }
        if (p.x > W + 10) p.x = -10;
        g.save(); g.translate(p.x, p.y); g.rotate(p.a); g.scale(1, Math.abs(Math.cos(t * 2 + p.ph)) * 0.7 + 0.3);
        g.fillStyle = hexA(pick(p.c), 0.85);
        g.beginPath(); g.ellipse(0, 0, p.s, p.s * 0.5, 0, 0, 6.283); g.fill();
        g.restore();
      }
    },
  },

  lasers: {
    init() { return { b: [...Array(8)].map((_, i) => ({ x: (i + 0.5) / 8, ph: rnd(0, 6), f: rnd(0.4, 1.1), c: i % 4 })) }; },
    frame(g, st, f) {
      const { W, H, t, col, speed, beat, pick } = f;
      g.fillStyle = col.base; g.fillRect(0, 0, W, H);
      const haze = g.createLinearGradient(0, H, 0, 0);
      haze.addColorStop(0, hexA(col.c2, 0.35)); haze.addColorStop(1, hexA(col.c2, 0));
      g.fillStyle = haze; g.fillRect(0, 0, W, H);
      g.globalCompositeOperation = 'lighter';
      for (const b of st.b) {
        const ox = W * b.x, oy = H + 4;
        const ang = -Math.PI / 2 + Math.sin(t * b.f * (0.7 + speed * 0.3) + b.ph) * 0.75;
        const len = H * 1.6, wdt = 0.035 + beat * 0.02;
        const grd = g.createLinearGradient(ox, oy, ox + Math.cos(ang) * len, oy + Math.sin(ang) * len);
        grd.addColorStop(0, hexA(pick(b.c), 0.75 + beat * 0.25)); grd.addColorStop(1, hexA(pick(b.c), 0));
        g.fillStyle = grd;
        g.beginPath(); g.moveTo(ox, oy);
        g.lineTo(ox + Math.cos(ang - wdt) * len, oy + Math.sin(ang - wdt) * len);
        g.lineTo(ox + Math.cos(ang + wdt) * len, oy + Math.sin(ang + wdt) * len);
        g.closePath(); g.fill();
      }
      g.globalCompositeOperation = 'source-over';
    },
  },

  skyline: {
    init(W, H) {
      const b = []; let x = -4;
      while (x < W) { const w = rnd(18, 42); b.push({ x, w, h: rnd(H * 0.18, H * 0.55), seed: Math.random() * 1000 }); x += w + rnd(1, 4); }
      return { b, stars: [...Array(60)].map(() => [rnd(0, W), rnd(0, H * 0.5), rnd(0, 6)]) };
    },
    frame(g, st, f) {
      const { W, H, t, col, beat } = f;
      const ground = H * 0.86;
      const sky = g.createLinearGradient(0, 0, 0, ground);
      sky.addColorStop(0, col.base); sky.addColorStop(1, hexA(col.c2, 0.55));
      g.fillStyle = sky; g.fillRect(0, 0, W, H);
      for (const [x, y, p] of st.stars) { g.fillStyle = `rgba(255,255,255,${0.2 + 0.4 * Math.abs(Math.sin(t * 0.8 + p))})`; g.fillRect(x, y, 1, 1); }
      const playing = S.state && S.state.media && S.state.media.status === 'playing';
      st.b.forEach((b, i) => {
        const level = playing ? 0.35 + 0.65 * Math.abs(Math.sin(t * (1.6 + (i % 5) * 0.4) + i)) : 0.15;
        const top = ground - b.h;
        g.fillStyle = hexA('#000000', 0.55); g.fillRect(b.x, top, b.w, b.h);
        g.fillStyle = hexA(col.a, 0.12 + level * 0.5); g.fillRect(b.x, top, b.w, 2); // equalizer glow on the roof
        for (let wy = top + 6; wy < ground - 4; wy += 7) for (let wx = b.x + 3; wx < b.x + b.w - 3; wx += 6) {
          const lit = ((Math.sin(b.seed + wx * 3.1 + wy * 7.7) + 1) / 2) < level * (1 - (wy - top) / b.h * 0.3);
          if (lit) { g.fillStyle = hexA((wx + wy) % 3 ? col.a : col.c3, 0.55 + beat * 0.3); g.fillRect(wx, wy, 3, 3); }
        }
      });
      const water = g.createLinearGradient(0, ground, 0, H);
      water.addColorStop(0, hexA(col.c1, 0.25)); water.addColorStop(1, col.base);
      g.fillStyle = water; g.fillRect(0, ground, W, H - ground);
      for (let y = ground + 3; y < H; y += 4) { g.fillStyle = hexA(col.a, 0.08 * (1 - (y - ground) / (H - ground))); g.fillRect(Math.sin(t + y) * 6, y, W, 1); }
    },
  },

  dna: {
    init() { return {}; },
    frame(g, st, f) {
      const { W, H, t, col, speed, beat } = f;
      g.fillStyle = col.base; g.fillRect(0, 0, W, H);
      const cy = H / 2, amp = H * 0.24 * (1 + beat * 0.08), pts = [];
      for (let x = -10; x < W + 10; x += 7) {
        const ph = x * 0.028 + t * 1.1 * speed;
        pts.push([x, cy + Math.sin(ph) * amp, Math.cos(ph), 0], [x, cy - Math.sin(ph) * amp, -Math.cos(ph), 1]);
        if (Math.round(x / 7) % 3 === 0) {
          g.strokeStyle = hexA(col.c3, 0.25 + 0.2 * Math.abs(Math.cos(ph)));
          g.lineWidth = 1.5; g.beginPath(); g.moveTo(x, cy + Math.sin(ph) * amp); g.lineTo(x, cy - Math.sin(ph) * amp); g.stroke();
        }
      }
      pts.sort((a, b) => a[2] - b[2]);
      for (const [x, y, z, s] of pts) {
        g.fillStyle = hexA(s ? col.a : col.c1, 0.35 + (z + 1) * 0.32);
        g.beginPath(); g.arc(x, y, 2 + (z + 1) * 1.6, 0, 6.283); g.fill();
      }
    },
  },

  radar: {
    init() { return { blips: [] }; },
    frame(g, st, f) {
      const { W, H, t, dt, col, speed, m } = f;
      g.fillStyle = col.base; g.fillRect(0, 0, W, H);
      const cx = W / 2, cy = H / 2, R = Math.min(W, H) * 0.46;
      g.strokeStyle = hexA(col.a, 0.2); g.lineWidth = 1;
      for (let k = 1; k <= 4; k++) { g.beginPath(); g.arc(cx, cy, (R * k) / 4, 0, 6.283); g.stroke(); }
      g.beginPath(); g.moveTo(cx - R, cy); g.lineTo(cx + R, cy); g.moveTo(cx, cy - R); g.lineTo(cx, cy + R); g.stroke();
      const a = (t * 1.1 * (0.7 + speed * 0.3)) % 6.283;
      for (let k = 0; k < 24; k++) {
        g.fillStyle = hexA(col.a, 0.22 * (1 - k / 24));
        g.beginPath(); g.moveTo(cx, cy); g.arc(cx, cy, R, a - (k + 1) * 0.04, a - k * 0.04); g.closePath(); g.fill();
      }
      if (Math.random() < dt * 1.5) { const ang = rnd(0, 6.283), r = rnd(0.15, 0.95) * R; st.blips.push({ ang, r, life: 0 }); }
      for (let i = st.blips.length - 1; i >= 0; i--) {
        const b = st.blips[i];
        const diff = (a - b.ang + 6.283) % 6.283;
        if (diff < 0.08) b.life = 1;
        b.life -= dt * m * 0.35;
        if (b.life <= -2) { st.blips.splice(i, 1); continue; }
        if (b.life > 0) { const r = 6; g.globalAlpha = b.life; g.drawImage(sprite(col.c1, r, 0.4), cx + Math.cos(b.ang) * b.r - r, cy + Math.sin(b.ang) * b.r - r); g.globalAlpha = 1; }
      }
    },
  },

  kaleido: {
    init() { return {}; },
    frame(g, st, f) {
      const { W, H, t, col, speed, beat, pick } = f;
      g.fillStyle = hexA(col.base, 0.22); g.fillRect(0, 0, W, H);
      const cx = W / 2, cy = H / 2, N = 12;
      for (let k = 0; k < N; k++) {
        g.save(); g.translate(cx, cy); g.rotate((k * 6.283) / N + t * 0.08 * speed);
        if (k % 2) g.scale(1, -1);
        for (let i = 0; i < 4; i++) {
          const r = 30 + i * 32 + Math.sin(t * 0.7 + i) * 18, a = Math.sin(t * 0.5 + i * 1.3) * 0.25;
          const s = 3 + (1 + Math.sin(t * 1.3 + i)) * 4 + beat * 4;
          g.fillStyle = hexA(pick(i), 0.55);
          g.beginPath(); g.arc(Math.cos(a) * r, Math.sin(a) * r, s, 0, 6.283); g.fill();
        }
        g.restore();
      }
    },
  },

  fireworks: {
    init() { return { rockets: [], sparks: [], next: 0.5 }; },
    frame(g, st, f) {
      const { W, H, dt, col, speed, beat, m, pick } = f;
      g.fillStyle = hexA(col.base, 0.28); g.fillRect(0, 0, W, H);
      st.next -= dt * m * (1 + beat * 1.5);
      if (st.next <= 0) { st.rockets.push({ x: rnd(W * 0.15, W * 0.85), y: H, vy: -rnd(H * 0.9, H * 1.2), c: (Math.random() * 4) | 0 }); st.next = rnd(0.5, 1.4); }
      g.fillStyle = 'rgba(255,240,200,.9)';
      for (let i = st.rockets.length - 1; i >= 0; i--) {
        const r = st.rockets[i]; r.vy += H * 0.9 * dt * m; r.y += r.vy * dt * m;
        g.fillRect(r.x, r.y, 1.5, 4);
        if (r.vy > -H * 0.08) {
          const n = 50;
          for (let k = 0; k < n; k++) { const a = (k / n) * 6.283, v = rnd(0.5, 1) * H * 0.35 * (0.8 + speed * 0.1); st.sparks.push({ x: r.x, y: r.y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, life: 1, c: r.c }); }
          st.rockets.splice(i, 1);
        }
      }
      g.globalCompositeOperation = 'lighter';
      for (let i = st.sparks.length - 1; i >= 0; i--) {
        const s = st.sparks[i];
        s.vx *= 0.98; s.vy = s.vy * 0.98 + H * 0.25 * dt * m; s.x += s.vx * dt * m; s.y += s.vy * dt * m; s.life -= dt * m * 0.6;
        if (s.life <= 0) { st.sparks.splice(i, 1); continue; }
        g.globalAlpha = s.life; g.drawImage(sprite(pick(s.c), 4, 0.4), s.x - 4, s.y - 4);
      }
      g.globalAlpha = 1; g.globalCompositeOperation = 'source-over';
    },
  },

  underwater: {
    init(W, H) { return { bub: [...Array(40)].map(() => ({ x: rnd(0, W), y: rnd(0, H), r: rnd(1, 4), v: rnd(10, 30), ph: rnd(0, 6) })), snow: [...Array(60)].map(() => [rnd(0, W), rnd(0, H), rnd(0, 6)]) }; },
    frame(g, st, f) {
      const { W, H, t, dt, col, speed, beat, m } = f;
      const sea = g.createLinearGradient(0, 0, 0, H);
      sea.addColorStop(0, hexA(col.c3, 0.55)); sea.addColorStop(0.6, hexA(col.c2, 0.4)); sea.addColorStop(1, col.base);
      g.fillStyle = col.base; g.fillRect(0, 0, W, H); g.fillStyle = sea; g.fillRect(0, 0, W, H);
      g.globalCompositeOperation = 'lighter';
      for (let i = 0; i < 7; i++) { // light shafts swaying from the surface
        const x = W * (i + 0.5) / 7 + Math.sin(t * 0.3 + i * 1.7) * 30, w = 14 + 10 * Math.sin(t * 0.5 + i);
        const ray = g.createLinearGradient(0, 0, 0, H * 0.9);
        ray.addColorStop(0, hexA(col.a, 0.18 + beat * 0.08)); ray.addColorStop(1, hexA(col.a, 0));
        g.fillStyle = ray;
        g.beginPath(); g.moveTo(x - w, 0); g.lineTo(x + w, 0); g.lineTo(x + w * 3 + 40, H * 0.9); g.lineTo(x - w + 40, H * 0.9); g.closePath(); g.fill();
      }
      g.globalCompositeOperation = 'source-over';
      for (const [x, y, p] of st.snow) { g.fillStyle = `rgba(255,255,255,${0.12 + 0.15 * Math.sin(t + p)})`; g.fillRect(x + Math.sin(t * 0.4 + p) * 6, y, 1, 1); }
      g.strokeStyle = 'rgba(255,255,255,.45)'; g.lineWidth = 0.8;
      for (const b of st.bub) {
        b.y -= b.v * dt * m * (0.7 + speed * 0.3); b.x += Math.sin(t * 2 + b.ph) * 0.3;
        if (b.y < -5) { b.y = H + 5; b.x = rnd(0, W); }
        g.beginPath(); g.arc(b.x, b.y, b.r, 0, 6.283); g.stroke();
      }
    },
  },
};
