// Knob ripple: turning the knob sends an effect across the screen from where the knob is mounted.
// Styles: Waves, Shockwave, Aurora bloom, Sparks, Edge only. The volume can trace the screen's
// edge (starting at the knob) and a glass readout can pop up. Pressing fires one bright burst.
(function () {
  const cv = document.createElement('canvas');
  cv.id = 'rippleFx';
  document.body.appendChild(cv);
  const x = cv.getContext('2d');
  const hud = document.createElement('div');
  hud.className = 'vol-hud glass';
  hud.innerHTML = '<span class="vh-ic"></span><b class="vh-num"></b><i class="vh-bar"><i></i></i>';
  document.body.appendChild(hud);
  let W = 0, H = 0, DPR = 1, fx = [], vol = 0, shown = 0, edgeA = 0, lastTurn = 0, running = false, hudTimer;

  function size() { DPR = Math.min(devicePixelRatio || 1, 1.5); W = cv.width = innerWidth * DPR; H = cv.height = innerHeight * DPR; }
  size(); addEventListener('resize', size);
  const css = (k, d) => getComputedStyle(document.documentElement).getPropertyValue(k).trim() || d;
  const style = () => (g('knob_ripple') === false ? 'off' : g('ripple_style') || 'waves');
  const amt = () => (g('ripple_power') ?? 60) / 60; // 1 = normal
  function origin() {
    const o = g('ripple_from') || 'bottom';
    const kx = (g('knob_x') ?? 50) / 100;
    return o === 'left' ? [0, H * 0.6] : o === 'right' ? [W, H * 0.6] : o === 'center' ? [W / 2, H / 2] : [W * kx, H];
  }

  function hitPanels(ox, oy, strong, speed) {
    $$('.screen:last-child .glass, .nav').forEach((el) => {
      const r = el.getBoundingClientRect();
      if (!r.width) return;
      const d = Math.hypot((r.left + r.width / 2) * DPR - ox, (r.top + r.height / 2) * DPR - oy) / DPR;
      setTimeout(() => {
        el.classList.remove('rip-hit', 'rip-hit2');
        void el.offsetWidth;
        el.classList.add(strong ? 'rip-hit2' : 'rip-hit');
      }, d * speed);
    });
  }

  // volume traced around the screen edge, starting where the knob is
  function edge(frac, alpha, accent) {
    if (alpha <= 0.01 || frac <= 0) return;
    const m = 3 * DPR;
    const [ox] = origin();
    const sx = (g('ripple_from') || 'bottom') === 'bottom' ? Math.min(W - m, Math.max(m, ox)) : W / 2;
    const pts = [[sx, H - m], [m, H - m], [m, m], [W - m, m], [W - m, H - m], [sx, H - m]];
    let per = 0;
    for (let i = 1; i < pts.length; i++) per += Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]);
    let left = per * frac, end = pts[0];
    x.save();
    x.globalAlpha = alpha;
    x.strokeStyle = accent; x.shadowColor = accent; x.shadowBlur = 24 * DPR; x.lineWidth = 5 * DPR; x.lineCap = 'round';
    x.beginPath(); x.moveTo(pts[0][0], pts[0][1]);
    for (let i = 1; i < pts.length && left > 0; i++) {
      const [ax, ay] = pts[i - 1], [bx, by] = pts[i], seg = Math.hypot(bx - ax, by - ay), k = Math.min(1, left / seg);
      end = [ax + (bx - ax) * k, ay + (by - ay) * k];
      x.lineTo(end[0], end[1]);
      left -= seg;
    }
    x.stroke();
    x.fillStyle = '#fff'; x.shadowBlur = 30 * DPR;
    x.beginPath(); x.arc(end[0], end[1], 5 * DPR, 0, 6.283); x.fill();
    x.restore();
  }

  function draw(f, accent, b2) {
    f.age++;
    x.save();
    if (f.kind === 'ring') {
      f.r += f.v * DPR; f.a *= f.fade;
      x.globalAlpha = f.a; x.strokeStyle = f.white ? '#fff' : accent; x.shadowColor = accent; x.shadowBlur = 18 * DPR;
      x.lineWidth = f.w * DPR * (0.4 + f.a);
      x.beginPath(); x.arc(f.x, f.y, f.r, 0, 6.283); x.stroke();
    } else if (f.kind === 'bloom') {
      f.r += f.v * DPR; f.a *= f.fade;
      const gr = x.createRadialGradient(f.x, f.y, 0, f.x, f.y, f.r);
      gr.addColorStop(0, accent); gr.addColorStop(0.45, b2); gr.addColorStop(1, 'rgba(0,0,0,0)');
      x.globalAlpha = f.a * 0.55; x.globalCompositeOperation = 'lighter';
      x.fillStyle = gr; x.beginPath(); x.arc(f.x, f.y, f.r, 0, 6.283); x.fill();
    } else if (f.kind === 'spark') {
      f.x += f.vx * DPR; f.y += f.vy * DPR; f.vy += 0.06; f.vx *= 0.985; f.vy *= 0.985; f.a *= 0.965;
      x.globalAlpha = f.a; x.globalCompositeOperation = 'lighter';
      x.strokeStyle = f.white ? '#fff' : accent; x.lineWidth = 2.2 * DPR; x.lineCap = 'round';
      x.shadowColor = accent; x.shadowBlur = 10 * DPR;
      x.beginPath(); x.moveTo(f.x, f.y); x.lineTo(f.x - f.vx * 3 * DPR, f.y - f.vy * 3 * DPR); x.stroke();
    } else if (f.kind === 'flash') {
      f.a *= 0.88;
      x.globalAlpha = f.a; x.fillStyle = f.col; x.fillRect(0, 0, W, H);
    }
    x.restore();
  }

  function frame(now) {
    x.clearRect(0, 0, W, H);
    const accent = css('--accent', '#5EEAD4'), b2 = css('--b2', '#7C3AED');
    shown += (vol - shown) * 0.22;
    const idle = (now - lastTurn) / 1000;
    edgeA = idle < 1.2 && g('ripple_edge') !== false ? Math.min(1, edgeA + 0.15) : Math.max(0, edgeA - 0.04);
    edge(shown / 100, edgeA, accent);
    fx = fx.filter((f) => f.a > 0.01);
    fx.forEach((f) => draw(f, accent, b2));
    if (fx.length || edgeA > 0.01) requestAnimationFrame(frame); else { running = false; x.clearRect(0, 0, W, H); }
  }
  function kick() { if (!running) { running = true; requestAnimationFrame(frame); } }

  function sparks(ox, oy, n, speed, white) {
    for (let i = 0; i < n; i++) {
      // fan out away from the edge the knob sits on
      const up = oy >= H - 2 ? -1 : 0;
      const a = up ? -Math.PI / 2 + (Math.random() - 0.5) * 2.4 : Math.random() * 6.283;
      const v = speed * (0.5 + Math.random());
      fx.push({ kind: 'spark', x: ox, y: oy, vx: Math.cos(a) * v, vy: Math.sin(a) * v, a: 1, age: 0, white: white && i % 3 === 0 });
    }
  }

  function burst(ox, oy, up, press) {
    const st = style(), p = amt();
    if (st === 'off') return;
    if (st === 'waves') {
      fx.push({ kind: 'ring', x: ox, y: oy, r: press ? 10 : 0, v: (press ? 26 : up ? 16 : 11) * p, a: press ? 1 : up ? 0.85 : 0.6, fade: 0.958, w: press ? 10 : up ? 6 : 4, white: press, age: 0 });
      if (press) fx.push({ kind: 'ring', x: ox, y: oy, r: 0, v: 18 * p, a: 0.8, fade: 0.95, w: 5, age: 0 });
    } else if (st === 'shock') {
      if (press || fx.filter((f) => f.kind === 'ring').length < 2) {
        fx.push({ kind: 'ring', x: ox, y: oy, r: 0, v: 34 * p, a: 1, fade: 0.94, w: press ? 16 : 11, white: press, age: 0 });
        fx.push({ kind: 'flash', a: press ? 0.22 : 0.1, col: press ? '#ffffff' : css('--accent', '#5EEAD4') });
      }
    } else if (st === 'aurora') {
      fx.push({ kind: 'bloom', x: ox, y: oy, r: 40, v: (press ? 30 : 18) * p, a: press ? 1 : 0.7, fade: 0.965, age: 0 });
    } else if (st === 'sparks') {
      sparks(ox, oy, Math.round((press ? 70 : up ? 22 : 12) * p), press ? 14 : 9, press);
    }
    // panels only react to a press, never to turning the volume (that made every panel flash)
    if (press && st !== 'edge') hitPanels(ox, oy, press, st === 'shock' ? 0.3 : 0.55);
    kick();
  }

  window.knobFx = function (m) {
    if (style() === 'off') return;
    const [ox, oy] = origin();
    if (m.act === 'press') return burst(ox, oy, true, true);
    vol = m.vol; lastTurn = performance.now();
    if (shown === 0) shown = vol;
    burst(ox, oy, m.dir > 0, false);
    if (g('ripple_hud') !== false) {
      hud.querySelector('.vh-num').textContent = vol;
      hud.querySelector('.vh-ic').innerHTML = ico('vol', 30);
      hud.querySelector('.vh-bar i').style.width = `${vol}%`;
      hud.dataset.kind = m.kind || 'volume';
      hud.classList.add('show');
      clearTimeout(hudTimer);
      hudTimer = setTimeout(() => hud.classList.remove('show'), 1300);
    }
    kick();
  };
})();
