/*
  Head Unit Knob — firmware for the Elecrow CrowPanel 1.28" ESP32-S3 rotary display.

  30 faces. Pick one on the Pi under Look > Knob, or swipe up/down on the knob to flip through them.
  Each face is a background, a ring and a center, put together from the parts below:
    Backgrounds  solid, aurora (drifting theme colors), radial glow, starfield, carbon weave,
                 sunburst, target rings, scanlines, radar sweep
    Rings        glow, LED segments, instrument dial, thin, dots, music bars, twin, gradient,
                 sport dial with redline, comet second hand, watch ticks
    Centers      song + play button, big digital clock, big speed, analog clock, big volume,
                 clock + equalizer, gauge readout, speed under the needle
  Speed faces show your speed from the phone's GPS; the others show the volume on the ring.
  Colors follow the Pi's theme (a few faces have their own fixed colors), brightness follows the
  Pi's dimmer, and how lively it all is follows the Pi's Motion setting.

  Controls: turn = volume · press = play/pause (answer a call) · double-press = next track ·
  hold = voice assistant (hang up) · swipe left/right = previous/next · swipe up/down = next face

  Arduino IDE (Tools menu): Board "ESP32S3 Dev Module", USB CDC On Boot "Enabled", PSRAM "OPI PSRAM"
  Library Manager: "GFX Library for Arduino" by Moon On Our Nation
*/
#include <Arduino_GFX_Library.h>
#include <Wire.h>
#include "fonts.h"

// ---- board pins (Elecrow CrowPanel 1.28" rotary) ----
#define LCD_DC 3
#define LCD_CS 9
#define LCD_SCK 10
#define LCD_MOSI 11
#define LCD_RST 14
#define LCD_BL 46
#define PWR_A 1
#define PWR_B 2
#define PWR_LED 40
#define TP_SDA 6
#define TP_SCL 7
#define TP_RST 13
#define TP_ADDR 0x15
#define ENC_A 45
#define ENC_B 42
#define ENC_SW 41

// If one click of the knob changes the volume by two steps, set this to 2.
// If you have to turn two clicks for one step, set it to 8.
#define TRANSITIONS_PER_CLICK 4

Arduino_DataBus *bus = new Arduino_ESP32SPI(LCD_DC, LCD_CS, LCD_SCK, LCD_MOSI, GFX_NOT_DEFINED);
Arduino_GFX *panel = new Arduino_GC9A01(bus, LCD_RST, 0 /* rotation */, true /* IPS */);
Arduino_Canvas *canvas = new Arduino_Canvas(240, 240, panel);
Arduino_GFX *gfx = canvas;

// ---------------------------------------------------------------- faces
enum Bg { BG_SOLID, BG_AURORA, BG_RADIAL, BG_STARS, BG_CARBON, BG_SUNBURST, BG_RINGS, BG_SCAN, BG_RADAR };
enum Ring { R_GLOW, R_SEGMENTS, R_DIAL, R_THIN, R_DOTS, R_BARS, R_DOUBLE, R_GRADIENT, R_NONE, R_SPORT, R_COMET, R_CLOCK };
enum Center { C_MUSIC, C_CLOCK, C_SPEED, C_ANALOG, C_VOLUME, C_EQCLOCK, C_GAUGEINFO, C_SPEEDLOW };
enum Pal { P_THEME, P_CLASSIC, P_RACING, P_AMBER, P_ICE, P_LED };
struct Face { uint8_t bg, ring, center, speed, pal; };
// Same order as web/knob_faces.json on the Pi
const Face FACES[] = {
  {BG_AURORA, R_GLOW, C_MUSIC, 0, P_THEME},  //  0 Aurora
  {BG_SOLID, R_DIAL, C_GAUGEINFO, 0, P_THEME},  //  1 Gauge
  {BG_RADIAL, R_SEGMENTS, C_EQCLOCK, 0, P_THEME},  //  2 Neon
  {BG_SOLID, R_THIN, C_MUSIC, 0, P_THEME},  //  3 Minimal
  {BG_AURORA, R_DIAL, C_SPEED, 1, P_THEME},  //  4 Speedometer
  {BG_CARBON, R_SPORT, C_SPEEDLOW, 1, P_RACING},  //  5 Sport
  {BG_CARBON, R_SPORT, C_SPEEDLOW, 1, P_THEME},  //  6 Turbo
  {BG_SOLID, R_SEGMENTS, C_SPEED, 1, P_THEME},  //  7 Digital speed
  {BG_SUNBURST, R_DIAL, C_SPEED, 1, P_AMBER},  //  8 Rally
  {BG_SCAN, R_GRADIENT, C_SPEED, 1, P_LED},  //  9 Night HUD
  {BG_RINGS, R_SPORT, C_SPEEDLOW, 1, P_CLASSIC},  // 10 Cockpit
  {BG_SOLID, R_CLOCK, C_ANALOG, 0, P_CLASSIC},  // 11 Classic watch
  {BG_RINGS, R_CLOCK, C_ANALOG, 0, P_THEME},  // 12 Chronograph
  {BG_AURORA, R_COMET, C_ANALOG, 0, P_THEME},  // 13 Aurora watch
  {BG_AURORA, R_NONE, C_CLOCK, 0, P_THEME},  // 14 Big clock
  {BG_RADIAL, R_GLOW, C_CLOCK, 0, P_THEME},  // 15 Halo
  {BG_STARS, R_GRADIENT, C_CLOCK, 0, P_THEME},  // 16 Night drive
  {BG_STARS, R_DOTS, C_MUSIC, 0, P_THEME},  // 17 Starfield
  {BG_CARBON, R_GLOW, C_MUSIC, 0, P_THEME},  // 18 Carbon
  {BG_SUNBURST, R_GRADIENT, C_MUSIC, 0, P_THEME},  // 19 Sunburst
  {BG_RADAR, R_THIN, C_CLOCK, 0, P_THEME},  // 20 Radar
  {BG_RADIAL, R_BARS, C_MUSIC, 0, P_THEME},  // 21 Pulse
  {BG_SOLID, R_BARS, C_EQCLOCK, 0, P_THEME},  // 22 Equalizer
  {BG_SCAN, R_SEGMENTS, C_CLOCK, 0, P_AMBER},  // 23 Retro amber
  {BG_SCAN, R_SEGMENTS, C_EQCLOCK, 0, P_LED},  // 24 Green LED
  {BG_RADIAL, R_DOUBLE, C_MUSIC, 0, P_ICE},  // 25 Ice
  {BG_SOLID, R_DOUBLE, C_VOLUME, 0, P_THEME},  // 26 Twin ring
  {BG_SOLID, R_DOTS, C_CLOCK, 0, P_THEME},  // 27 Dot matrix
  {BG_SOLID, R_GRADIENT, C_VOLUME, 0, P_THEME},  // 28 Big volume
  {BG_AURORA, R_BARS, C_MUSIC, 0, P_THEME},  // 29 Bloom
};
const int FACE_COUNT = sizeof(FACES) / sizeof(FACES[0]);
// accent, background, text, blob 1, blob 2, blob 3 for the faces with their own colors
const uint32_t PALETTES[][6] = {
  {0, 0, 0, 0, 0, 0},
  {0xFFFFFF, 0x101214, 0xFFFFFF, 0x3F3F46, 0x27272A, 0x52525B},  // classic
  {0xEF4444, 0x0A0A0A, 0xFFFFFF, 0xB91C1C, 0x1F2937, 0xDC2626},  // racing
  {0xFFB000, 0x120A00, 0xFFD27A, 0xB45309, 0x78350F, 0xF59E0B},  // amber
  {0x7DD3FC, 0x020A12, 0xE0F2FE, 0x38BDF8, 0x1E3A8A, 0xA5F3FC},  // ice
  {0x39FF14, 0x000800, 0xB6FF5C, 0x14532D, 0x16A34A, 0x052E16},  // green LED
};

// ---------------------------------------------------------------- state from the Pi
struct State {
  int volume = 40;
  bool playing = false;
  uint16_t tAccent = 0x5F3A, tBase = 0x0000, tText = 0xFFFF, tBlob[3] = {0x15D4, 0x79DD, 0x05DD};  // theme
  uint16_t accent = 0x5F3A, base = 0x0000, text = 0xFFFF, sub = 0xBDF7, dim = 0x2104;           // in use
  uint16_t blob[3] = {0x15D4, 0x79DD, 0x05DD};
  String clock = "", title = "", artist = "", call = "", caller = "";
  int face = 0;
  bool animate = true;
  int bright = 100;
  String speed = "", units = "mph", top = "clock";
  int motion = 1;  // 0 calm, 1 lively, 2 wild
  long secs = -1;  // seconds since midnight when the last message came in
  unsigned long secsAtMs = 0;
} st;
float shownSpeed = 0;
unsigned long bootSweepMs = 0;
bool haveState = false;
unsigned long lastStateMs = 0, volumeShownMs = 0;
float shownVol = 40;
bool dirty = true;
inline const Face &face() { return FACES[constrain(st.face, 0, FACE_COUNT - 1)]; }

// ---------------------------------------------------------------- color helpers
uint16_t rgb565(uint32_t v) { return ((v >> 8) & 0xF800) | ((v >> 5) & 0x07E0) | ((v >> 3) & 0x001F); }
uint16_t hex565(const String &h) { return rgb565(strtol(h.c_str(), nullptr, 16)); }
uint16_t mix565(uint16_t a, uint16_t b, float t) {  // t = 0 -> a, t = 1 -> b
  int r = ((a >> 11) & 31) * (1 - t) + ((b >> 11) & 31) * t;
  int g = ((a >> 5) & 63) * (1 - t) + ((b >> 5) & 63) * t;
  int bl = (a & 31) * (1 - t) + (b & 31) * t;
  return (r << 11) | (g << 5) | bl;
}
inline void unpack(uint16_t c, int &r, int &g, int &b) { r = ((c >> 11) & 31) << 3; g = ((c >> 5) & 63) << 2; b = (c & 31) << 3; }
inline uint16_t pack(int r, int g, int b) { return ((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3); }
const uint16_t REDLINE_COLOR = 0xF186;

void applyColors() {
  int p = face().pal;
  if (p == P_THEME) {
    st.accent = st.tAccent; st.base = st.tBase; st.text = st.tText;
    for (int k = 0; k < 3; k++) st.blob[k] = st.tBlob[k];
  } else {
    st.accent = rgb565(PALETTES[p][0]); st.base = rgb565(PALETTES[p][1]); st.text = rgb565(PALETTES[p][2]);
    for (int k = 0; k < 3; k++) st.blob[k] = rgb565(PALETTES[p][3 + k]);
  }
  st.sub = mix565(st.base, st.text, 0.65);
  st.dim = mix565(st.base, st.text, 0.16);
}

// ---------------------------------------------------------------- text
int textWidth(const String &s, const GFXfont *f) {
  int16_t x1, y1; uint16_t w, h;
  gfx->setFont(f);
  gfx->getTextBounds(s.c_str(), 0, 100, &x1, &y1, &w, &h);
  return w + x1;
}
String fitText(String s, const GFXfont *f, int maxW) {
  if (textWidth(s, f) <= maxW) return s;
  while (s.length() > 1 && textWidth(s + "...", f) > maxW) s.remove(s.length() - 1);
  return s + "...";
}
void centerText(const String &s, int baseline, const GFXfont *f, uint16_t color, int maxW = 190) {
  String t = fitText(s, f, maxW);
  gfx->setFont(f);
  gfx->setTextColor(color);
  gfx->setCursor(120 - textWidth(t, f) / 2, baseline);
  gfx->print(t);
}
// Long song titles scroll; the ring drawn afterwards hides the edges.
bool marqueeActive = false;
void marquee(const String &s, int baseline, const GFXfont *f, uint16_t color, int maxW = 180) {
  int w = textWidth(s, f);
  if (w <= maxW || !st.animate) { centerText(s, baseline, f, color, maxW); return; }
  marqueeActive = true;
  int gap = 50, cycle = w + gap;
  int off = (millis() / 28) % cycle;
  gfx->setFont(f);
  gfx->setTextColor(color);
  for (int x = 30 - off; x < 240; x += cycle) { gfx->setCursor(x, baseline); gfx->print(s); }
}
// Big digits with a drawn colon (the large font only has digits): "12:45"
void bigDigits(const String &s, int baseline, uint16_t color) {
  const GFXfont *f = &Bold76;
  int w = 0;
  for (unsigned i = 0; i < s.length(); i++) w += s[i] == ':' ? 22 : textWidth(String(s[i]), f);
  int x = 120 - w / 2;
  gfx->setFont(f);
  gfx->setTextColor(color);
  for (unsigned i = 0; i < s.length(); i++) {
    if (s[i] == ':') {
      gfx->fillCircle(x + 11, baseline - 44, 5, color);
      gfx->fillCircle(x + 11, baseline - 16, 5, color);
      x += 22;
    } else if (s[i] >= '0' && s[i] <= '9') {
      gfx->setCursor(x, baseline);
      gfx->print(s[i]);
      x += textWidth(String(s[i]), f);
    }
  }
}
void thickLine(float x0, float y0, float x1, float y1, float w, uint16_t c) {
  float dx = x1 - x0, dy = y1 - y0, len = sqrtf(dx * dx + dy * dy);
  if (len < 0.5f) return;
  float nx = -dy / len * w / 2, ny = dx / len * w / 2;
  gfx->fillTriangle(x0 + nx, y0 + ny, x1 + nx, y1 + ny, x1 - nx, y1 - ny, c);
  gfx->fillTriangle(x0 + nx, y0 + ny, x1 - nx, y1 - ny, x0 - nx, y0 - ny, c);
}
float clockSecs() {  // seconds since midnight, running between messages
  if (st.secs < 0) return 0;
  return fmodf(st.secs + (millis() - st.secsAtMs) / 1000.0f, 86400.0f);
}

// ---------------------------------------------------------------- backgrounds
uint16_t *bgCache = nullptr;
uint32_t bgKey = 0xFFFFFFFF;

// Aurora: three soft blobs in the theme's colors drifting slowly, with a frosted center disc.
void drawAurora(float t) {
  uint16_t *fb = canvas->getFramebuffer();
  int br, bgc, bb; unpack(st.base, br, bgc, bb);
  int cr[3], cg[3], cb[3];
  for (int k = 0; k < 3; k++) unpack(st.blob[k], cr[k], cg[k], cb[k]);
  int bx[3] = {int(70 + 45 * sinf(t * 0.31f)), int(175 + 40 * cosf(t * 0.23f)), int(150 + 50 * sinf(t * 0.19f + 1))};
  int by[3] = {int(75 + 40 * cosf(t * 0.27f)), int(170 + 40 * sinf(t * 0.29f)), int(80 + 50 * cosf(t * 0.21f + 2))};
  const int R = 150, R2 = R * R, INV = (256 << 16) / R2, GLASS2 = 97 * 97;
  for (int y = 0; y < 240; y++) {
    int dyc = y - 120;
    int half = sqrtf(max(0, 14400 - dyc * dyc)) + 1;
    int x0 = max(0, 120 - half), x1 = min(239, 120 + half);
    uint16_t *row = fb + y * 240;
    for (int x = 0; x < x0; x++) row[x] = 0;
    for (int x = x1 + 1; x < 240; x++) row[x] = 0;
    for (int x = x0; x <= x1; x++) {
      int r = br, g = bgc, b = bb;
      for (int k = 0; k < 3; k++) {
        int dx = x - bx[k], dy = y - by[k];
        int d2 = dx * dx + dy * dy;
        if (d2 < R2) {
          int w = ((R2 - d2) * INV) >> 16;
          w = (w * w) >> 8;
          w = (w * 215) >> 8;
          r += ((cr[k] - r) * w) >> 8;
          g += ((cg[k] - g) * w) >> 8;
          b += ((cb[k] - b) * w) >> 8;
        }
      }
      int dxc = x - 120;
      if (dxc * dxc + dyc * dyc < GLASS2) {
        r = (r * 120 + br * 136) >> 8; g = (g * 120 + bgc * 136) >> 8; b = (b * 120 + bb * 136) >> 8;
      }
      row[x] = pack(r, g, b);
    }
  }
  gfx->drawCircle(120, 120, 97, mix565(st.base, st.text, 0.22));
}

// Backgrounds that don't move are drawn once and copied every frame.
void buildStatic(int kind) {
  uint16_t *fb = canvas->getFramebuffer();
  int br, bg, bb, ar, ag, ab; unpack(st.base, br, bg, bb); unpack(st.accent, ar, ag, ab);
  if (kind == BG_SOLID || kind == BG_RINGS || kind == BG_RADAR || kind == BG_STARS) {
    gfx->fillScreen(st.base);
    if (kind == BG_RINGS || kind == BG_RADAR)
      for (int r = 20; r < 120; r += 18) gfx->drawCircle(120, 120, r, mix565(st.base, kind == BG_RADAR ? st.accent : st.text, kind == BG_RADAR ? 0.22f : 0.12f));
    if (kind == BG_RADAR) { gfx->drawLine(0, 120, 239, 120, mix565(st.base, st.accent, 0.18f)); gfx->drawLine(120, 0, 120, 239, mix565(st.base, st.accent, 0.18f)); }
  } else {
    for (int y = 0; y < 240; y++) for (int x = 0; x < 240; x++) {
      int dx = x - 120, dy = y - 120;
      float t = 0;
      int r = br, g = bg, b = bb;
      if (kind == BG_RADIAL) {
        float d = sqrtf(dx * dx + dy * dy) / 150.0f;
        t = d < 1 ? (1 - d) * (1 - d) * 0.42f : 0;
      } else if (kind == BG_CARBON) {
        int cell = ((x / 6) + (y / 6)) & 1;
        int v = cell ? (x % 6) : (y % 6);
        int lift = 6 + v * 3 - (cell ? 0 : 4);
        r = min(255, br + lift); g = min(255, bg + lift); b = min(255, bb + lift);
        float d = sqrtf(dx * dx + dy * dy) / 120.0f;  // gentle light from the center
        int glow = d < 1 ? int((1 - d) * 14) : 0;
        r = min(255, r + glow); g = min(255, g + glow); b = min(255, b + glow);
      } else if (kind == BG_SUNBURST) {
        int wedge = int((atan2f(dy, dx) + PI) / (2 * PI) * 24) & 1;
        float d = sqrtf(dx * dx + dy * dy) / 170.0f;
        t = wedge ? 0.10f * (1 - d * 0.5f) : 0.02f;
      } else if (kind == BG_SCAN) {
        float d = sqrtf(dx * dx + dy * dy) / 170.0f;
        t = 0.10f * (1 - d);
        if (y % 3 == 0) { r = r * 6 / 10; g = g * 6 / 10; b = b * 6 / 10; }
      }
      if (t > 0) { r += int((ar - r) * t); g += int((ag - g) * t); b += int((ab - b) * t); }
      fb[y * 240 + x] = pack(r, g, b);
    }
  }
  if (bgCache) memcpy(bgCache, fb, 240 * 240 * 2);
}

const int STARS = 70;
float sx[STARS], sy[STARS], sz[STARS];
void starfield(float dt) {
  float v = (0.08f + 0.06f * st.motion) * (1 + (st.speed.length() ? st.speed.toFloat() / 40.0f : 0));
  for (int i = 0; i < STARS; i++) {
    if (st.animate) sz[i] -= dt * v;
    if (sz[i] <= 0.05f) { sx[i] = random(-1000, 1000) / 1000.0f; sy[i] = random(-1000, 1000) / 1000.0f; sz[i] = 1; }
    int x = 120 + sx[i] / sz[i] * 90, y = 120 + sy[i] / sz[i] * 90;
    if (x < 0 || x > 239 || y < 0 || y > 239) { sz[i] = 0; continue; }
    float k = 1 - sz[i];
    uint16_t c = mix565(st.base, i % 4 == 0 ? st.accent : st.text, min(1.0f, k * 1.4f));
    if (k > 0.6f) gfx->fillCircle(x, y, 1, c); else gfx->drawPixel(x, y, c);
  }
}

void drawBackground(float t, float dt) {
  int kind = face().bg;
  if (kind == BG_AURORA) { drawAurora(st.animate ? t * (0.6f + 0.5f * st.motion) : 0); return; }
  uint32_t key = (kind << 28) ^ (st.base << 12) ^ st.accent ^ (st.text << 5);
  if (key != bgKey || !bgCache) { buildStatic(kind); bgKey = key; }
  else memcpy(canvas->getFramebuffer(), bgCache, 240 * 240 * 2);
  if (kind == BG_STARS) starfield(dt);
  if (kind == BG_RADAR && st.animate) {
    float a = fmodf(t * (60 + 40 * st.motion), 360);
    for (int k = 0; k < 10; k++) gfx->fillArc(120, 120, 118, 0, a - (k + 1) * 5, a - k * 5, mix565(st.base, st.accent, 0.38f * (1 - k / 10.0f)));
    float ra = a * DEG_TO_RAD;
    gfx->drawLine(120, 120, 120 + cosf(ra) * 118, 120 + sinf(ra) * 118, mix565(st.accent, 0xFFFF, 0.4f));
  }
  if (kind == BG_SCAN && st.animate) {
    int y = int(t * (40 + 30 * st.motion)) % 300 - 30;
    for (int k = 0; k < 14; k++) if (y + k >= 0 && y + k < 240) gfx->drawFastHLine(0, y + k, 240, mix565(st.base, st.accent, 0.10f * (1 - abs(k - 7) / 7.0f)));
  }
}

// ---------------------------------------------------------------- rings
const float START = 135, SWEEP = 270;  // gap at the bottom
inline float angleFor(float frac) { return START + SWEEP * constrain(frac, 0.0f, 1.0f); }
void dot(float angleDeg, int r, int size, uint16_t c) {
  float a = angleDeg * DEG_TO_RAD;
  gfx->fillCircle(120 + cosf(a) * r, 120 + sinf(a) * r, size, c);
}
// A bright spot that runs along the lit part of a ring
void shimmer(float litDeg, int r1, int r2, float t) {
  if (!st.animate || st.motion == 0 || litDeg < 12) return;
  float pos = fmodf(t * (70 + 60 * st.motion), litDeg + 40) - 20;
  float a0 = START + max(0.0f, pos - 9), a1 = START + min(litDeg, pos + 9);
  if (a1 > a0) gfx->fillArc(120, 120, r1, r2, a0, a1, mix565(st.accent, 0xFFFF, 0.6));
}
int speedMax() { return st.units == "km/h" ? 200 : 120; }

void ringGlow(float f, bool halo) {
  gfx->fillArc(120, 120, 117, 109, START, START + SWEEP, st.dim);
  if (f > 0.005f) {
    if (halo) gfx->fillArc(120, 120, 120, 105, START, angleFor(f), mix565(st.base, st.accent, 0.35));
    gfx->fillArc(120, 120, 117, 109, START, angleFor(f), st.accent);
    shimmer(SWEEP * f, 117, 109, millis() / 1000.0f);
    dot(angleFor(f), 113, 7, st.text);
    dot(angleFor(f), 113, 4, st.accent);
  }
}
void ringSegments(float f) {
  const int N = 30;
  const float seg = SWEEP / N, gap = 3;
  for (int i = 0; i < N; i++) {
    float a0 = START + i * seg, a1 = a0 + seg - gap;
    if ((i + 0.5f) / N <= f) {
      gfx->fillArc(120, 120, 121, 99, a0 - 1, a1 + 1, mix565(st.base, st.accent, 0.28));
      gfx->fillArc(120, 120, 117, 104, a0, a1, st.accent);
      gfx->fillArc(120, 120, 113, 108, a0 + 1, a1 - 1, mix565(st.accent, 0xFFFF, 0.45));
    } else {
      gfx->fillArc(120, 120, 117, 104, a0, a1, st.dim);
    }
  }
  if (st.animate && st.motion == 2) {  // wild: the lit segments flicker in a chase
    int lit = int(f * N);
    if (lit > 0) { float a0 = START + ((millis() / 60) % lit) * seg; gfx->fillArc(120, 120, 117, 104, a0, a0 + seg - gap, 0xFFFF); }
  }
}
void needle(float f, int len, uint16_t c) {
  float a = angleFor(f) * DEG_TO_RAD, ca = cosf(a), sa = sinf(a);
  gfx->drawLine(120 + ca * 20, 120 + sa * 20, 120 + ca * (len + 4), 120 + sa * (len + 4), mix565(st.base, c, 0.45));
  int tx = 120 + ca * len, ty = 120 + sa * len;
  int lx = 120 - sa * 6 - ca * 16, ly = 120 + ca * 6 - sa * 16;
  int rx = 120 + sa * 6 - ca * 16, ry = 120 - ca * 6 - sa * 16;
  gfx->fillTriangle(tx, ty, lx, ly, rx, ry, c);
  gfx->fillCircle(tx, ty, 2, mix565(c, 0xFFFF, 0.6));
  gfx->fillCircle(120, 120, 13, c);
  gfx->fillCircle(120, 120, 6, st.base);
}
// Instrument dial: 40 ticks, numbers on the big ones
void dialTicks(float f, int maxValue, int labelEvery) {
  const int N = 40;
  for (int i = 0; i <= N; i++) {
    float a = (START + SWEEP * i / N) * DEG_TO_RAD, ca = cosf(a), sa = sinf(a);
    bool major = i % 4 == 0;
    int len = major ? 15 : 7;
    uint16_t c = (float(i) / N <= f + 0.0001f) ? st.accent : st.dim;
    for (int w = -(major ? 1 : 0); w <= (major ? 1 : 0); w++) {
      float px = -sa * w, py = ca * w;
      gfx->drawLine(120 + ca * 117 + px, 120 + sa * 117 + py, 120 + ca * (117 - len) + px, 120 + sa * (117 - len) + py, c);
    }
    if (i % labelEvery == 0) {
      String lbl = String(i * maxValue / N);
      gfx->setFont(&Sans15);
      gfx->setTextColor(st.sub);
      gfx->setCursor(120 + ca * 84 - textWidth(lbl, &Sans15) / 2, 120 + sa * 84 + 6);
      gfx->print(lbl);
    }
  }
}
// Sport dial: big numbered ticks, a red zone at the top of the range, a thin lit arc on the rim
void sportTicks(float f, int maxValue) {
  const int N = 24;  // 6 numbered marks, 4 small ticks between each
  float red = 0.83f;
  gfx->fillArc(120, 120, 120, 116, angleFor(red), START + SWEEP, mix565(st.base, REDLINE_COLOR, 0.85));
  if (f > 0.005f) gfx->fillArc(120, 120, 120, 117, START, angleFor(min(f, red)), st.accent);
  for (int i = 0; i <= N; i++) {
    float frac = float(i) / N;
    float a = angleFor(frac) * DEG_TO_RAD, ca = cosf(a), sa = sinf(a);
    bool major = i % 4 == 0;
    uint16_t c = frac >= red ? REDLINE_COLOR : (major ? st.text : st.sub);
    thickLine(120 + ca * 113, 120 + sa * 113, 120 + ca * (major ? 97 : 105), 120 + sa * (major ? 97 : 105), major ? 3.2f : 1.4f, c);
    if (major) {
      String lbl = String(int(frac * maxValue + 0.5f));
      gfx->setFont(&Sans15);
      gfx->setTextColor(frac >= red ? REDLINE_COLOR : st.text);
      gfx->setCursor(120 + ca * 80 - textWidth(lbl, &Sans15) / 2, 120 + sa * 80 + 6);
      gfx->print(lbl);
    }
  }
}
void ringThin(float f) {
  gfx->fillArc(120, 120, 116, 113, START, START + SWEEP, st.dim);
  if (f > 0.005f) { gfx->fillArc(120, 120, 117, 112, START, angleFor(f), st.accent); dot(angleFor(f), 114, 5, st.text); }
}
void ringDots(float f) {
  for (int i = 0; i <= 36; i++) {
    float fr = i / 36.0f;
    bool lit = fr <= f;
    dot(START + SWEEP * fr, 112, lit ? 4 : 2, lit ? (fr > f - 0.03f ? mix565(st.accent, 0xFFFF, 0.5) : st.accent) : st.dim);
  }
}
void ringBars(float f, float t) {
  for (int i = 0; i < 48; i++) {
    float a = (i * 7.5f - 90) * DEG_TO_RAD, ca = cosf(a), sa = sinf(a);
    bool lit = i / 48.0f <= f;
    float len = 4;
    if (lit) len = (st.playing && st.animate) ? 6 + 16 * fabsf(sinf(t * (2.5f + (i % 5) * 0.8f) * (0.7f + 0.3f * st.motion) + i * 1.3f)) : 10;
    thickLine(120 + ca * 117, 120 + sa * 117, 120 + ca * (117 - len), 120 + sa * (117 - len), 3.2f, lit ? st.accent : st.dim);
  }
}
void ringDouble(float f, float t) {
  gfx->fillArc(120, 120, 118, 113, 0, 360, st.dim);
  if (f > 0.005f) gfx->fillArc(120, 120, 118, 113, START, angleFor(f), st.accent);
  gfx->fillArc(120, 120, 105, 102, 0, 360, mix565(st.base, st.blob[0], 0.25));
  float spin = st.animate ? fmodf(t * (30 + 25 * st.motion), 360) : 0;
  gfx->fillArc(120, 120, 106, 101, 360 - spin, 360 - spin + 60, st.blob[0]);
  gfx->fillArc(120, 120, 106, 101, 180 - spin, 180 - spin + 60, st.blob[0]);
}
void ringGradient(float f) {
  const int N = 54;
  for (int i = 0; i < N; i++) {
    float a0 = START + SWEEP * i / N, a1 = START + SWEEP * (i + 1) / N + 0.6f;
    bool lit = (i + 0.5f) / N <= f;
    gfx->fillArc(120, 120, 117, 104, a0, a1, lit ? mix565(st.blob[0], st.accent, float(i) / N) : st.dim);
  }
  if (f > 0.01f) {
    dot(START, 110, 6, st.blob[0]);
    dot(angleFor(f), 110, 7, mix565(st.accent, 0xFFFF, 0.3));
  }
}
void ringComet(float secs) {
  gfx->drawCircle(120, 120, 114, st.dim);
  gfx->drawCircle(120, 120, 115, st.dim);
  float a = fmodf(secs, 60) * 6 - 90;
  for (int k = 0; k < 14; k++)
    gfx->fillArc(120, 120, 118 - k / 4, 111 + k / 4, a - (k + 1) * 4, a - k * 4 + 0.5f, mix565(st.base, st.accent, 1 - k / 14.0f));
  dot(a, 114, 5, 0xFFFF);
}
void ringClock() {
  for (int i = 0; i < 60; i++) {
    float a = (i * 6) * DEG_TO_RAD, ca = cosf(a), sa = sinf(a);
    bool hour = i % 5 == 0;
    thickLine(120 + ca * 117, 120 + sa * 117, 120 + ca * (hour ? 103 : 111), 120 + sa * (hour ? 103 : 111), hour ? 3.5f : 1.3f, hour ? st.text : st.dim);
  }
  const char *n[4] = {"3", "6", "9", "12"};
  for (int k = 0; k < 4; k++) {
    float a = (k * 90) * DEG_TO_RAD;
    String s = n[k];
    gfx->setFont(&Bold19);
    gfx->setTextColor(st.text);
    gfx->setCursor(120 + cosf(a) * 86 - textWidth(s, &Bold19) / 2, 120 + sinf(a) * 86 + 8);
    gfx->print(s);
  }
}

// Parts of the ring that go under the text, and parts that go on top (needles)
void ringUnder(int ring, float f, float t) {
  switch (ring) {
    case R_GLOW: ringGlow(f, true); break;
    case R_SEGMENTS: ringSegments(f); break;
    case R_DIAL: dialTicks(f, face().speed ? speedMax() : 100, face().speed ? (st.units == "km/h" ? 8 : 8) : 8); break;
    case R_THIN: ringThin(f); break;
    case R_DOTS: ringDots(f); break;
    case R_BARS: ringBars(f, t); break;
    case R_DOUBLE: ringDouble(f, t); break;
    case R_GRADIENT: ringGradient(f); break;
    case R_SPORT: sportTicks(f, face().speed ? speedMax() : 100); break;
    case R_COMET: ringComet(clockSecs()); break;
    case R_CLOCK: ringClock(); break;
    default: break;
  }
}
void ringOver(int ring, float f) {
  if (ring == R_DIAL) needle(f, 100, st.accent);
  if (ring == R_SPORT) needle(f, 108, face().pal == P_THEME ? st.accent : (face().pal == P_CLASSIC ? 0xFD20 : st.accent));
}

// ---------------------------------------------------------------- centers
String topLine() {
  if (st.top == "speed" && st.speed.length()) return st.speed + " " + st.units;
  return st.clock;
}
void playButton(int cx, int cy, float t) {
  if (st.playing && st.animate) {
    float p = (sinf(t * 3.0f) + 1) / 2;  // breathing halo
    gfx->fillCircle(cx, cy, 26 + p * 5, mix565(st.base, st.accent, 0.25f + 0.15f * p));
  }
  gfx->fillCircle(cx, cy, 23, st.accent);
  uint16_t ink = st.base;
  if (st.playing) {
    gfx->fillRoundRect(cx - 9, cy - 10, 6, 20, 2, ink);
    gfx->fillRoundRect(cx + 3, cy - 10, 6, 20, 2, ink);
  } else {
    gfx->fillTriangle(cx - 6, cy - 11, cx - 6, cy + 11, cx + 11, cy, ink);
  }
}
void equalizer(int cx, int baseY, float t) {
  for (int i = 0; i < 5; i++) {
    float h = st.playing ? (st.animate ? 6 + 16 * (0.5f + 0.5f * sinf(t * (4.0f + i * 1.3f) + i)) : 14) : 4;
    gfx->fillRoundRect(cx - 22 + i * 9, baseY - h, 6, h, 2, st.playing ? st.accent : st.dim);
  }
}
void analogHands(float secs) {
  float h = fmodf(secs / 3600.0f, 12), m = fmodf(secs / 60.0f, 60), s = fmodf(secs, 60);
  if (!st.animate) s = floorf(s);
  auto hand = [](float deg, float len, float tail, float w, uint16_t c) {
    float a = (deg - 90) * DEG_TO_RAD;
    thickLine(120 - cosf(a) * tail, 120 - sinf(a) * tail, 120 + cosf(a) * len, 120 + sinf(a) * len, w, c);
  };
  hand(h * 30, 54, 10, 7, st.text);
  hand(m * 6, 84, 12, 4.5f, st.text);
  hand(s * 6, 94, 20, 2, st.accent);
  gfx->fillCircle(120, 120, 7, st.accent);
  gfx->fillCircle(120, 120, 3, st.base);
}
void drawCenter(int c, float t) {
  switch (c) {
    case C_CLOCK:
      bigDigits(st.clock, 150, st.text);
      if (st.title.length()) centerText(st.title, 184, &Sans15, st.sub, 150);
      break;
    case C_SPEED: {
      String sp = st.speed.length() ? String(int(shownSpeed + 0.5f)) : "0";
      centerText(sp, 160, &Bold76, st.text, 220);
      centerText(st.speed.length() ? st.units : "No GPS", 186, &Sans15, st.sub);
      centerText(st.clock, 66, &Sans15, st.sub);
      break;
    }
    case C_SPEEDLOW: {
      String sp = st.speed.length() ? String(int(shownSpeed + 0.5f)) : "0";
      centerText(sp, 186, &Bold34, st.text, 120);
      centerText(st.speed.length() ? st.units : "No GPS", 206, &Sans15, st.sub);
      break;
    }
    case C_ANALOG:
      if (st.secs < 0) centerText("Waiting for time", 172, &Sans15, st.sub);
      analogHands(clockSecs());
      break;
    case C_VOLUME:
      centerText(topLine(), 70, &Sans15, st.sub);
      centerText(String(st.volume), 152, &Bold76, st.text, 220);
      centerText("Volume", 184, &Sans15, st.sub);
      break;
    case C_EQCLOCK:
      centerText(st.top == "speed" && st.speed.length() ? st.speed : st.clock, 112, &Bold34, st.text);
      if (st.top == "speed" && st.speed.length()) centerText(st.units, 70, &Sans15, st.sub);
      marquee(st.title.length() ? st.title : "Nothing playing", 144, &Sans15, st.sub, 170);
      equalizer(120, 182, t);
      break;
    case C_GAUGEINFO:
      centerText(topLine(), 66, &Sans15, st.sub);
      centerText(String(st.volume), 168, &Bold19, st.text);
      centerText(st.title.length() ? st.title : "Nothing playing", 194, &Sans15, st.sub, 120);
      break;
    default:  // C_MUSIC
      centerText(topLine(), 64, &Sans15, st.sub);
      if (st.title.length()) {
        marquee(st.title, 108, &Bold19, st.text, 180);
        centerText(st.artist, 134, &Sans15, st.sub, 170);
      } else {
        centerText("Nothing playing", 118, &Sans15, st.sub);
      }
      playButton(120, 176, t);
  }
}

// ---------------------------------------------------------------- screens
void drawNormal(float t, bool volMode) {
  const Face &fc = face();
  float f = fc.speed ? shownSpeed / speedMax() : shownVol / 100.0f;
  bool ringShowsVolume = !fc.speed && fc.ring != R_NONE && fc.ring != R_COMET && fc.ring != R_CLOCK;
  if (volMode && fc.center != C_VOLUME && fc.center != C_GAUGEINFO) {
    // turning the knob: show the volume big, on this face's ring if it can show it
    int ring = ringShowsVolume ? fc.ring : R_GLOW;
    float v = shownVol / 100.0f;
    ringUnder(ring, v, t);
    centerText(String(st.volume), 152, &Bold76, st.text, 220);
    centerText("Volume", 184, &Sans15, st.sub);
    if (ring == R_DIAL || ring == R_SPORT) dot(angleFor(v), 113, 6, st.text);
    return;
  }
  ringUnder(fc.ring, f, t);
  drawCenter(fc.center, t);
  ringOver(fc.ring, f);
}

void drawCall(float t) {
  bool ringing = st.call == "incoming" || st.call == "waiting";
  uint16_t green = 0x3666;
  float p = (sinf(t * 5) + 1) / 2;
  gfx->fillArc(120, 120, 119, 106, 0, 360, ringing ? mix565(st.base, green, 0.4f + 0.6f * p) : st.accent);
  centerText(ringing ? "Incoming call" : (st.call == "active" ? "On a call" : "Calling..."), 78, &Sans15, st.sub);
  centerText(st.caller, 118, &Bold19, st.text, 170);
  if (ringing) {
    centerText("Press to answer", 156, &Sans15, st.text);
    centerText("Hold to decline", 178, &Sans15, st.sub);
  } else {
    centerText("Hold to hang up", 166, &Sans15, st.sub);
  }
}

unsigned long lastFrameMs = 0;
void draw() {
  float t = millis() / 1000.0f;
  float dt = min(0.1f, (millis() - lastFrameMs) / 1000.0f);
  lastFrameMs = millis();
  marqueeActive = false;
  drawBackground(t, dt);
  if (!haveState || millis() - lastStateMs > 40000) {
    centerText("Head unit", 112, &Bold19, st.text);
    centerText("Connecting...", 140, &Sans15, st.sub);
    ringGlow(0, false);
  } else if (st.call.length()) {
    drawCall(t);
  } else {
    drawNormal(t, millis() - volumeShownMs < 1800);
  }
  gfx->flush();
}

// ---------------------------------------------------------------- messages from the Pi
// S|vol|playing|accent|base|text|clock|title|artist|call|caller|face|blob1|blob2|blob3|animate|bright|speed|units|top|motion|secs
String inbuf;
void applyBrightness() {
  int b = st.bright <= 0 ? 6 : map(constrain(st.bright, 1, 100), 1, 100, 14, 255);
  analogWrite(LCD_BL, b);
}
void handleLine(const String &line) {
  if (!line.startsWith("S|")) return;
  String f[24];
  int n = 0, from = 0;
  while (n < 24) {
    int bar = line.indexOf('|', from);
    if (bar < 0) { f[n++] = line.substring(from); break; }
    f[n++] = line.substring(from, bar);
    from = bar + 1;
  }
  if (n < 11) return;
  int newVol = f[1].toInt();
  if (haveState && newVol != st.volume) volumeShownMs = millis();
  st.volume = newVol;
  st.playing = f[2] == "1";
  st.tAccent = hex565(f[3]);
  st.tBase = hex565(f[4]);
  st.tText = hex565(f[5]);
  st.clock = f[6]; st.title = f[7]; st.artist = f[8]; st.call = f[9]; st.caller = f[10];
  if (n >= 17) {
    st.face = constrain(f[11].toInt(), 0, FACE_COUNT - 1);
    for (int k = 0; k < 3; k++) st.tBlob[k] = hex565(f[12 + k]);
    st.animate = f[15] == "1";
    int nb = f[16].toInt();
    if (nb != st.bright) { st.bright = nb; applyBrightness(); }
  }
  if (n >= 21) {
    st.speed = f[17]; st.units = f[18]; st.top = f[19]; st.motion = constrain(f[20].toInt(), 0, 2);
  }
  if (n >= 22 && f[21].length()) { st.secs = f[21].toInt(); st.secsAtMs = millis(); }
  applyColors();
  if (!haveState) { shownVol = 0; bootSweepMs = millis(); }
  haveState = true;
  lastStateMs = millis();
  dirty = true;
}
void readSerial() {
  while (Serial.available()) {
    char c = Serial.read();
    if (c == '\n') { handleLine(inbuf); inbuf = ""; }
    else if (c != '\r' && inbuf.length() < 500) inbuf += c;
  }
}

// ---------------------------------------------------------------- rotary encoder
volatile int encTransitions = 0;
volatile uint8_t encPrev = 0;
const int8_t QDEC[16] = {0, -1, 1, 0, 1, 0, 0, -1, -1, 0, 0, 1, 0, 1, -1, 0};
void IRAM_ATTR onEncoder() {
  uint8_t now = (digitalRead(ENC_A) << 1) | digitalRead(ENC_B);
  encTransitions += QDEC[(encPrev << 2) | now];
  encPrev = now;
}
void readEncoder() {
  noInterrupts();
  int clicks = encTransitions / TRANSITIONS_PER_CLICK;
  encTransitions -= clicks * TRANSITIONS_PER_CLICK;
  interrupts();
  if (clicks) {
    Serial.printf("R%+d\n", clicks);
    st.volume = constrain(st.volume + 2 * clicks, 0, 100);  // instant feedback before the Pi answers
    volumeShownMs = millis();
    dirty = true;
  }
}

// ---------------------------------------------------------------- push button
bool swDown = false, longSent = false, waitingDouble = false;
unsigned long swDownMs = 0, lastReleaseMs = 0;
void readButton() {
  bool down = digitalRead(ENC_SW) == LOW;
  unsigned long now = millis();
  if (down && !swDown) { swDown = true; swDownMs = now; longSent = false; }
  if (down && !longSent && now - swDownMs > 700) { Serial.println("L"); longSent = true; }
  if (!down && swDown) {
    swDown = false;
    if (!longSent && now - swDownMs > 20) {
      if (waitingDouble && now - lastReleaseMs < 350) { Serial.println("D"); waitingDouble = false; }
      else { waitingDouble = true; lastReleaseMs = now; }
    }
  }
  if (waitingDouble && !swDown && now - lastReleaseMs >= 350) { Serial.println("P"); waitingDouble = false; }
}

// ---------------------------------------------------------------- touch
bool touching = false;
int tx0 = 0, ty0 = 0, txL = 0, tyL = 0;
unsigned long touchStartMs = 0, lastTouchPoll = 0;
void readTouch() {
  if (millis() - lastTouchPoll < 20) return;
  lastTouchPoll = millis();
  Wire.beginTransmission(TP_ADDR);
  Wire.write(0x02);
  if (Wire.endTransmission(false) != 0) return;
  if (Wire.requestFrom(TP_ADDR, 5) != 5) return;
  uint8_t fingers = Wire.read();
  uint8_t xh = Wire.read(), xl = Wire.read(), yh = Wire.read(), yl = Wire.read();
  int x = ((xh & 0x0F) << 8) | xl, y = ((yh & 0x0F) << 8) | yl;
  if (fingers && !touching) { touching = true; tx0 = txL = x; ty0 = tyL = y; touchStartMs = millis(); }
  else if (fingers) { txL = x; tyL = y; }
  else if (touching) {
    touching = false;
    int dx = txL - tx0, dy = tyL - ty0;
    if (abs(dy) > 60 && abs(dy) > abs(dx)) {
      Serial.println("K");
      st.face = (st.face + (dy > 0 ? 1 : FACE_COUNT - 1)) % FACE_COUNT;  // show it right away
      applyColors();
      dirty = true;
    } else if (dx > 60) Serial.println("SR");
    else if (dx < -60) Serial.println("SL");
    else if (millis() - touchStartMs < 400) Serial.println("P");
  }
}

// ---------------------------------------------------------------- main
void setup() {
  Serial.begin(115200);
  pinMode(PWR_A, OUTPUT); digitalWrite(PWR_A, HIGH);
  pinMode(PWR_B, OUTPUT); digitalWrite(PWR_B, HIGH);
  pinMode(PWR_LED, OUTPUT); digitalWrite(PWR_LED, LOW);
  pinMode(LCD_BL, OUTPUT);
  applyBrightness();
  delay(200);

  gfx->begin(80000000);
  gfx->setTextWrap(false);
  bgCache = (uint16_t *)ps_malloc(240 * 240 * 2);
  for (int i = 0; i < STARS; i++) { sx[i] = random(-1000, 1000) / 1000.0f; sy[i] = random(-1000, 1000) / 1000.0f; sz[i] = random(50, 1000) / 1000.0f; }
  applyColors();

  pinMode(TP_RST, OUTPUT);
  digitalWrite(TP_RST, LOW); delay(10);
  digitalWrite(TP_RST, HIGH); delay(50);
  Wire.begin(TP_SDA, TP_SCL, 400000);

  pinMode(ENC_A, INPUT_PULLUP);
  pinMode(ENC_B, INPUT_PULLUP);
  pinMode(ENC_SW, INPUT_PULLUP);
  encPrev = (digitalRead(ENC_A) << 1) | digitalRead(ENC_B);
  attachInterrupt(digitalPinToInterrupt(ENC_A), onEncoder, CHANGE);
  attachInterrupt(digitalPinToInterrupt(ENC_B), onEncoder, CHANGE);
}

unsigned long lastDraw = 0;
bool volumeWasShown = false;
void loop() {
  readSerial();
  readEncoder();
  readButton();
  readTouch();

  // start-up flourish: the ring sweeps all the way round, then settles on the volume
  unsigned long since = millis() - bootSweepMs;
  if (bootSweepMs && since < 1400 && st.animate) {
    float k = since / 1400.0f;
    shownVol = k < 0.55f ? 100.0f * (k / 0.55f) : 100.0f + (st.volume - 100.0f) * ((k - 0.55f) / 0.45f);
    shownSpeed = speedMax() * (k < 0.55f ? k / 0.55f : 1 - (k - 0.55f) / 0.45f);
    dirty = true;
  } else {
    // glide the ring toward the real volume, the needle toward the real speed
    float diff = st.volume - shownVol;
    if (fabsf(diff) > 0.2f) { shownVol += diff * 0.25f; dirty = true; } else shownVol = st.volume;
    float target = st.speed.length() ? st.speed.toFloat() : 0;
    float ds = target - shownSpeed;
    if (fabsf(ds) > 0.2f) { shownSpeed += ds * 0.15f; dirty = true; } else shownSpeed = target;
  }

  bool volNow = millis() - volumeShownMs < 1800;
  if (volNow != volumeWasShown) { volumeWasShown = volNow; dirty = true; }

  const Face &fc = face();
  bool animatedFace = fc.bg == BG_AURORA || fc.bg == BG_STARS || fc.bg == BG_RADAR || fc.bg == BG_SCAN ||
                      fc.ring == R_BARS || fc.ring == R_DOUBLE || fc.ring == R_COMET || fc.center == C_ANALOG;
  bool moving = haveState && (
      (st.animate && (animatedFace || st.motion > 0 || st.playing)) ||
      marqueeActive || st.call == "incoming" || st.call == "waiting");
  unsigned long gap = millis() - lastDraw;
  // analog clocks tick once a second even with animations off
  bool tick = fc.center == C_ANALOG && gap > 1000;
  if (((dirty || moving) && gap > 33) || tick || gap > 5000) {
    dirty = false;
    lastDraw = millis();
    draw();
  }
  delay(1);
}
