-- WirePlumber 0.4: Pi acts as a car stereo (receives music, hands-free calls via oFono)
bluez_monitor.properties["bluez5.roles"] = "[ a2dp_sink hfp_hf ]"
bluez_monitor.properties["bluez5.hfphsp-backend"] = "ofono"
