// Gauges: draws every <canvas data-gauge="..."> on the screen (the Gauges screen and gauge tiles on Home).
// Readings come from the OBD adapter (speed falls back to the phone's GPS). Needles glide between readings
// at the screen's frame rate. Colors follow the theme. Loaded after app.js (uses S, OBDS, settings, g).
'use strict';
(function () {
  const TAU = Math.PI * 2, rad = (d) => (d * Math.PI) / 180, clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  let A0 = rad(135), SWEEP = rad(270);   // dials open at the bottom (the 'arcs' layout bends these per canvas)
  let ARC = null;   // 'left' | 'right' while drawing a canvas in an .arcL / .arcR tile (cluster layout 'arcs')

  // ---------------------------------------------------------------- readings
  const sm = {};   // smoothed values
  const trip = { mpgAvg: null, mpgN: 0, lastKmh: null, lastT: 0, accel: 0 };
  function raw() {
    if (QO.demo != null) {   // test hook (?demo=0..1): fake readings
      const d = clamp(Number(QO.demo) || 0, 0, 1);
      return { rpm: 7000 * d, kmh: 225 * d, fuel: 100 * d, coolant: 40 + 70 * d, volts: 11 + 4 * d, intake: 30 * d, load: 100 * d, throttle: 100 * d, mpg: 40 * d,
        oil: 40 + 80 * d, ambient: 20 * d, map: 30 + 100 * d, maf: 100 * d, wxTemp: null,
        runtime: 1234 + 2000 * d, dist_clr: 4000 * d, warmups: Math.round(60 * d), baro: 98.6, stft: 6 * d - 2, ltft: 3.1, timing: 8 + 24 * d, cat: 250 + 500 * d };
    }
    const st = S.state || {}, d = ((st.obd || {}).data) || {}, cur = (typeof OBDS !== 'undefined' && OBDS.cur) || {};
    const kmh = cur.speed ?? d.speed ?? (st.speed ? st.speed.mps * 3.6 : null);
    const maf = d.maf;
    const mpg = kmh != null && maf ? (kmh > 4 ? clamp((7.107 * kmh) / maf, 0, 99) : 0) : null;
    const w = st.weather;
    return { rpm: cur.rpm ?? d.rpm, kmh, fuel: d.fuel, coolant: d.coolant, volts: d.volts, intake: d.intake, load: d.load, throttle: d.throttle, mpg,
      oil: d.oil, ambient: d.ambient, map: d.map, maf: d.maf,
      // only if the backend polls them (PIDs 1F 31 30 33 06 07 0E 3C): run time s, km since codes cleared, warm-ups, kPa, %, %, deg, °C
      runtime: d.runtime, dist_clr: d.dist_clr, warmups: d.warmups, baro: d.baro, stft: d.stft, ltft: d.ltft, timing: d.timing, cat: d.cat,
      // outside: the car's sensor, else the weather (already in your units: kept apart so it isn't converted twice)
      wxTemp: d.ambient == null && w && w.temp != null ? +w.temp : null };
  }
  function update(dt) {
    const r = raw();
    trip.scroll = frac((trip.scroll || 0) + dt * (0.12 + Math.min(1.5, (sm.kmh || 0) / 90)));   // synthwave grid speed
    for (const [k, v] of Object.entries(r)) {
      if (v == null) { sm[k] = null; continue; }
      const rate = k === 'rpm' || k === 'kmh' ? 0.35 : 0.08;
      sm[k] = sm[k] == null ? v : sm[k] + (v - sm[k]) * Math.min(1, rate * dt * 60);
    }
    // trip average fuel economy and acceleration (the fuel tank sloshes with it)
    if (r.mpg != null && r.kmh > 4) {
      trip.mpgN = Math.min(trip.mpgN + dt, 600);
      trip.mpgAvg = trip.mpgAvg == null ? r.mpg : trip.mpgAvg + (r.mpg - trip.mpgAvg) * (dt / Math.max(30, trip.mpgN));
    }
    if (r.rpm != null && r.rpm > (trip.maxRpm || 0)) trip.maxRpm = r.rpm;
    if (r.kmh != null && r.kmh > (trip.maxKmh || 0) && r.kmh < 300) trip.maxKmh = r.kmh;
    if (r.kmh != null) {   // 0-60 mph (0-100 km/h) timer: starts when you pull away from a stop
      const goal = metric() ? 100 : 96.56, now = performance.now();
      if (r.kmh < 1) { trip.z0 = null; trip.zArmed = true; }
      else if (trip.zArmed && trip.z0 == null) trip.z0 = now;
      if (trip.z0 != null && r.kmh >= goal) { const t = (now - trip.z0) / 1000; trip.zLast = t; trip.zBest = Math.min(trip.zBest || 99, t); trip.z0 = null; trip.zArmed = false; }
      if (trip.z0 != null && now - trip.z0 > 30000) { trip.z0 = null; trip.zArmed = false; }
    }
    if (r.kmh != null) {
      if (trip.lastKmh != null) { const a = (r.kmh - trip.lastKmh) / Math.max(dt, 0.016); trip.accel += (clamp(a, -40, 40) - trip.accel) * Math.min(1, dt * 3); }
      trip.lastKmh = r.kmh;
    }
    more(r, dt);
  }
  // ---- history (10 samples a second, the last 60 s) and the trip computer, quarter mile, eco score
  const HN = 600, HIST = { rpm: new Float32Array(HN).fill(NaN), kmh: new Float32Array(HN).fill(NaN), mpg: new Float32Array(HN).fill(NaN) };
  let hHead = 0, hAcc = 0;
  function more(r, dt) {
    hAcc += dt;
    for (let k = 0; hAcc >= 0.1 && k < 20; k++) {
      hAcc -= 0.1;
      for (const key in HIST) HIST[key][hHead] = r[key] == null ? NaN : r[key];
      hHead = (hHead + 1) % HN;
    }
    if (hAcc > 1) hAcc = 0;
    const now = performance.now();
    if (r.kmh != null) {
      if (r.kmh > 2) { trip.km = (trip.km || 0) + (r.kmh * dt) / 3600; trip.secs = (trip.secs || 0) + dt; }
      if (r.kmh < 1) { trip.q0 = null; trip.qArmed = true; }   // quarter mile: from a stop to 402 m
      else if (trip.qArmed && trip.q0 == null) { trip.q0 = now; trip.qD = 0; }
      if (trip.q0 != null) {
        trip.qD += (r.kmh / 3.6) * dt;
        if (trip.qD >= 402.34) { const tt = (now - trip.q0) / 1000; trip.qLast = tt; trip.qTrap = r.kmh; trip.qBest = Math.min(trip.qBest || 999, tt); trip.q0 = null; trip.qArmed = false; }
        else if (now - trip.q0 > 45000) { trip.q0 = null; trip.qArmed = false; }
      }
      if (r.kmh > 5) {   // eco: how smooth you are (speed changes and pedal stabs), averaged over ~20 s
        const dthr = r.throttle != null && trip.lastThr != null ? Math.abs(r.throttle - trip.lastThr) / Math.max(dt, 0.016) : 0;
        const inst = 0.6 * Math.min(2, Math.abs(trip.accel) / 10) ** 2 + 0.4 * Math.min(2, dthr / 80) ** 2;
        trip.ecoE = trip.ecoE == null ? inst : trip.ecoE + (inst - trip.ecoE) * Math.min(1, dt / 20);
      }
    }
    trip.lastThr = r.throttle;
    if (r.maf) trip.fuelL = (trip.fuelL || 0) + (r.maf / 14.7 / 737) * dt;   // grams of air -> liters of gas
    more3(r, dt, now);
  }
  // ---- round 3 bookkeeping: idle/moving time, time per rpm band, engine map, 0-30 launches, 10-minute slow history
  const RB = 20, EM_R = 16, EM_L = 10, EMAP = new Float32Array(EM_R * EM_L), SHN = 300;
  const SH = { volts: new Float32Array(SHN).fill(NaN), coolant: new Float32Array(SHN).fill(NaN) };
  let shHead = 0, shAcc = 0;
  Object.assign(trip, { moveSecs: 0, stopSecs: 0, idleSecs: 0, engSecs: 0, idleL: 0, rpmBands: new Float32Array(RB), launches: [] });
  function more3(r, dt, now) {
    const on = r.rpm != null && r.rpm > 300;
    if (on) {
      trip.engSecs += dt;
      trip.rpmBands[Math.min(RB - 1, Math.floor(r.rpm / 500))] += dt;
      if (r.load != null) EMAP[Math.min(EM_R - 1, Math.floor(r.rpm / 500)) * EM_L + Math.min(EM_L - 1, Math.floor(r.load / 10))] += dt;
    }
    if (r.kmh != null) {
      if (r.kmh >= 1) trip.moveSecs += dt;
      else if (trip.moveSecs > 0 || on) { trip.stopSecs += dt; if (on) { trip.idleSecs += dt; if (r.maf) trip.idleL += (r.maf / 14.7 / 737) * dt; } }
      const goal = metric() ? 50 : 48.28;   // 0-30 mph (0-50 km/h) launches
      if (r.kmh < 1) { trip.l0 = null; trip.lArmed = true; }
      else if (trip.lArmed && trip.l0 == null) trip.l0 = now;
      if (trip.l0 != null && r.kmh >= goal) {
        const tt = (now - trip.l0) / 1000; trip.launches.unshift(tt); trip.launches.length = Math.min(5, trip.launches.length);
        trip.lBest = Math.min(trip.lBest || 99, tt); trip.l0 = null; trip.lArmed = false;
      } else if (trip.l0 != null && now - trip.l0 > 20000) { trip.l0 = null; trip.lArmed = false; }
    }
    shAcc += dt;
    if (shAcc >= 2) { shAcc = 0; for (const k in SH) SH[k][shHead] = r[k] == null ? NaN : r[k]; shHead = (shHead + 1) % SHN; }
  }
  function demoFill() {   // test hook (?demo): a minute of made-up driving for the traces
    for (let i = 0; i < HN; i++) { const x = i / 10; HIST.rpm[i] = 1800 + 1500 * Math.sin(x * 0.4) + 900 * Math.sin(x * 1.7) ** 2; HIST.kmh[i] = 60 + 35 * Math.sin(x * 0.12) + 8 * Math.sin(x * 0.9); HIST.mpg[i] = 22 + 14 * Math.sin(x * 0.3) + 6 * Math.sin(x * 2.1); }
    Object.assign(trip, { km: 23.4, secs: 1720, fuelL: 2.6, ecoE: 0.12, qLast: 15.8, qBest: 15.2, qTrap: 141, mpgAvg: 27.5, mpgN: 300,
      moveSecs: 1720, stopSecs: 412, idleSecs: 380, engSecs: 2140, idleL: 0.21, launches: [3.9, 3.4, 4.6, 3.7], lBest: 3.4 });
    const bands = [0, 0, 20, 90, 260, 420, 380, 300, 180, 90, 50, 30, 12, 6, 2];
    bands.forEach((v, i) => { trip.rpmBands[i] = v; });
    for (let i = 0; i < EM_R; i++) for (let j = 0; j < EM_L; j++) EMAP[i * EM_L + j] = Math.max(0, 60 * Math.exp(-((i - 4.5) ** 2) / 4 - ((j - 3 - (i - 4) * 0.3) ** 2) / 3) - 2);
    for (let i = 0; i < SHN; i++) { SH.volts[i] = i < 20 ? 12.5 : 14.1 - 0.3 * Math.exp(-(i - 20) / 40) + 0.08 * Math.sin(i * 0.3); SH.coolant[i] = 30 + 60 * (1 - Math.exp(-i / 60)); }
  }
  const metric = () => speedUnits(S.state || {}) === 'kmh';
  const tempF = () => tempUnits() === 'F';

  // ---------------------------------------------------------------- theme
  let T = null, themeKey = '', themeAt = 0;
  function theme() {
    // colors change only with the look: re-read the CSS variables twice a second, not on every frame
    const nowMs = performance.now();
    if (T && nowMs - themeAt < 500) return T;
    themeAt = nowMs;
    const cs = getComputedStyle(document.body);
    const v = (n, d) => (cs.getPropertyValue(n).trim() || d);
    const key = v('--accent', '') + v('--b1', '') + v('--text', '');
    if (key !== themeKey || !T) {
      themeKey = key;
      T = { accent: v('--accent', '#5EEAD4'), b1: v('--b1', '#14B8A6'), b2: v('--b2', '#7C3AED'), b3: v('--b3', '#0EA5E9'),
        text: v('--text', '#F5F7FA'), sub: v('--sub', 'rgba(245,247,250,.65)'), faint: 'rgba(255,255,255,.09)',
        red: '#FF4D4D', amber: '#FFB020', green: '#34D399', blue: '#4FA3FF', font: cs.fontFamily || 'Inter, sans-serif' };
    }
    return T;
  }
  const F = (w, px) => `${w} ${Math.round(px)}px ${(typeof P !== 'undefined' && P.font) || T.font}`;
  // light faces (white/cream/frost dials): text in the theme's text colors becomes the face's ink while drawing on one
  let LIGHT = false;
  function text(g, s, x, y, w, px, col, align = 'center') {
    if (LIGHT && (col === T.text || col === T.sub)) col = col === T.text ? P.ink : P.inkSub;
    g.font = F(w, px); g.fillStyle = col; g.textAlign = align; g.textBaseline = 'middle'; g.fillText(s, x, y); }
  function arc(g, cx, cy, r, a0, a1, w, col, glow = 0, cap = 'round', keepShadowColor = false) {
    g.lineWidth = w; g.strokeStyle = col; g.lineCap = cap;
    if (glow && GK > 0) { if (!keepShadowColor) g.shadowColor = typeof col === 'string' ? col : T.accent; g.shadowBlur = glow * GK; }
    g.beginPath(); g.arc(cx, cy, r, a0, a1, a1 < a0); g.stroke(); g.shadowBlur = 0;
  }
  // ---------------------------------------------------------------- dial faces + per-part styles
  // settings.cluster: face, needle, ticks, numerals, arc ('face' = whatever the face does), glow 0..100, redline rpm.
  // Test hook: ?face=..&needle=..&ticks=..&numerals=..&arc=..&glow=..&redline=..&demo=0.7 (fake readings) override settings.
  const Q = new URLSearchParams(location.search), QO = {};
  for (const k of ['face', 'needle', 'ticks', 'numerals', 'glow', 'arc', 'redline', 'demo']) if (Q.has(k)) QO[k] = Q.get(k);
  if (QO.demo != null) demoFill();
  const OPTS = {
    needle: ['face', 'blade', 'laser', 'comet', 'classic', 'none'],
    ticks: ['face', 'fine', 'bold', 'minimal', 'none'],
    numerals: ['face', 'thin', 'bold', 'digital', 'none'],
    arc: ['face', 'gradient', 'solid', 'segments', 'none'],
  };
  // what each face does by default ('auto' arc = the gauge's own: segments on the tach, a gradient elsewhere)
  const PROF = {
    // ---- Obsidian set (2026.11.17): made for the OLED, true black dials where only the reading gives off light
    obsidian: { needle: 'none', ticks: 'minimal', numerals: 'thin', arc: 'beam' },
    halo: { needle: 'comet', ticks: 'none', numerals: 'thin', arc: 'beam', dyn: 1, ncol: '#ffffff' },
    ion: { needle: 'laser', ticks: 'fine', numerals: 'thin', arc: 'segments', dyn: 1 },
    filament: { needle: 'laser', ticks: 'fine', numerals: 'thin', arc: 'filament', ncol: '#ffcf8a' },
    eclipse: { needle: 'none', ticks: 'minimal', numerals: 'thin', arc: 'beam', dyn: 1 },
    classic: { needle: 'classic', ticks: 'fine', numerals: 'bold', arc: 'auto' },
    neon: { needle: 'laser', ticks: 'fine', numerals: 'bold', arc: 'auto', dyn: 1 },
    plasma: { needle: 'classic', ticks: 'fine', numerals: 'bold', arc: 'auto', dyn: 1, ncol: '#ffffff' },
    galaxy: { needle: 'classic', ticks: 'fine', numerals: 'bold', arc: 'auto', dyn: 1, ncol: '#ffffff' },
    chrome: { needle: 'classic', ticks: 'fine', numerals: 'bold', arc: 'auto', ncol: '#ff3b30' },
    hud: { needle: 'laser', ticks: 'fine', numerals: 'thin', arc: 'auto', dyn: 1 },
    hologram: { needle: 'laser', ticks: 'fine', numerals: 'thin', arc: 'holo', dyn: 1, ncol: 'accent' },
    synthwave: { needle: 'blade', ticks: 'fine', numerals: 'bold', arc: 'synth', dyn: 1, ncol: '#ff2d95' },
    liquid: { needle: 'none', ticks: 'fine', numerals: 'thin', arc: 'tube' },
    aurora: { needle: 'comet', ticks: 'fine', numerals: 'thin', arc: 'aurora', dyn: 1 },
    carbon: { needle: 'blade', ticks: 'bold', numerals: 'bold', arc: 'segments', ncol: '#ff2a1a' },
    particles: { needle: 'laser', ticks: 'minimal', numerals: 'thin', arc: 'particles' },
    glass: { needle: 'blade', ticks: 'fine', numerals: 'thin', arc: 'gradient' },
    minimal: { needle: 'none', ticks: 'minimal', numerals: 'thin', arc: 'hair' },
    tron: { needle: 'laser', ticks: 'fine', numerals: 'bold', arc: 'tron', dyn: 1, ncol: '#ff8a1f' },
    retro: { needle: 'none', ticks: 'bold', numerals: 'digital', arc: 'vfd', font: '"DejaVu Sans Mono", monospace' },
    luxe: { needle: 'blade', ticks: 'bold', numerals: 'thin', arc: 'none', ncol: '#e9c46a', font: '"DejaVu Serif", Georgia, serif' },
    lava: { needle: 'blade', ticks: 'fine', numerals: 'bold', arc: 'lava', dyn: 1, ncol: '#ffcf6a' },
    crystal: { needle: 'blade', ticks: 'fine', numerals: 'thin', arc: 'prism', dyn: 1, ncol: '#ffffff' },
    blueprint: { needle: 'classic', ticks: 'fine', numerals: 'thin', arc: 'hatch', ncol: '#ffffff', font: '"DejaVu Sans Mono", monospace' },
    // round 3 faces
    motorsport: { needle: 'classic', ticks: 'bold', numerals: 'bold', arc: 'none', ncol: '#e10600', light: 1, ink: '#111111', inkSub: 'rgba(0,0,0,.6)' },
    vintage: { needle: 'classic', ticks: 'fine', numerals: 'thin', arc: 'none', ncol: '#8e1b12', light: 1, ink: '#2a2118', inkSub: 'rgba(42,33,24,.68)', font: '"DejaVu Serif", "Liberation Serif", Georgia, serif' },
    f1: { needle: 'none', ticks: 'minimal', numerals: 'digital', arc: 'segments' },
    aviation: { needle: 'classic', ticks: 'bold', numerals: 'bold', arc: 'none', ncol: '#f4f4f4', font: '"Liberation Sans Narrow", "DejaVu Sans", sans-serif' },
    oled: { needle: 'none', ticks: 'minimal', numerals: 'thin', arc: 'flat' },
    matrix: { needle: 'laser', ticks: 'fine', numerals: 'thin', arc: 'term', dyn: 1, ncol: '#3dff7a', font: '"DejaVu Sans Mono", monospace' },
    sapphire: { needle: 'blade', ticks: 'fine', numerals: 'thin', arc: 'gradient', ncol: '#ffffff' },
    ice: { needle: 'blade', ticks: 'fine', numerals: 'thin', arc: 'flat', ncol: '#0a84d0', light: 1, ink: '#0b2236', inkSub: 'rgba(11,34,54,.62)' },
    sunset: { needle: 'blade', ticks: 'fine', numerals: 'bold', arc: 'flat', ncol: '#fff1d6' },
    rosegold: { needle: 'blade', ticks: 'bold', numerals: 'thin', arc: 'none', ncol: '#f0b6a4', font: '"DejaVu Serif", "Liberation Serif", Georgia, serif' },
    glitch: { needle: 'laser', ticks: 'fine', numerals: 'bold', arc: 'segments', dyn: 1, ncol: '#fcee0a' },
    jdm: { needle: 'classic', ticks: 'fine', numerals: 'bold', arc: 'none', ncol: '#ff5a1a' },
  };
  let nowT = 0, FACE = 'classic', P = PROF.classic, GK = 1, DPR = 1, DT = 1 / 30, CUR = null;
  const O = { needle: 'face', ticks: 'face', numerals: 'face', arc: 'face', redline: 6000 };
  function readOpts() {
    const c = settings().cluster || {}, src = Object.assign({}, c, QO);
    FACE = QO.face || (typeof window.gaugeFace === 'function' ? window.gaugeFace() : c.face) || 'classic';
    if (!PROF[FACE] && FACE !== 'real') FACE = 'classic';
    P = PROF[FACE] || PROF.classic;
    for (const k in OPTS) O[k] = OPTS[k].includes(src[k]) ? src[k] : 'face';
    const gl = Number(src.glow), rl = Number(src.redline);
    GK = (src.glow != null && src.glow !== '' && Number.isFinite(gl) ? clamp(gl, 0, 100) : 60) / 60;
    O.redline = Number.isFinite(rl) && rl >= 3000 && rl <= 12000 ? rl : 6000;
  }
  const face = () => FACE;
  const part = (k) => (O[k] !== 'face' ? O[k] : P[k]);
  const ST = new WeakMap();   // per-canvas animation state (comet trail, particles)
  const state = () => { let s = ST.get(CUR); if (!s) { s = {}; if (CUR) ST.set(CUR, s); } return s; };
  const frac = (x) => x - Math.floor(x);

  // colors: theme vars may be #hex or rgb(); these mix/alpha any of them
  const RGB = new Map();
  function rgb(c) {
    let v = RGB.get(c);
    if (v) return v;
    const s = String(c).trim();
    if (s[0] === '#') {
      let h = s.slice(1); if (h.length <= 4) h = [...h].map((x) => x + x).join('');
      v = [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)];
    } else { const m = s.match(/[\d.]+/g); v = m && m.length >= 3 ? m.slice(0, 3).map(Number) : [255, 255, 255]; }
    if (v.some((n) => !Number.isFinite(n))) v = [255, 255, 255];
    if (RGB.size > 200) RGB.clear();
    RGB.set(c, v); return v;
  }
  const rgba = (c, a) => { const [r, g, b] = rgb(c); return `rgba(${r},${g},${b},${clamp(a, 0, 1).toFixed(3)})`; };
  const mix = (c1, c2, k) => { const a = rgb(c1), b = rgb(c2); return `rgb(${a.map((x, i) => Math.round(x + (b[i] - x) * k)).join(',')})`; };
  const SYN_C = '#2de2e6', SYN_M = '#ff2d95';

  // ---- static layers are drawn once into offscreen canvases (keyed by size, theme, face and options)
  let CW = 0, CH = 0;
  const CACHE = new Map(), CACHE_MAX = 64;   // 8 cluster gauges x 3-4 layers each must fit, or they redraw every frame
  function layer(g, key, cx, cy, ext, draw) {
    const x0 = Math.floor(Math.max(0, cx - ext)), y0 = Math.floor(Math.max(0, cy - ext));
    const x1 = Math.ceil(Math.min(CW, cx + ext)), y1 = Math.ceil(Math.min(CH, cy + ext));
    if (x1 <= x0 || y1 <= y0) return;
    key = `${key}|${x0},${y0},${x1},${y1}|${DPR}|${themeKey}|${FACE}|${GK.toFixed(2)}`;
    let c = CACHE.get(key);
    if (c) { CACHE.delete(key); CACHE.set(key, c); }
    else {
      c = document.createElement('canvas');
      c.width = Math.max(1, Math.round((x1 - x0) * DPR)); c.height = Math.max(1, Math.round((y1 - y0) * DPR));
      const x = c.getContext('2d'); x.setTransform(DPR, 0, 0, DPR, -x0 * DPR, -y0 * DPR); draw(x);
      CACHE.set(key, c);
      while (CACHE.size > CACHE_MAX) CACHE.delete(CACHE.keys().next().value);
    }
    g.drawImage(c, x0, y0, x1 - x0, y1 - y0);
  }
  const circ = (g, cx, cy, r) => { g.beginPath(); g.arc(cx, cy, r, 0, TAU); };
  const STARS = [...Array(70)].map((_, i) => [((i * 97) % 360) * Math.PI / 180, ((i * 53) % 100) / 100, ((i * 31) % 10) / 10]);

  // ---- what sits behind a dial: the parts that never move (cached) ...
  function backStatic(g, cx, cy, r, mini) {
    const f = FACE;
    if (f === 'obsidian' || f === 'eclipse') {   // black: an outer hairline, a fainter inner one, nothing else lit
      arc(g, cx, cy, r * 1.07, A0, A0 + SWEEP, 1, 'rgba(255,255,255,.13)', 0, 'butt');
      arc(g, cx, cy, r * 0.62, A0, A0 + SWEEP, 1, 'rgba(255,255,255,.05)', 0, 'butt');
      if (f === 'eclipse') { const p2 = g.createRadialGradient(cx, cy, r * 0.55, cx, cy, r * 0.7); p2.addColorStop(0, 'rgba(0,0,0,0)'); p2.addColorStop(1, rgba(T.accent, 0.05)); g.fillStyle = p2; circ(g, cx, cy, r * 0.7); g.fill(); }
      return;
    }
    if (f === 'halo') { g.strokeStyle = rgba(T.accent, 0.06); g.lineWidth = r * 0.16; circ(g, cx, cy, r); g.stroke(); return; }
    if (f === 'ion') {
      g.strokeStyle = 'rgba(255,255,255,.07)'; g.lineWidth = 1;
      for (const k of [1.05, 0.74, 0.5]) { circ(g, cx, cy, r * k); g.stroke(); }
      return;
    }
    if (f === 'filament') {   // a dark glass tube the wire runs through
      arc(g, cx, cy, r, A0, A0 + SWEEP, r * 0.07, 'rgba(255,190,120,.05)', 0, 'round');
      arc(g, cx, cy, r + r * 0.035, A0, A0 + SWEEP, 1, 'rgba(255,220,180,.12)', 0, 'round');
      arc(g, cx, cy, r - r * 0.035, A0, A0 + SWEEP, 1, 'rgba(255,220,180,.08)', 0, 'round');
      return;
    }
    if (f === 'chrome') {
      const bz = g.createLinearGradient(cx - r, cy - r, cx + r, cy + r);
      bz.addColorStop(0, '#f4f6f8'); bz.addColorStop(0.25, '#7b8088'); bz.addColorStop(0.5, '#ffffff'); bz.addColorStop(0.75, '#5a5f66'); bz.addColorStop(1, '#d9dde2');
      g.fillStyle = bz; circ(g, cx, cy, r * 1.16); g.fill();
      const fc = g.createRadialGradient(cx, cy - r * 0.4, r * 0.1, cx, cy, r * 1.08);
      fc.addColorStop(0, '#2a2f37'); fc.addColorStop(1, '#050607');
      g.fillStyle = fc; circ(g, cx, cy, r * 1.08); g.fill();
      const sh = g.createLinearGradient(cx, cy - r, cx, cy + r * 0.2);   // glass glare across the top
      sh.addColorStop(0, 'rgba(255,255,255,.16)'); sh.addColorStop(1, 'rgba(255,255,255,0)');
      g.fillStyle = sh; g.beginPath(); g.ellipse(cx, cy - r * 0.45, r * 0.9, r * 0.5, 0, Math.PI, TAU); g.fill();
    } else if (f === 'neon') {
      const in1 = g.createRadialGradient(cx, cy, 0, cx, cy, r);
      in1.addColorStop(0, 'rgba(0,0,0,0)'); in1.addColorStop(1, rgba(T.b2, 0.2));
      g.fillStyle = in1; circ(g, cx, cy, r); g.fill();
    } else if (f === 'galaxy') {
      g.save(); circ(g, cx, cy, r * 1.08); g.clip();
      const neb = g.createRadialGradient(cx + r * 0.2, cy - r * 0.2, 0, cx, cy, r * 1.1);
      neb.addColorStop(0, rgba(T.b2, 0.4)); neb.addColorStop(0.5, rgba(T.b3, 0.13)); neb.addColorStop(1, 'rgba(0,0,0,0)');
      g.fillStyle = neb; g.fillRect(cx - r * 1.1, cy - r * 1.1, r * 2.2, r * 2.2); g.restore();
      g.strokeStyle = rgba(T.b3, 0.33); g.lineWidth = 1.5; circ(g, cx, cy, r * 1.1); g.stroke();
    } else if (f === 'hologram') {
      g.save(); circ(g, cx, cy, r * 1.02); g.clip();
      const b = g.createRadialGradient(cx, cy, 0, cx, cy, r * 1.02);   // brighter at the edge, like a projected shell
      b.addColorStop(0, rgba(T.accent, 0.13)); b.addColorStop(0.55, rgba(T.accent, 0.03)); b.addColorStop(0.9, rgba(T.b3, 0.1)); b.addColorStop(1, rgba(T.accent, 0.22));
      g.fillStyle = b; g.fillRect(cx - r * 1.1, cy - r * 1.1, r * 2.2, r * 2.2);
      g.fillStyle = rgba(T.accent, 0.16); const st = Math.max(6, r * 0.075), d = Math.max(1, r * 0.006);   // dot grid
      for (let y = cy - r; y < cy + r; y += st) for (let x = cx - r + ((Math.round((y - cy) / st) & 1) ? st / 2 : 0); x < cx + r; x += st) g.fillRect(x - d / 2, y - d / 2, d, d);
      g.restore();
      g.strokeStyle = rgba(T.accent, 0.25); g.lineWidth = 1;
      for (const k of [0.3, 0.48]) { circ(g, cx, cy, r * k); g.stroke(); }
      for (let i = 0; i < 4; i++) { const a = i * Math.PI / 2 + Math.PI / 4; g.beginPath(); g.moveTo(cx + r * 0.44 * Math.cos(a), cy + r * 0.44 * Math.sin(a)); g.lineTo(cx + r * 0.52 * Math.cos(a), cy + r * 0.52 * Math.sin(a)); g.stroke(); }
      g.strokeStyle = rgba(T.accent, 0.6); g.lineWidth = Math.max(1.5, r * 0.008); circ(g, cx, cy, r * 1.04); g.stroke();
      g.strokeStyle = rgba(T.accent, 0.3); g.lineWidth = Math.max(2, r * 0.02); g.setLineDash([1.5, Math.max(4, r * 0.035)]);
      circ(g, cx, cy, r * 1.09); g.stroke(); g.setLineDash([]);
    } else if (f === 'synthwave') {
      const hz = cy + r * (mini ? -0.25 : 0.18), R = r * 1.0;
      g.save(); circ(g, cx, cy, R); g.clip();
      const sky = g.createLinearGradient(0, cy - R, 0, hz);
      sky.addColorStop(0, '#07001a'); sky.addColorStop(0.55, mix(T.b2, '#1a0033', 0.6)); sky.addColorStop(1, mix(SYN_M, '#3a0050', 0.45));
      g.fillStyle = sky; g.fillRect(cx - R, cy - R, R * 2, hz - (cy - R));
      const glow = g.createRadialGradient(cx, hz, 0, cx, hz, r * 0.85);
      glow.addColorStop(0, 'rgba(255,45,149,.55)'); glow.addColorStop(1, 'rgba(255,45,149,0)');
      g.fillStyle = glow; g.fillRect(cx - R, cy - R, R * 2, hz - (cy - R));
      // the sun, cut by slits that get thicker toward the horizon
      const sr = r * (mini ? 0.3 : 0.44), sy = hz - r * 0.02, keep = new Path2D();
      let y = sy - sr;
      for (let k = 0; y < hz; k++) { const gap = r * (mini ? 0.012 + k * 0.008 : 0.006 + k * 0.0055), band = r * (mini ? 0.09 - k * 0.018 : 0.11 - k * 0.012); const b = Math.max(r * 0.02, band); keep.rect(cx - sr, y, sr * 2, b); y += b + gap; }
      g.save(); g.clip(keep);
      const sun = g.createLinearGradient(0, sy - sr, 0, hz);
      sun.addColorStop(0, '#fff3a0'); sun.addColorStop(0.45, '#ff9a5a'); sun.addColorStop(1, SYN_M);
      g.fillStyle = sun; circ(g, cx, sy, sr); g.fill(); g.restore();
      // mountains on the horizon
      g.beginPath(); g.moveTo(cx - R, hz);
      const pk = [[-1, 0], [-0.82, 0.1], [-0.7, 0.04], [-0.55, 0.16], [-0.4, 0.02], [0.35, 0.02], [0.48, 0.13], [0.62, 0.05], [0.78, 0.19], [0.92, 0.06], [1, 0]];
      for (const [px, py] of pk) g.lineTo(cx + R * px, hz - r * py * (mini ? 0.6 : 1));
      g.closePath(); g.fillStyle = '#12002b'; g.fill(); g.strokeStyle = rgba(SYN_C, 0.7); g.lineWidth = 1.2; g.stroke();
      const gr = g.createLinearGradient(0, hz, 0, cy + R);
      gr.addColorStop(0, '#1a0036'); gr.addColorStop(1, '#030008');
      g.fillStyle = gr; g.fillRect(cx - R, hz, R * 2, cy + R - hz);
      g.strokeStyle = rgba(SYN_M, 0.55); g.lineWidth = 1;   // the grid's lines to the vanishing point
      g.beginPath();
      for (let k = -10; k <= 10; k++) { g.moveTo(cx + k * r * 0.03, hz); g.lineTo(cx + k * r * 0.34, cy + R); }
      g.stroke(); g.restore();
      g.save(); g.shadowColor = SYN_M; g.shadowBlur = r * 0.05 * GK;
      g.strokeStyle = '#ffd1ec'; g.lineWidth = Math.max(1.5, r * 0.008); g.beginPath(); g.moveTo(cx - R * 0.98, hz); g.lineTo(cx + R * 0.98, hz); g.stroke(); g.restore();
      if (g.createConicGradient) {   // the rim: cyan to magenta neon
        const ring = g.createConicGradient(0, cx, cy); ring.addColorStop(0, SYN_C); ring.addColorStop(0.5, SYN_M); ring.addColorStop(1, SYN_C);
        g.save(); g.shadowColor = SYN_M; g.shadowBlur = r * 0.08 * GK; g.strokeStyle = ring; g.lineWidth = Math.max(2, r * 0.018); circ(g, cx, cy, r * 1.06); g.stroke(); g.restore();
      }
    } else if (f === 'liquid') {
      const fc = g.createRadialGradient(cx, cy - r * 0.3, r * 0.05, cx, cy, r * 1.05);
      fc.addColorStop(0, '#20242a'); fc.addColorStop(0.7, '#0c0e11'); fc.addColorStop(1, '#040506');
      g.fillStyle = fc; circ(g, cx, cy, r * 1.05); g.fill();
      g.strokeStyle = 'rgba(255,255,255,.018)'; g.lineWidth = 1;   // machined rings
      for (let k = 0.15; k < 1.03; k += 0.022) { circ(g, cx, cy, r * k); g.stroke(); }
      const bz = g.createLinearGradient(cx - r, cy - r, cx + r, cy + r);
      bz.addColorStop(0, '#e8ecf0'); bz.addColorStop(0.3, '#5b6068'); bz.addColorStop(0.55, '#f6f8fa'); bz.addColorStop(1, '#2c2f34');
      g.strokeStyle = bz; g.lineWidth = Math.max(2, r * 0.03); circ(g, cx, cy, r * 1.07); g.stroke();
    } else if (f === 'aurora') {
      g.save(); circ(g, cx, cy, r * 1.04); g.clip();
      const b = g.createRadialGradient(cx, cy - r * 0.3, 0, cx, cy, r * 1.05);
      b.addColorStop(0, mix(T.b2, '#000000', 0.78)); b.addColorStop(1, '#02040a');
      g.fillStyle = b; g.fillRect(cx - r * 1.1, cy - r * 1.1, r * 2.2, r * 2.2);
      for (const [a0, d, k] of STARS) { g.globalAlpha = 0.25 + k * 0.5; g.fillStyle = '#fff'; const rr = r * Math.sqrt(d); g.fillRect(cx + rr * Math.cos(a0), cy + rr * Math.sin(a0) - r * 0.2, k > 0.8 ? 1.8 : 1.1, k > 0.8 ? 1.8 : 1.1); }
      g.restore(); g.globalAlpha = 1;
      g.strokeStyle = rgba(T.accent, 0.35); g.lineWidth = Math.max(1, r * 0.006); circ(g, cx, cy, r * 1.04); g.stroke();
    } else if (f === 'carbon') {
      const bz = g.createLinearGradient(cx, cy - r * 1.15, cx, cy + r * 1.15);   // dark machined bezel
      bz.addColorStop(0, '#4a4e55'); bz.addColorStop(0.5, '#0b0c0e'); bz.addColorStop(1, '#2a2d31');
      g.fillStyle = bz; circ(g, cx, cy, r * 1.14); g.fill();
      const t = document.createElement('canvas'), cs = Math.max(4, Math.round(r * 0.035 * DPR)); t.width = t.height = cs * 2;
      const x = t.getContext('2d');
      for (let i = 0; i < 2; i++) for (let j = 0; j < 2; j++) {
        const hz = (i + j) % 2 === 0, gr = hz ? x.createLinearGradient(0, j * cs, 0, j * cs + cs) : x.createLinearGradient(i * cs, 0, i * cs + cs, 0);
        gr.addColorStop(0, '#0e0f11'); gr.addColorStop(0.5, '#34373c'); gr.addColorStop(1, '#0a0b0c');
        x.fillStyle = gr; x.fillRect(i * cs, j * cs, cs, cs);
      }
      const pat = g.createPattern(t, 'repeat');
      if (pat.setTransform) pat.setTransform(new DOMMatrix([1 / DPR, 0, 0, 1 / DPR, 0, 0]).rotate(45));
      g.save(); circ(g, cx, cy, r * 1.06); g.clip(); g.fillStyle = pat; g.fillRect(cx - r * 1.1, cy - r * 1.1, r * 2.2, r * 2.2);
      const v = g.createRadialGradient(cx, cy, r * 0.2, cx, cy, r * 1.06);
      v.addColorStop(0, 'rgba(0,0,0,.25)'); v.addColorStop(1, 'rgba(0,0,0,.75)');
      g.fillStyle = v; g.fillRect(cx - r * 1.1, cy - r * 1.1, r * 2.2, r * 2.2); g.restore();
      g.strokeStyle = '#ff2a1a'; g.lineWidth = Math.max(1.5, r * 0.01); circ(g, cx, cy, r * 1.06); g.stroke();
      g.fillStyle = '#ffd200'; g.fillRect(cx - r * 0.012, cy - r * 1.14, r * 0.024, r * 0.08);   // top-dead-centre mark
    } else if (f === 'particles') {
      const b = g.createRadialGradient(cx, cy, 0, cx, cy, r * 1.08);
      b.addColorStop(0, 'rgba(0,0,0,.45)'); b.addColorStop(0.8, 'rgba(0,0,0,.25)'); b.addColorStop(1, 'rgba(0,0,0,0)');
      g.fillStyle = b; circ(g, cx, cy, r * 1.08); g.fill();
      g.fillStyle = rgba(T.accent, 0.35); const n = 120;
      for (let i = 0; i < n; i++) { const a = (i / n) * TAU; g.fillRect(cx + r * 1.08 * Math.cos(a) - 1, cy + r * 1.08 * Math.sin(a) - 1, 2, 2); }
    } else if (f === 'glass') {
      g.fillStyle = 'rgba(255,255,255,.025)'; circ(g, cx, cy, r * 1.08); g.fill();
      g.fillStyle = 'rgba(255,255,255,.035)'; g.beginPath(); g.arc(cx, cy, r * 1.08, 0, TAU); g.arc(cx, cy, r * 0.86, 0, TAU, true); g.fill();
      for (const [wd, a] of [[r * 0.07, 0.035], [r * 0.035, 0.07], [r * 0.015, 0.14]]) {   // soft outer glow, no shadowBlur
        g.strokeStyle = rgba(T.accent, a * Math.min(1.6, GK)); g.lineWidth = wd; circ(g, cx, cy, r * 1.09); g.stroke();
      }
      const rim = g.createLinearGradient(0, cy - r, 0, cy + r);
      rim.addColorStop(0, 'rgba(255,255,255,.85)'); rim.addColorStop(0.5, rgba(T.accent, 0.7)); rim.addColorStop(1, rgba(T.b2, 0.8));
      g.strokeStyle = rim; g.lineWidth = Math.max(1.5, r * 0.01); circ(g, cx, cy, r * 1.09); g.stroke();
      g.strokeStyle = 'rgba(255,255,255,.14)'; g.lineWidth = 1; circ(g, cx, cy, r * 0.86); g.stroke();
    } else if (f === 'tron') {
      g.fillStyle = 'rgba(1,4,8,.88)'; circ(g, cx, cy, r * 1.1); g.fill();
      g.save(); circ(g, cx, cy, r * 1.04); g.clip();
      g.strokeStyle = rgba(T.accent, 0.13); g.lineWidth = 1; const st = r * 0.13; g.beginPath();   // the grid
      for (let k = -8; k <= 8; k++) { g.moveTo(cx + k * st, cy - r * 1.1); g.lineTo(cx + k * st, cy + r * 1.1); g.moveTo(cx - r * 1.1, cy + k * st); g.lineTo(cx + r * 1.1, cy + k * st); }
      g.stroke();
      const v = g.createRadialGradient(cx, cy, r * 0.3, cx, cy, r * 1.04); v.addColorStop(0, 'rgba(1,4,8,.75)'); v.addColorStop(1, 'rgba(1,4,8,0)');
      g.fillStyle = v; g.fillRect(cx - r * 1.1, cy - r * 1.1, r * 2.2, r * 2.2); g.restore();
      g.save(); g.shadowColor = T.accent; g.shadowBlur = r * 0.06 * GK;
      g.strokeStyle = T.accent; g.lineWidth = Math.max(2, r * 0.012); circ(g, cx, cy, r * 1.06); g.stroke();
      g.lineWidth = 1; g.globalAlpha = 0.5; circ(g, cx, cy, r * 1.1); g.stroke(); g.globalAlpha = 1;
      g.strokeStyle = '#ff8a1f'; g.shadowColor = '#ff8a1f'; g.lineWidth = Math.max(3, r * 0.022); g.lineCap = 'butt';
      for (const a of [rad(-90), rad(30), rad(150)]) { g.beginPath(); g.arc(cx, cy, r * 1.1, a - 0.12, a + 0.12); g.stroke(); }
      g.restore();
    } else if (f === 'retro') {
      const bz = g.createLinearGradient(cx, cy - r * 1.15, cx, cy + r * 1.15);
      bz.addColorStop(0, '#3a3530'); bz.addColorStop(0.5, '#0d0b09'); bz.addColorStop(1, '#25211d');
      g.fillStyle = bz; circ(g, cx, cy, r * 1.13); g.fill();
      const fc = g.createRadialGradient(cx, cy - r * 0.3, 0, cx, cy, r * 1.05);
      fc.addColorStop(0, '#1d1209'); fc.addColorStop(1, '#070402');
      g.fillStyle = fc; circ(g, cx, cy, r * 1.05); g.fill();
      g.save(); circ(g, cx, cy, r * 1.05); g.clip(); g.strokeStyle = 'rgba(255,170,60,.035)'; g.lineWidth = 1; g.beginPath();   // VFD mesh
      for (let k = -r * 1.1; k < r * 1.1; k += Math.max(3, r * 0.022)) { g.moveTo(cx + k, cy - r * 1.1); g.lineTo(cx + k + r * 0.6, cy + r * 1.1); g.moveTo(cx + k + r * 0.6, cy - r * 1.1); g.lineTo(cx + k, cy + r * 1.1); }
      g.stroke(); g.restore();
      g.strokeStyle = 'rgba(255,230,200,.25)'; g.lineWidth = 1; circ(g, cx, cy, r * 1.05); g.stroke();
    } else if (f === 'luxe') {
      const dc = mix(T.b3, '#081226', 0.72);
      g.save(); circ(g, cx, cy, r * 1.04); g.clip();
      if (g.createConicGradient) {   // sunburst finish
        const sb = g.createConicGradient(0, cx, cy);
        for (let i = 0; i <= 36; i++) sb.addColorStop(i / 36, i % 2 ? mix(dc, '#ffffff', 0.1) : mix(dc, '#000000', 0.25));
        g.fillStyle = sb;
      } else g.fillStyle = dc;
      g.fillRect(cx - r * 1.1, cy - r * 1.1, r * 2.2, r * 2.2);
      g.strokeStyle = 'rgba(255,255,255,.06)'; g.lineWidth = 1;   // guilloche rosette
      for (let i = 0; i < 64; i++) { const a = (i / 64) * TAU; circ(g, cx + r * 0.18 * Math.cos(a), cy + r * 0.18 * Math.sin(a), r * 0.42); g.stroke(); }
      const v = g.createRadialGradient(cx, cy - r * 0.3, r * 0.1, cx, cy, r * 1.05); v.addColorStop(0, 'rgba(255,255,255,.08)'); v.addColorStop(1, 'rgba(0,0,0,.45)');
      g.fillStyle = v; g.fillRect(cx - r * 1.1, cy - r * 1.1, r * 2.2, r * 2.2); g.restore();
      g.strokeStyle = 'rgba(233,196,106,.35)'; g.lineWidth = 1;   // railway minute track
      circ(g, cx, cy, r * 0.93); g.stroke(); circ(g, cx, cy, r * 0.965); g.stroke();
      const gold = g.createLinearGradient(cx - r, cy - r, cx + r, cy + r);
      gold.addColorStop(0, '#fff1c1'); gold.addColorStop(0.3, '#b8892e'); gold.addColorStop(0.55, '#ffe9a8'); gold.addColorStop(0.8, '#8a6420'); gold.addColorStop(1, '#e8c36a');
      g.strokeStyle = gold; g.lineWidth = Math.max(3, r * 0.06); circ(g, cx, cy, r * 1.07); g.stroke();
      g.strokeStyle = 'rgba(0,0,0,.5)'; g.lineWidth = 1; circ(g, cx, cy, r * 1.04); g.stroke();
    } else if (f === 'lava') {
      const b = g.createRadialGradient(cx, cy - r * 0.2, 0, cx, cy, r * 1.08);
      b.addColorStop(0, '#24110a'); b.addColorStop(0.7, '#110604'); b.addColorStop(1, '#050201');
      g.fillStyle = b; circ(g, cx, cy, r * 1.08); g.fill();
      const rnd = rng(7); g.save(); circ(g, cx, cy, r * 1.06); g.clip();
      for (let i = 0; i < 500; i++) { g.fillStyle = rnd() > 0.5 ? 'rgba(255,255,255,.035)' : 'rgba(0,0,0,.25)'; const d = 1 + rnd() * r * 0.012; g.fillRect(cx + (rnd() * 2 - 1) * r * 1.06, cy + (rnd() * 2 - 1) * r * 1.06, d, d); }
      g.restore();
      const rim = g.createLinearGradient(cx, cy - r * 1.1, cx, cy + r * 1.1); rim.addColorStop(0, '#3b2a22'); rim.addColorStop(1, '#0c0605');
      g.strokeStyle = rim; g.lineWidth = Math.max(3, r * 0.05); circ(g, cx, cy, r * 1.08); g.stroke();
      g.strokeStyle = 'rgba(255,110,30,.5)'; g.lineWidth = 1; circ(g, cx, cy, r * 1.05); g.stroke();
    } else if (f === 'crystal') {
      g.fillStyle = 'rgba(8,10,18,.55)'; circ(g, cx, cy, r * 1.06); g.fill();
      const n = 16, ro = r * 1.06, ri = r * 0.46, rnd = rng(3);
      const P2 = (rr, a) => [cx + rr * Math.cos(a), cy + rr * Math.sin(a)];
      for (let i = 0; i < n; i++) {   // facets: an inner octagon, a ring of triangles to the rim
        const a0 = (i / n) * TAU, a1 = ((i + 1) / n) * TAU, am = (a0 + a1) / 2, ai = Math.floor(i / 2) * 2 / n * TAU + TAU / n;
        for (const tri of [[P2(ri, ai), P2(ro, a0), P2(ro, a1)], [P2(ri, ai), P2(ri, ai + (i % 2 ? TAU / n * 2 : -TAU / n * 2)), P2(ro, i % 2 ? a1 : a0)]]) {
          g.beginPath(); g.moveTo(...tri[0]); g.lineTo(...tri[1]); g.lineTo(...tri[2]); g.closePath();
          const lg = g.createLinearGradient(...P2(ri, am), ...P2(ro, am)); const k = rnd();
          lg.addColorStop(0, `rgba(255,255,255,${(0.02 + k * 0.08).toFixed(3)})`); lg.addColorStop(1, `rgba(255,255,255,${(0.1 - k * 0.07).toFixed(3)})`);
          g.fillStyle = lg; g.fill(); g.strokeStyle = 'rgba(255,255,255,.13)'; g.lineWidth = 1; g.stroke();
        }
      }
      g.beginPath(); for (let i = 0; i < 8; i++) { const [x, y] = P2(ri, (i / 8) * TAU + TAU / n); i ? g.lineTo(x, y) : g.moveTo(x, y); } g.closePath();
      g.fillStyle = 'rgba(255,255,255,.04)'; g.fill(); g.strokeStyle = 'rgba(255,255,255,.22)'; g.stroke();
      if (g.createConicGradient) {
        const rb = g.createConicGradient(0, cx, cy);
        ['#ff4d6d', '#ffb84d', '#fff35c', '#5cff8d', '#4dd8ff', '#7a5cff', '#ff4dd2', '#ff4d6d'].forEach((c, i, a) => rb.addColorStop(i / (a.length - 1), c));
        g.globalAlpha = 0.55; g.strokeStyle = rb; g.lineWidth = Math.max(2, r * 0.02); circ(g, cx, cy, r * 1.07); g.stroke(); g.globalAlpha = 1;
      }
      g.strokeStyle = 'rgba(255,255,255,.6)'; g.lineWidth = 1; circ(g, cx, cy, r * 1.09); g.stroke();
    } else if (f === 'blueprint') {
      const bp = mix('#0f3e7c', T.b3, 0.18);
      g.save(); circ(g, cx, cy, r * 1.1); g.clip();
      g.fillStyle = bp; g.fillRect(cx - r * 1.12, cy - r * 1.12, r * 2.24, r * 2.24);
      const st = r * 0.05; g.lineWidth = 1;
      for (let k = -24; k <= 24; k++) {
        g.strokeStyle = k % 5 ? 'rgba(255,255,255,.07)' : 'rgba(255,255,255,.17)'; g.beginPath();
        g.moveTo(cx + k * st, cy - r * 1.12); g.lineTo(cx + k * st, cy + r * 1.12); g.moveTo(cx - r * 1.12, cy + k * st); g.lineTo(cx + r * 1.12, cy + k * st); g.stroke();
      }
      const v = g.createRadialGradient(cx, cy, r * 0.5, cx, cy, r * 1.12); v.addColorStop(0, 'rgba(0,0,0,0)'); v.addColorStop(1, 'rgba(0,10,30,.35)');
      g.fillStyle = v; g.fillRect(cx - r * 1.12, cy - r * 1.12, r * 2.24, r * 2.24); g.restore();
      g.strokeStyle = 'rgba(255,255,255,.8)'; g.lineWidth = 1.2; circ(g, cx, cy, r * 1.1); g.stroke();
      g.strokeStyle = 'rgba(255,255,255,.35)'; g.setLineDash([r * 0.06, r * 0.02, r * 0.01, r * 0.02]);   // centre lines
      g.beginPath(); g.moveTo(cx - r * 1.08, cy); g.lineTo(cx + r * 1.08, cy); g.moveTo(cx, cy - r * 1.08); g.lineTo(cx, cy + r * 1.08); g.stroke();
      g.setLineDash([r * 0.02, r * 0.02]); circ(g, cx, cy, r * 0.5); g.stroke(); g.setLineDash([]);
      g.strokeStyle = 'rgba(255,255,255,.55)'; g.fillStyle = 'rgba(255,255,255,.7)';   // a dimension callout
      const a = rad(-45), x1 = cx + r * 1.1 * Math.cos(a), y1 = cy + r * 1.1 * Math.sin(a);
      g.beginPath(); g.moveTo(x1, y1); g.lineTo(x1 + r * 0.12, y1 - r * 0.12); g.lineTo(x1 + r * 0.32, y1 - r * 0.12); g.stroke();
      g.font = F(400, r * 0.055); g.textAlign = 'left'; g.textBaseline = 'bottom'; g.fillText('Ø 2.20', x1 + r * 0.13, y1 - r * 0.13);
    } else if (f === 'motorsport') {   // white race-team dial in a black bezel, a red pin-stripe
      const bz = g.createLinearGradient(cx, cy - r * 1.15, cx, cy + r * 1.15);
      bz.addColorStop(0, '#3c3c3e'); bz.addColorStop(0.5, '#08080a'); bz.addColorStop(1, '#2a2a2c');
      g.fillStyle = bz; circ(g, cx, cy, r * 1.13); g.fill();
      const fc = g.createRadialGradient(cx, cy - r * 0.3, r * 0.1, cx, cy, r * 1.05);
      fc.addColorStop(0, '#ffffff'); fc.addColorStop(0.7, '#f2f2ef'); fc.addColorStop(1, '#c9c9c4');
      g.fillStyle = fc; circ(g, cx, cy, r * 1.05); g.fill();
      g.strokeStyle = '#e10600'; g.lineWidth = Math.max(1.5, r * 0.014); circ(g, cx, cy, r * 0.995); g.stroke();
      g.fillStyle = '#111'; circ(g, cx, cy, r * 0.03); g.fill();
    } else if (f === 'vintage') {   // cream enamel, thin chrome bezel, printed rings, a little age
      const bz = g.createLinearGradient(cx - r, cy - r, cx + r, cy + r);
      bz.addColorStop(0, '#fbfbfb'); bz.addColorStop(0.3, '#878c93'); bz.addColorStop(0.55, '#ffffff'); bz.addColorStop(0.8, '#5c6067'); bz.addColorStop(1, '#d6d9dd');
      g.fillStyle = bz; circ(g, cx, cy, r * 1.12); g.fill();
      const fc = g.createRadialGradient(cx, cy - r * 0.25, r * 0.05, cx, cy, r * 1.06);
      fc.addColorStop(0, '#f8f0da'); fc.addColorStop(0.7, '#eadcb8'); fc.addColorStop(1, '#c9b68a');
      g.fillStyle = fc; circ(g, cx, cy, r * 1.06); g.fill();
      const rnd = rng(19);
      for (let i = 0; i < 60; i++) { g.fillStyle = `rgba(120,90,40,${(0.012 + rnd() * 0.022).toFixed(3)})`; circ(g, cx + (rnd() * 2 - 1) * r * 0.9, cy + (rnd() * 2 - 1) * r * 0.9, r * (0.01 + rnd() * 0.05)); g.fill(); }
      g.strokeStyle = 'rgba(42,33,24,.5)'; g.lineWidth = 1; circ(g, cx, cy, r * 0.915); g.stroke();
      g.strokeStyle = 'rgba(42,33,24,.25)'; circ(g, cx, cy, r * 0.25); g.stroke();
    } else if (f === 'f1') {   // black carbon disc, the steering-wheel display's green / red / purple light band
      g.fillStyle = '#050506'; circ(g, cx, cy, r * 1.1); g.fill();
      g.save(); circ(g, cx, cy, r * 1.08); g.clip(); g.fillStyle = 'rgba(255,255,255,.022)';
      for (let y = cy - r * 1.1; y < cy + r * 1.1; y += 4) g.fillRect(cx - r * 1.1, y, r * 2.2, 1.5);
      g.restore();
      for (const [a, b, c] of [[0, 0.62, '#19e65a'], [0.62, 0.86, '#ff2a2a'], [0.86, 1, '#a35bff']]) arc(g, cx, cy, r * 1.06, A0 + SWEEP * a + 0.02, A0 + SWEEP * b - 0.02, Math.max(2, r * 0.025), c, 0, 'butt');
      g.strokeStyle = 'rgba(255,255,255,.12)'; g.lineWidth = 1; circ(g, cx, cy, r * 1.1); g.stroke();
    } else if (f === 'aviation') {   // matte black instrument in a square-ish bezel with four screws
      g.fillStyle = '#1a1b1d'; circ(g, cx, cy, r * 1.17); g.fill();
      const fc = g.createRadialGradient(cx, cy, r * 0.2, cx, cy, r * 1.06); fc.addColorStop(0, '#141415'); fc.addColorStop(1, '#070708');
      g.fillStyle = fc; circ(g, cx, cy, r * 1.06); g.fill();
      g.strokeStyle = 'rgba(255,255,255,.1)'; g.lineWidth = 1; circ(g, cx, cy, r * 1.06); g.stroke();
      for (let i = 0; i < 4; i++) {
        const a = rad(45 + i * 90), x = cx + r * 1.115 * Math.cos(a), y = cy + r * 1.115 * Math.sin(a), sr = Math.max(2, r * 0.035);
        const sg = g.createRadialGradient(x - sr * 0.3, y - sr * 0.3, 0, x, y, sr); sg.addColorStop(0, '#9a9da2'); sg.addColorStop(1, '#2a2b2e');
        g.fillStyle = sg; circ(g, x, y, sr); g.fill();
        g.strokeStyle = '#0c0c0d'; g.lineWidth = Math.max(1, sr * 0.3); g.beginPath(); g.moveTo(x - sr * 0.7 * Math.cos(a + 0.6), y - sr * 0.7 * Math.sin(a + 0.6)); g.lineTo(x + sr * 0.7 * Math.cos(a + 0.6), y + sr * 0.7 * Math.sin(a + 0.6)); g.stroke();
      }
    } else if (f === 'oled') {   // true black: the pixels are off
      g.fillStyle = '#000'; circ(g, cx, cy, r * 1.08); g.fill();
      g.strokeStyle = 'rgba(255,255,255,.07)'; g.lineWidth = 1; circ(g, cx, cy, r * 1.08); g.stroke();
    } else if (f === 'matrix') {   // a green terminal: dim glyph grid, the rain itself is drawn live
      g.fillStyle = '#010a04'; circ(g, cx, cy, r * 1.07); g.fill();
      g.save(); circ(g, cx, cy, r * 1.05); g.clip();
      const cs = Math.max(7, r * 0.075), rnd = rng(23), GL = '0123456789ABCDEF<>/*+=#';
      g.font = `400 ${Math.round(cs * 0.85)}px "DejaVu Sans Mono", monospace`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillStyle = 'rgba(61,255,122,.07)';
      for (let y = cy - r; y < cy + r; y += cs) for (let x = cx - r; x < cx + r; x += cs * 0.8) g.fillText(GL[Math.floor(rnd() * GL.length)], x, y);
      g.restore();
      g.strokeStyle = 'rgba(61,255,122,.5)'; g.lineWidth = Math.max(1.5, r * 0.01); circ(g, cx, cy, r * 1.07); g.stroke();
    } else if (f === 'sapphire') {   // deep blue crystal with a silver bezel
      const bz = g.createLinearGradient(cx - r, cy - r, cx + r, cy + r);
      bz.addColorStop(0, '#f2f5fa'); bz.addColorStop(0.35, '#7d8796'); bz.addColorStop(0.6, '#ffffff'); bz.addColorStop(1, '#4a5260');
      g.fillStyle = bz; circ(g, cx, cy, r * 1.12); g.fill();
      const fc = g.createRadialGradient(cx - r * 0.2, cy - r * 0.35, r * 0.05, cx, cy, r * 1.07);
      fc.addColorStop(0, '#2f6ee0'); fc.addColorStop(0.45, '#0f3a9a'); fc.addColorStop(1, '#020b2a');
      g.fillStyle = fc; circ(g, cx, cy, r * 1.07); g.fill();
      if (g.createConicGradient) {   // faint radial sun-ray texture
        const sb = g.createConicGradient(0, cx, cy);
        for (let i = 0; i <= 48; i++) sb.addColorStop(i / 48, i % 2 ? 'rgba(255,255,255,.035)' : 'rgba(0,0,0,.06)');
        g.fillStyle = sb; circ(g, cx, cy, r * 1.07); g.fill();
      }
    } else if (f === 'ice') {   // frosted pale glass with frost ferns round the edge
      const bz = g.createLinearGradient(cx, cy - r * 1.1, cx, cy + r * 1.1); bz.addColorStop(0, '#f2fbff'); bz.addColorStop(1, '#7ea6c2');
      g.fillStyle = bz; circ(g, cx, cy, r * 1.12); g.fill();
      const fc = g.createRadialGradient(cx, cy - r * 0.3, r * 0.05, cx, cy, r * 1.07);
      fc.addColorStop(0, '#f7fcff'); fc.addColorStop(0.65, '#dcecf6'); fc.addColorStop(1, '#a9c8dd');
      g.fillStyle = fc; circ(g, cx, cy, r * 1.07); g.fill();
      g.save(); circ(g, cx, cy, r * 1.06); g.clip(); g.strokeStyle = 'rgba(255,255,255,.75)'; g.lineWidth = 1; g.lineCap = 'round';
      const rnd = rng(31);
      const fern = (x, y, a, L, d) => { if (d > 3 || L < 2) return; const x2 = x + L * Math.cos(a), y2 = y + L * Math.sin(a); g.beginPath(); g.moveTo(x, y); g.lineTo(x2, y2); g.stroke();
        for (let k = 1; k <= 3; k++) { const t2 = k / 4, bx = x + (x2 - x) * t2, by = y + (y2 - y) * t2; fern(bx, by, a + 0.8, L * 0.4, d + 1); fern(bx, by, a - 0.8, L * 0.4, d + 1); } };
      for (let i = 0; i < 14; i++) { const a = rnd() * TAU, d = r * (1.05 - rnd() * 0.08); fern(cx + d * Math.cos(a), cy + d * Math.sin(a), a + Math.PI + (rnd() - 0.5) * 0.8, r * (0.14 + rnd() * 0.16), 0); }
      g.restore();
    } else if (f === 'sunset') {   // the sky going down behind the dial
      g.save(); circ(g, cx, cy, r * 1.08); g.clip();
      const sk = g.createLinearGradient(0, cy - r * 1.08, 0, cy + r * 1.08);
      sk.addColorStop(0, '#2a1446'); sk.addColorStop(0.35, '#8a2c64'); sk.addColorStop(0.62, '#e0563f'); sk.addColorStop(0.78, '#f39a46'); sk.addColorStop(1, '#3a1636');
      g.fillStyle = sk; g.fillRect(cx - r * 1.1, cy - r * 1.1, r * 2.2, r * 2.2);
      const sun = g.createRadialGradient(cx, cy + r * 0.62, 0, cx, cy + r * 0.62, r * 0.6); sun.addColorStop(0, 'rgba(255,230,160,.9)'); sun.addColorStop(1, 'rgba(255,200,120,0)');
      g.fillStyle = sun; g.fillRect(cx - r * 1.1, cy - r * 1.1, r * 2.2, r * 2.2);
      const dk = g.createRadialGradient(cx, cy, r * 0.1, cx, cy, r * 0.8); dk.addColorStop(0, 'rgba(10,0,20,.45)'); dk.addColorStop(1, 'rgba(10,0,20,0)');   // keeps the numbers readable
      g.fillStyle = dk; g.fillRect(cx - r * 1.1, cy - r * 1.1, r * 2.2, r * 2.2);
      g.restore();
      g.strokeStyle = 'rgba(255,220,180,.55)'; g.lineWidth = Math.max(1.5, r * 0.012); circ(g, cx, cy, r * 1.08); g.stroke();
    } else if (f === 'rosegold') {   // dark chocolate dial, brushed rings, rose-gold bezel
      const fc = g.createRadialGradient(cx, cy - r * 0.3, r * 0.05, cx, cy, r * 1.06); fc.addColorStop(0, '#2a1d1f'); fc.addColorStop(1, '#0b0708');
      g.fillStyle = fc; circ(g, cx, cy, r * 1.06); g.fill();
      g.strokeStyle = 'rgba(255,220,210,.025)'; g.lineWidth = 1;
      for (let k = 0.1; k < 1.05; k += 0.018) { circ(g, cx, cy, r * k); g.stroke(); }
      const rg = g.createLinearGradient(cx - r, cy - r, cx + r, cy + r);
      rg.addColorStop(0, '#ffe1d6'); rg.addColorStop(0.3, '#b76e5d'); rg.addColorStop(0.55, '#ffd9cc'); rg.addColorStop(0.8, '#8c4a3d'); rg.addColorStop(1, '#f2b7a6');
      g.strokeStyle = rg; g.lineWidth = Math.max(3, r * 0.065); circ(g, cx, cy, r * 1.08); g.stroke();
      g.strokeStyle = 'rgba(0,0,0,.5)'; g.lineWidth = 1; circ(g, cx, cy, r * 1.045); g.stroke();
    } else if (f === 'glitch') {   // cyberpunk: yellow cut-corner rim, hazard stripes, cyan readouts
      const Y = '#fcee0a', C = '#00f0ff';
      g.fillStyle = '#07070b'; circ(g, cx, cy, r * 1.08); g.fill();
      g.save(); circ(g, cx, cy, r * 1.07); g.clip();
      g.strokeStyle = 'rgba(0,240,255,.06)'; g.lineWidth = 1; g.beginPath();
      for (let y = cy - r * 1.1; y < cy + r * 1.1; y += Math.max(3, r * 0.03)) { g.moveTo(cx - r * 1.1, y); g.lineTo(cx + r * 1.1, y); }
      g.stroke();
      g.save(); g.beginPath(); g.rect(cx - r * 0.5, cy + r * 0.86, r, r * 0.12); g.clip();   // hazard stripes at the bottom
      g.fillStyle = Y; for (let x = cx - r * 0.7; x < cx + r * 0.7; x += r * 0.12) { g.beginPath(); g.moveTo(x, cy + r * 0.98); g.lineTo(x + r * 0.06, cy + r * 0.98); g.lineTo(x + r * 0.12, cy + r * 0.86); g.lineTo(x + r * 0.06, cy + r * 0.86); g.closePath(); g.fill(); }
      g.restore(); g.restore();
      g.lineCap = 'butt';
      for (let i = 0; i < 6; i++) { const a = rad(-90 + i * 60); arc(g, cx, cy, r * 1.08, a + 0.12, a + rad(60) - 0.12, Math.max(2, r * 0.03), i % 3 === 1 ? C : Y, 0, 'butt'); }
      g.fillStyle = Y; g.font = `700 ${Math.round(Math.max(8, r * 0.06))}px "DejaVu Sans Mono", monospace`; g.textAlign = 'left'; g.textBaseline = 'middle';
      g.fillText('SYS//', cx - r * 0.85, cy - r * 0.92);
      g.fillStyle = C; g.textAlign = 'right'; g.fillText('NC-77', cx + r * 0.85, cy - r * 0.92);
    } else if (f === 'jdm') {   // 80s Japanese: matte black, the tri-color stripe across the lower dial
      const bz = g.createLinearGradient(cx, cy - r * 1.15, cx, cy + r * 1.15); bz.addColorStop(0, '#2b2b2d'); bz.addColorStop(1, '#0a0a0b');
      g.fillStyle = bz; circ(g, cx, cy, r * 1.12); g.fill();
      g.fillStyle = '#0d0d0e'; circ(g, cx, cy, r * 1.06); g.fill();
      g.save(); circ(g, cx, cy, r * 1.05); g.clip();
      const sy = cy + r * 0.66, sh = r * 0.045;
      [['#ffb000', 0], ['#ff6a00', 1], ['#e8261a', 2]].forEach(([c, k]) => { g.fillStyle = c; g.globalAlpha = 0.85; g.fillRect(cx - r * 1.1, sy + k * sh * 1.6, r * 2.2, sh); });
      g.globalAlpha = 1; g.restore();
      g.strokeStyle = 'rgba(255,255,255,.18)'; g.lineWidth = 1; circ(g, cx, cy, r * 1.06); g.stroke();
    }
  }
  const rng = (seed) => () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296; };
  // ... and the parts that move (drawn every frame)
  function backDyn(g, cx, cy, r, mini) {
    const f = FACE, t = nowT;
    if (f === 'ion') {   // three dashed rings turning at different speeds, like a particle accelerator
      g.save(); g.lineCap = 'round';
      [[1.05, 0.18, 1.2, T.accent], [0.74, -0.32, 2.2, T.b3], [0.5, 0.5, 1.4, T.b2]].forEach(([k, sp, w, c]) => {
        g.strokeStyle = rgba(c, 0.35 * Math.min(1.5, GK)); g.lineWidth = w; g.setLineDash([r * 0.02, r * 0.09]); g.lineDashOffset = -t * sp * r * 0.6;
        circ(g, cx, cy, r * k); g.stroke();
      });
      g.setLineDash([]); g.restore(); return;
    }
    if (f === 'halo') {   // a slow breath of light behind the reading
      const k = 0.5 + 0.5 * Math.sin(t * 0.9), rg = g.createRadialGradient(cx, cy, r * 0.2, cx, cy, r * 0.9);
      rg.addColorStop(0, rgba(T.accent, 0.05 + 0.04 * k)); rg.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = rg; circ(g, cx, cy, r * 0.9); g.fill(); return;
    }
    if (f === 'eclipse') {   // a corona flickering round the black disc
      g.save(); g.globalCompositeOperation = 'lighter';
      for (let i = 0; i < 3; i++) { g.strokeStyle = rgba(i ? T.b3 : T.accent, (0.05 + 0.04 * Math.sin(t * (1.3 + i) + i)) * Math.min(1.5, GK)); g.lineWidth = r * (0.03 + i * 0.03); circ(g, cx, cy, r * 0.64 + i * r * 0.025); g.stroke(); }
      g.restore(); return;
    }
    if (f === 'neon' && g.createConicGradient) {
      const ring = g.createConicGradient(t * 0.6, cx, cy);
      ring.addColorStop(0, T.b1); ring.addColorStop(0.33, T.accent); ring.addColorStop(0.66, T.b2); ring.addColorStop(1, T.b1);
      g.save(); g.shadowColor = T.accent; g.shadowBlur = r * 0.25 * GK; g.strokeStyle = ring; g.lineWidth = r * 0.035;
      circ(g, cx, cy, r * 1.12); g.stroke();
      g.lineWidth = r * 0.012; g.globalAlpha = 0.6; circ(g, cx, cy, r * 1.04); g.stroke(); g.restore();
    } else if (f === 'plasma' && g.createConicGradient) {
      g.save(); circ(g, cx, cy, r * 1.08); g.clip();
      for (let k = 0; k < 3; k++) {
        const cg = g.createConicGradient(t * (0.5 + k * 0.35) * (k % 2 ? -1 : 1), cx + Math.sin(t * 0.7 + k) * r * 0.25, cy + Math.cos(t * 0.5 + k) * r * 0.25);
        cg.addColorStop(0, T.b1); cg.addColorStop(0.3, T.b2); cg.addColorStop(0.6, T.accent); cg.addColorStop(1, T.b1);
        g.globalAlpha = 0.22; g.fillStyle = cg; g.fillRect(cx - r * 1.1, cy - r * 1.1, r * 2.2, r * 2.2);
      }
      g.globalAlpha = 1;
      const v = g.createRadialGradient(cx, cy, r * 0.2, cx, cy, r * 1.1);
      v.addColorStop(0, 'rgba(0,0,0,.65)'); v.addColorStop(0.7, 'rgba(0,0,0,.25)'); v.addColorStop(1, 'rgba(0,0,0,.5)');
      g.fillStyle = v; g.fillRect(cx - r * 1.1, cy - r * 1.1, r * 2.2, r * 2.2); g.restore();
    } else if (f === 'galaxy') {
      g.save(); circ(g, cx, cy, r * 1.08); g.clip();
      for (const [a0, d, b] of STARS) {
        const a = a0 + t * 0.05 * (1 - d), rr = r * 1.05 * Math.sqrt(d);
        g.globalAlpha = 0.35 + 0.65 * Math.abs(Math.sin(t * (1 + b * 2) + a0 * 7));
        g.fillStyle = b > 0.7 ? T.accent : '#fff';
        g.fillRect(cx + rr * Math.cos(a), cy + rr * Math.sin(a), b > 0.8 ? 2.2 : 1.4, b > 0.8 ? 2.2 : 1.4);
      }
      g.restore(); g.globalAlpha = 1;
    } else if (f === 'hud') {
      g.save(); g.strokeStyle = rgba(T.accent, 0.27); g.lineWidth = 1;
      for (let k = 0; k < 3; k++) { g.beginPath(); g.arc(cx, cy, r * (1.08 + k * 0.05), A0 - 0.2 + k * 0.3 + t * 0.2 * (k - 1), A0 + SWEEP * 0.4 + k * 0.5 + t * 0.2 * (k - 1)); g.stroke(); }
      g.restore();
    } else if (f === 'hologram') {
      g.save(); g.lineWidth = Math.max(1, r * 0.006);
      g.strokeStyle = rgba(T.accent, 0.22);   // gyroscope rings turning in 3D
      g.beginPath(); g.ellipse(cx, cy, r * 1.0 * Math.abs(Math.cos(t * 0.45)) + 0.5, r * 1.0, 0, 0, TAU); g.stroke();
      g.strokeStyle = rgba(T.b3, 0.18);
      g.beginPath(); g.ellipse(cx, cy, r * 1.0, r * 1.0 * Math.abs(Math.cos(t * 0.31 + 1)) + 0.5, rad(25), 0, TAU); g.stroke();
      g.strokeStyle = rgba(T.accent, 0.55); g.lineWidth = Math.max(1.5, r * 0.012); g.lineCap = 'butt';
      for (let k = 0; k < 3; k++) { const a = t * (k % 2 ? -0.35 : 0.5) + k * 2.1; g.beginPath(); g.arc(cx, cy, r * 1.14, a, a + 0.5 + k * 0.2); g.stroke(); }
      const sy = cy - r * 1.1 + frac(t * 0.22) * r * 3.2;   // a scan band rolling down now and then
      if (sy < cy + r * 1.05) {
        circ(g, cx, cy, r * 1.02); g.clip();
        const sb = g.createLinearGradient(0, sy - r * 0.12, 0, sy);
        sb.addColorStop(0, rgba(T.accent, 0)); sb.addColorStop(1, rgba(T.accent, 0.16));
        g.fillStyle = sb; g.fillRect(cx - r * 1.05, sy - r * 0.12, r * 2.1, r * 0.12);
      }
      g.restore();
    } else if (f === 'synthwave') {
      const hz = cy + r * (mini ? -0.25 : 0.18), R = r, bot = cy + R;
      g.save(); circ(g, cx, cy, R * 0.995); g.clip();
      g.strokeStyle = SYN_C; g.lineWidth = Math.max(1, r * 0.006);
      for (let i = 0; i < 9; i++) {
        const p = (i + trip.scroll) / 9, y = hz + (bot - hz) * p * p;
        g.globalAlpha = 0.15 + 0.7 * p; g.beginPath(); g.moveTo(cx - R, y); g.lineTo(cx + R, y); g.stroke();
      }
      g.restore(); g.globalAlpha = 1;
    } else if (f === 'aurora') {
      g.save(); circ(g, cx, cy, r * 1.03); g.clip(); g.globalCompositeOperation = 'lighter';
      const cols = [T.accent, T.b1, T.b3], rw = r * 0.045;
      for (let k = 0; k < 3; k++) {   // curtains of light: vertical rays hanging from a slowly waving line
        const base = cy - r * (0.32 - k * 0.2), amp = r * 0.12, ph = t * (0.3 + k * 0.1) + k * 1.9, hgt = r * (0.55 - k * 0.1);
        const gr = g.createLinearGradient(0, base - hgt, 0, base + rw);
        gr.addColorStop(0, rgba(cols[k], 0)); gr.addColorStop(0.75, rgba(cols[k], 0.22)); gr.addColorStop(0.95, rgba(mix(cols[k], '#ffffff', 0.4), 0.38)); gr.addColorStop(1, rgba(cols[k], 0));
        g.fillStyle = gr;
        for (let x = -1.02; x < 1.02; x += rw / r) {
          const dy = Math.sin(x * 2.4 + ph) * amp + Math.sin(x * 5.1 - ph * 1.4) * amp * 0.3;
          const a = 0.35 + 0.65 * Math.max(0, Math.sin(x * 7.3 + ph * 1.7 + k) * 0.6 + Math.sin(x * 17 - ph * 2.3) * 0.4);
          g.globalAlpha = a; g.translate(0, dy); g.fillRect(cx + r * x, base - hgt, rw * 1.02, hgt + rw); g.translate(0, -dy);
        }
      }
      g.globalAlpha = 1;
      g.restore();
    } else if (f === 'tron' && g.createConicGradient) {   // two light cycles racing round the rim
      for (const [rr, sp, col] of [[1.1, 0.55, '#ff8a1f'], [1.06, -0.4, T.accent]]) {
        const a = t * sp * 2, a0 = sp > 0 ? a - 1.1 : a, cg = g.createConicGradient(a0, cx, cy);
        cg.addColorStop(0, rgba(col, sp > 0 ? 0 : 1)); cg.addColorStop(1.1 / TAU, rgba(col, sp > 0 ? 1 : 0)); cg.addColorStop(1, rgba(col, 0));
        g.strokeStyle = cg; g.lineWidth = Math.max(2, r * 0.014); g.lineCap = 'butt'; g.beginPath(); g.arc(cx, cy, r * rr, a0, a0 + 1.1); g.stroke();
        g.fillStyle = '#fff'; circ(g, cx + r * rr * Math.cos(a), cy + r * rr * Math.sin(a), Math.max(2, r * 0.012)); g.fill();
      }
    } else if (f === 'lava') {   // the cracks breathe, embers rise
      g.globalAlpha = 0.55 + 0.45 * (0.5 + 0.5 * Math.sin(t * 1.3)) * (0.85 + 0.15 * Math.sin(t * 5.1));
      layer(g, `lavacr|${cx | 0},${cy | 0},${r | 0}`, cx, cy, r * 1.1, (x) => lavaCracks(x, cx, cy, r));
      g.globalAlpha = 1;
      g.save(); circ(g, cx, cy, r * 1.04); g.clip(); g.globalCompositeOperation = 'lighter';
      for (let i = 0; i < 16; i++) {
        const ph = frac(t * (0.08 + (i % 5) * 0.02) + i * 0.618), x = cx + Math.sin(i * 7.7 + t * 0.6) * r * 0.75 + Math.sin(ph * 9 + i) * r * 0.05, y = cy + r - ph * r * 2;
        g.fillStyle = `rgba(255,${120 + (i % 3) * 40},40,${(0.8 * Math.sin(Math.PI * ph)).toFixed(3)})`; circ(g, x, y, Math.max(1, r * (0.006 + (i % 4) * 0.003))); g.fill();
      }
      g.restore();
    } else if (f === 'matrix') {
      matrixRain(g, cx, cy, r);
    } else if (f === 'crystal' && g.createConicGradient) {   // a rainbow sheen turning slowly, a glint now and then
      g.save(); circ(g, cx, cy, r * 1.06); g.clip(); g.globalCompositeOperation = 'lighter';
      const cg = g.createConicGradient(t * 0.25, cx, cy);
      ['#ff4d6d', '#ffb84d', '#fff35c', '#5cff8d', '#4dd8ff', '#7a5cff', '#ff4d6d'].forEach((c, i, a) => cg.addColorStop(i / (a.length - 1), c));
      g.globalAlpha = 0.07; g.fillStyle = cg; g.fillRect(cx - r * 1.1, cy - r * 1.1, r * 2.2, r * 2.2);
      const ph = frac(t / 6);
      if (ph < 0.25) {
        const x = cx - r * 1.4 + ph * 4 * r * 2.8, gl = g.createLinearGradient(x - r * 0.2, 0, x + r * 0.2, 0);
        gl.addColorStop(0, 'rgba(255,255,255,0)'); gl.addColorStop(0.5, 'rgba(255,255,255,.5)'); gl.addColorStop(1, 'rgba(255,255,255,0)');
        g.globalAlpha = 0.35; g.fillStyle = gl; g.translate(x, cy); g.rotate(0.5); g.translate(-x, -cy); g.fillRect(x - r * 0.2, cy - r * 1.5, r * 0.4, r * 3);
      }
      g.restore();
    }
  }
  // matrix face: glyph columns drawn once, then slid down the dial (8 drawImage calls a frame)
  function matrixRain(g, cx, cy, r) {
    const cw = Math.max(6, r * 0.085), colH = r * 0.95, rows = Math.max(4, Math.floor(colH / cw));
    const spr = sprite(`mx|${r | 0}`, cw, colH, (x, W, H) => {
      x.font = `500 ${Math.round(cw * 0.9)}px "DejaVu Sans Mono", monospace`; x.textAlign = 'center'; x.textBaseline = 'top';
      const rnd = rng(5), GL = '0123456789ABCDEFXZ<>*+=';
      for (let i = 0; i < rows; i++) { const k = (i + 1) / rows; x.fillStyle = i === rows - 1 ? 'rgba(225,255,235,.95)' : `rgba(61,255,122,${(k * k * 0.6).toFixed(3)})`; x.fillText(GL[Math.floor(rnd() * GL.length)], W / 2, (i * H) / rows); }
    });
    g.save(); circ(g, cx, cy, r * 1.04); g.clip(); g.globalAlpha = 0.55;
    const N = 8;
    for (let i = 0; i < N; i++) {
      const sp = 0.16 + ((i * 37) % 10) * 0.03, x = cx - r + ((i + 0.5) * 2 * r) / N - cw / 2 + ((i * 13) % 5) * cw * 0.15;
      g.drawImage(spr, x, cy - r - colH + frac(nowT * sp + i * 0.37) * (2 * r + colH), cw, colH);
    }
    g.restore();
  }
  // glitch face: now and then a few slices of the finished dial jump sideways (copies of the canvas onto itself)
  function glitchSlices(g, cx, cy, r) {
    const ph = frac(nowT * 0.37 + cx * 0.0031);
    if (ph > 0.06 || !CUR) return;
    const rnd = rng(Math.floor(nowT * 24) * 7 + (cx | 0)), xs = window.CL_XS || 1, kx = DPR * xs, ky = DPR;
    g.save(); g.setTransform(1, 0, 0, 1, 0, 0);
    const x0 = Math.max(0, Math.floor((cx - r * 1.1) * kx)), ww = Math.min(CUR.width - x0, Math.floor(r * 2.2 * kx));
    for (let i = 0; i < 3; i++) {
      const y = Math.floor((cy - r + rnd() * r * 2) * ky), hh = Math.floor((2 + rnd() * r * 0.07) * ky), dx = Math.round((rnd() - 0.5) * r * 0.18 * kx);
      if (ww > 0 && hh > 0 && y >= 0 && y + hh <= CUR.height) g.drawImage(CUR, x0, y, ww, hh, x0 + dx, y, ww, hh);
    }
    g.fillStyle = rnd() > 0.5 ? 'rgba(0,240,255,.35)' : 'rgba(255,0,90,.3)';
    g.fillRect(x0, Math.floor((cy - r + rnd() * r * 2) * ky), ww, Math.max(1, Math.floor(ky * 1.5)));
    g.restore();
  }
  function lavaCracks(g, cx, cy, r) {
    const rnd = rng(11), paths = [];
    for (let i = 0; i < 13; i++) {
      let a = rnd() * TAU, d = r * (0.5 + rnd() * 0.45), x = cx + d * Math.cos(a), y = cy + d * Math.sin(a), dir = rnd() * TAU;
      const p = [[x, y]];
      for (let k = 0; k < 9; k++) { dir += (rnd() - 0.5) * 1.3; const L = r * (0.04 + rnd() * 0.07); x += L * Math.cos(dir); y += L * Math.sin(dir); p.push([x, y]); }
      paths.push(p);
    }
    g.save(); circ(g, cx, cy, r * 1.04); g.clip(); g.lineCap = 'round'; g.lineJoin = 'round';
    for (const [wd, c] of [[r * 0.035, 'rgba(255,70,10,.18)'], [r * 0.014, 'rgba(255,120,20,.55)'], [Math.max(1, r * 0.004), 'rgba(255,230,140,.95)']]) {
      g.strokeStyle = c; g.lineWidth = wd; g.beginPath();
      for (const p of paths) { g.moveTo(...p[0]); for (const q of p.slice(1)) g.lineTo(...q); }
      g.stroke();
    }
    g.globalCompositeOperation = 'destination-out';   // keep the middle calm so the numbers read
    const cm = g.createRadialGradient(cx, cy, 0, cx, cy, r * 0.75); cm.addColorStop(0, 'rgba(0,0,0,.92)'); cm.addColorStop(0.6, 'rgba(0,0,0,.7)'); cm.addColorStop(1, 'rgba(0,0,0,0)');
    g.fillStyle = cm; g.fillRect(cx - r, cy - r, r * 2, r * 2);
    g.restore();
  }
  // over the ticks (static): glass glare, clear coat
  function frontStatic(g, cx, cy, r) {
    if (FACE === 'glass') {
      g.save(); g.lineCap = 'round';
      const gl = g.createLinearGradient(cx - r, cy - r, cx, cy);
      gl.addColorStop(0, 'rgba(255,255,255,.55)'); gl.addColorStop(1, 'rgba(255,255,255,0)');
      g.strokeStyle = gl; g.lineWidth = Math.max(2, r * 0.018); g.beginPath(); g.arc(cx, cy, r * 1.04, rad(190), rad(265)); g.stroke(); g.restore();
    } else if (FACE === 'carbon' || FACE === 'liquid' || FACE === 'luxe' || FACE === 'retro' || FACE === 'crystal' || FACE === 'motorsport' || FACE === 'vintage'
      || FACE === 'aviation' || FACE === 'sapphire' || FACE === 'ice' || FACE === 'rosegold' || FACE === 'jdm') {
      const sh = g.createLinearGradient(cx, cy - r, cx, cy);
      sh.addColorStop(0, 'rgba(255,255,255,.09)'); sh.addColorStop(1, 'rgba(255,255,255,0)');
      g.fillStyle = sh; g.beginPath(); g.ellipse(cx, cy - r * 0.42, r * 0.92, r * 0.55, 0, Math.PI, TAU); g.fill();
    }
  }
  let SCAN = null, scanKey = '';
  function frontDyn(g, cx, cy, r) {
    if (FACE === 'glitch') return glitchSlices(g, cx, cy, r);
    if (FACE !== 'hologram') return;
    if (scanKey !== themeKey) {
      const c = document.createElement('canvas'); c.width = 2; c.height = 4; const x = c.getContext('2d');
      x.fillStyle = rgba(T.accent, 0.09); x.fillRect(0, 0, 2, 1); x.fillStyle = 'rgba(0,0,0,.16)'; x.fillRect(0, 2, 2, 1);
      SCAN = g.createPattern(c, 'repeat'); scanKey = themeKey;
    }
    g.save(); circ(g, cx, cy, r * 1.02); g.clip(); g.translate(0, (nowT * 12) % 4);
    g.fillStyle = SCAN; g.fillRect(cx - r * 1.05, cy - r * 1.1, r * 2.1, r * 2.2); g.restore();
  }
  const holoFlick = () => { const t = nowT, n = Math.sin(t * 23.7) * Math.sin(t * 7.3 + 1.3) * Math.sin(t * 2.1); return n > 0.8 ? 0.55 : 0.94 + 0.06 * Math.sin(t * 50); };
  // the whole back of a dial (used by dials, small gauges and the coolant gauge)
  function faceBack(g, cx, cy, r, mini) {
    LIGHT = !!P.light;
    layer(g, `fb|${cx | 0},${cy | 0},${r | 0}|${mini ? 1 : 0}`, cx, cy, r * 1.2, (x) => backStatic(x, cx, cy, r, mini));
    if (P.dyn) backDyn(g, cx, cy, r, mini);
  }
  // the empty track the value fills
  function track(g, cx, cy, r, mode, tw, nseg) {
    if (mode === 'tube') {
      const rg = g.createRadialGradient(cx, cy, r - tw * 0.6, cx, cy, r + tw * 0.6);
      rg.addColorStop(0, 'rgba(255,255,255,.10)'); rg.addColorStop(0.12, 'rgba(0,0,0,.9)'); rg.addColorStop(0.6, 'rgba(20,22,26,.9)'); rg.addColorStop(0.9, 'rgba(0,0,0,.9)'); rg.addColorStop(1, 'rgba(255,255,255,.14)');
      arc(g, cx, cy, r, A0, A0 + SWEEP, tw * 1.2, rg, 0, 'round');
    } else if (mode === 'particles') {
      g.fillStyle = 'rgba(255,255,255,.16)'; const n = Math.round(r * 0.6), d = Math.max(1.2, r * 0.008);
      for (let i = 0; i <= n; i++) { const a = A0 + (SWEEP * i) / n; g.fillRect(cx + r * Math.cos(a) - d / 2, cy + r * Math.sin(a) - d / 2, d, d); }
    } else if (mode === 'hair') {
      arc(g, cx, cy, r, A0, A0 + SWEEP, 1, 'rgba(255,255,255,.22)', 0, 'butt');
    } else if (mode === 'segments' || mode === 'holo') {
      const n = mode === 'holo' ? 90 : nseg, k = mode === 'holo' ? 0.42 : 0.72;
      g.strokeStyle = mode === 'holo' ? rgba(T.accent, 0.1) : 'rgba(255,255,255,.06)'; g.lineWidth = tw * (mode === 'holo' ? 1.25 : 1); g.lineCap = 'butt';
      g.beginPath();
      for (let i = 0; i < n; i++) { const a = A0 + SWEEP * (i / n), b = A0 + SWEEP * ((i + k) / n); g.moveTo(cx + r * Math.cos(a), cy + r * Math.sin(a)); g.arc(cx, cy, r, a, b, b < a); }
      g.stroke();
    } else if (mode === 'flat') {
      arc(g, cx, cy, r, A0, A0 + SWEEP, tw * 0.75, P.light ? 'rgba(0,0,0,.1)' : 'rgba(255,255,255,.08)');
    } else if (mode === 'vfd' || mode === 'term') {
      const n = nseg; g.strokeStyle = mode === 'term' ? 'rgba(61,255,122,.08)' : rgba(AMBER, 0.08); g.lineWidth = tw; g.lineCap = 'butt'; g.beginPath();
      for (let i = 0; i < n; i++) { const a = A0 + SWEEP * (i / n), b = A0 + SWEEP * ((i + 0.72) / n); g.moveTo(cx + r * Math.cos(a), cy + r * Math.sin(a)); g.arc(cx, cy, r, a, b, b < a); }
      g.stroke();
    } else if (mode === 'hatch') {
      g.strokeStyle = 'rgba(255,255,255,.7)'; g.lineWidth = 1;
      for (const rr of [r - tw / 2, r + tw / 2]) { g.beginPath(); g.arc(cx, cy, rr, A0, A0 + SWEEP, SWEEP < 0); g.stroke(); }
      for (const a of [A0, A0 + SWEEP]) { g.beginPath(); g.moveTo(cx + (r - tw / 2) * Math.cos(a), cy + (r - tw / 2) * Math.sin(a)); g.lineTo(cx + (r + tw / 2) * Math.cos(a), cy + (r + tw / 2) * Math.sin(a)); g.stroke(); }
    } else if (mode === 'beam') {
      arc(g, cx, cy, r, A0, A0 + SWEEP, 1, 'rgba(255,255,255,.14)', 0, 'butt');
    } else if (mode === 'filament') {
      // the glass tube is part of the face (backStatic)
    } else if (mode === 'tron') {
      arc(g, cx, cy, r, A0, A0 + SWEEP, tw * 0.55, rgba(T.accent, 0.1), 0, 'butt');
    } else if (mode === 'synth') {
      arc(g, cx, cy, r, A0, A0 + SWEEP, tw, 'rgba(20,0,40,.55)');
      arc(g, cx, cy, r, A0, A0 + SWEEP, 1, rgba(SYN_C, 0.25), 0, 'butt');
    } else if (mode !== 'none' || FACE !== 'minimal') arc(g, cx, cy, r, A0, A0 + SWEEP, tw, FACE === 'glass' ? 'rgba(255,255,255,.12)' : P.light ? 'rgba(0,0,0,.1)' : T.faint);
  }
  // the value: 0..1 along the sweep, drawn the way the face (or the arc option) says
  function arcFill(g, cx, cy, r, f, tw, col, mode, nseg) {
    f = clamp(f, 0, 1);
    const cf = (v) => (typeof col === 'function' ? col(v) : col), c = cf(Math.max(f, 0.001)), t = nowT;
    if (mode === 'none') return;
    if (mode === 'vfd') { const c0 = col; col = (v) => ((typeof c0 === 'function' ? c0(v) : c0) === T.red ? '#ff5a3c' : AMBER); mode = 'segments'; }
    if (mode === 'term') { const c0 = col; col = (v) => ((typeof c0 === 'function' ? c0(v) : c0) === T.red ? T.red : '#3dff7a'); mode = 'segments'; }
    if (mode === 'segments' || mode === 'holo') {
      const holo = mode === 'holo', n = holo ? 90 : nseg, k = holo ? 0.42 : 0.72, groups = new Map();
      let last = -1;
      for (let i = 0; i < n; i++) {
        const v = (i + 1) / n;
        if (v > f + 1e-6) break;
        const cc = holo && typeof col !== 'function' ? T.accent : cf(v), a = A0 + SWEEP * (i / n), b = A0 + SWEEP * ((i + k) / n);
        let p = groups.get(cc); if (!p) { p = new Path2D(); groups.set(cc, p); }
        p.moveTo(cx + r * Math.cos(a), cy + r * Math.sin(a)); p.arc(cx, cy, r, a, b, b < a); last = i;
      }
      g.lineWidth = tw * (holo ? 1.25 : 1); g.lineCap = 'butt';
      for (const [cc, p] of groups) { g.strokeStyle = cc; g.shadowColor = cc; g.shadowBlur = r * 0.08 * GK; g.stroke(p); }
      g.shadowBlur = 0;
      if (holo && last >= 0) {   // the leading bars burn white, a shimmer runs up the lit ones
        g.strokeStyle = '#ffffff';
        for (let i = Math.max(0, last - 2); i <= last; i++) { g.globalAlpha = 0.45 + 0.18 * (i - last + 2); g.beginPath(); g.arc(cx, cy, r, A0 + SWEEP * (i / n), A0 + SWEEP * ((i + k) / n), SWEEP < 0); g.stroke(); }
        const sh = Math.floor(frac(t * 0.6) * (last + 12)) - 6;
        g.globalAlpha = 0.35;
        for (let i = Math.max(0, sh - 3); i <= Math.min(last, sh + 3); i++) { g.beginPath(); g.arc(cx, cy, r, A0 + SWEEP * (i / n), A0 + SWEEP * ((i + k) / n), SWEEP < 0); g.stroke(); }
        g.globalAlpha = 1;
      }
      return;
    }
    if (f <= 0.002) return;
    const end = A0 + SWEEP * f;
    if (mode === 'beam' || mode === 'filament') {   // light, not paint: a wide soft bloom, a bright core, a white-hot head
      const warm = mode === 'filament', hc = warm ? '#ff9a3c' : c, core = warm ? '#fff3df' : mix(c, '#ffffff', 0.55), k = Math.min(1.6, GK);
      let tail = hc;
      if (g.createConicGradient && SWEEP > 0) {   // the beam fades in from where it starts
        const cg = g.createConicGradient(A0, cx, cy), span = Math.min(0.999, (end - A0) / TAU);
        cg.addColorStop(0, rgba(hc, 0)); cg.addColorStop(span * 0.6, rgba(hc, 0.75)); cg.addColorStop(span, hc); cg.addColorStop(Math.min(1, span + 0.001), rgba(hc, 0)); tail = cg;
      }
      g.save(); g.globalCompositeOperation = 'lighter';
      g.globalAlpha = 0.07 * k; arc(g, cx, cy, r, A0, end, tw * 3.2, tail, 0, 'round');
      g.globalAlpha = 0.22 * k; arc(g, cx, cy, r, A0, end, tw * 1.2, tail, 0, 'round');
      g.globalAlpha = 1; arc(g, cx, cy, r, A0, end, Math.max(1.5, tw * (warm ? 0.18 : 0.32)), warm ? core : tail, 0, 'round');
      if (!warm) arc(g, cx, cy, r, Math.max(A0, end - SWEEP * 0.12) , end, Math.max(1, tw * 0.14), 'rgba(255,255,255,.85)', 0, 'round');
      const hx = cx + r * Math.cos(end), hy = cy + r * Math.sin(end);
      const hg = g.createRadialGradient(hx, hy, 0, hx, hy, tw * 1.6);
      hg.addColorStop(0, 'rgba(255,255,255,.95)'); hg.addColorStop(0.25, rgba(hc, 0.8)); hg.addColorStop(1, rgba(hc, 0));
      g.fillStyle = hg; circ(g, hx, hy, tw * 1.6); g.fill();
      g.restore();
      return;
    }
    if (mode === 'gradient') {
      const gr = g.createLinearGradient(cx - r, cy, cx + r, cy);
      gr.addColorStop(0, T.b3); gr.addColorStop(1, c);
      g.shadowColor = c; arc(g, cx, cy, r, A0, end, tw, gr, r * 0.12, 'round', true);
    } else if (mode === 'solid') {
      arc(g, cx, cy, r, A0, end, tw, c, r * 0.12);
    } else if (mode === 'flat') {   // no glow: one clean stroke and a bright tip
      arc(g, cx, cy, r, A0, end, tw * 0.75, c, 0, 'round');
      g.fillStyle = P.light ? '#ffffff' : 'rgba(255,255,255,.9)'; circ(g, cx + r * Math.cos(end), cy + r * Math.sin(end), tw * 0.2); g.fill();
    } else if (mode === 'synth' && g.createConicGradient) {
      const cg = g.createConicGradient(A0, cx, cy); cg.addColorStop(0, SYN_C); cg.addColorStop(SWEEP / TAU, SYN_M); cg.addColorStop(1, SYN_M);
      g.shadowColor = SYN_M; arc(g, cx, cy, r, A0, end, tw * 0.8, cg, r * 0.1, 'round', true);
      arc(g, cx, cy, r, A0, end, Math.max(1.5, tw * 0.22), 'rgba(255,255,255,.85)');
    } else if (mode === 'tube') {
      const dark = mix(c, '#000000', 0.72), mid = mix(c, '#c4ccd4', 0.4), lite = mix(c, '#ffffff', 0.65);
      const rg = g.createRadialGradient(cx, cy, r - tw * 0.45, cx, cy, r + tw * 0.45);
      rg.addColorStop(0, dark); rg.addColorStop(0.3, mid); rg.addColorStop(0.5, lite); rg.addColorStop(0.58, '#ffffff'); rg.addColorStop(0.68, mid); rg.addColorStop(1, dark);
      g.shadowColor = c; arc(g, cx, cy, r, A0, end, tw * 0.9, rg, r * 0.07, 'round', true);
      const L = end - A0, ph = frac(t * 0.4), sa = A0 + L * ph, se = Math.min(end, sa + Math.min(0.4, L * 0.35));   // a glint running along it
      if (se > sa) arc(g, cx, cy, r + tw * 0.05, sa, se, tw * 0.16, `rgba(255,255,255,${(0.8 * Math.sin(Math.PI * ph)).toFixed(3)})`);
      const tx = cx + r * Math.cos(end), ty = cy + r * Math.sin(end), mg = g.createRadialGradient(tx - tw * 0.12, ty - tw * 0.15, tw * 0.03, tx, ty, tw * 0.48);   // meniscus
      mg.addColorStop(0, '#ffffff'); mg.addColorStop(0.35, lite); mg.addColorStop(1, dark);
      g.fillStyle = mg; circ(g, tx, ty, tw * 0.46); g.fill();
    } else if (mode === 'aurora' && g.createConicGradient) {
      const cg = g.createConicGradient(t * 0.6, cx, cy);
      [T.b1, T.accent, T.b2, T.b3, T.b1].forEach((cc, i) => cg.addColorStop(i / 4, cc));
      const k = Math.min(1.6, GK);
      g.globalAlpha = 0.09 * k; arc(g, cx, cy, r, A0, end, tw * 4.2, cg);
      g.globalAlpha = 0.22 * k; arc(g, cx, cy, r, A0, end, tw * 2.1, cg);
      g.globalAlpha = 1; arc(g, cx, cy, r, A0, end, tw, cg);
      arc(g, cx, cy, r - tw * 0.12, A0, end, Math.max(1, tw * 0.16), 'rgba(255,255,255,.55)');
      if (typeof col === 'function' && c === T.red) arc(g, cx, cy, r, A0, end, tw, rgba(T.red, 0.5));
    } else if (mode === 'particles') {
      const s = state(), L = end - A0;
      s.pp = (s.pp || 0) + DT * (0.15 + 1.1 * f);
      arc(g, cx, cy, r, A0, end, tw * 2.2, rgba(c, 0.07 * Math.min(1.6, GK)), 0, 'butt');
      arc(g, cx, cy, r, A0, end, Math.max(1.5, tw * 0.45), rgba(c, 0.4));
      g.save(); g.globalCompositeOperation = 'lighter';
      const N = r > 110 ? 170 : 70, sz = Math.max(1, r / 120), tail = mix(T.b3, c, 0.3);
      for (let i = 0; i < N; i++) {
        const h1 = frac(i * 0.6180339), h2 = frac(i * 0.7548776 + 0.31), ph = frac(s.pp * (0.6 + h2 * 0.8) + h1);
        const a = A0 + L * ph, rr = r + (h2 - 0.5) * tw * 3.4 * (1 - ph * 0.8), d = (1 + 3.2 * ph) * sz;
        g.fillStyle = rgba(ph > 0.6 ? c : tail, 0.12 + 0.88 * ph * ph);
        g.fillRect(cx + rr * Math.cos(a) - d / 2, cy + rr * Math.sin(a) - d / 2, d, d);
      }
      const tx = cx + r * Math.cos(end), ty = cy + r * Math.sin(end), gr = g.createRadialGradient(tx, ty, 0, tx, ty, tw * 1.8 * Math.max(0.4, Math.min(1.5, GK)));
      gr.addColorStop(0, rgba(c, 0.95)); gr.addColorStop(1, rgba(c, 0));
      g.fillStyle = gr; circ(g, tx, ty, tw * 1.8 * Math.max(0.4, Math.min(1.5, GK))); g.fill();
      g.fillStyle = '#fff'; circ(g, tx, ty, Math.max(1.5, tw * 0.22)); g.fill(); g.restore();
    } else if (mode === 'hair') {
      arc(g, cx, cy, r, A0, end, Math.max(2, r * 0.014), c, r * 0.06);
      g.fillStyle = '#fff'; g.shadowColor = c; g.shadowBlur = r * 0.08 * GK; circ(g, cx + r * Math.cos(end), cy + r * Math.sin(end), Math.max(2.5, r * 0.028)); g.fill(); g.shadowBlur = 0;
    } else if (mode === 'tron') {
      g.shadowColor = T.accent; arc(g, cx, cy, r, A0, end, tw * 0.55, T.accent, r * 0.08, 'butt', true);
      arc(g, cx, cy, r, A0, end, Math.max(1.5, tw * 0.16), '#ffffff', 0, 'butt');
      const tx = cx + r * Math.cos(end), ty = cy + r * Math.sin(end);
      g.save(); g.translate(tx, ty); g.rotate(end); g.fillStyle = c === T.red ? T.red : '#ff8a1f'; g.shadowColor = g.fillStyle; g.shadowBlur = r * 0.06 * GK;
      g.fillRect(-tw * 0.45, -tw * 0.45, tw * 0.9, tw * 0.9); g.restore();
    } else if (mode === 'lava' && g.createConicGradient) {
      const cg = g.createConicGradient(-t * 0.5, cx, cy);
      ['#5a0a00', '#ff4a00', '#ffb000', '#ff4a00', '#8a1500', '#ff6a00', '#ffd060', '#ff4a00', '#5a0a00'].forEach((cc, i, a) => cg.addColorStop(i / (a.length - 1), cc));
      g.globalAlpha = 0.25 * Math.min(1.6, GK); arc(g, cx, cy, r, A0, end, tw * 2.4, '#ff4a00'); g.globalAlpha = 1;
      arc(g, cx, cy, r, A0, end, tw, cg);
      arc(g, cx, cy, r, A0, end, Math.max(1, tw * 0.2), 'rgba(255,240,180,.75)');
      const tx = cx + r * Math.cos(end), ty = cy + r * Math.sin(end), gr = g.createRadialGradient(tx, ty, 0, tx, ty, tw * 1.4);
      gr.addColorStop(0, 'rgba(255,240,180,1)'); gr.addColorStop(0.4, 'rgba(255,140,20,.8)'); gr.addColorStop(1, 'rgba(255,60,0,0)');
      g.fillStyle = gr; circ(g, tx, ty, tw * 1.4); g.fill();
    } else if (mode === 'prism' && g.createConicGradient) {
      const cg = g.createConicGradient(A0, cx, cy);
      ['#4dd8ff', '#5cff8d', '#fff35c', '#ffb84d', '#ff4d6d', '#ff4dd2'].forEach((cc, i, a) => cg.addColorStop((i / (a.length - 1)) * (SWEEP / TAU), cc));
      cg.addColorStop(0.875, '#ff4dd2'); cg.addColorStop(1, '#4dd8ff');
      g.globalAlpha = 0.2 * Math.min(1.6, GK); arc(g, cx, cy, r, A0, end, tw * 2.4, cg); g.globalAlpha = 1;
      arc(g, cx, cy, r, A0, end, tw, cg);
      arc(g, cx, cy, r - tw * 0.18, A0, end, Math.max(1, tw * 0.18), 'rgba(255,255,255,.7)');
    } else if (mode === 'hatch') {
      g.strokeStyle = 'rgba(255,255,255,.85)'; g.lineWidth = 1; g.beginPath();
      const step = Math.max(0.012, 5 / r);
      const sg = Math.sign(SWEEP);
      for (let a = A0; (end - a) * sg > 0; a += step * sg) { g.moveTo(cx + (r - tw / 2) * Math.cos(a), cy + (r - tw / 2) * Math.sin(a)); const b = sg > 0 ? Math.min(end, a + step * 1.6) : Math.max(end, a - step * 1.6); g.lineTo(cx + (r + tw / 2) * Math.cos(b), cy + (r + tw / 2) * Math.sin(b)); }
      g.stroke();
      g.lineWidth = 2; g.beginPath(); g.moveTo(cx + (r - tw) * Math.cos(end), cy + (r - tw) * Math.sin(end)); g.lineTo(cx + (r + tw) * Math.cos(end), cy + (r + tw) * Math.sin(end)); g.stroke();
    } else arc(g, cx, cy, r, A0, end, tw, c, r * 0.12);
  }
  const AMBER = '#ffb347';

  // ---- needles: blade, laser, comet (with a fading trail), classic. `inner` = only a pointer from there out (small gauges)
  function needle(g, cx, cy, len, a, col, w, inner) {
    const st = part('needle');
    if (st === 'none') return;
    if (P.ncol && col !== T.red) col = P.ncol === 'accent' ? T.accent : P.ncol;
    const hub = inner == null, r0 = hub ? 0 : inner, ca = Math.cos(a), sa = Math.sin(a);
    const line = (s, e) => { g.beginPath(); g.moveTo(cx + s * ca, cy + s * sa); g.lineTo(cx + e * ca, cy + e * sa); g.stroke(); };
    if (st === 'comet') {
      const s = state();
      if (s.lag == null || !Number.isFinite(s.lag)) s.lag = a;
      s.lag += (a - s.lag) * Math.min(1, DT * 2.6);
      const d = a - s.lag;
      if (Math.abs(d) > 0.004 && g.createConicGradient) {
        const a1 = Math.min(a, s.lag), a2 = Math.max(a, s.lag), span = Math.min(0.999, (a2 - a1) / TAU), cg = g.createConicGradient(a1, cx, cy);
        const c0 = rgba(col, 0), c1 = rgba(col, 0.6 * Math.min(1, 0.4 + GK * 0.6));
        cg.addColorStop(0, d > 0 ? c0 : c1); cg.addColorStop(span, d > 0 ? c1 : c0); cg.addColorStop(1, c0);
        g.fillStyle = cg; g.beginPath(); g.arc(cx, cy, len * 1.02, a1, a2); g.arc(cx, cy, Math.max(r0, len * 0.3), a2, a1, true); g.closePath(); g.fill();
      }
    }
    if (st === 'laser' || st === 'comet') {
      const s0 = hub ? len * 0.22 : r0;
      g.lineCap = 'round';
      g.strokeStyle = rgba(col, 0.22 * Math.min(1.5, GK)); g.lineWidth = w * 3.4; line(s0, len);
      g.strokeStyle = col; g.lineWidth = Math.max(2, w * 0.75); line(s0, len);
      g.strokeStyle = 'rgba(255,255,255,.9)'; g.lineWidth = Math.max(1, w * 0.28); line(s0 + (len - s0) * 0.3, len);
      g.fillStyle = '#fff'; g.shadowColor = col; g.shadowBlur = w * 5 * GK; circ(g, cx + len * ca, cy + len * sa, w * 0.85); g.fill(); g.shadowBlur = 0;
      if (hub) { g.strokeStyle = col; g.lineWidth = 2; circ(g, cx, cy, w * 2.2); g.stroke(); g.fillStyle = col; circ(g, cx, cy, w * 0.8); g.fill(); }
      return;
    }
    g.save(); g.translate(cx, cy); g.rotate(a);
    if (st === 'blade') {
      const wb = w * 1.2, tail = hub ? -len * 0.2 : r0, mid = hub ? 0 : r0, wm = hub ? wb : wb * 0.55;
      const all = () => { g.beginPath(); g.moveTo(tail, -wm * 0.55); g.lineTo(mid, -wm); g.lineTo(len, 0); g.lineTo(mid, wm); g.lineTo(tail, wm * 0.55); g.closePath(); };
      all(); g.fillStyle = col; g.shadowColor = col; g.shadowBlur = w * 3.5 * GK; g.fill(); g.shadowBlur = 0;
      g.beginPath(); g.moveTo(tail, -wm * 0.55); g.lineTo(mid, -wm); g.lineTo(len, 0); g.lineTo(tail, 0); g.closePath(); g.fillStyle = mix(col, '#ffffff', 0.3); g.fill();   // lit and shaded halves
      g.beginPath(); g.moveTo(tail, wm * 0.55); g.lineTo(mid, wm); g.lineTo(len, 0); g.lineTo(tail, 0); g.closePath(); g.fillStyle = mix(col, '#000000', 0.35); g.fill();
      g.strokeStyle = 'rgba(255,255,255,.55)'; g.lineWidth = 1; g.beginPath(); g.moveTo(mid, 0); g.lineTo(len * 0.97, 0); g.stroke();
      g.restore();
      if (hub) {
        const hc = g.createRadialGradient(cx - w, cy - w * 1.2, w * 0.2, cx, cy, w * 3);
        hc.addColorStop(0, '#9aa1aa'); hc.addColorStop(0.5, '#2a2d33'); hc.addColorStop(1, '#08090b');
        g.fillStyle = hc; circ(g, cx, cy, w * 2.8); g.fill();
        g.strokeStyle = rgba(col, 0.85); g.lineWidth = Math.max(1.5, w * 0.35); g.stroke();
        g.fillStyle = col; circ(g, cx, cy, w * 0.7); g.fill();
      }
      return;
    }
    // classic
    g.shadowColor = col; g.shadowBlur = w * 3 * GK; g.fillStyle = col;
    g.beginPath();
    if (hub) { g.moveTo(-len * 0.16, -w); g.lineTo(len, -w * 0.18); g.lineTo(len, w * 0.18); g.lineTo(-len * 0.16, w); }
    else { g.moveTo(r0, -w * 0.6); g.lineTo(len, -w * 0.18); g.lineTo(len, w * 0.18); g.lineTo(r0, w * 0.6); }
    g.closePath(); g.fill();
    g.restore(); g.shadowBlur = 0;
    if (!hub) return;
    const hb = g.createRadialGradient(cx - w, cy - w, 1, cx, cy, w * 3.2);
    hb.addColorStop(0, '#666b74'); hb.addColorStop(1, '#0d0f12');
    g.fillStyle = hb; circ(g, cx, cy, w * 3); g.fill();
  }
  const pulse = (t, speed = 4) => 0.5 + 0.5 * Math.sin(t * speed);
  const noData = (g, cx, cy, size, what) => text(g, what, cx, cy, 500, size * 0.07, T.sub);

  // ---- seven-segment digits (numerals: digital, and the carbon face's readout)
  const SEG = { 0: 0x3f, 1: 0x06, 2: 0x5b, 3: 0x4f, 4: 0x66, 5: 0x6d, 6: 0x7d, 7: 0x07, 8: 0x7f, 9: 0x6f, '-': 0x40, ' ': 0 };
  function seg7(g, s, x, y, hgt, col, align = 'center', ghost = 0.08) {
    const cw = hgt * 0.54, gap = hgt * 0.17, th = Math.max(1.5, hgt * 0.13), dotW = hgt * 0.26, chars = [...String(s)];
    const fb = (ch) => { g.font = F(500, hgt * 0.75); return g.measureText(ch).width + gap * 0.5; };
    const wOf = (ch) => (ch === '.' ? dotW : SEG[ch] != null ? cw + gap : fb(ch));
    const total = chars.reduce((a, ch) => a + wOf(ch), 0) - gap;
    let px = align === 'center' ? x - total / 2 : align === 'right' ? x - total : x;
    const top = y - hgt / 2, lit = new Path2D(), off = new Path2D(), i0 = th * 0.14, falls = [];
    const hs = (p, x0, x1, yy) => { p.moveTo(x0 + i0, yy); p.lineTo(x0 + i0 + th / 2, yy - th / 2); p.lineTo(x1 - i0 - th / 2, yy - th / 2); p.lineTo(x1 - i0, yy); p.lineTo(x1 - i0 - th / 2, yy + th / 2); p.lineTo(x0 + i0 + th / 2, yy + th / 2); p.closePath(); };
    const vs = (p, xx, y0, y1) => { p.moveTo(xx, y0 + i0); p.lineTo(xx + th / 2, y0 + i0 + th / 2); p.lineTo(xx + th / 2, y1 - i0 - th / 2); p.lineTo(xx, y1 - i0); p.lineTo(xx - th / 2, y1 - i0 - th / 2); p.lineTo(xx - th / 2, y0 + i0 + th / 2); p.closePath(); };
    for (const ch of chars) {
      if (ch === '.') { lit.rect(px, top + hgt - th, th, th); px += dotW; continue; }
      const m = SEG[ch];
      if (m == null) { falls.push([ch, px]); px += wOf(ch); continue; }
      const l = px + th / 2, rr = px + cw - th / 2, t0 = top + th / 2, mid = top + hgt / 2, b0 = top + hgt - th / 2;
      const segs = [(p) => hs(p, l, rr, t0), (p) => vs(p, rr, t0, mid), (p) => vs(p, rr, mid, b0), (p) => hs(p, l, rr, b0), (p) => vs(p, l, mid, b0), (p) => vs(p, l, t0, mid), (p) => hs(p, l, rr, mid)];
      segs.forEach((fn, i) => fn((m >> i) & 1 ? lit : off));
      px += cw + gap;
    }
    g.save(); g.transform(1, 0, -0.08, 1, 0.08 * y, 0);
    if (ghost) { g.fillStyle = rgba(col, ghost); g.fill(off); }
    g.fillStyle = col; g.shadowColor = col; g.shadowBlur = hgt * 0.25 * GK; g.fill(lit); g.restore();
    for (const [ch, fx] of falls) text(g, ch, fx, y, 500, hgt * 0.75, col, 'left');
  }
  // the big number on a gauge, in the face's (or the numerals option's) type
  function valText(g, s, x, y, px, col, wgt = 300) {
    const num = part('numerals');
    if (FACE === 'retro' && num === 'digital') return seg7(g, s, x, y, px * 0.74, col === T.red ? '#ff5a3c' : AMBER, 'center', 0.1);
    if (num === 'digital' || (FACE === 'carbon' && O.numerals === 'face')) return seg7(g, s, x, y, px * 0.74, col);
    if (FACE === 'tron' && O.numerals === 'face') { g.save(); g.shadowColor = T.accent; g.shadowBlur = px * 0.2 * GK; text(g, s, x, y, 300, px, col === T.red ? T.red : '#ffffff'); g.restore(); return; }
    if (FACE === 'lava') { g.save(); g.shadowColor = '#ff5a00'; g.shadowBlur = px * 0.2 * GK; text(g, s, x, y, num === 'thin' ? 200 : 500, px, col === T.red ? '#ff3b1a' : '#ffe6c4'); g.restore(); return; }
    if (FACE === 'synthwave' && O.numerals === 'face') {
      g.font = F('italic 800', px); g.textAlign = 'center'; g.textBaseline = 'middle';
      const gr = g.createLinearGradient(0, y - px * 0.4, 0, y + px * 0.4);
      gr.addColorStop(0, '#ffffff'); gr.addColorStop(0.48, '#ffd6f0'); gr.addColorStop(0.52, col === T.red ? T.red : SYN_M); gr.addColorStop(1, '#7a1fff');
      g.save(); g.shadowColor = SYN_C; g.shadowBlur = px * 0.18 * GK; g.fillStyle = gr; g.fillText(s, x, y); g.restore();
      return;
    }
    const w = num === 'thin' ? (FACE === 'minimal' ? 100 : 200) : O.numerals === 'bold' ? 650 : wgt;
    if (FACE === 'hologram') {
      const o = Math.max(1.2, px * 0.025) * (holoFlick() < 0.7 ? 3 : 1);
      g.globalCompositeOperation = 'lighter';
      text(g, s, x - o, y, w, px, 'rgba(255,0,90,.55)'); text(g, s, x + o, y, w, px, 'rgba(0,230,255,.55)');
      g.globalCompositeOperation = 'source-over';
      g.save(); g.shadowColor = T.accent; g.shadowBlur = px * 0.15 * GK; text(g, s, x, y, w, px, col === T.red ? T.red : mix(T.accent, '#ffffff', 0.6)); g.restore();
      return;
    }
    if (FACE === 'matrix') return text(g, s, x, y, 400, px, col === T.red ? T.red : '#8dffa8');
    if (FACE === 'glitch') {   // chromatic split that jumps when the dial glitches
      const o = Math.max(1.5, px * 0.03) * (frac(nowT * 0.37 + x * 0.0031) < 0.06 ? 4 : 1);
      text(g, s, x - o, y, 700, px, 'rgba(0,240,255,.7)'); text(g, s, x + o, y, 700, px, 'rgba(255,0,90,.6)');
      return text(g, s, x, y, 700, px, col === T.red ? T.red : '#fcee0a');
    }
    if ((FACE === 'jdm' || FACE === 'motorsport') && O.numerals === 'face') return text(g, s, x, y, 'italic 800', px, col);
    if (FACE === 'glass' || FACE === 'aurora' || FACE === 'particles') { g.save(); g.shadowColor = 'rgba(0,0,0,.7)'; g.shadowBlur = px * 0.12; text(g, s, x, y, w, px, col); g.restore(); return; }
    text(g, s, x, y, w, px, col);
  }
  // tach / speedo readout: under the hub, or big in the middle when there's no needle
  function readout(g, cx, cy, r, val, unit, col) {
    const center = part('needle') === 'none';
    const px = center ? r * (FACE === 'minimal' ? 0.52 : 0.42) : r * 0.26, vy = center ? cy - r * 0.02 : cy + r * 0.42, uy = center ? cy + r * 0.34 : cy + r * 0.62;
    if (FACE === 'luxe' && O.numerals === 'face') {   // a date window
      const sv = String(val), fw = r * 0.14; g.font = F(500, fw); const ww = g.measureText(sv).width + r * 0.08, wh = fw * 1.35, x0 = cx - ww / 2, y0 = cy + r * 0.4 - wh / 2;
      g.save(); g.beginPath(); g.roundRect ? g.roundRect(x0, y0, ww, wh, r * 0.015) : g.rect(x0, y0, ww, wh);
      g.fillStyle = '#f4efe2'; g.fill(); g.strokeStyle = '#c9a24a'; g.lineWidth = Math.max(1.5, r * 0.008); g.stroke(); g.restore();
      text(g, sv, cx, cy + r * 0.405, 500, fw, col === T.red ? '#b3261e' : '#1b1b1b');
      text(g, unit.toUpperCase(), cx, y0 + wh + r * 0.07, 400, r * 0.06, 'rgba(233,196,106,.85)');
      return;
    }
    if (FACE === 'carbon' && O.numerals === 'face') {   // recessed LCD window
      const ww = Math.max(r * 0.62, String(val).length * px * 0.58 + r * 0.12), wh = px * 1.05, x0 = cx - ww / 2, y0 = vy - wh / 2;
      g.save(); g.beginPath(); g.roundRect ? g.roundRect(x0, y0, ww, wh, r * 0.04) : g.rect(x0, y0, ww, wh);
      const wg = g.createLinearGradient(0, y0, 0, y0 + wh); wg.addColorStop(0, '#000'); wg.addColorStop(1, '#0d1013');
      g.fillStyle = wg; g.fill(); g.strokeStyle = 'rgba(255,255,255,.14)'; g.lineWidth = 1; g.stroke();
      g.clip(); g.strokeStyle = 'rgba(0,0,0,.9)'; g.lineWidth = r * 0.03; g.beginPath(); g.moveTo(x0, y0); g.lineTo(x0 + ww, y0); g.stroke(); g.restore();
      seg7(g, val, cx, vy, px * 0.7, col === T.text ? T.accent : col);
      text(g, unit.toUpperCase(), cx, y0 + wh + r * 0.08, 700, r * 0.075, T.sub);
      return;
    }
    let fpx = px;
    if (center) { g.font = F(200, px); const tw = g.measureText(String(val)).width; if (tw > r * 1.05) fpx = px * (r * 1.05) / tw; }
    valText(g, val, cx, vy, fpx, col);
    text(g, FACE === 'minimal' ? unit.toUpperCase() : unit, cx, uy, FACE === 'minimal' ? 400 : 500, r * (FACE === 'minimal' ? 0.075 : 0.1), T.sub);
  }
  // tick marks and their numbers (static: cached with the over layer)
  function ticks(g, cx, cy, r, labels, redFrom, small) {
    const st = part('ticks'), num = small ? 'none' : part('numerals'), n = labels.length - 1, f = FACE;
    const pal = f === 'synthwave' ? { maj: SYN_C, min: rgba(SYN_M, 0.7), lab: '#ffe9f7' }
      : f === 'hologram' ? { maj: T.accent, min: rgba(T.accent, 0.4), lab: rgba(mix(T.accent, '#ffffff', 0.5), 0.9) }
      : f === 'liquid' ? { maj: '#e6ebf0', min: 'rgba(230,235,240,.35)', lab: 'rgba(230,235,240,.8)' }
      : f === 'minimal' ? { maj: rgba(T.text, 0.7), min: rgba(T.text, 0.25), lab: rgba(T.text, 0.55) }
      : f === 'tron' ? { maj: T.accent, min: rgba(T.accent, 0.45), lab: '#ffffff' }
      : f === 'retro' ? { maj: AMBER, min: rgba(AMBER, 0.4), lab: AMBER }
      : f === 'luxe' ? { maj: '#e9c46a', min: 'rgba(233,196,106,.55)', lab: '#f3e3b5' }
      : f === 'lava' ? { maj: '#ffd9a0', min: 'rgba(255,160,80,.45)', lab: '#ffe2c0' }
      : f === 'blueprint' ? { maj: '#ffffff', min: 'rgba(255,255,255,.55)', lab: 'rgba(255,255,255,.9)' }
      : f === 'motorsport' ? { maj: '#111111', min: 'rgba(0,0,0,.55)', lab: '#111111' }
      : f === 'vintage' ? { maj: '#2a2118', min: 'rgba(42,33,24,.55)', lab: '#2a2118' }
      : f === 'ice' ? { maj: '#0b2236', min: 'rgba(11,34,54,.5)', lab: '#0b2236' }
      : f === 'f1' || f === 'aviation' ? { maj: '#f4f4f4', min: 'rgba(244,244,244,.55)', lab: '#f4f4f4' }
      : f === 'oled' || f === 'obsidian' || f === 'halo' || f === 'eclipse' || f === 'ion' ? { maj: rgba(T.text, 0.85), min: rgba(T.text, 0.3), lab: rgba(T.text, 0.62) }
      : f === 'filament' ? { maj: 'rgba(255,214,170,.8)', min: 'rgba(255,214,170,.28)', lab: 'rgba(255,224,190,.7)' }
      : f === 'matrix' ? { maj: '#3dff7a', min: 'rgba(61,255,122,.45)', lab: '#9dffb8' }
      : f === 'sapphire' ? { maj: '#e8f0ff', min: 'rgba(200,220,255,.5)', lab: '#eef4ff' }
      : f === 'sunset' ? { maj: '#fff4e0', min: 'rgba(255,240,220,.55)', lab: '#fff4e0' }
      : f === 'rosegold' ? { maj: '#f0b6a4', min: 'rgba(240,182,164,.5)', lab: '#f6cfc3' }
      : f === 'glitch' ? { maj: '#fcee0a', min: 'rgba(0,240,255,.55)', lab: '#eafcff' }
      : f === 'jdm' ? { maj: '#ff8c1a', min: 'rgba(255,255,255,.5)', lab: '#ffffff' }
      : { maj: T.text, min: 'rgba(255,255,255,.35)', lab: 'rgba(255,255,255,.75)' };
    const glow = f === 'synthwave' || f === 'hologram' || f === 'neon' || f === 'tron' || f === 'retro' || f === 'lava';
    if (st !== 'none') {
      const sub = st === 'bold' ? 2 : st === 'minimal' ? 1 : 5;
      for (let i = 0; i <= n * sub; i++) {
        const a = A0 + (SWEEP * i) / (n * sub), major = i % sub === 0, red = redFrom != null && i / (n * sub) >= redFrom - 1e-6;
        const cc = red ? T.red : major ? pal.maj : pal.min;
        if (glow) { g.shadowColor = cc; g.shadowBlur = r * 0.03 * GK; }
        if (st === 'minimal') {
          g.fillStyle = cc; circ(g, cx + r * 0.88 * Math.cos(a), cy + r * 0.88 * Math.sin(a), Math.max(1.5, r * 0.013)); g.fill(); continue;
        }
        const r1 = r - r * 0.1, r2 = r1 - (st === 'bold' ? (major ? r * 0.14 : r * 0.07) : (major ? r * 0.1 : r * 0.05));
        if (f === 'luxe' && major && !red) {   // applied gold index: bevelled baton
          const wd = Math.max(4, r * 0.035), ux = Math.cos(a), uy = Math.sin(a), px = -uy * wd / 2, py = ux * wd / 2;
          const q = [[cx + r1 * ux + px, cy + r1 * uy + py], [cx + r2 * ux + px, cy + r2 * uy + py], [cx + r2 * ux, cy + r2 * uy], [cx + r1 * ux, cy + r1 * uy]];
          const q2 = [[cx + r1 * ux - px, cy + r1 * uy - py], [cx + r2 * ux - px, cy + r2 * uy - py], [cx + r2 * ux, cy + r2 * uy], [cx + r1 * ux, cy + r1 * uy]];
          for (const [pp, c2] of [[q, '#fff0c0'], [q2, '#a87b25']]) { g.beginPath(); g.moveTo(...pp[0]); pp.slice(1).forEach((v) => g.lineTo(...v)); g.closePath(); g.fillStyle = c2; g.fill(); }
          continue;
        }
        g.strokeStyle = cc; g.lineCap = 'butt';
        g.lineWidth = st === 'bold' ? (major ? Math.max(3, r * 0.03) : Math.max(2, r * 0.013)) : (major ? Math.max(2, r * 0.018) : 1);
        g.beginPath(); g.moveTo(cx + r1 * Math.cos(a), cy + r1 * Math.sin(a)); g.lineTo(cx + r2 * Math.cos(a), cy + r2 * Math.sin(a)); g.stroke();
      }
      g.shadowBlur = 0;
    }
    if (num === 'none') return;
    const rr = r * (st === 'bold' ? 0.64 : st === 'minimal' || st === 'none' ? 0.74 : 0.7);
    labels.forEach((l, i) => {
      const a = A0 + (SWEEP * i) / n, x = cx + rr * Math.cos(a), y = cy + rr * Math.sin(a), red = redFrom != null && i / n >= redFrom - 1e-6;
      const cc = red ? T.red : pal.lab;
      if (num === 'digital') return seg7(g, l, x, y, r * 0.085, cc, 'center', 0);
      const wt = num === 'thin' ? (f === 'luxe' ? 'italic 400' : f === 'vintage' || f === 'rosegold' ? 400 : 300) : f === 'carbon' || f === 'synthwave' || f === 'jdm' || f === 'motorsport' ? 'italic 700' : 600;
      const px = r * (num === 'thin' ? (f === 'minimal' ? 0.09 : 0.125) : 0.12);
      if (f === 'hologram') { text(g, l, x - 1.2, y, wt, px, 'rgba(255,0,90,.45)'); text(g, l, x + 1.2, y, wt, px, 'rgba(0,230,255,.45)'); }
      if (glow) { g.shadowColor = cc; g.shadowBlur = r * 0.04 * GK; }
      text(g, l, x, y, wt, px, cc); g.shadowBlur = 0;
    });
  }
  const arcMode = (auto) => { const m = part('arc'); return m === 'auto' ? auto : m; };

  // a dial: a value from 0..1 on a 270 degree sweep, ticks and labels (the needle and readout are drawn by the gauge)
  function dial(g, cx, cy, r, opt) {
    const { f, labels, zones, col } = opt, tw = r * 0.075, nseg = opt.segs || 48;
    const mode = arcMode(opt.segs ? 'segments' : 'gradient');
    const key = `d|${cx | 0},${cy | 0},${r | 0}|${A0.toFixed(3)},${SWEEP.toFixed(3)}|${mode}|${nseg}|${(zones || []).map((z) => z.join()).join(';')}`;
    faceBack(g, cx, cy, r);
    layer(g, 't' + key, cx, cy, r * 1.15, (x) => {
      track(x, cx, cy, r, mode, tw, nseg);
      for (const [z0, z1, zc] of zones || []) arc(x, cx, cy, r + r * 0.07, A0 + SWEEP * z0, A0 + SWEEP * z1, r * 0.025, zc, 8, 'butt');
    });
    arcFill(g, cx, cy, r, f, tw, col, mode, nseg);
    const fl = FACE === 'hologram' ? holoFlick() : 1;
    g.globalAlpha = fl;
    layer(g, `o${key}|${labels.join(',')}|${opt.redFrom}|${part('ticks')}|${part('numerals')}`, cx, cy, r * 1.15, (x) => { ticks(x, cx, cy, r, labels, opt.redFrom); frontStatic(x, cx, cy, r); });
    g.globalAlpha = 1;
    frontDyn(g, cx, cy, r);
  }

  // ---------------------------------------------------------------- tall side arcs (cluster layout 'arcs')
  // A big circle whose centre sits near the screen edge; ~136 degrees of it sweep up the side of the bar. The map
  // between the two dials is masked by the same circles (CSS vars on #cmap), with a glowing edge drawn here.
  function arcGauge(g, w, h, t, o) {
    const left = ARC === 'left', th = rad(68), R = Math.max(20, Math.min((h * 0.44) / Math.sin(th), w / 1.22)), cy = h / 2;
    const cx = left ? w - R * 1.16 - w * 0.015 : R * 1.16 + w * 0.015, Rm = R * 1.13;
    A0 = left ? th : Math.PI - th; SWEEP = left ? -2 * th : 2 * th;
    layer(g, `edge|${cx | 0},${cy | 0},${Rm | 0}`, cx, cy, Rm * 1.05, (x) => {   // the map's curved border
      x.strokeStyle = rgba(T.accent, 0.12 * Math.min(1.6, GK)); x.lineWidth = Math.max(8, R * 0.06); circ(x, cx, cy, Rm); x.stroke();
      x.save(); x.shadowColor = T.accent; x.shadowBlur = R * 0.05 * GK; x.strokeStyle = rgba(T.accent, 0.9); x.lineWidth = Math.max(1.5, R * 0.006); circ(x, cx, cy, Rm); x.stroke(); x.restore();
    });
    if (o.hot) { const gl = g.createRadialGradient(cx, cy, R * 0.3, cx, cy, R * 1.15); gl.addColorStop(0, `rgba(255,60,60,${0.22 * pulse(t, 14) * Math.min(1.5, GK)})`); gl.addColorStop(1, 'rgba(255,60,60,0)'); g.fillStyle = gl; circ(g, cx, cy, R * 1.12); g.fill(); }
    dial(g, cx, cy, R, o);
    needle(g, cx, cy, R * 0.86, A0 + SWEEP * o.f, o.ncol, Math.max(3, R * 0.026));
    const rx = cx + (left ? 1 : -1) * R * 0.4, px = R * 0.21;
    g.font = F(300, px); const tw = g.measureText(String(o.val)).width;
    valText(g, o.val, rx, cy - R * 0.06, tw > R * 0.42 ? px * (R * 0.42) / tw : px, o.vcol);
    fit(g, o.unit, rx, cy + R * 0.12, R * 0.5, 600, R * 0.07, T.sub);
    if (o.note) fit(g, o.note, rx, cy + R * 0.22, R * 0.5, 500, R * 0.055, T.sub);
    arcMask(cx, cy, Rm);
  }
  function arcMask(cx, cy, Rm) {
    const c = CUR, main = c && c.closest && c.closest('.L-arcs'), map = main && main.querySelector('#cmap');
    if (!map) return;
    const cr = huBox(c), mr = huBox(map), sx = mr.width / (map.offsetWidth || 1) || 1, sy = mr.height / (map.offsetHeight || 1) || 1;
    const side = ARC === 'left' ? 'L' : 'R', x = (cr.left - mr.left) / sx + cx, y = (cr.top - mr.top) / sy + cy, v = `${x.toFixed(1)}|${y.toFixed(1)}|${Rm.toFixed(1)}`;
    if (map.dataset['arc' + side] === v) return;
    map.dataset['arc' + side] = v;
    map.style.setProperty(`--ax${side}`, `${x.toFixed(1)}px`); map.style.setProperty(`--ay${side}`, `${y.toFixed(1)}px`); map.style.setProperty(`--ar${side}`, `${Rm.toFixed(1)}px`);
  }

  // ---------------------------------------------------------------- wide, short tiles
  // A round dial in a wide, short tile is a tiny circle with empty glass either side. There every gauge
  // becomes a readout instead: a big number filling the height, its name, and a bar that fills the width.
  const isWide = (w, h) => w / h >= 1.8;
  function wide(g, w, h, t, o) {
    const p = clamp(h * 0.14, 6, 16), mid = h / 2;
    const col = o.col || T.text;
    // the number fills the height, but never takes more than about half the width (the bar needs room)
    let big = h * 0.62;
    const measure = () => {
      g.font = F(300, big); const vw = g.measureText(o.val).width;
      g.font = F(500, big * 0.3); const uw = o.unit ? g.measureText(o.unit).width + big * 0.1 : 0;
      return [vw, uw];
    };
    let [vw, uw] = measure();
    const room = w * 0.46 - p;
    if (vw + uw > room) { big *= room / (vw + uw); [vw, uw] = measure(); }
    const vy = mid + big * 0.04;
    text(g, o.val, p, vy, 300, big, col, 'left');
    if (o.unit) text(g, o.unit, p + vw + big * 0.08, vy + big * 0.2, 500, big * 0.3, T.sub, 'left');
    const bx = p + vw + uw + Math.max(p, w * 0.04), bw = Math.max(10, w - bx - p - 2);
    const fs = clamp(h * 0.16, 10, 18), bh = clamp(h * 0.13, 5, 14);
    const showNote = o.note && h > 44;
    const by = mid - bh / 2 + (showNote ? 0 : fs * 0.35);
    text(g, o.name, bx, by - fs * 0.85, 650, fs, T.sub, 'left');
    const rr = bh / 2, f = clamp(o.f || 0, 0, 1);
    const bar = (x, w2, c) => { g.beginPath(); g.roundRect ? g.roundRect(x, by, w2, bh, rr) : g.rect(x, by, w2, bh); g.fillStyle = c; g.fill(); };
    bar(bx, bw, T.faint);
    for (const [z0, z1, zc] of o.zones || []) {   // thin colored zones under the bar (redline, C/H bands)
      g.fillStyle = zc; g.fillRect(bx + bw * z0, by + bh + 3, bw * (z1 - z0), Math.max(2, bh * 0.25));
    }
    if (o.segs) {
      const n = o.segs, gap = Math.max(1.5, (bw / n) * 0.28), sw = bw / n - gap;
      for (let i = 0; i < n; i++) {
        const v = (i + 1) / n, on = v <= f + 1e-6, c = typeof o.segCol === 'function' ? o.segCol(v) : col;
        g.fillStyle = on ? c : 'rgba(255,255,255,.07)';
        if (on) { g.shadowColor = c; g.shadowBlur = bh * 0.8; }
        g.fillRect(bx + i * (sw + gap), by, sw, bh); g.shadowBlur = 0;
      }
    } else if (o.has) {
      const fc = o.barCol || col, gr = g.createLinearGradient(bx, 0, bx + bw, 0);
      gr.addColorStop(0, o.barCol ? fc : T.b3); gr.addColorStop(1, fc);
      g.save(); g.shadowColor = fc; g.shadowBlur = bh; bar(bx, Math.max(bh, bw * f), gr); g.restore();
      if (o.dot) { g.fillStyle = '#fff'; g.shadowColor = fc; g.shadowBlur = bh; g.beginPath(); g.arc(bx + Math.max(bh / 2, bw * f - bh / 2), by + bh / 2, bh * 0.75, 0, TAU); g.fill(); g.shadowBlur = 0; }
    }
    if (showNote) {
      g.save(); g.beginPath(); g.rect(bx, 0, w - bx - p * 0.5, h); g.clip();   // long notes fade off the edge, never over it
      text(g, o.note, bx, by + bh + (o.zones ? 5 : 2) + fs * 0.75, 600, fs * 0.9, o.noteCol || T.sub, 'left');
      g.restore();
    }
  }

  // ---------------------------------------------------------------- the gauges
  function fuelLeft(fuel, short) {
    const tank = (settings().tank || 185) / 10;
    if (trip.mpgAvg && trip.mpgN > 90) {
      const miles = (fuel / 100) * tank * trip.mpgAvg;
      if (short) return metric() ? `${Math.round(miles * 1.609)} km left` : `${Math.round(miles)} mi left`;
      return metric() ? `about ${Math.round(miles * 1.609)} km left` : `about ${Math.round(miles)} miles left`;
    }
    return short ? `${((fuel / 100) * tank).toFixed(1)} gal` : `about ${((fuel / 100) * tank).toFixed(1)} gallons`;
  }
  const G = {
    tach(g, w, h, t) {
      if (face() === 'real' && !isWide(w, h) && !ARC) return realBig(g, w, h, 'tach');
      const RL = O.redline, maxK = Math.max(7, Math.floor(RL / 1000) + 1), MAX = maxK * 1000;
      const rpm = sm.rpm, f = rpm == null ? 0 : clamp(rpm / MAX, 0, 1.02), red = RL / MAX;
      const hot = rpm != null && rpm > RL;
      const segCol = (v) => (v > red ? T.red : v > red - 0.14 ? T.amber : T.accent);
      if (ARC) return arcGauge(g, w, h, t, { f, labels: [...Array(maxK + 1)].map((_, i) => String(i)), redFrom: red, segs: maxK * 6, col: segCol,
        zones: [[red, 1, 'rgba(255,77,77,.8)']], ncol: hot ? T.red : T.amber, val: rpm == null ? '--' : String(Math.round(rpm / 10) * 10), unit: 'rpm', vcol: hot ? T.red : T.text, hot });
      if (isWide(w, h)) return wide(g, w, h, t, { name: 'Tachometer', val: rpm == null ? '--' : String(Math.round(rpm / 10) * 10), unit: 'rpm',
        f, segs: Math.max(12, Math.round(w / 9)), segCol, col: hot ? T.red : T.text, zones: [[red, 1, 'rgba(255,77,77,.85)']],
        note: rpm == null ? 'No OBD adapter' : '' });
      const r = Math.min(w * 0.455, h * 0.54), cx = w / 2, cy = h / 2 + r * 0.17;
      if (hot) { const gl = g.createRadialGradient(cx, cy, r * 0.3, cx, cy, r * 1.3); gl.addColorStop(0, `rgba(255,60,60,${0.25 * pulse(t, 14) * Math.min(1.5, GK)})`); gl.addColorStop(1, 'rgba(255,60,60,0)'); g.fillStyle = gl; g.fillRect(0, 0, w, h); }
      dial(g, cx, cy, r, { f, labels: [...Array(maxK + 1)].map((_, i) => String(i)), redFrom: red, segs: maxK * 8,
        col: segCol, zones: [[red, 1, 'rgba(255,77,77,.8)']] });
      needle(g, cx, cy, r * 0.82, A0 + SWEEP * f, hot ? T.red : T.amber, Math.max(3, r * 0.03));
      readout(g, cx, cy, r, rpm == null ? '--' : String(Math.round(rpm / 10) * 10), 'rpm', hot ? T.red : T.text);
      if (rpm == null) noData(g, cx, cy - r * 0.38, r * 2, 'No OBD adapter');
    },
    speed(g, w, h, t) {
      if (face() === 'real' && !isWide(w, h) && !ARC) return realBig(g, w, h, 'speed');
      const km = metric();
      const v = sm.kmh == null ? null : km ? sm.kmh : sm.kmh * 0.621371, max = km ? 220 : 140;
      if (ARC) return arcGauge(g, w, h, t, { f: v == null ? 0 : clamp(v / max, 0, 1), labels: (km ? [0, 40, 80, 120, 160, 200, 220] : [0, 20, 40, 60, 80, 100, 120, 140]).map(String),
        col: T.accent, ncol: T.accent, val: v == null ? '--' : String(Math.round(v)), unit: km ? 'km/h' : 'mph', vcol: T.text });
      if (isWide(w, h)) return wide(g, w, h, t, { name: 'Speed', val: v == null ? '--' : String(Math.round(v)), unit: km ? 'km/h' : 'mph',
        f: v == null ? 0 : v / max, has: v != null, barCol: T.accent, dot: true });
      const r = Math.min(w * 0.455, h * 0.54), cx = w / 2, cy = h / 2 + r * 0.17;
      const f = v == null ? 0 : clamp(v / max, 0, 1);
      dial(g, cx, cy, r, { f, labels: (km ? [0, 40, 80, 120, 160, 200, 220] : [0, 20, 40, 60, 80, 100, 120, 140]).map(String), col: T.accent });
      needle(g, cx, cy, r * 0.82, A0 + SWEEP * f, T.accent, Math.max(3, r * 0.03));
      readout(g, cx, cy, r, v == null ? '--' : String(Math.round(v)), km ? 'km/h' : 'mph', T.text);
    },
    fuel(g, w, h, t) {
      if (face() === 'real' && !isWide(w, h)) { const r = Math.min(w * 0.36, h * 0.5); return realMini(g, w / 2, h * 0.62, r, fuelF(), 'E', 'F', 'FUEL', true, false); }
      const fuel = sm.fuel, low = fuel != null && fuel < 15, lowish = fuel != null && fuel < 25;
      if (isWide(w, h) && h < 150) {
        const c = low ? T.red : lowish ? T.amber : T.accent;
        return wide(g, w, h, t, { name: 'Fuel', val: fuel == null ? '--' : `${Math.round(fuel)}%`, f: (fuel || 0) / 100, has: fuel != null,
          barCol: c, col: low ? T.red : T.text, zones: [[0, 0.15, 'rgba(255,77,77,.8)']],
          note: fuel == null ? 'No OBD adapter' : low ? 'Low fuel' : fuelLeft(fuel, true), noteCol: low ? `rgba(255,77,77,${0.55 + 0.45 * pulse(t, 5)})` : T.sub });
      }
      // the tank: a rounded capsule, liquid inside sloshing with acceleration
      // tank on the left and the readout beside it, unless that leaves too little room for the words:
      // then the tank goes on top and the readout underneath
      const tall = w - (w * 0.12 + Math.min(w * 0.42, h * 0.5) + Math.max(w * 0.13, 56)) < 170;
      const tw = tall ? Math.min(w * 0.46, h * 0.36) : Math.min(w * 0.42, h * 0.56), th = tall ? h * 0.6 : h * 0.8;
      const tx = tall ? (w - tw) / 2 - w * 0.07 : w * 0.1, ty = tall ? h * 0.07 : (h - th) / 2 + h * 0.03, rr = tw * 0.32;
      const path = () => { g.beginPath(); g.moveTo(tx + rr, ty); g.arcTo(tx + tw, ty, tx + tw, ty + th, rr); g.arcTo(tx + tw, ty + th, tx, ty + th, rr); g.arcTo(tx, ty + th, tx, ty, rr); g.arcTo(tx, ty, tx + tw, ty, rr); g.closePath(); };
      path(); g.fillStyle = 'rgba(0,0,0,.25)'; g.fill();
      if (fuel != null) {
        g.save(); path(); g.clip();
        const lvl = ty + th - (th * clamp(fuel, 0, 100)) / 100, tilt = clamp(-trip.accel / 60, -0.25, 0.25);
        const c1 = low ? T.red : lowish ? T.amber : T.accent, c2 = low ? '#7a1010' : lowish ? '#7a4a05' : T.b2;
        const gr = g.createLinearGradient(0, lvl, 0, ty + th); gr.addColorStop(0, c1); gr.addColorStop(1, c2);
        g.beginPath(); g.moveTo(tx - 2, ty + th + 2);
        for (let x = 0; x <= tw + 4; x += 4) g.lineTo(tx + x - 2, lvl + tilt * (x - tw / 2) + Math.sin(t * 2.4 + x * 0.06) * tw * 0.02 + Math.sin(t * 3.7 - x * 0.04) * tw * 0.012);
        g.lineTo(tx + tw + 2, ty + th + 2); g.closePath();
        g.fillStyle = gr; g.shadowColor = c1; g.shadowBlur = low ? 20 + 20 * pulse(t, 5) : 16; g.fill(); g.shadowBlur = 0;
        g.strokeStyle = 'rgba(255,255,255,.55)'; g.lineWidth = 2; g.stroke();
        for (let i = 0; i < 6; i++) {  // bubbles
          const by = ty + th - ((t * (14 + i * 5) + i * 31) % Math.max(10, ty + th - lvl));
          if (by > lvl + 6) { g.strokeStyle = 'rgba(255,255,255,.5)'; g.lineWidth = 1; g.beginPath(); g.arc(tx + tw * (0.2 + (i * 0.13) % 0.6), by, 1.5 + (i % 3), 0, TAU); g.stroke(); }
        }
        g.restore();
      }
      path(); g.strokeStyle = 'rgba(255,255,255,.28)'; g.lineWidth = 2; g.stroke();
      const sh = g.createLinearGradient(tx, 0, tx + tw, 0); sh.addColorStop(0, 'rgba(255,255,255,.14)'); sh.addColorStop(0.3, 'rgba(255,255,255,0)');
      path(); g.fillStyle = sh; g.fill();
      // E . 1/4 . 1/2 . 3/4 . F marks
      ['E', '¼', '½', '¾', 'F'].forEach((l, i) => {
        const y = ty + th - (th * i) / 4;
        g.strokeStyle = 'rgba(255,255,255,.4)'; g.lineWidth = 2; g.beginPath(); g.moveTo(tx + tw + 6, y); g.lineTo(tx + tw + 16, y); g.stroke();
        text(g, l, tx + tw + 30, y, 600, Math.max(12, h * 0.05), i === 0 ? T.red : T.sub);
      });
      // readout
      const al = tall ? 'center' : 'left', rx = tall ? w / 2 : tx + tw + Math.max(w * 0.13, 56);
      const big = tall ? Math.min(w * 0.26, h * 0.13) : Math.min((w - rx) * 0.4, h * 0.28), small = Math.max(12, Math.min(h * 0.05, w * 0.05));
      const y1 = tall ? ty + th + big * 0.85 : h / 2 - h * 0.1, y2 = y1 + big * 0.62 + small * 0.4, y3 = y2 + small * 1.45;
      text(g, fuel == null ? '--' : `${Math.round(fuel)}%`, rx, y1, 200, big, low ? T.red : T.text, al);
      const sub = fuel == null ? 'Fuel' : fuelLeft(fuel);
      text(g, sub, rx, y2, 500, small, T.sub, al);
      if (low) text(g, 'Low fuel', rx, y3, 700, small * 1.1, `rgba(255,77,77,${0.55 + 0.45 * pulse(t, 5)})`, al);
      if (fuel == null) text(g, 'No OBD adapter', rx, y3, 500, small, T.sub, al);
    },
    coolant(g, w, h, t) {
      if (face() === 'real' && !isWide(w, h)) { const r = Math.min(w * 0.36, h * 0.5); return realMini(g, w / 2, h * 0.62, r, tempFrac(), 'C', 'H', 'TEMP', false, true); }
      const c = sm.coolant, f = c == null ? null : c * 9 / 5 + 32;   // zones are worked out in °F
      const lo = 100, hi = 260, k = f == null ? 0 : clamp((f - lo) / (hi - lo), 0, 1);
      const state = f == null ? null : f < 160 ? 'cold' : f < 225 ? 'ok' : f < 240 ? 'warm' : 'hot';
      const zc = { cold: T.blue, ok: T.green, warm: T.amber, hot: T.red };
      // colored band C ... H
      const bands = [[0, (160 - lo) / (hi - lo), T.blue], [(160 - lo) / (hi - lo), (225 - lo) / (hi - lo), T.green], [(225 - lo) / (hi - lo), (240 - lo) / (hi - lo), T.amber], [(240 - lo) / (hi - lo), 1, T.red]];
      const shown = c == null ? '--' : tempF() ? `${Math.round(f)}°` : `${Math.round(c)}°`;
      const msg = { cold: 'Warming up', ok: 'Normal', warm: 'Running warm', hot: 'Overheating! Pull over' }[state] || 'No OBD adapter';
      const msgCol = state === 'hot' ? `rgba(255,77,77,${0.6 + 0.4 * pulse(t, 6)})` : state ? zc[state] : T.sub;
      if (isWide(w, h)) return wide(g, w, h, t, { name: 'Coolant', val: shown, f: k, has: f != null, barCol: state ? zc[state] : T.sub, dot: true,
        col: state === 'hot' ? T.red : T.text, zones: bands.map(([a, b, col]) => [a, b, col + '99']), note: msg, noteCol: msgCol });
      const r = Math.min(w * 0.45, h * 0.48), cx = w / 2, cy = h / 2 + r * 0.12;
      const a0 = rad(160), sw = rad(220);
      faceBack(g, cx, cy, r * 0.92, true);
      arc(g, cx, cy, r, a0, a0 + sw, r * 0.12, T.faint);
      for (const [z0, z1, col] of bands) arc(g, cx, cy, r, a0 + sw * z0, a0 + sw * z1, r * 0.12, col.replace(')', ',.35)').replace('rgb(', 'rgba(').startsWith('#') ? col + '55' : col, 0, 'butt');
      if (f != null) {
        const col = zc[state];
        arc(g, cx, cy, r, a0, a0 + sw * k, r * 0.12, col, state === 'hot' ? 18 + 18 * pulse(t, 6) : 14, 'butt');
        const a = a0 + sw * k;
        g.fillStyle = '#fff'; g.shadowColor = col; g.shadowBlur = 16 * GK;
        g.beginPath(); g.arc(cx + r * Math.cos(a), cy + r * Math.sin(a), r * 0.085, 0, TAU); g.fill(); g.shadowBlur = 0;
      }
      text(g, 'C', cx + (r + r * 0.18) * Math.cos(a0), cy + (r + r * 0.18) * Math.sin(a0), 700, r * 0.13, T.blue);
      text(g, 'H', cx + (r + r * 0.18) * Math.cos(a0 + sw), cy + (r + r * 0.18) * Math.sin(a0 + sw), 700, r * 0.13, T.red);
      // thermometer icon
      g.save(); g.translate(cx, cy - r * 0.58); const s = r * 0.0048;
      g.strokeStyle = f == null ? T.sub : zc[state]; g.lineWidth = 2.5; g.lineCap = 'round';
      g.beginPath(); g.arc(0, 18 * s * 2, 7 * s * 2, 0, TAU); g.moveTo(-3.5 * s * 2, 13 * s * 2); g.lineTo(-3.5 * s * 2, -16 * s * 2); g.arc(0, -16 * s * 2, 3.5 * s * 2, Math.PI, 0); g.lineTo(3.5 * s * 2, 13 * s * 2); g.stroke();
      g.restore();
      text(g, shown, cx, cy + r * 0.05, 200, r * 0.42, state === 'hot' ? T.red : T.text);
      text(g, msg, cx, cy + r * 0.42, 600, r * 0.12, msgCol);
      text(g, 'Coolant', cx, cy + r * 0.62, 500, r * 0.1, T.sub);
    },
    // ---- smaller arcs: battery, fuel economy, intake air, engine load, throttle
    volts(g, w, h, t) { small(g, w, h, t, sm.volts, 10, 16, (v) => `${v.toFixed(1)} V`, 'Battery', (v) => (v < 11.8 ? T.red : v < 12.6 ? T.amber : v > 15.2 ? T.red : T.green), (v) => (v >= 13.2 ? 'Charging' : v >= 12.4 ? 'Engine off' : 'Low')); },
    mpg(g, w, h, t) { small(g, w, h, t, sm.mpg, 0, 50, (v) => (metric() ? (v > 0.5 ? `${(235.2 / v).toFixed(1)}` : '--') : v.toFixed(0)), metric() ? 'L/100 km' : 'mpg now', () => T.accent, () => (trip.mpgAvg && trip.mpgN > 30 ? `Trip ${metric() ? (235.2 / trip.mpgAvg).toFixed(1) : trip.mpgAvg.toFixed(1)}` : '')); },
    intake(g, w, h, t) { small(g, w, h, t, sm.intake, -20, 80, (v) => (tempF() ? `${Math.round(v * 9 / 5 + 32)}°` : `${Math.round(v)}°`), 'Intake air', () => T.b3); },
    load(g, w, h, t) { small(g, w, h, t, sm.load, 0, 100, (v) => `${Math.round(v)}%`, 'Engine load', (v) => (v > 85 ? T.amber : T.accent)); },
    throttle(g, w, h, t) { small(g, w, h, t, sm.throttle, 0, 100, (v) => `${Math.round(v)}%`, 'Throttle', () => T.accent); },
    // ---- more: oil, outside, boost, power, g-force, 0-60, fuel flow, range, clock, rev lights, this drive's peaks
    oil(g, w, h, t) { small(g, w, h, t, sm.oil, 20, 150, fmtTemp, 'Oil temp', (v) => (v < 60 ? T.blue : v < 120 ? T.green : v < 130 ? T.amber : T.red), (v) => (v < 60 ? 'Warming up' : v < 120 ? 'Normal' : v < 130 ? 'Hot' : 'Too hot!')); },
    ambient(g, w, h, t) {
      if (sm.ambient == null && sm.wxTemp != null) return small(g, w, h, t, sm.wxTemp, tempF() ? -10 : -25, tempF() ? 110 : 45, (v) => `${Math.round(v)}°`, 'Outside', () => T.b3, () => 'From the weather');
      small(g, w, h, t, sm.ambient, -25, 45, fmtTemp, 'Outside', (v) => (v < 1 ? T.blue : T.b3), (v) => (v < 3 ? 'Ice possible' : ''));
    },
    boost(g, w, h, t) {   // manifold pressure vs the air outside: vacuum when cruising, boost on a turbo
      const psi = sm.map == null ? null : (sm.map - 101.3) * 0.145038;
      small(g, w, h, t, psi, -15, 15, (v) => `${v > 0 ? '+' : ''}${v.toFixed(1)}`, psi != null && psi > 0 ? 'Boost psi' : 'Vacuum psi', (v) => (v > 0 ? T.amber : T.accent), (v) => (v < -12 ? 'Coasting' : v < -6 ? 'Cruising' : v < 0 ? 'Pulling' : 'Boost!'));
    },
    power(g, w, h, t) {   // rough horsepower from the air the engine is breathing (about 1.3 hp per g/s)
      small(g, w, h, t, sm.maf == null ? null : sm.maf * 1.32, 0, 200, (v) => `${Math.round(v)}`, 'Horsepower (est.)', (v) => (v > 140 ? T.red : v > 90 ? T.amber : T.accent));
    },
    gforce(g, w, h, t) {
      const gs = trip.accel / 35.3, has = sm.kmh != null;   // km/h per second -> g
      trip.gMax = Math.max(trip.gMax || 0, has ? gs : 0); trip.gMin = Math.min(trip.gMin || 0, has ? gs : 0);
      const col = gs < -0.05 ? T.red : gs > 0.05 ? T.green : T.accent;
      if (isWide(w, h)) return wide(g, w, h, t, { name: 'G-force', val: has ? `${gs >= 0 ? '+' : ''}${gs.toFixed(2)}` : '--', unit: 'g', f: 0.5 + clamp(gs, -1, 1) / 2, has, barCol: col, dot: true,
        note: has ? `Best +${(trip.gMax || 0).toFixed(2)} / ${(trip.gMin || 0).toFixed(2)} g` : 'No speed yet' });
      const r = Math.min(w, h) * 0.4, cx = w / 2, cy = h / 2;
      [1, 0.66, 0.33].forEach((k) => { g.strokeStyle = 'rgba(255,255,255,.12)'; g.lineWidth = 1.5; g.beginPath(); g.arc(cx, cy, r * k, 0, TAU); g.stroke(); });
      g.beginPath(); g.moveTo(cx - r, cy); g.lineTo(cx + r, cy); g.moveTo(cx, cy - r); g.lineTo(cx, cy + r); g.stroke();
      const py = cy - clamp(gs, -1, 1) * r;   // forward = up
      g.fillStyle = col; g.shadowColor = col; g.shadowBlur = r * 0.2 * GK; g.beginPath(); g.arc(cx, py, r * 0.09, 0, TAU); g.fill(); g.shadowBlur = 0;
      text(g, has ? `${gs >= 0 ? '+' : ''}${gs.toFixed(2)} g` : '--', cx, cy + r * 1.12, 300, r * 0.2, T.text);
      text(g, 'G-force', cx, cy - r * 1.12, 600, r * 0.12, T.sub);
    },
    zero60(g, w, h, t) {
      const run = trip.z0 != null ? (performance.now() - trip.z0) / 1000 : null, lab = metric() ? '0-100 km/h' : '0-60 mph';
      const shown = run != null ? run : trip.zLast;
      const note = run != null ? 'Go go go!' : trip.zBest ? `Best ${trip.zBest.toFixed(1)} s` : 'Starts when you pull away from a stop';
      if (isWide(w, h)) return wide(g, w, h, t, { name: lab, val: shown == null ? '--' : shown.toFixed(1), unit: 's', f: shown == null ? 0 : clamp(shown / 15, 0, 1), has: shown != null, barCol: run != null ? T.amber : T.accent, note });
      const r = Math.min(w * 0.43, h * 0.46), cx = w / 2, cy = h / 2 + r * 0.1;
      arc(g, cx, cy, r, A0, A0 + SWEEP, r * 0.1, T.faint);
      if (shown != null) arc(g, cx, cy, r, A0, A0 + SWEEP * clamp(shown / 15, 0.004, 1), r * 0.1, run != null ? T.amber : T.accent, 16);
      text(g, shown == null ? '--' : `${shown.toFixed(1)}`, cx, cy, 200, r * 0.48, run != null ? T.amber : T.text);
      text(g, `${lab}, seconds`, cx, cy + r * 0.45, 600, r * 0.12, T.sub);
      text(g, note, cx, cy + r * 0.7, 500, r * 0.11, T.sub);
    },
    flow(g, w, h, t) {
      const lph = sm.maf == null ? null : sm.maf * 0.3323;
      small(g, w, h, t, lph == null ? null : metric() ? lph : lph * 0.264172, 0, metric() ? 40 : 10, (v) => v.toFixed(metric() ? 1 : 2), metric() ? 'Fuel L/hour' : 'Fuel gal/hour', (v) => (v > (metric() ? 25 : 6.5) ? T.amber : T.accent));
    },
    range(g, w, h, t) {
      const fuel = sm.fuel, tank = (settings().tank || 185) / 10, mpg = trip.mpgAvg && trip.mpgN > 90 ? trip.mpgAvg : 24;
      const mi = fuel == null ? null : (fuel / 100) * tank * mpg, v = mi == null ? null : metric() ? mi * 1.609 : mi;
      small(g, w, h, t, v, 0, metric() ? 800 : 500, (x) => `${Math.round(x)}`, metric() ? 'km to empty' : 'Miles to empty', (x) => (x < (metric() ? 80 : 50) ? T.red : x < (metric() ? 160 : 100) ? T.amber : T.green), () => (trip.mpgAvg && trip.mpgN > 90 ? 'From this drive’s mpg' : 'Estimate'));
    },
    clock(g, w, h, t) {
      const d = new Date(), r = Math.min(w, h) * 0.42, cx = w / 2, cy = h / 2;
      g.fillStyle = 'rgba(0,0,0,.2)'; g.beginPath(); g.arc(cx, cy, r, 0, TAU); g.fill();
      for (let i = 0; i < 60; i++) {
        const a = (i / 60) * TAU, big = i % 5 === 0, r2 = r * (big ? 0.84 : 0.91);
        g.strokeStyle = big ? T.text : 'rgba(255,255,255,.3)'; g.lineWidth = big ? Math.max(2, r * 0.025) : 1;
        g.beginPath(); g.moveTo(cx + r * 0.97 * Math.sin(a), cy - r * 0.97 * Math.cos(a)); g.lineTo(cx + r2 * Math.sin(a), cy - r2 * Math.cos(a)); g.stroke();
      }
      const sec = d.getSeconds() + d.getMilliseconds() / 1000, min = d.getMinutes() + sec / 60, hr = (d.getHours() % 12) + min / 60;
      const hand = (a, len, wd, col) => { g.strokeStyle = col; g.lineWidth = wd; g.lineCap = 'round'; g.beginPath(); g.moveTo(cx, cy); g.lineTo(cx + len * Math.sin(a), cy - len * Math.cos(a)); g.stroke(); };
      hand((hr / 12) * TAU, r * 0.5, Math.max(4, r * 0.06), T.text);
      hand((min / 60) * TAU, r * 0.74, Math.max(3, r * 0.04), T.text);
      g.shadowColor = T.accent; g.shadowBlur = 8 * GK; hand((sec / 60) * TAU, r * 0.8, Math.max(1.5, r * 0.015), T.accent); g.shadowBlur = 0;
      g.fillStyle = T.accent; g.beginPath(); g.arc(cx, cy, r * 0.05, 0, TAU); g.fill();
    },
    revleds(g, w, h, t) {   // a race-car shift light: LEDs fill green, amber, red, then all flash at the shift point
      const rpm = sm.rpm, shift = (settings().cluster || {}).shift || O.redline, lo = Math.max(1000, shift - 3500);
      const n = isWide(w, h) ? 15 : 12, f = rpm == null ? 0 : clamp((rpm - lo) / (shift - lo), 0, 1), flash = rpm != null && rpm >= shift;
      const on = flash ? (Math.floor(t * 10) % 2 === 0 ? n : 0) : Math.round(f * n);
      const colOf = (i) => (flash ? '#4FA3FF' : i < n * 0.5 ? T.green : i < n * 0.8 ? T.amber : T.red);
      const wideMode = isWide(w, h);
      const rr = wideMode ? Math.min(h * 0.28, (w / n) * 0.36) : Math.min(w, h) * 0.05;
      for (let i = 0; i < n; i++) {
        let x, y;
        if (wideMode) { x = w * 0.06 + ((w * 0.88) / (n - 1)) * i; y = h * 0.42; }
        else { const a = A0 + (SWEEP * i) / (n - 1), R = Math.min(w, h) * 0.38; x = w / 2 + R * Math.cos(a); y = h / 2 + R * Math.sin(a) + R * 0.1; }
        const c = colOf(i), lit = i < on;
        g.fillStyle = lit ? c : 'rgba(255,255,255,.07)';
        if (lit) { g.shadowColor = c; g.shadowBlur = rr * 1.6; }
        g.beginPath(); g.arc(x, y, rr, 0, TAU); g.fill(); g.shadowBlur = 0;
      }
      const label = rpm == null ? noVal() : `${Math.round(rpm / 10) * 10} rpm`;
      if (wideMode) text(g, label, w / 2, h * 0.82, 600, clamp(h * 0.16, 10, 22), flash ? '#4FA3FF' : T.sub);
      else { text(g, rpm == null ? '--' : String(Math.round(rpm / 10) * 10), w / 2, h / 2 + Math.min(w, h) * 0.05, 300, Math.min(w, h) * 0.16, flash ? '#4FA3FF' : T.text); text(g, flash ? 'SHIFT' : 'Shift light', w / 2, h / 2 + Math.min(w, h) * 0.2, 700, Math.min(w, h) * 0.06, flash ? '#4FA3FF' : T.sub); }
    },
    peak(g, w, h, t) {
      const km = metric(), top = trip.maxKmh ? (km ? trip.maxKmh : trip.maxKmh * 0.621371) : null, rpm = trip.maxRpm || null;
      if (isWide(w, h)) return wide(g, w, h, t, { name: 'This drive’s peaks', val: top == null ? '--' : String(Math.round(top)), unit: km ? 'km/h' : 'mph', f: top == null ? 0 : top / (km ? 220 : 140), has: top != null, barCol: T.accent, note: rpm ? `Highest rpm ${Math.round(rpm / 10) * 10}` : '' });
      const m = Math.min(w, h), cx = w / 2;
      text(g, 'Top speed', cx, h * 0.2, 600, m * 0.07, T.sub);
      text(g, top == null ? '--' : String(Math.round(top)), cx, h * 0.38, 200, m * 0.22, T.text);
      text(g, km ? 'km/h' : 'mph', cx, h * 0.52, 500, m * 0.06, T.sub);
      text(g, 'Highest rpm', cx, h * 0.66, 600, m * 0.07, T.sub);
      text(g, rpm ? String(Math.round(rpm / 10) * 10) : '--', cx, h * 0.8, 300, m * 0.13, rpm > O.redline ? T.red : T.text);
    },
  };
  // ---------------------------------------------------------------- "real" face: looks like an actual car's cluster
  const IVORY = '#EEEAE0', NEEDLE1 = '#ff7a33', NEEDLE2 = '#ff2a12';
  const RA0 = rad(150), RSW = rad(240);   // sweep from 8 o'clock to 4 o'clock, leaving room at the bottom
  function realNeedle(g, cx, cy, len, a, w, tail = 0.2) {
    // widest at the hub, a short slim tail behind it, tapering to a fine tip
    const poly = () => { g.beginPath(); g.moveTo(-len * tail, -w * 0.55); g.lineTo(0, -w * 1.25); g.lineTo(len, -w * 0.16); g.lineTo(len, w * 0.16); g.lineTo(0, w * 1.25); g.lineTo(-len * tail, w * 0.55); g.closePath(); };
    g.save(); g.translate(cx + w * 0.8, cy + w * 1.2); g.rotate(a);            // its shadow on the dial face
    g.fillStyle = 'rgba(0,0,0,.55)'; g.shadowColor = 'rgba(0,0,0,.6)'; g.shadowBlur = w * 2.5; poly(); g.fill(); g.restore();
    g.save(); g.translate(cx, cy); g.rotate(a);
    const gr = g.createLinearGradient(0, -w, 0, w); gr.addColorStop(0, NEEDLE1); gr.addColorStop(1, NEEDLE2);
    g.fillStyle = gr; g.shadowColor = 'rgba(255,90,30,.75)'; g.shadowBlur = w * 2; poly(); g.fill(); g.restore();
    const hub = g.createRadialGradient(cx - w * 1.2, cy - w * 1.4, w * 0.3, cx, cy, w * 3.4);   // metal hub cap
    hub.addColorStop(0, '#7b8088'); hub.addColorStop(0.45, '#2c2f34'); hub.addColorStop(1, '#08090a');
    g.fillStyle = hub; g.beginPath(); g.arc(cx, cy, w * 3.2, 0, TAU); g.fill();
    g.strokeStyle = 'rgba(255,255,255,.18)'; g.lineWidth = 1; g.stroke();
  }
  function realFace(g, cx, cy, R) {
    g.fillStyle = 'rgba(0,0,0,.6)'; g.beginPath(); g.arc(cx, cy + R * 0.03, R * 1.04, 0, TAU); g.fill();   // housing shadow
    const bz = g.createLinearGradient(cx - R, cy - R, cx + R, cy + R);                              // thin chrome bezel
    bz.addColorStop(0, '#d9dde2'); bz.addColorStop(0.35, '#6a6f76'); bz.addColorStop(0.55, '#f2f4f6'); bz.addColorStop(1, '#3a3d42');
    g.strokeStyle = bz; g.lineWidth = R * 0.035; g.beginPath(); g.arc(cx, cy, R, 0, TAU); g.stroke();
    const fc = g.createRadialGradient(cx, cy - R * 0.2, R * 0.05, cx, cy, R * 0.98);
    fc.addColorStop(0, '#1d2024'); fc.addColorStop(0.7, '#0e1012'); fc.addColorStop(1, '#050506');
    g.fillStyle = fc; g.beginPath(); g.arc(cx, cy, R * 0.982, 0, TAU); g.fill();
    g.strokeStyle = 'rgba(255,255,255,.014)'; g.lineWidth = 1;                                       // faint machined rings
    for (let k = 0.2; k < 0.97; k += 0.025) { g.beginPath(); g.arc(cx, cy, R * k, 0, TAU); g.stroke(); }
  }
  function realGlass(g, cx, cy, R) {
    g.save(); g.beginPath(); g.arc(cx, cy, R * 0.98, 0, TAU); g.clip();
    const gl = g.createRadialGradient(cx - R * 0.35, cy - R * 0.75, R * 0.1, cx - R * 0.2, cy - R * 0.55, R * 1.1);
    gl.addColorStop(0, 'rgba(255,255,255,.10)'); gl.addColorStop(0.5, 'rgba(255,255,255,.02)'); gl.addColorStop(1, 'rgba(255,255,255,0)');
    g.fillStyle = gl; g.fillRect(cx - R, cy - R, R * 2, R * 2);
    g.fillStyle = 'rgba(0,0,0,.25)'; g.beginPath(); g.arc(cx, cy, R * 0.98, 0, TAU); g.arc(cx, cy, R * 0.93, 0, TAU, true); g.fill();   // the face's edge in shadow
    g.restore();
  }
  // a printed scale: majors with numbers, mediums and minors; red from `red` (0..1)
  function realScale(g, cx, cy, R, n, sub, nums, red, numSize) {
    for (let i = 0; i <= n * sub; i++) {
      const f = i / (n * sub), a = RA0 + RSW * f, maj = i % sub === 0, med = !maj && sub % 2 === 0 && i % (sub / 2) === 0;
      const len = maj ? 0.12 : med ? 0.075 : 0.045, wd = maj ? 0.02 : med ? 0.012 : 0.008;
      const isRed = red != null && f >= red - 1e-6;
      g.strokeStyle = isRed ? '#ff3b2e' : IVORY; g.lineWidth = Math.max(1, R * wd); g.lineCap = 'butt';
      g.shadowColor = isRed ? 'rgba(255,60,40,.7)' : 'rgba(255,245,225,.55)'; g.shadowBlur = R * 0.02;
      g.beginPath(); g.moveTo(cx + R * 0.9 * Math.cos(a), cy + R * 0.9 * Math.sin(a)); g.lineTo(cx + R * (0.9 - len) * Math.cos(a), cy + R * (0.9 - len) * Math.sin(a)); g.stroke();
    }
    if (red != null) { g.shadowBlur = 0; g.strokeStyle = '#d61f14'; g.lineWidth = R * 0.035; g.beginPath(); g.arc(cx, cy, R * 0.915, RA0 + RSW * red, RA0 + RSW, false); g.stroke(); }
    nums.forEach((l, i) => {
      const f = i / (nums.length - 1), a = RA0 + RSW * f, isRed = red != null && f >= red - 1e-6;
      g.shadowColor = isRed ? 'rgba(255,60,40,.6)' : 'rgba(255,245,225,.5)'; g.shadowBlur = R * 0.025;
      text(g, l, cx + R * 0.66 * Math.cos(a), cy + R * 0.66 * Math.sin(a), 600, numSize, isRed ? '#ff4a3a' : IVORY);
    });
    g.shadowBlur = 0;
  }
  // the small classic gauge in the bottom of a dial (fuel E-F, temperature C-H), or on its own
  function realMini(g, cx, cy, r, f, lo, hi, label, warnLo, warnHi) {
    const a0 = rad(205), sw = rad(130);
    g.lineCap = 'butt';
    for (let i = 0; i <= 4; i++) {
      const a = a0 + (sw * i) / 4, warn = (warnLo && i === 0) || (warnHi && i === 4);
      g.strokeStyle = warn ? '#ff3b2e' : IVORY; g.lineWidth = Math.max(1, r * (i % 2 ? 0.035 : 0.06));
      g.shadowColor = 'rgba(255,245,225,.5)'; g.shadowBlur = r * 0.05;
      const l = i % 2 ? 0.12 : 0.2;
      g.beginPath(); g.moveTo(cx + r * Math.cos(a), cy + r * Math.sin(a)); g.lineTo(cx + r * (1 - l) * Math.cos(a), cy + r * (1 - l) * Math.sin(a)); g.stroke();
    }
    g.shadowBlur = 0;
    text(g, lo, cx + r * 1.18 * Math.cos(a0), cy + r * 1.18 * Math.sin(a0), 700, r * 0.24, warnLo ? '#ff4a3a' : IVORY);
    text(g, hi, cx + r * 1.18 * Math.cos(a0 + sw), cy + r * 1.18 * Math.sin(a0 + sw), 700, r * 0.24, warnHi ? '#ff4a3a' : IVORY);
    text(g, label, cx, cy - r * 0.5, 600, r * 0.17, 'rgba(238,234,224,.6)');
    realNeedle(g, cx, cy, r * 0.92, a0 + sw * clamp(f == null ? 0 : f, 0, 1), Math.max(1.6, r * 0.045), 0.12);
  }
  const fuelF = () => (sm.fuel == null ? null : sm.fuel / 100);
  const tempFrac = () => (sm.coolant == null ? null : clamp((sm.coolant * 9 / 5 + 32 - 120) / 150, 0, 1));   // 195 F sits in the middle
  function realBig(g, w, h, kind) {
    const R = Math.min(w, h) * 0.47, cx = w / 2, cy = h / 2;
    realFace(g, cx, cy, R);
    let f = 0;
    if (kind === 'speed') {
      const km = metric(), v = sm.kmh == null ? null : km ? sm.kmh : sm.kmh * 0.621371, max = km ? 240 : 140;
      realScale(g, cx, cy, R, km ? 12 : 7, 4, (km ? [0, 20, 40, 60, 80, 100, 120, 140, 160, 180, 200, 220, 240] : [0, 20, 40, 60, 80, 100, 120, 140]).map(String), null, R * (km ? 0.095 : 0.12));
      // the other unit printed small on an inner ring, like a real speedometer
      const other = km ? [0, 20, 40, 60, 80, 100, 120, 140] : [0, 40, 80, 120, 160, 200];
      other.forEach((u) => { const ff = km ? (u * 1.609) / max : (u / 1.609) / max; if (ff > 1) return; const a = RA0 + RSW * ff;
        text(g, String(u), cx + R * 0.47 * Math.cos(a), cy + R * 0.47 * Math.sin(a), 500, R * 0.055, 'rgba(238,234,224,.45)'); });
      text(g, km ? 'km/h' : 'MPH', cx, cy - R * 0.3, 700, R * 0.07, 'rgba(238,234,224,.7)');
      text(g, km ? 'MPH' : 'km/h', cx, cy - R * 0.2, 500, R * 0.045, 'rgba(238,234,224,.4)');
      f = v == null ? 0 : clamp(v / max, 0, 1);
      realMini(g, cx, cy + R * 0.66, R * 0.24, fuelF(), 'E', 'F', 'FUEL', true, false);
    } else {
      const rpm = sm.rpm;
      realScale(g, cx, cy, R, 8, 4, ['0', '1', '2', '3', '4', '5', '6', '7', '8'], 6 / 8, R * 0.13);
      text(g, 'x1000 r/min', cx, cy - R * 0.3, 600, R * 0.06, 'rgba(238,234,224,.7)');
      f = rpm == null ? 0 : clamp(rpm / 8000, 0, 1);
      realMini(g, cx, cy + R * 0.66, R * 0.24, tempFrac(), 'C', 'H', 'TEMP', false, true);
    }
    realNeedle(g, cx, cy, R * 0.86, RA0 + RSW * f, Math.max(2.5, R * 0.022), 0.14);
    realGlass(g, cx, cy, R);
  }
  // ---- liquid orbs: a glass ball of liquid that sloshes with acceleration (fuel: how full; coolant: rises as it warms)
  function orb(g, w, h, t, lvl, c1, c2, o) {
    const r = Math.min(w, h) * (isWide(w, h) ? 0.4 : 0.36), cx = isWide(w, h) ? w * 0.26 : w / 2, cy = isWide(w, h) ? h / 2 : h * 0.44;
    g.fillStyle = 'rgba(0,0,0,.35)'; g.beginPath(); g.arc(cx, cy, r, 0, TAU); g.fill();
    if (lvl != null) {
      g.save(); g.beginPath(); g.arc(cx, cy, r * 0.97, 0, TAU); g.clip();
      const L = clamp(lvl, 0, 1), tilt = clamp(-trip.accel / 45, -0.45, 0.45), surf = cy + r - 2 * r * L;
      const amp = r * (0.035 + Math.min(0.08, Math.abs(trip.accel) / 400)) * (o.boil ? 1.8 : 1);
      const wave = (ph, k, a) => { g.beginPath(); g.moveTo(cx - r, cy + r * 1.1);
        for (let x = -r; x <= r; x += 3) g.lineTo(cx + x, surf + tilt * x + Math.sin(t * (2.2 + k) + x / r * 4 + ph) * amp * a + Math.sin(t * 3.3 - x / r * 6 + ph) * amp * 0.5 * a);
        g.lineTo(cx + r, cy + r * 1.1); g.closePath(); };
      wave(2.1, 0.7, 1.2); g.fillStyle = c2 + 'aa'; g.fill();                     // the back wave, darker
      const gr = g.createLinearGradient(0, surf - r * 0.1, 0, cy + r);
      gr.addColorStop(0, c1); gr.addColorStop(1, c2);
      wave(0, 0, 1); g.fillStyle = gr; g.shadowColor = c1; g.shadowBlur = r * 0.3; g.fill(); g.shadowBlur = 0;
      g.strokeStyle = 'rgba(255,255,255,.6)'; g.lineWidth = Math.max(1.5, r * 0.012); g.stroke();
      const n = o.boil ? 26 : 9;                                                    // bubbles (boiling when hot)
      for (let i = 0; i < n; i++) {
        const sp = (o.boil ? 60 : 18) + (i % 5) * 9, span = Math.max(10, cy + r - surf);
        const by = cy + r - ((t * sp + i * 37) % span), bx = cx + Math.sin(i * 12.9 + t * (0.8 + (i % 3) * 0.3)) * r * 0.7;
        if (by > surf + 4) { g.strokeStyle = 'rgba(255,255,255,.55)'; g.lineWidth = 1; g.beginPath(); g.arc(bx, by, r * (0.012 + (i % 4) * 0.008), 0, TAU); g.stroke(); }
      }
      g.restore();
    }
    // glass: rim, a bright highlight top-left, shade at the bottom
    const hl = g.createRadialGradient(cx - r * 0.4, cy - r * 0.45, r * 0.02, cx - r * 0.3, cy - r * 0.35, r * 0.6);
    hl.addColorStop(0, 'rgba(255,255,255,.55)'); hl.addColorStop(1, 'rgba(255,255,255,0)');
    g.fillStyle = hl; g.beginPath(); g.arc(cx, cy, r, 0, TAU); g.fill();
    const sh = g.createRadialGradient(cx, cy, r * 0.6, cx, cy, r);
    sh.addColorStop(0, 'rgba(0,0,0,0)'); sh.addColorStop(1, 'rgba(0,0,0,.45)');
    g.fillStyle = sh; g.beginPath(); g.arc(cx, cy, r, 0, TAU); g.fill();
    g.strokeStyle = 'rgba(255,255,255,.35)'; g.lineWidth = Math.max(2, r * 0.02); g.beginPath(); g.arc(cx, cy, r, 0, TAU); g.stroke();
    if (isWide(w, h)) {
      const x = cx + r * 1.35;
      text(g, o.val, x, h * 0.42, 300, Math.min(h * 0.42, (w - x) * 0.32), o.valCol || T.text, 'left');
      text(g, o.note, x, h * 0.74, 600, clamp(h * 0.13, 10, 20), o.noteCol || T.sub, 'left');
    } else {
      g.save(); g.shadowColor = 'rgba(0,0,0,.8)'; g.shadowBlur = r * 0.15;
      text(g, o.val, cx, cy + r * 0.05, 300, r * 0.42, o.valCol || '#fff'); g.restore();
      text(g, o.label, cx, cy + r * 1.22, 650, r * 0.14, T.sub);
      text(g, o.note, cx, cy + r * 1.45, 500, r * 0.12, o.noteCol || T.sub);
    }
  }
  G.fuelorb = (g, w, h, t) => {
    const f = sm.fuel, low = f != null && f < 15, lowish = f != null && f < 25;
    orb(g, w, h, t, f == null ? null : f / 100, low ? T.red : lowish ? T.amber : T.accent, low ? '#5a0a0a' : lowish ? '#6a3a05' : T.b2,
      { val: f == null ? '--' : `${Math.round(f)}%`, label: 'Fuel', note: f == null ? noVal() : low ? 'Low fuel' : fuelLeft(f, true), noteCol: low ? T.red : T.sub });
  };
  G.coolorb = (g, w, h, t) => {
    const c = sm.coolant, f = c == null ? null : c * 9 / 5 + 32;
    const st = f == null ? null : f < 160 ? 'cold' : f < 225 ? 'ok' : f < 240 ? 'warm' : 'hot';
    const col = { cold: [T.blue, '#0a2a5a'], ok: [T.green, '#064e3b'], warm: [T.amber, '#6a3a05'], hot: [T.red, '#5a0a0a'] }[st] || [T.sub, '#222'];
    orb(g, w, h, t, f == null ? null : clamp((f - 60) / 200, 0.08, 1), col[0], col[1],
      { val: c == null ? '--' : tempF() ? `${Math.round(f)}°` : `${Math.round(c)}°`, label: 'Coolant', boil: st === 'hot' || st === 'warm',
        note: { cold: 'Warming up', ok: 'Normal', warm: 'Running warm', hot: 'Overheating!' }[st] || noVal(), noteCol: st ? col[0] : T.sub });
  };
  // ---------------------------------------------------------------- more gauges (round 2)
  const fmtDur = (x) => { x = Math.max(0, Math.round(x)); const hh = Math.floor(x / 3600), mm = Math.floor((x % 3600) / 60), ss = x % 60;
    return hh ? `${hh}:${String(mm).padStart(2, '0')}:${String(ss).padStart(2, '0')}` : `${mm}:${String(ss).padStart(2, '0')}`; };
  // text that shrinks to fit, then gets cut with an ellipsis
  function fit(g, s, x, y, maxW, w, px, col, align = 'center', minK = 0.3) {
    s = String(s); g.font = F(w, px); let tw = g.measureText(s).width;
    if (tw > maxW) { const k = Math.max(minK, (maxW / tw) * 0.96); px *= k; g.font = F(w, px); tw = g.measureText(s).width; }
    while (tw > maxW * 1.04 && s.length > 2) { s = s.slice(0, -2) + '…'; tw = g.measureText(s).width; }
    text(g, s, x, y, w, px, col, align);
  }
  const rr = (g, x, y, w, h, r) => { g.beginPath(); g.roundRect ? g.roundRect(x, y, w, h, r) : g.rect(x, y, w, h); };
  const glowOn = (g, c, b) => { g.shadowColor = c; g.shadowBlur = b * GK; };

  // ---- scrolling 60 s history: an oscilloscope with a glowing trace
  function trace(g, w, h, t, key, o) {
    const wd = isWide(w, h), m = Math.min(w, h), p = clamp(m * 0.07, 6, 20);
    const v = sm[key === 'kmh' ? 'kmh' : key], cur = v == null ? null : o.conv(v), col = o.col();
    let x0, y0, pw, ph;
    if (wd) {
      const lw = Math.min(w * 0.3, h * 1.7);
      text(g, o.name, p, h * 0.26, 650, clamp(h * 0.15, 10, 18), T.sub, 'left');
      fit(g, cur == null ? '--' : o.fmt(cur), p, h * 0.6, lw - p * 2, 300, h * 0.42, T.text, 'left');
      x0 = lw; y0 = p; pw = w - lw - p; ph = h - p * 2;
    } else {
      const hh = clamp(h * 0.24, 22, 90);
      text(g, o.name, p, p + hh * 0.3, 650, hh * 0.26, T.sub, 'left');
      text(g, cur == null ? '--' : o.fmt(cur), w - p, p + hh * 0.48, 300, hh * 0.8, T.text, 'right');
      text(g, o.unit, w - p, p + hh * 1.0, 500, hh * 0.2, T.sub, 'right');
      x0 = p; y0 = p + hh * 1.15; pw = w - p * 2; ph = h - y0 - p * 1.6;
    }
    if (pw < 20 || ph < 10) return;
    // the screen: a dark glass with a grid that scrolls with time
    rr(g, x0, y0, pw, ph, Math.min(10, ph * 0.08)); g.fillStyle = 'rgba(0,0,0,.28)'; g.fill();
    g.save(); g.clip();
    g.strokeStyle = 'rgba(255,255,255,.06)'; g.lineWidth = 1; g.beginPath();
    for (let k = 1; k < 4; k++) { const y = y0 + (ph * k) / 4; g.moveTo(x0, y); g.lineTo(x0 + pw, y); }
    const sh = (hAcc / 0.1) * (pw / HN), off = ((hHead % 100) / 100) * (pw / 6);
    for (let k = 0; k <= 6; k++) { const x = x0 + pw - ((k * pw) / 6 + off + sh) % (pw + pw / 6); g.moveTo(x, y0); g.lineTo(x, y0 + ph); }
    g.stroke();
    if (o.red != null && o.red < o.max) {   // redline
      const y = y0 + ph * (1 - o.red / o.max);
      g.fillStyle = 'rgba(255,77,77,.08)'; g.fillRect(x0, y0, pw, y - y0);
      g.strokeStyle = 'rgba(255,77,77,.6)'; g.setLineDash([6, 5]); g.beginPath(); g.moveTo(x0, y); g.lineTo(x0 + pw, y); g.stroke(); g.setLineDash([]);
    }
    if (o.avg != null) {
      const y = y0 + ph * (1 - clamp(o.avg / o.max, 0, 1));
      g.strokeStyle = rgba(T.text, 0.55); g.setLineDash([2, 4]); g.beginPath(); g.moveTo(x0, y); g.lineTo(x0 + pw, y); g.stroke(); g.setLineDash([]);
      const fs2 = clamp(ph * 0.08, 9, 14); g.font = F(600, fs2); g.fillStyle = 'rgba(0,0,0,.55)'; g.fillRect(x0 + 2, y - fs2 * 1.6, g.measureText(o.avgLabel).width + 8, fs2 * 1.3);
      text(g, o.avgLabel, x0 + 6, y - fs2 * 0.95, 600, fs2, rgba(T.text, 0.85), 'left');
    }
    const arr = HIST[key], step = Math.max(1, Math.floor(HN / pw));
    const X = (i) => x0 + (pw * i) / (HN - 1) - sh, Y = (val) => y0 + ph * (1 - clamp(o.conv(val) / o.max, 0, 1));
    if (o.bars) {   // one bar per second
      const bw = pw / 60;
      for (let s2 = 0; s2 < 60; s2++) {
        let sum = 0, n = 0;
        for (let k = 0; k < 10; k++) { const val = arr[(hHead + s2 * 10 + k) % HN]; if (!Number.isNaN(val)) { sum += val; n++; } }
        if (!n) continue;
        const val = o.conv(sum / n), y = y0 + ph * (1 - clamp(val / o.max, 0, 1)), c = o.barCol(val);
        const gr = g.createLinearGradient(0, y, 0, y0 + ph); gr.addColorStop(0, c); gr.addColorStop(1, rgba(c, 0.15));
        g.fillStyle = gr; g.fillRect(x0 + s2 * bw + bw * 0.15, y, bw * 0.7, y0 + ph - y);
      }
    } else {
      const path = new Path2D(); let open = false, firstX = null, lastX = 0, lastY = 0;
      for (let i = 0; i < HN; i += step) {
        const val = arr[(hHead + i) % HN];
        if (Number.isNaN(val)) { open = false; continue; }
        const x = X(i), y = Y(val);
        if (!open) { path.moveTo(x, y); open = true; if (firstX == null) firstX = x; } else path.lineTo(x, y);
        lastX = x; lastY = y;
      }
      if (firstX != null) {
        const fill = new Path2D(path); fill.lineTo(lastX, y0 + ph); fill.lineTo(firstX, y0 + ph); fill.closePath();
        const gr = g.createLinearGradient(0, y0, 0, y0 + ph); gr.addColorStop(0, rgba(col, 0.35)); gr.addColorStop(1, rgba(col, 0));
        g.fillStyle = gr; g.fill(fill);
        g.lineJoin = 'round'; g.lineCap = 'round';
        g.strokeStyle = rgba(col, 0.25 * Math.min(1.5, GK)); g.lineWidth = 7; g.stroke(path);
        g.strokeStyle = col; g.lineWidth = 2.2; g.stroke(path);
        g.fillStyle = '#fff'; glowOn(g, col, 14); circ(g, lastX, lastY, 3.5); g.fill(); g.shadowBlur = 0;
      }
    }
    g.restore();
    if (!wd) text(g, '60 s', x0 + 4, y0 + ph + p * 0.8, 500, clamp(ph * 0.07, 8, 12), T.sub, 'left');
    if (cur == null && !Number.isFinite(arr[(hHead + HN - 1) % HN])) text(g, noVal(), x0 + pw / 2, y0 + ph / 2, 500, clamp(ph * 0.1, 10, 18), T.sub);
  }
  G.rpmtrace = (g, w, h, t) => trace(g, w, h, t, 'rpm', { name: 'Engine rpm', unit: 'rpm', max: Math.max(7, Math.floor(O.redline / 1000) + 1) * 1000, red: O.redline,
    conv: (x) => x, fmt: (x) => String(Math.round(x / 10) * 10), col: () => ((sm.rpm || 0) > O.redline ? T.red : T.accent) });
  G.speedtrace = (g, w, h, t) => trace(g, w, h, t, 'kmh', { name: 'Speed', unit: metric() ? 'km/h' : 'mph', max: metric() ? 160 : 100,
    conv: (x) => (metric() ? x : x * 0.621371), fmt: (x) => String(Math.round(x)), col: () => T.b3 });
  G.mpgtrace = (g, w, h, t) => {
    const km = metric(), avg = trip.mpgAvg && trip.mpgN > 30 ? trip.mpgAvg : null;
    trace(g, w, h, t, 'mpg', { name: km ? 'Economy (km/L)' : 'Economy', unit: km ? 'km/L' : 'mpg', max: km ? 20 : 50, bars: true,
      conv: (x) => (km ? x * 0.4251 : x), fmt: (x) => x.toFixed(km ? 1 : 0), col: () => T.green,
      barCol: (x) => { const k = x / (km ? 20 : 50); return k > 0.5 ? T.green : k > 0.3 ? T.accent : k > 0.15 ? T.amber : T.red; },
      avg: avg == null ? null : km ? avg * 0.4251 : avg, avgLabel: avg == null ? '' : `Trip ${km ? (avg * 0.4251).toFixed(1) : avg.toFixed(1)}` });
  };

  // ---- gear: a "virtual gear" from how fast you go per 1000 rpm
  const GEAR_AT = [0, 13, 21, 30, 39, 48];   // km/h per 1000 rpm where each gear starts
  G.gear = (g, w, h, t) => {
    const rpm = sm.rpm, kmh = sm.kmh, has = rpm != null && kmh != null;
    const ratio = has && rpm > 400 ? kmh / (rpm / 1000) : null;
    let gear = null;
    if (has) gear = kmh < 3 ? (rpm > 300 ? 'N' : 'P') : ratio == null ? 'N' : String(GEAR_AT.reduce((n, a, i) => (ratio >= a ? i + 1 : n), 1));
    const gn = gear && /\d/.test(gear) ? +gear : 0;
    const up = gn && gn < 6 && rpm > O.redline * 0.82, down = gn > 1 && rpm < 1400;
    const col = up ? T.amber : T.accent, ru = metric() ? ratio : ratio == null ? null : ratio * 0.621371;
    const note = ratio == null ? (has ? 'Stopped' : noVal()) : `${ru.toFixed(1)} ${metric() ? 'km/h' : 'mph'} per 1000 rpm`;
    const plate = (cx, cy, s) => {   // the gear digit on a glowing hexagon plate
      g.beginPath(); for (let i = 0; i < 6; i++) { const a = (i / 6) * TAU + Math.PI / 6; g.lineTo(cx + s * Math.cos(a), cy + s * Math.sin(a)); } g.closePath();
      const gr = g.createLinearGradient(0, cy - s, 0, cy + s); gr.addColorStop(0, 'rgba(255,255,255,.08)'); gr.addColorStop(1, 'rgba(0,0,0,.35)');
      g.fillStyle = gr; g.fill(); g.strokeStyle = rgba(col, 0.8); g.lineWidth = Math.max(2, s * 0.03); glowOn(g, col, s * 0.25); g.stroke(); g.shadowBlur = 0;
      g.save(); glowOn(g, col, s * 0.35); text(g, gear || '-', cx, cy + s * 0.05, 700, s * 1.15, gear ? '#fff' : T.sub); g.restore();
      if (up || down) {   // shift hint
        const a = 0.5 + 0.5 * pulse(t, 8), y = up ? cy - s * 1.22 : cy + s * 1.22, d = up ? -1 : 1;
        g.fillStyle = rgba(up ? T.amber : T.b3, a); g.beginPath(); g.moveTo(cx - s * 0.25, y - d * s * 0.08); g.lineTo(cx + s * 0.25, y - d * s * 0.08); g.lineTo(cx, y + d * s * 0.18); g.closePath(); g.fill();
      }
    };
    const pips = (x, y, wd2, hh) => {   // 1..6 with the current one lit
      const n = 6, gp = wd2 * 0.04, pw = (wd2 - gp * (n - 1)) / n;
      for (let i = 0; i < n; i++) {
        const on = gn === i + 1; rr(g, x + i * (pw + gp), y, pw, hh, hh * 0.3);
        g.fillStyle = on ? col : 'rgba(255,255,255,.08)'; if (on) glowOn(g, col, hh); g.fill(); g.shadowBlur = 0;
        text(g, String(i + 1), x + i * (pw + gp) + pw / 2, y + hh / 2, 700, hh * 0.62, on ? '#000' : T.sub);
      }
    };
    if (isWide(w, h)) {
      const s = h * 0.38; plate(h * 0.55, h / 2, s);
      const x = h * 1.1, fs = clamp(h * 0.15, 10, 18);
      text(g, 'Gear', x, h * 0.26, 650, fs, T.sub, 'left');
      pips(x, h * 0.4, w - x - 12, clamp(h * 0.2, 10, 30));
      fit(g, note, x, h * 0.78, w - x - 12, 500, fs * 0.9, T.sub, 'left');
      return;
    }
    const m = Math.min(w, h), s = m * 0.26, cy = h * 0.42;
    plate(w / 2, cy, s);
    const pw = Math.min(w * 0.8, m * 0.95), ph = clamp(m * 0.08, 10, 34);
    pips(w / 2 - pw / 2, cy + s * 1.45, pw, ph);
    fit(g, note, w / 2, cy + s * 1.45 + ph + m * 0.07, w * 0.9, 500, clamp(m * 0.05, 9, 18), T.sub);
    text(g, 'Gear', w / 2, Math.max(m * 0.06, cy - s * 1.45), 650, clamp(m * 0.055, 10, 20), T.sub);
  };

  // ---- eco: a leaf when you drive smoothly, a flame when you don't
  function leaf(g, x, y, s, col, t) {
    g.save(); g.translate(x, y); g.rotate(-0.5 + Math.sin(t * 1.3) * 0.08);
    const gr = g.createLinearGradient(0, -s, 0, s); gr.addColorStop(0, mix(col, '#ffffff', 0.35)); gr.addColorStop(1, mix(col, '#000000', 0.35));
    g.beginPath(); g.moveTo(0, s); g.bezierCurveTo(-s * 0.9, s * 0.3, -s * 0.7, -s * 0.7, 0, -s); g.bezierCurveTo(s * 0.7, -s * 0.7, s * 0.9, s * 0.3, 0, s); g.closePath();
    glowOn(g, col, s * 0.4); g.fillStyle = gr; g.fill(); g.shadowBlur = 0;
    g.strokeStyle = 'rgba(255,255,255,.6)'; g.lineWidth = Math.max(1, s * 0.05); g.beginPath(); g.moveTo(0, s * 1.15); g.lineTo(0, -s * 0.8);
    for (let k = 1; k < 4; k++) { const yy = s * (0.6 - k * 0.38); g.moveTo(0, yy + s * 0.15); g.lineTo(-s * 0.4, yy - s * 0.05); g.moveTo(0, yy + s * 0.15); g.lineTo(s * 0.4, yy - s * 0.05); }
    g.stroke(); g.restore();
  }
  function flame(g, x, y, s, t, hot) {
    g.save(); g.globalCompositeOperation = 'lighter';
    const layers = [[1, hot ? '#ff2a1a' : '#ff6a00', 0.7], [0.72, '#ff9a1a', 0.8], [0.45, '#ffe08a', 0.95]];
    for (const [k, c, a] of layers) {
      const f = 1 + 0.08 * Math.sin(t * 13 + k * 5) + 0.05 * Math.sin(t * 21 + k), sw = Math.sin(t * 7 + k * 3) * s * 0.08 * k;
      const hh = s * k * f, ww = s * 0.6 * k;
      g.beginPath(); g.moveTo(x, y + s * 0.55);
      g.bezierCurveTo(x - ww, y + s * 0.5, x - ww * 1.05, y - hh * 0.2, x + sw, y - hh);
      g.bezierCurveTo(x + ww * 1.05, y - hh * 0.2, x + ww, y + s * 0.5, x, y + s * 0.55);
      const gr = g.createRadialGradient(x, y + s * 0.3, 0, x, y, hh); gr.addColorStop(0, c); gr.addColorStop(1, rgba(c, 0.1));
      g.globalAlpha = a; g.fillStyle = gr; g.fill();
    }
    g.restore();
  }
  G.eco = (g, w, h, t) => {
    const sc = trip.ecoE == null ? null : Math.round(100 * Math.exp(-2.5 * trip.ecoE));
    const col = sc == null ? T.sub : sc >= 70 ? T.green : sc >= 45 ? T.amber : T.red;
    const word = sc == null ? (sm.kmh == null ? noVal() : 'Starts when you drive') : sc >= 85 ? 'Silky smooth' : sc >= 70 ? 'Smooth' : sc >= 45 ? 'Easy on it' : 'Aggressive';
    if (isWide(w, h)) {
      const s = h * 0.3; sc == null || sc >= 60 ? leaf(g, h * 0.5, h / 2, s, sc == null ? T.sub : col, t) : flame(g, h * 0.5, h * 0.55, s * 1.3, t, sc < 30);
      g.save(); g.translate(h, 0); wide(g, w - h, h, t, { name: 'Eco score', val: sc == null ? '--' : String(sc), f: (sc || 0) / 100, has: sc != null, barCol: col, note: word, noteCol: col }); g.restore(); return;
    }
    const r = Math.min(w * 0.43, h * 0.46), cx = w / 2, cy = h / 2 + r * 0.1, tw = r * 0.1;
    arc(g, cx, cy, r, A0, A0 + SWEEP, tw, T.faint);
    if (g.createConicGradient) {
      const cg = g.createConicGradient(A0, cx, cy); cg.addColorStop(0, T.red); cg.addColorStop(0.35, T.amber); cg.addColorStop(0.75, T.green); cg.addColorStop(1, T.green);
      g.globalAlpha = 0.3; arc(g, cx, cy, r, A0, A0 + SWEEP, tw, cg, 0, 'butt'); g.globalAlpha = 1;
      if (sc != null) { g.shadowColor = col; arc(g, cx, cy, r, A0, A0 + SWEEP * Math.max(0.01, sc / 100), tw, cg, r * 0.1, 'round', true); }
    }
    if (sc != null) { const a = A0 + SWEEP * sc / 100; g.fillStyle = '#fff'; glowOn(g, col, r * 0.1); circ(g, cx + r * Math.cos(a), cy + r * Math.sin(a), tw * 0.7); g.fill(); g.shadowBlur = 0; }
    if (sc == null || sc >= 60) leaf(g, cx, cy - r * 0.32, r * 0.24, sc == null ? T.sub : col, t); else flame(g, cx, cy - r * 0.28, r * 0.34, t, sc < 30);
    valText(g, sc == null ? '--' : String(sc), cx, cy + r * 0.22, r * 0.36, T.text);
    text(g, 'Eco score', cx, cy + r * 0.52, 600, r * 0.13, T.sub);
    fit(g, word, cx, cy + r * 0.74, r * 1.5, 600, r * 0.12, col);
  };

  // ---- trip computer
  G.trip = (g, w, h, t) => {
    const km = metric(), dist = (trip.km || 0) * (km ? 1 : 0.621371), secs = trip.secs || 0;
    const avg = secs > 5 ? (trip.km / (secs / 3600)) * (km ? 1 : 0.621371) : null;
    const gal = (trip.fuelL || 0) / 3.785, econ = trip.fuelL > 0.05 ? (km ? (trip.fuelL / Math.max(0.1, trip.km)) * 100 : (trip.km * 0.621371) / gal) : null;
    const cells = [['Distance', dist < 100 ? dist.toFixed(1) : String(Math.round(dist)), km ? 'km' : 'mi'], ['Driving', fmtDur(secs), ''],
      ['Avg speed', avg == null ? '--' : String(Math.round(avg)), km ? 'km/h' : 'mph'], ['Economy', econ == null ? '--' : econ.toFixed(1), km ? 'L/100' : 'mpg']];
    const wd = isWide(w, h), cols = wd ? 4 : 2, rows = wd ? 1 : 2, p = clamp(Math.min(w, h) * 0.06, 6, 18);
    const top = wd ? p : clamp(h * 0.14, 20, 60);
    if (!wd) { text(g, 'Trip', p * 1.2, top * 0.55, 700, top * 0.42, T.text, 'left'); g.fillStyle = T.accent; g.fillRect(p * 1.2, top * 0.88, Math.min(60, w * 0.1), 2); }
    const cw = (w - p * 2) / cols, ch = (h - top - p) / rows;
    cells.forEach(([lab, val, unit], i) => {
      const x = p + (i % cols) * cw, y = top + Math.floor(i / cols) * ch, s = Math.min(cw * 0.3, ch * 0.42);
      if (i % cols) { g.fillStyle = 'rgba(255,255,255,.07)'; g.fillRect(x, y + ch * 0.15, 1, ch * 0.7); }
      text(g, lab, x + cw * 0.12, y + ch * 0.24, 600, s * 0.32, T.sub, 'left');
      fit(g, val, x + cw * 0.12, y + ch * 0.58, cw * 0.8, 300, s, T.text, 'left');
      if (unit) { g.font = F(300, s); const vw = Math.min(cw * 0.8, g.measureText(val).width); text(g, unit, x + cw * 0.12 + vw + s * 0.12, y + ch * 0.58 + s * 0.2, 500, s * 0.3, T.sub, 'left'); }
    });
  };

  // ---- quarter mile: a drag strip tree, elapsed time, trap speed
  G.quarter = (g, w, h, t) => {
    const run = trip.q0 != null, el = run ? (performance.now() - trip.q0) / 1000 : trip.qLast, km = metric();
    const dist = run ? trip.qD / 402.34 : trip.qLast != null ? 1 : 0, armed = !run && trip.qArmed && sm.kmh != null && sm.kmh < 1;
    const trap = trip.qTrap == null ? null : km ? trip.qTrap : trip.qTrap * 0.621371;
    const note = run ? 'Go go go!' : trip.qBest ? `Best ${trip.qBest.toFixed(2)} s${trap ? ` · trap ${Math.round(trap)} ${km ? 'km/h' : 'mph'}` : ''}` : sm.kmh == null ? noVal() : 'Starts when you pull away from a stop';
    const lights = (x, y, s, horiz) => {   // pre-stage, stage, three ambers, green
      const L = [['#4FA3FF', armed || run], ['#4FA3FF', armed || run], [T.amber, armed && pulse(t, 6) > 0.3], [T.amber, armed && pulse(t, 6) > 0.5], [T.amber, armed && pulse(t, 6) > 0.7], [T.green, run]];
      L.forEach(([c, on], i) => {
        const cx = horiz ? x + i * s * 2.4 : x, cy = horiz ? y : y + i * s * 2.4;
        g.fillStyle = on ? c : 'rgba(255,255,255,.07)'; if (on) glowOn(g, c, s * 1.5); circ(g, cx, cy, s); g.fill(); g.shadowBlur = 0;
        g.strokeStyle = 'rgba(255,255,255,.15)'; g.lineWidth = 1; g.stroke();
      });
    };
    const strip = (x, y, ww, hh) => {   // the strip with the car's progress
      rr(g, x, y, ww, hh, hh / 2); g.fillStyle = 'rgba(255,255,255,.07)'; g.fill();
      if (dist > 0) { rr(g, x, y, Math.max(hh, ww * Math.min(1, dist)), hh, hh / 2); const gr = g.createLinearGradient(x, 0, x + ww, 0); gr.addColorStop(0, T.b3); gr.addColorStop(1, run ? T.amber : T.green); g.fillStyle = gr; glowOn(g, T.accent, hh); g.fill(); g.shadowBlur = 0; }
      g.fillStyle = '#fff'; for (let k = 0; k < 6; k++) g.fillRect(x + ww - hh * 0.6 + (k % 2) * hh * 0.3, y + Math.floor(k / 2) * hh / 3, hh * 0.3, hh / 3);   // checkered finish
    };
    if (isWide(w, h)) {
      const s = clamp(h * 0.09, 3, 9); lights(s * 2, h * 0.22, s, true);
      const x = s * 2 + s * 2.4 * 6 + s;
      fit(g, el == null ? '--' : el.toFixed(2), x, h * 0.4, w * 0.3, 300, h * 0.42, run ? T.amber : T.text, 'left');
      strip(x + w * 0.3, h * 0.33, w - x - w * 0.3 - 10, clamp(h * 0.12, 6, 14));
      fit(g, `1/4 mile · ${note}`, s, h * 0.8, w - s * 2, 600, clamp(h * 0.14, 9, 16), T.sub, 'left');
      return;
    }
    const m = Math.min(w, h), s = m * 0.045, tx = w * 0.14;
    lights(tx, h / 2 - s * 2.4 * 2.5, s, false);
    const cx = (w + tx + s * 2) / 2;
    text(g, '1/4 mile', cx, h * 0.2, 650, m * 0.07, T.sub);
    fit(g, el == null ? '--' : el.toFixed(2), cx, h * 0.4, w - tx - s * 4, 200, m * 0.24, run ? T.amber : T.text);
    text(g, 'seconds', cx, h * 0.53, 500, m * 0.05, T.sub);
    strip(tx + s * 3, h * 0.64, w - tx - s * 3 - m * 0.08, clamp(m * 0.035, 6, 16));
    fit(g, note, cx, h * 0.82, w - tx - s * 4, 500, m * 0.05, run ? T.amber : T.sub);
  };

  // ---- torque: where you are on the engine's torque curve (2.5 L boxer, ~170 lb-ft at 4000 rpm)
  const tqNorm = (rpm) => { const x = rpm / 1000; return clamp(0.62 + 0.38 * Math.exp(-((x - 4) ** 2) / 5.12), 0, 1) * clamp(rpm / 900, 0, 1); };
  G.torque = (g, w, h, t) => {
    const rpm = sm.rpm, load = sm.load, km = metric(), has = rpm != null && load != null;
    const lbft = has ? (load / 100) * 170 * tqNorm(rpm) : null, val = lbft == null ? null : km ? lbft * 1.3558 : lbft;
    const hp = lbft == null ? null : (lbft * rpm) / 5252, maxR = Math.max(7, Math.floor(O.redline / 1000) + 1) * 1000, unit = km ? 'Nm' : 'lb-ft';
    const wd = isWide(w, h), p = clamp(Math.min(w, h) * 0.07, 6, 18);
    let x0, y0, pw, ph;
    if (wd) {
      const lw = Math.min(w * 0.32, h * 1.8);
      text(g, 'Torque (est.)', p, h * 0.24, 650, clamp(h * 0.14, 10, 17), T.sub, 'left');
      fit(g, val == null ? '--' : `${Math.round(val)} ${unit}`, p, h * 0.55, lw - p * 2, 300, h * 0.32, T.text, 'left');
      text(g, hp == null ? noVal() : `${Math.round(hp)} hp`, p, h * 0.82, 600, clamp(h * 0.13, 9, 16), T.accent, 'left');
      x0 = lw; y0 = p; pw = w - lw - p; ph = h - p * 2;
    } else {
      const hh = clamp(h * 0.26, 24, 100);
      text(g, 'Torque (est.)', p, p + hh * 0.22, 650, hh * 0.2, T.sub, 'left');
      text(g, val == null ? '--' : String(Math.round(val)), p, p + hh * 0.66, 200, hh * 0.62, T.text, 'left');
      g.font = F(200, hh * 0.62); const vw = g.measureText(val == null ? '--' : String(Math.round(val))).width;
      text(g, unit, p + vw + 6, p + hh * 0.8, 500, hh * 0.18, T.sub, 'left');
      text(g, hp == null ? noVal() : `${Math.round(hp)} hp`, w - p, p + hh * 0.66, 400, hh * (hp == null ? 0.16 : 0.32), hp == null ? T.sub : T.accent, 'right');
      x0 = p; y0 = p + hh * 1.12; pw = w - p * 2; ph = h - y0 - p * 1.8;
    }
    if (pw < 30 || ph < 16) return;
    const X = (r2) => x0 + (pw * r2) / maxR, Y = (k) => y0 + ph * (1 - k);
    g.strokeStyle = 'rgba(255,255,255,.07)'; g.lineWidth = 1; g.beginPath();
    for (let k = 1000; k < maxR; k += 1000) { g.moveTo(X(k), y0); g.lineTo(X(k), y0 + ph); }
    g.moveTo(x0, y0 + ph); g.lineTo(x0 + pw, y0 + ph); g.stroke();
    const curve = (k) => { const pth = new Path2D(); for (let r2 = 0; r2 <= maxR; r2 += maxR / 60) { const x = X(r2), y = Y(tqNorm(r2) * k); r2 ? pth.lineTo(x, y) : pth.moveTo(x, y); } return pth; };
    const full = curve(1), area = new Path2D(full); area.lineTo(X(maxR), y0 + ph); area.lineTo(x0, y0 + ph); area.closePath();
    const gr = g.createLinearGradient(0, y0, 0, y0 + ph); gr.addColorStop(0, rgba(T.accent, 0.25)); gr.addColorStop(1, rgba(T.accent, 0));
    g.fillStyle = gr; g.fill(area); g.strokeStyle = rgba(T.accent, 0.8); g.lineWidth = 2; g.stroke(full);
    g.fillStyle = 'rgba(255,77,77,.12)'; g.fillRect(X(O.redline), y0, X(maxR) - X(O.redline), ph);
    if (has) {
      g.setLineDash([4, 4]); g.strokeStyle = rgba(T.text, 0.4); g.lineWidth = 1; g.stroke(curve(load / 100)); g.setLineDash([]);
      const x = X(clamp(rpm, 0, maxR)), y = Y(tqNorm(rpm) * load / 100);
      g.strokeStyle = rgba(T.amber, 0.4); g.beginPath(); g.moveTo(x, y0 + ph); g.lineTo(x, y); g.stroke();
      g.fillStyle = '#fff'; glowOn(g, T.amber, 16); circ(g, x, y, Math.max(4, ph * 0.04)); g.fill(); g.shadowBlur = 0;
      g.strokeStyle = T.amber; g.lineWidth = 2; circ(g, x, y, Math.max(7, ph * 0.07) * (1 + 0.15 * pulse(t, 5))); g.stroke();
    }
    if (!wd && ph > 40) for (let k = 0; k < maxR; k += 2000) text(g, `${k / 1000}k`, X(k) + 3, y0 + ph + p * 0.8, 500, clamp(ph * 0.08, 8, 12), T.sub, 'left');
  };

  // ---- air: a breathing gauge for the air going in (intake temp, outside temp, manifold pressure)
  G.air = (g, w, h, t) => {
    const it = sm.intake, amb = sm.ambient != null ? sm.ambient : null, map = sm.map, rpm = sm.rpm || 0, load = sm.load || 0;
    const st = state(); st.br = (st.br || 0) + DT * (0.25 + rpm / 2400);
    const ph = st.br * TAU, amp = it == null ? 0.02 : 0.04 + load / 1000;
    const hot = it == null ? 0 : clamp((it - 10) / 50, 0, 1), col = mix(T.b3, '#ff7a2a', hot);
    const wd = isWide(w, h), m = Math.min(w, h);
    const R = wd ? h * 0.32 : m * 0.25, cx = wd ? h * 0.55 : w / 2, cy = wd ? h / 2 : h * 0.4;
    g.save(); g.globalCompositeOperation = 'lighter';
    for (let k = 0; k < 3; k++) {   // ripples flowing in
      const q = frac(st.br * 0.5 + k / 3), rad2 = R * (1.9 - q * 0.9);
      g.strokeStyle = rgba(col, 0.35 * q); g.lineWidth = Math.max(1, R * 0.04); circ(g, cx, cy, rad2); g.stroke();
    }
    const s = 1 + amp * Math.sin(ph), gr = g.createRadialGradient(cx, cy, 0, cx, cy, R * s);
    gr.addColorStop(0, rgba(mix(col, '#ffffff', 0.4), 0.55)); gr.addColorStop(0.7, rgba(col, 0.28)); gr.addColorStop(1, rgba(col, 0.05));
    g.fillStyle = gr; circ(g, cx, cy, R * s); g.fill(); g.restore();
    g.strokeStyle = rgba(col, 0.8); g.lineWidth = Math.max(1.5, R * 0.03); glowOn(g, col, R * 0.3); circ(g, cx, cy, R * s); g.stroke(); g.shadowBlur = 0;
    const tf = (v) => (v == null ? '--' : fmtTemp(v)), mapS = map == null ? '--' : `${Math.round(map)} kPa`;
    const out = amb != null ? tf(amb) : sm.wxTemp != null ? `${Math.round(sm.wxTemp)}°` : '--';
    if (wd) {
      const x = h * 1.15, cw = (w - x - 8) / 3, fs = clamp(h * 0.14, 9, 16);
      [['Intake', tf(it)], ['Outside', out], ['Manifold', mapS]].forEach(([l, v], i) => {
        text(g, l, x + i * cw, h * 0.3, 600, fs, T.sub, 'left'); fit(g, v, x + i * cw, h * 0.62, cw * 0.92, 300, h * 0.3, T.text, 'left');
      });
      return;
    }
    valText(g, tf(it), cx, cy, R * 0.62, T.text);
    text(g, 'Intake air', cx, cy + R * 0.55, 600, R * 0.17, T.sub);
    const y = h * 0.86, fs = clamp(m * 0.05, 9, 18);
    text(g, 'Outside', w * 0.28, y - fs, 600, fs * 0.8, T.sub); text(g, out, w * 0.28, y + fs * 0.3, 300, fs * 1.4, T.text);
    text(g, 'Manifold', w * 0.72, y - fs, 600, fs * 0.8, T.sub); text(g, mapS, w * 0.72, y + fs * 0.3, 300, fs * 1.4, T.text);
    if (it == null) text(g, noVal(), cx, cy - R * 0.5, 500, R * 0.14, T.sub);
  };

  // ---- battery: a cell that fills with voltage, current flowing in when charging
  G.battery = (g, w, h, t) => {
    const v = sm.volts, has = v != null, k = has ? clamp((v - 11.6) / (14.6 - 11.6), 0.03, 1) : 0;
    const chg = has && v >= 13.2, col = !has ? T.sub : v < 11.8 ? T.red : v < 12.4 ? T.amber : v > 15.2 ? T.red : T.green;
    const word = !has ? noVal() : v > 15.2 ? 'Overcharging!' : chg ? 'Charging' : v >= 12.4 ? 'Engine off' : 'Low';
    const wd = isWide(w, h), m = Math.min(w, h);
    const bw = wd ? Math.min(h * 1.5, w * 0.42) : Math.min(w * 0.7, m * 0.95), bh = wd ? Math.min(h * 0.56, bw * 0.5) : bw * 0.42, bx = wd ? h * 0.25 : (w - bw) / 2, by = wd ? (h - bh) / 2 : h * 0.18;
    const r = bh * 0.16;
    rr(g, bx, by, bw, bh, r); g.fillStyle = 'rgba(0,0,0,.35)'; g.fill(); g.strokeStyle = 'rgba(255,255,255,.4)'; g.lineWidth = Math.max(2, bh * 0.04); g.stroke();
    rr(g, bx + bw, by + bh * 0.3, bw * 0.05, bh * 0.4, r * 0.3); g.fillStyle = 'rgba(255,255,255,.4)'; g.fill();   // terminal
    if (has) {
      const pd = bh * 0.09, fw = (bw - pd * 2) * k;
      g.save(); rr(g, bx + pd, by + pd, Math.max(r, fw), bh - pd * 2, r * 0.6); g.clip();
      const gr = g.createLinearGradient(0, by, 0, by + bh); gr.addColorStop(0, mix(col, '#ffffff', 0.35)); gr.addColorStop(0.5, col); gr.addColorStop(1, mix(col, '#000000', 0.4));
      g.fillStyle = gr; g.fillRect(bx, by, bw, bh);
      if (chg) {   // chevrons flowing in
        g.strokeStyle = 'rgba(255,255,255,.45)'; g.lineWidth = Math.max(2, bh * 0.08); g.lineCap = 'round'; const sp = bh * 0.5, off = (t * bh * 0.8) % sp;
        g.beginPath(); for (let x = bx - sp + off; x < bx + bw; x += sp) { g.moveTo(x, by + bh * 0.25); g.lineTo(x + bh * 0.18, by + bh / 2); g.lineTo(x, by + bh * 0.75); } g.stroke();
      }
      g.fillStyle = 'rgba(255,255,255,.18)'; g.fillRect(bx, by + pd, bw, bh * 0.12); g.restore();
      g.save(); glowOn(g, col, bh * 0.4); g.strokeStyle = rgba(col, 0.6); g.lineWidth = 1.5; rr(g, bx + pd, by + pd, Math.max(r, fw), bh - pd * 2, r * 0.6); g.stroke(); g.restore();
    }
    if (chg) {   // lightning bolt
      const cx = bx + bw / 2, cy = by + bh / 2, s = bh * 0.3;
      g.fillStyle = `rgba(255,255,255,${(0.6 + 0.4 * pulse(t, 3)).toFixed(2)})`; g.beginPath();
      g.moveTo(cx + s * 0.15, cy - s); g.lineTo(cx - s * 0.45, cy + s * 0.12); g.lineTo(cx - s * 0.02, cy + s * 0.12); g.lineTo(cx - s * 0.15, cy + s); g.lineTo(cx + s * 0.45, cy - s * 0.12); g.lineTo(cx + s * 0.02, cy - s * 0.12); g.closePath(); g.fill();
    }
    if (wd) {
      const x = bx + bw * 1.12, fs = clamp(h * 0.14, 9, 16);
      text(g, 'Battery', x, h * 0.25, 650, fs, T.sub, 'left');
      fit(g, has ? `${v.toFixed(1)} V` : '--', x, h * 0.55, w - x - 8, 300, h * 0.36, T.text, 'left');
      fit(g, word, x, h * 0.83, w - x - 8, 600, fs, col, 'left');
      return;
    }
    valText(g, has ? `${v.toFixed(1)} V` : '--', w / 2, by + bh + m * 0.17, m * 0.2, T.text);
    text(g, 'Battery', w / 2, by + bh + m * 0.31, 600, m * 0.06, T.sub);
    fit(g, word, w / 2, by + bh + m * 0.4, w * 0.9, 600, m * 0.055, col);
  };

  // ---- now playing: song progress ring, title, artist, an equalizer
  const mediaPos = (md) => { let p2 = md.position || 0; if (md.status === 'playing') p2 += (Date.now() / 1000 - (md.at || 0)) * 1000; return md.duration ? Math.min(p2, md.duration) : p2; };
  G.nowplaying = (g, w, h, t) => {
    const md = (S.state || {}).media || {}, has = !!md.title && md.status !== 'stopped', play = has && md.status === 'playing';
    const pos = has ? mediaPos(md) / 1000 : 0, dur = has ? (md.duration || 0) / 1000 : 0, k = dur ? clamp(pos / dur, 0, 1) : 0;
    const times = has ? (dur ? `${fmtDur(pos)} / ${fmtDur(dur)}` : fmtDur(pos)) : '';
    const eq = (x, y, ww, hh, n) => {
      const bw = ww / n;
      for (let i = 0; i < n; i++) {
        const lv = play ? 0.2 + 0.8 * Math.abs(Math.sin(t * (3 + (i % 4)) + i * 1.7) * Math.sin(t * 1.3 + i)) : 0.08;
        const bh = hh * lv, gr = g.createLinearGradient(0, y - bh, 0, y); gr.addColorStop(0, T.accent); gr.addColorStop(1, T.b2);
        g.fillStyle = gr; rr(g, x + i * bw + bw * 0.18, y - bh, bw * 0.64, bh, bw * 0.3); g.fill();
      }
    };
    if (isWide(w, h)) {
      const p = clamp(h * 0.12, 6, 16), ew = Math.min(w * 0.18, h * 1.2);
      eq(p, h * 0.78, ew, h * 0.56, 7);
      const x = p * 2 + ew, tw = w - x - p;
      fit(g, has ? md.title : 'Nothing playing', x, h * 0.3, tw, 650, clamp(h * 0.24, 11, 28), has ? T.text : T.sub, 'left', 0.7);
      fit(g, has ? `${md.artist || ''}${times ? `   ${times}` : ''}` : '', x, h * 0.56, tw, 500, clamp(h * 0.15, 9, 17), T.sub, 'left');
      rr(g, x, h * 0.74, tw, clamp(h * 0.07, 3, 7), 3); g.fillStyle = T.faint; g.fill();
      if (k) { rr(g, x, h * 0.74, Math.max(4, tw * k), clamp(h * 0.07, 3, 7), 3); g.fillStyle = T.accent; glowOn(g, T.accent, 10); g.fill(); g.shadowBlur = 0; }
      return;
    }
    const r = Math.min(w, h) * 0.42, cx = w / 2, cy = h / 2, tw = r * 0.09;
    arc(g, cx, cy, r, 0, TAU, tw, T.faint);
    if (k) {
      const a0 = -Math.PI / 2, a1 = a0 + TAU * k, gr = g.createLinearGradient(cx - r, cy - r, cx + r, cy + r);
      gr.addColorStop(0, T.b3); gr.addColorStop(1, T.accent);
      g.shadowColor = T.accent; arc(g, cx, cy, r, a0, a1, tw, gr, r * 0.12, 'round', true);
      g.fillStyle = '#fff'; glowOn(g, T.accent, r * 0.1); circ(g, cx + r * Math.cos(a1), cy + r * Math.sin(a1), tw * 0.75); g.fill(); g.shadowBlur = 0;
    }
    eq(cx - r * 0.42, cy - r * 0.18, r * 0.84, r * 0.4, 9);
    fit(g, has ? md.title : 'Nothing playing', cx, cy + r * 0.08, r * 1.55, 650, r * 0.16, has ? T.text : T.sub, 'center', 0.7);
    fit(g, has ? md.artist || '' : '', cx, cy + r * 0.3, r * 1.45, 500, r * 0.11, T.sub);
    if (times) text(g, times, cx, cy + r * 0.52, 500, r * 0.1, T.accent);
    if (has && !play) text(g, 'Paused', cx, cy - r * 0.55, 700, r * 0.09, T.sub);
  };

  // ---- throttle vs load: twin LED columns with peak hold
  G.dualbars = (g, w, h, t) => {
    const thr = sm.throttle, load = sm.load, st = state(), wd = isWide(w, h);
    const bars = [['Throttle', thr, 'pt'], ['Load', load, 'pl']];
    const colOf = (q) => (q > 0.85 ? T.red : q > 0.6 ? T.amber : T.accent);
    for (const [, v, pk] of bars) { const q = v == null ? 0 : v / 100; st[pk] = Math.max(q, (st[pk] || 0) - DT * 0.25); }
    const n = wd ? 24 : 18, p = clamp(Math.min(w, h) * 0.07, 6, 18);
    bars.forEach(([lab, v, pk], bi) => {
      const q = v == null ? 0 : clamp(v / 100, 0, 1), peak = st[pk] || 0;
      if (wd) {
        const lw = Math.min(w * 0.22, 120), y = p + bi * (h - p * 2) / 2, hh = (h - p * 2) / 2, bh = hh * 0.5, x0 = p + lw, bw = w - x0 - p;
        text(g, lab, p, y + hh * 0.3, 600, clamp(hh * 0.28, 9, 16), T.sub, 'left');
        text(g, v == null ? '--' : `${Math.round(v)}%`, p, y + hh * 0.72, 300, clamp(hh * 0.42, 10, 30), T.text, 'left');
        const sw = bw / n;
        for (let i = 0; i < n; i++) {
          const f2 = (i + 1) / n, on = f2 <= q + 1e-6, isPk = Math.abs(f2 - peak) < 0.5 / n, c = colOf(f2);
          g.fillStyle = on || isPk ? c : 'rgba(255,255,255,.07)'; if (on) glowOn(g, c, bh * 0.6);
          g.fillRect(x0 + i * sw + sw * 0.12, y + (hh - bh) / 2, sw * 0.76, bh); g.shadowBlur = 0;
        }
        return;
      }
      const cw = (w - p * 3) / 2, x = p + bi * (cw + p), top = p + clamp(h * 0.16, 16, 60), bot = h - p - clamp(h * 0.1, 12, 40), colH = bot - top;
      text(g, v == null ? '--' : `${Math.round(v)}%`, x + cw / 2, p + (top - p) * 0.5, 300, clamp((top - p) * 0.7, 10, 54), T.text);
      text(g, lab, x + cw / 2, bot + (h - bot) * 0.45, 600, clamp((h - bot) * 0.45, 9, 18), T.sub);
      const sh = colH / n, bw = Math.min(cw * 0.7, colH * 0.5), bx = x + (cw - bw) / 2;
      for (let i = 0; i < n; i++) {
        const f2 = (i + 1) / n, on = f2 <= q + 1e-6, isPk = Math.abs(f2 - peak) < 0.5 / n && peak > 0.02, c = colOf(f2);
        g.fillStyle = on || isPk ? c : 'rgba(255,255,255,.07)'; if (on) glowOn(g, c, sh * 0.8);
        rr(g, bx, bot - (i + 1) * sh + sh * 0.14, bw, sh * 0.72, Math.min(3, sh * 0.2)); g.fill(); g.shadowBlur = 0;
      }
    });
    if (thr == null && load == null) text(g, noVal(), w / 2, h / 2, 500, clamp(Math.min(w, h) * 0.06, 9, 16), T.sub);
  };

  // ---------------------------------------------------------------- round 3 gauges (2026.11.08)
  // Static parts are cached (layer / sprite); nothing here uses shadowBlur per frame: glows are wide translucent strokes.
  function sprite(key, w, h, draw) {   // an offscreen picture not tied to a position (cached like layer())
    w = Math.max(1, Math.ceil(w)); h = Math.max(1, Math.ceil(h));
    key = `sp|${key}|${w}x${h}|${DPR}|${themeKey}|${FACE}`;
    let c = CACHE.get(key);
    if (c) { CACHE.delete(key); CACHE.set(key, c); return c; }
    c = document.createElement('canvas'); c.width = Math.round(w * DPR); c.height = Math.round(h * DPR);
    const x = c.getContext('2d'); x.setTransform(DPR, 0, 0, DPR, 0, 0); draw(x, w, h);
    CACHE.set(key, c);
    while (CACHE.size > CACHE_MAX) CACHE.delete(CACHE.keys().next().value);
    return c;
  }
  const spd = (kmh) => (metric() ? kmh : kmh * 0.621371), SU = () => (metric() ? 'km/h' : 'mph');
  const glowLine = (g, path, col, wd) => { g.strokeStyle = rgba(col, 0.22 * Math.min(1.5, GK)); g.lineWidth = wd * 3.2; g.stroke(path); g.strokeStyle = col; g.lineWidth = wd; g.stroke(path); };
  // the big number in the face's numerals, shrunk to fit maxW
  function bigNum(g, s, x, y, maxW, px, col, align = 'center') {
    s = String(s); g.font = F(300, px); let tw = g.measureText(s).width;
    if (tw > maxW) { px *= maxW / tw; tw = maxW; }
    valText(g, s, align === 'left' ? x + tw / 2 : align === 'right' ? x - tw / 2 : x, y, px, col, 200);
    return tw;
  }
  // a line of the last minute (HIST, 10 samples/s) in a box; returns the newest point
  function spark(g, arr, x0, y0, pw, ph, max, conv, col) {
    const step = Math.max(1, Math.floor(HN / Math.max(30, pw / 3))), sh = (hAcc / 0.1) * (pw / HN);
    const p = new Path2D(); let open = false, fx = null, lx = 0, ly = 0;
    for (let i = 0; i < HN; i += step) {
      const v = arr[(hHead + i) % HN];
      if (Number.isNaN(v)) { open = false; continue; }
      const x = x0 + (pw * i) / (HN - 1) - sh, y = y0 + ph * (1 - clamp(conv(v) / max, 0, 1));
      if (!open) { p.moveTo(x, y); open = true; if (fx == null) fx = x; } else p.lineTo(x, y);
      lx = x; ly = y;
    }
    if (fx == null) return null;
    const f = new Path2D(p); f.lineTo(lx, y0 + ph); f.lineTo(fx, y0 + ph); f.closePath();
    const gr = g.createLinearGradient(0, y0, 0, y0 + ph); gr.addColorStop(0, rgba(col, 0.3)); gr.addColorStop(1, rgba(col, 0));
    g.fillStyle = gr; g.fill(f);
    g.lineJoin = 'round'; g.lineCap = 'round'; glowLine(g, p, col, 2);
    return [lx, ly];
  }
  const title = (g, s, x, y, px, align = 'left') => text(g, s, x, y, 650, px, T.sub, align);

  // ---- big digital speed with a trend arrow and the last minute underneath
  G.bigspeed = (g, w, h, t) => {
    const v = sm.kmh == null ? null : spd(sm.kmh), a = trip.accel, s = v == null ? '--' : String(Math.round(v));
    const trend = v == null || v < 2 ? 0 : a > 2.5 ? 1 : a < -2.5 ? -1 : 0, tc = trend > 0 ? T.green : T.red, max = metric() ? 160 : 100;
    const chev = (x, y, sz) => {
      if (!trend) return;
      g.strokeStyle = tc; g.lineWidth = Math.max(2, sz * 0.18); g.lineCap = 'round'; g.lineJoin = 'round';
      for (let k = 0; k < 2; k++) {
        const yy = y + trend * k * sz * 0.5; g.globalAlpha = k ? 0.4 : 1;
        g.beginPath(); g.moveTo(x - sz * 0.45, yy + trend * sz * 0.22); g.lineTo(x, yy - trend * sz * 0.22); g.lineTo(x + sz * 0.45, yy + trend * sz * 0.22); g.stroke();
      }
      g.globalAlpha = 1;
    };
    if (isWide(w, h)) {
      const p = clamp(h * 0.12, 6, 16), lw = Math.min(w * 0.45, h * 2.4);
      const tw = bigNum(g, s, p, h * 0.52, lw - p - h * 0.75, h * 0.82, T.text, 'left');
      text(g, SU(), p + tw + h * 0.08, h * 0.78, 600, clamp(h * 0.16, 9, 18), T.sub, 'left');
      chev(p + tw + h * 0.3, h * 0.36, h * 0.3);
      spark(g, HIST.kmh, lw, p, w - lw - p, h - p * 2, max, spd, T.accent);
      return;
    }
    const m = Math.min(w, h);
    title(g, 'Speed', w * 0.07, h * 0.1, clamp(m * 0.06, 10, 20));
    const tw = bigNum(g, s, w / 2, h * 0.42, w * 0.74, Math.min(h * 0.5, w * 0.55), T.text);
    text(g, SU(), w / 2, h * 0.42 + Math.min(h * 0.5, w * 0.55) * 0.52, 600, clamp(m * 0.065, 10, 26), T.sub);
    chev(Math.min(w * 0.93, w / 2 + tw / 2 + m * 0.09), h * 0.38, m * 0.11);
    if (v == null) text(g, noVal(), w / 2, h * 0.86, 500, clamp(m * 0.05, 9, 16), T.sub);
    else spark(g, HIST.kmh, w * 0.08, h * 0.74, w * 0.84, h * 0.2, max, spd, T.accent);
  };

  // ---- speedometer with the tach as an inner ring
  G.twin = (g, w, h, t) => {
    const km = metric(), v = sm.kmh == null ? null : spd(sm.kmh), max = km ? 220 : 140, rpm = sm.rpm;
    const RL = O.redline, maxK = Math.max(7, Math.floor(RL / 1000) + 1), MAX = maxK * 1000, red = RL / MAX;
    const fr = rpm == null ? 0 : clamp(rpm / MAX, 0, 1), hot = rpm != null && rpm > RL, rc = hot ? T.red : fr > red - 0.12 ? T.amber : T.b3;
    if (isWide(w, h)) return wide(g, w, h, t, { name: 'Speed · rpm', val: v == null ? '--' : String(Math.round(v)), unit: SU(), f: fr, segs: Math.max(12, Math.round(w / 10)),
      segCol: (x) => (x > red ? T.red : x > red - 0.12 ? T.amber : T.accent), note: rpm == null ? noVal() : `${Math.round(rpm / 50) * 50} rpm`, noteCol: hot ? T.red : T.sub });
    const r = Math.min(w * 0.455, h * 0.54), cx = w / 2, cy = h / 2 + r * 0.17, f = v == null ? 0 : clamp(v / max, 0, 1);
    dial(g, cx, cy, r, { f, labels: (km ? [0, 40, 80, 120, 160, 200, 220] : [0, 20, 40, 60, 80, 100, 120, 140]).map(String), col: T.accent });
    const ri = r * 0.5, tw = r * 0.055;
    layer(g, `twin|${cx | 0},${cy | 0},${r | 0}|${maxK}|${RL}`, cx, cy, ri * 1.25, (x) => {
      arc(x, cx, cy, ri, A0, A0 + SWEEP, tw, P.light ? 'rgba(0,0,0,.1)' : 'rgba(255,255,255,.08)', 0, 'butt');
      arc(x, cx, cy, ri + tw * 0.95, A0 + SWEEP * red, A0 + SWEEP, tw * 0.3, T.red, 0, 'butt');
      x.strokeStyle = P.light ? 'rgba(0,0,0,.45)' : 'rgba(255,255,255,.4)'; x.lineWidth = 1; x.beginPath();
      for (let i = 0; i <= maxK; i++) { const a = A0 + (SWEEP * i) / maxK; x.moveTo(cx + (ri - tw * 0.9) * Math.cos(a), cy + (ri - tw * 0.9) * Math.sin(a)); x.lineTo(cx + (ri - tw * 1.6) * Math.cos(a), cy + (ri - tw * 1.6) * Math.sin(a)); }
      x.stroke();
    });
    if (fr > 0.003) arc(g, cx, cy, ri, A0, A0 + SWEEP * fr, tw, rc, 0, 'butt');
    text(g, rpm == null ? '--' : String(Math.round(rpm / 50) * 50), cx, cy - r * 0.24, 500, r * 0.1, hot ? T.red : T.text);
    text(g, 'rpm', cx, cy - r * 0.14, 600, r * 0.05, T.sub);
    needle(g, cx, cy, r * 0.82, A0 + SWEEP * f, T.accent, Math.max(3, r * 0.03));
    readout(g, cx, cy, r, v == null ? '--' : String(Math.round(v)), SU(), T.text);
  };

  // ---- artificial horizon: the nose pitches up when you speed up, down when you brake
  G.horizon = (g, w, h, t) => {
    const has = sm.kmh != null, gs = has ? trip.accel / 35.3 : 0;
    if (isWide(w, h)) return G.gforce(g, w, h, t);
    const m = Math.min(w, h), r = m * 0.4, cx = w / 2, cy = h / 2 + m * 0.02, st = state();
    st.p = (st.p || 0) + (clamp(gs, -0.8, 0.8) - (st.p || 0)) * Math.min(1, DT * 4);
    const ppg = r * 1.6;   // pixels per g of pitch
    const spr = sprite(`hz|${r | 0}`, r * 2, r * 5.4, (x, W, H) => {
      const mid = H / 2, sky = x.createLinearGradient(0, 0, 0, mid);
      sky.addColorStop(0, mix(T.b3, '#061a3a', 0.6)); sky.addColorStop(1, mix(T.b3, '#9fd3ff', 0.45));
      x.fillStyle = sky; x.fillRect(0, 0, W, mid);
      const gr = x.createLinearGradient(0, mid, 0, H); gr.addColorStop(0, '#6b4524'); gr.addColorStop(1, '#22140a');
      x.fillStyle = gr; x.fillRect(0, mid, W, H - mid);
      x.fillStyle = '#ffffff'; x.fillRect(0, mid - 1, W, 2);
      x.strokeStyle = 'rgba(255,255,255,.85)'; x.lineWidth = Math.max(1, r * 0.012); x.fillStyle = 'rgba(255,255,255,.85)';
      x.font = `600 ${Math.round(r * 0.09)}px sans-serif`; x.textBaseline = 'middle';
      for (let k = -6; k <= 6; k++) {
        if (!k) continue;
        const y = mid - k * ppg * 0.125, L = r * (k % 2 ? 0.18 : 0.38);
        x.beginPath(); x.moveTo(W / 2 - L, y); x.lineTo(W / 2 + L, y); x.stroke();
        if (Math.abs(k) === 2) { x.textAlign = 'left'; x.fillText((Math.abs(k) * 0.125).toFixed(2), W / 2 + L + r * 0.04, y); x.textAlign = 'right'; x.fillText((Math.abs(k) * 0.125).toFixed(2), W / 2 - L - r * 0.04, y); }
      }
    });
    g.save(); circ(g, cx, cy, r); g.clip();
    g.drawImage(spr, cx - r, cy - r * 2.7 + st.p * ppg, r * 2, r * 5.4);
    g.restore();
    layer(g, `hzf|${cx | 0},${cy | 0},${r | 0}`, cx, cy, r * 1.2, (x) => {   // bezel, roll scale, the fixed aircraft symbol
      x.strokeStyle = '#15171b'; x.lineWidth = r * 0.12; circ(x, cx, cy, r * 1.06); x.stroke();
      x.strokeStyle = rgba(T.accent, 0.6); x.lineWidth = Math.max(1.5, r * 0.012); circ(x, cx, cy, r * 1.12); x.stroke();
      x.strokeStyle = '#fff'; x.lineWidth = Math.max(1.5, r * 0.015); x.beginPath();
      for (const d of [-60, -45, -30, -20, -10, 0, 10, 20, 30, 45, 60]) { const a = rad(-90 + d), L = d % 30 ? 0.06 : 0.11; x.moveTo(cx + r * Math.cos(a), cy + r * Math.sin(a)); x.lineTo(cx + r * (1 - L) * Math.cos(a), cy + r * (1 - L) * Math.sin(a)); }
      x.stroke();
      x.strokeStyle = T.amber; x.lineWidth = Math.max(3, r * 0.04); x.lineCap = 'round'; x.lineJoin = 'round'; x.beginPath();
      x.moveTo(cx - r * 0.55, cy); x.lineTo(cx - r * 0.18, cy); x.lineTo(cx - r * 0.09, cy + r * 0.09); x.lineTo(cx, cy); x.lineTo(cx + r * 0.09, cy + r * 0.09); x.lineTo(cx + r * 0.18, cy); x.lineTo(cx + r * 0.55, cy); x.stroke();
      x.fillStyle = T.amber; circ(x, cx, cy, r * 0.03); x.fill();
    });
    const word = !has ? noVal() : gs > 0.08 ? 'Speeding up' : gs < -0.08 ? 'Braking' : 'Level';
    text(g, has ? `${gs >= 0 ? '+' : ''}${gs.toFixed(2)} g` : '--', cx, Math.min(h - m * 0.05, cy + r * 1.22), 400, m * 0.075, T.text);
    text(g, word, cx, Math.max(m * 0.04, cy - r * 1.22), 600, m * 0.05, gs < -0.08 ? T.red : T.sub);
  };

  // ---- a ring of moving vs stopped time
  function ring(g, cx, cy, r, parts, tw) {   // parts: [[fraction, color]...] from 12 o'clock
    arc(g, cx, cy, r, 0, TAU, tw, P.light ? 'rgba(0,0,0,.1)' : 'rgba(255,255,255,.08)', 0, 'butt');
    let a = -Math.PI / 2;
    for (const [f, c] of parts) { if (f > 0.002) { arc(g, cx, cy, r, a, a + TAU * Math.min(f, 0.999), tw, c, 0, 'butt'); a += TAU * f; } }
  }
  G.drivetime = (g, w, h, t) => {
    const mv = trip.moveSecs || 0, sp = trip.stopSecs || 0, tot = mv + sp, k = tot > 0 ? mv / tot : 0, has = sm.kmh != null || tot > 0;
    if (isWide(w, h)) return wide(g, w, h, t, { name: 'Driving time', val: fmtDur(mv), f: k, has: tot > 0, barCol: T.accent, note: has ? `Stopped ${fmtDur(sp)} · ${Math.round(k * 100)}% moving` : noVal() });
    const m = Math.min(w, h), r = m * 0.4, cx = w / 2, cy = h / 2, tw = r * 0.09;
    ring(g, cx, cy, r, tot > 0 ? [[k, T.accent], [1 - k, T.amber]] : [], tw);
    const sa = -Math.PI / 2 + frac(Date.now() / 60000) * TAU;   // a dot going round once a minute
    g.fillStyle = '#fff'; circ(g, cx + r * Math.cos(sa), cy + r * Math.sin(sa), tw * 0.32); g.fill();
    title(g, 'Driving', cx, cy - r * 0.42, r * 0.13, 'center');
    bigNum(g, fmtDur(mv), cx, cy - r * 0.05, r * 1.4, r * 0.4, T.text);
    text(g, tot > 0 ? `Stopped ${fmtDur(sp)}` : has ? 'Not moving yet' : noVal(), cx, cy + r * 0.38, 600, r * 0.12, tot > 0 ? T.amber : T.sub);
  };

  // ---- average speed: the dial shows now, the marker and the big number the average
  G.avgspeed = (g, w, h, t) => {
    const km = metric(), max = km ? 160 : 100, cur = sm.kmh == null ? null : spd(sm.kmh);
    const avg = (trip.secs || 0) > 5 ? spd(trip.km / (trip.secs / 3600)) : null;
    if (isWide(w, h)) return wide(g, w, h, t, { name: 'Average speed', val: avg == null ? '--' : String(Math.round(avg)), unit: SU(), f: avg == null ? 0 : avg / max, has: avg != null, barCol: T.accent, dot: true,
      note: cur == null ? noVal() : `Now ${Math.round(cur)} ${SU()}` });
    const r = Math.min(w * 0.43, h * 0.5), cx = w / 2, cy = h / 2 + r * 0.12;
    dial(g, cx, cy, r, { f: cur == null ? 0 : clamp(cur / max, 0, 1), labels: (km ? [0, 40, 80, 120, 160] : [0, 25, 50, 75, 100]).map(String), col: rgba(T.accent, 0.55) });
    if (avg != null) {
      const a = A0 + SWEEP * clamp(avg / max, 0, 1), x = cx + r * 1.13 * Math.cos(a), y = cy + r * 1.13 * Math.sin(a);
      g.save(); g.translate(x, y); g.rotate(a); g.fillStyle = T.amber; g.beginPath(); g.moveTo(-r * 0.07, 0); g.lineTo(r * 0.05, -r * 0.06); g.lineTo(r * 0.05, r * 0.06); g.closePath(); g.fill(); g.restore();
    }
    if (cur != null) needle(g, cx, cy, r * 0.8, A0 + SWEEP * clamp(cur / max, 0, 1), T.accent, Math.max(2.5, r * 0.025));
    valText(g, avg == null ? '--' : String(Math.round(avg)), cx, cy + r * 0.4, r * 0.3, T.text);
    text(g, `average ${SU()}`, cx, cy + r * 0.62, 600, r * 0.085, T.amber);
  };

  // ---- economy now vs this drive's average, as two columns
  G.mpgbars = (g, w, h, t) => {
    const km = metric(), conv = (x) => (km ? x * 0.4251 : x), max = km ? 20 : 50, unit = km ? 'km/L' : 'mpg';
    const now = sm.mpg == null ? null : conv(sm.mpg), avg = trip.mpgAvg && trip.mpgN > 30 ? conv(trip.mpgAvg) : null;
    const better = now != null && avg != null && now >= avg, nc = now == null ? T.sub : avg == null ? T.accent : better ? T.green : T.amber;
    const bars = [['Now', now, nc], ['This drive', avg, T.b3]];
    const p = clamp(Math.min(w, h) * 0.07, 6, 18);
    if (isWide(w, h)) {
      const lw = Math.min(w * 0.22, 130), bh = (h - p * 3) / 2;
      bars.forEach(([lab, v, c], i) => {
        const y = p + i * (bh + p), fs = clamp(bh * 0.45, 9, 20);
        fit(g, lab, p, y + bh / 2, lw - p * 1.5, 650, fs, T.sub, 'left');
        rr(g, lw, y + bh * 0.2, w - lw - p - fs * 3, bh * 0.6, bh * 0.3); g.fillStyle = T.faint; g.fill();
        if (v != null) { rr(g, lw, y + bh * 0.2, Math.max(bh * 0.6, (w - lw - p - fs * 3) * clamp(v / max, 0, 1)), bh * 0.6, bh * 0.3); g.fillStyle = c; g.fill(); }
        text(g, v == null ? '--' : v.toFixed(km ? 1 : 0), w - p, y + bh / 2, 400, fs * 1.4, T.text, 'right');
      });
      return;
    }
    const top = clamp(h * 0.16, 20, 70), bot = h - clamp(h * 0.14, 18, 50), cw = (w - p * 3) / 2, ph = bot - top - p;
    title(g, `Economy (${unit})`, p, top * 0.45, clamp(top * 0.32, 10, 20));
    bars.forEach(([lab, v, c], i) => {
      const x = p + i * (cw + p), bw = cw * 0.5, bx = x + (cw - bw) / 2, fh = v == null ? 0 : ph * 0.82 * clamp(v / max, 0, 1);
      rr(g, bx, top + ph * 0.18, bw, ph * 0.82, Math.min(10, bw * 0.15)); g.fillStyle = T.faint; g.fill();
      if (fh > 1) {
        const gr = g.createLinearGradient(0, top + p + ph - fh, 0, top + ph); gr.addColorStop(0, c); gr.addColorStop(1, rgba(c, 0.35));
        rr(g, bx, top + ph - fh, bw, fh, Math.min(10, bw * 0.15)); g.fillStyle = gr; g.fill();
      }
      fit(g, v == null ? '--' : v.toFixed(km ? 1 : 0), x + cw / 2, top + ph * 0.08, cw, 300, Math.min(cw * 0.36, ph * 0.16), T.text);
      fit(g, lab, x + cw / 2, bot + (h - bot) * 0.45, cw, 600, clamp((h - bot) * 0.45, 9, 18), i ? T.sub : nc);
    });
    if (now == null && avg == null) text(g, noVal(), w / 2, top + ph / 2, 500, clamp(Math.min(w, h) * 0.05, 9, 16), T.sub);
  };

  // ---- what this drive's fuel cost (settings.fuel_price: cents per gallon, or per liter in metric; else a typical price)
  const fuelPrice = () => { const p = Number(settings().fuel_price); return p > 0 ? p / 100 : metric() ? 1.8 : 3.5; };
  const money = (x) => `${settings().currency || '$'}${x < 10 ? x.toFixed(2) : x.toFixed(1)}`;
  G.tripcost = (g, w, h, t) => {
    const km = metric(), L = trip.fuelL || 0, qty = km ? L : L / 3.785, cost = qty * fuelPrice(), dist = km ? trip.km || 0 : (trip.km || 0) * 0.621371;
    const has = sm.maf != null || L > 0, per = dist > 0.5 ? cost / dist : null;
    const note = !has ? noVal() : `${qty.toFixed(2)} ${km ? 'L' : 'gal'}${per != null ? ` · ${(per * 100).toFixed(0)}¢ per ${km ? 'km' : 'mile'}` : ''}`;
    if (isWide(w, h)) return wide(g, w, h, t, { name: 'Fuel cost this drive', val: has ? money(cost) : '--', f: clamp(qty / (km ? 40 : 10), 0, 1), has, barCol: T.amber, note });
    const m = Math.min(w, h), cx = w / 2;
    layer(g, `pump|${w | 0},${h | 0}`, cx, h * 0.24, m * 0.14, (x) => {   // a fuel pump icon
      const s = m * 0.1, x0 = cx - s * 0.55, y0 = h * 0.24 - s * 0.65;
      x.strokeStyle = T.amber; x.lineWidth = Math.max(2, s * 0.12); x.lineJoin = 'round'; x.lineCap = 'round';
      x.strokeRect(x0, y0, s * 0.8, s * 1.3); x.fillStyle = rgba(T.amber, 0.25); x.fillRect(x0 + s * 0.15, y0 + s * 0.15, s * 0.5, s * 0.35);
      x.beginPath(); x.moveTo(x0 + s * 0.8, y0 + s * 0.35); x.lineTo(x0 + s * 1.05, y0 + s * 0.55); x.lineTo(x0 + s * 1.05, y0 + s * 1.05); x.lineTo(x0 + s * 1.2, y0 + s * 1.05); x.lineTo(x0 + s * 1.2, y0 + s * 0.3); x.stroke();
    });
    bigNum(g, has ? money(cost) : '--', cx, h * 0.5, w * 0.82, m * 0.24, T.text);
    text(g, 'Fuel this drive', cx, h * 0.66, 600, clamp(m * 0.06, 10, 22), T.sub);
    fit(g, note, cx, h * 0.78, w * 0.9, 500, clamp(m * 0.05, 9, 18), T.sub);
    fit(g, settings().fuel_price ? `at ${money(fuelPrice())} per ${km ? 'L' : 'gal'}` : `at about ${money(fuelPrice())} per ${km ? 'L' : 'gal'}`, cx, h * 0.88, w * 0.9, 400, clamp(m * 0.04, 8, 14), rgba(T.text, 0.45));
  };

  // ---- three thermometers: coolant, oil, intake air
  const TEMPS = [['Coolant', 'coolant', 40, 130, (c) => (c < 71 ? T.blue : c < 107 ? T.green : c < 115 ? T.amber : T.red)],
    ['Oil', 'oil', 40, 150, (c) => (c < 60 ? T.blue : c < 120 ? T.green : c < 130 ? T.amber : T.red)],
    ['Intake', 'intake', -20, 80, (c) => (c < 0 ? T.blue : c < 45 ? T.accent : c < 60 ? T.amber : T.red)]];
  G.temps = (g, w, h, t) => {
    const p = clamp(Math.min(w, h) * 0.06, 6, 16);
    if (isWide(w, h)) {
      const cw = (w - p * 2) / 3;
      TEMPS.forEach(([lab, k, lo, hi, cf], i) => {
        const v = sm[k], x = p + i * cw, fs = clamp(h * 0.16, 9, 18), bw = cw * 0.8, by = h * 0.78, bh = clamp(h * 0.09, 4, 10);
        text(g, lab, x, h * 0.22, 650, fs, T.sub, 'left');
        fit(g, v == null ? '--' : fmtTemp(v), x, h * 0.5, bw, 300, h * 0.36, T.text, 'left');
        rr(g, x, by, bw, bh, bh / 2); g.fillStyle = T.faint; g.fill();
        if (v != null) { rr(g, x, by, Math.max(bh, bw * clamp((v - lo) / (hi - lo), 0, 1)), bh, bh / 2); g.fillStyle = cf(v); g.fill(); }
      });
      return;
    }
    const cw = (w - p * 2) / 3, top = h * 0.2, bot = h * 0.8, tr = Math.min(cw * 0.12, h * 0.035), br = tr * 2.1;
    layer(g, `tmp3|${w | 0},${h | 0}`, w / 2, h / 2, Math.max(w, h), (x) => {   // the glass tubes
      for (let i = 0; i < 3; i++) {
        const cx = p + cw * (i + 0.5);
        x.beginPath(); x.moveTo(cx - tr, bot - br * 0.8); x.lineTo(cx - tr, top + tr); x.arc(cx, top + tr, tr, Math.PI, 0); x.lineTo(cx + tr, bot - br * 0.8);
        x.arc(cx, bot, br, -Math.PI / 2 + 0.5, Math.PI * 1.5 - 0.5); x.closePath();
        x.fillStyle = 'rgba(0,0,0,.3)'; x.fill(); x.strokeStyle = 'rgba(255,255,255,.35)'; x.lineWidth = 1.5; x.stroke();
        x.strokeStyle = 'rgba(255,255,255,.25)'; x.lineWidth = 1; x.beginPath();
        for (let k = 0; k <= 8; k++) { const y = top + tr * 2 + ((bot - br - top - tr * 2) * k) / 8; x.moveTo(cx + tr + 3, y); x.lineTo(cx + tr + (k % 4 ? 7 : 11), y); }
        x.stroke();
      }
    });
    const any = TEMPS.some(([, k]) => sm[k] != null);
    TEMPS.forEach(([lab, k, lo, hi, cf], i) => {
      const v = sm[k], cx = p + cw * (i + 0.5), c = v == null ? T.sub : cf(v);
      const y1 = bot - br * 0.5, y0 = top + tr * 2 + (bot - br - top - tr * 2) * (1 - clamp(v == null ? 0 : (v - lo) / (hi - lo), 0, 1));
      g.fillStyle = v == null ? 'rgba(255,255,255,.12)' : c; circ(g, cx, bot, br * 0.72); g.fill();
      if (v != null) { g.fillRect(cx - tr * 0.55, y0, tr * 1.1, y1 - y0); g.fillStyle = 'rgba(255,255,255,.5)'; g.fillRect(cx - tr * 0.35, y0, tr * 0.22, y1 - y0); }
      fit(g, v == null ? '--' : fmtTemp(v), cx, top * 0.5, cw * 0.95, 300, Math.min(cw * 0.3, h * 0.12), v != null && c === T.red ? T.red : T.text);
      fit(g, lab, cx, bot + br + (h - bot - br) * 0.5, cw * 0.95, 600, clamp(h * 0.05, 9, 18), T.sub);
    });
    if (!any) text(g, noVal(), w / 2, h * 0.5, 500, clamp(Math.min(w, h) * 0.05, 9, 16), T.sub);
  };

  // ---- battery voltage over the last 10 minutes, with the charging band
  G.voltrace = (g, w, h, t) => {
    const v = sm.volts, lo = 11, hi = 15.5, p = clamp(Math.min(w, h) * 0.07, 6, 18), wd = isWide(w, h);
    const col = v == null ? T.sub : v < 12.2 ? T.red : v < 13.1 ? T.amber : v > 15.2 ? T.red : T.green;
    const word = v == null ? noVal() : v >= 13.2 && v <= 15.2 ? 'Charging' : v > 15.2 ? 'Too high' : v >= 12.4 ? 'Engine off / not charging' : 'Low';
    let x0, y0, pw, ph;
    if (wd) {
      const lw = Math.min(w * 0.3, h * 1.8);
      title(g, 'Battery', p, h * 0.24, clamp(h * 0.15, 10, 18));
      fit(g, v == null ? '--' : `${v.toFixed(1)} V`, p, h * 0.56, lw - p * 2, 300, h * 0.38, T.text, 'left');
      fit(g, word, p, h * 0.84, lw - p * 2, 600, clamp(h * 0.13, 9, 16), col, 'left');
      x0 = lw; y0 = p; pw = w - lw - p; ph = h - p * 2;
    } else {
      const hh = clamp(h * 0.24, 22, 90);
      title(g, 'Battery', p, p + hh * 0.3, hh * 0.24);
      fit(g, v == null ? '--' : `${v.toFixed(1)} V`, w - p, p + hh * 0.5, w * 0.55, 300, hh * 0.72, T.text, 'right');
      fit(g, word, p, p + hh * 0.85, w * 0.5, 600, hh * 0.2, col, 'left');
      x0 = p; y0 = p + hh * 1.2; pw = w - p * 2; ph = h - y0 - p;
    }
    if (pw < 20 || ph < 10) return;
    const Y = (x) => y0 + ph * (1 - clamp((x - lo) / (hi - lo), 0, 1));
    layer(g, `vt|${x0 | 0},${y0 | 0},${pw | 0},${ph | 0}`, x0 + pw / 2, y0 + ph / 2, Math.max(pw, ph), (x) => {
      rr(x, x0, y0, pw, ph, Math.min(10, ph * 0.08)); x.fillStyle = 'rgba(0,0,0,.28)'; x.fill();
      x.fillStyle = rgba(T.green, 0.1); x.fillRect(x0, Y(14.8), pw, Y(13.2) - Y(14.8));
      x.fillStyle = rgba(T.red, 0.1); x.fillRect(x0, Y(12.2), pw, y0 + ph - Y(12.2));
      x.strokeStyle = 'rgba(255,255,255,.08)'; x.lineWidth = 1; x.beginPath();
      for (const k of [12, 13, 14, 15]) { x.moveTo(x0, Y(k)); x.lineTo(x0 + pw, Y(k)); }
      x.stroke();
      for (const k of [12, 13, 14, 15]) text(x, String(k), x0 + 4, Y(k) - 7, 500, clamp(ph * 0.07, 8, 12), 'rgba(255,255,255,.4)', 'left');
    });
    const arr = SH.volts, path = new Path2D(); let open = false, lx = 0, ly = 0;
    for (let i = 0; i < SHN; i++) {
      const val = arr[(shHead + i) % SHN];
      if (Number.isNaN(val)) { open = false; continue; }
      const x = x0 + (pw * i) / SHN, y = Y(val);
      if (!open) { path.moveTo(x, y); open = true; } else path.lineTo(x, y);
      lx = x; ly = y;
    }
    if (v != null) { if (open) path.lineTo(x0 + pw, Y(v)); else path.moveTo(x0 + pw - 1, Y(v)); lx = x0 + pw; ly = Y(v); }
    g.lineJoin = 'round'; g.lineCap = 'round'; glowLine(g, path, col === T.sub ? T.accent : col, 2);
    if (v != null) { g.fillStyle = '#fff'; circ(g, lx - 2, ly, 3.5); g.fill(); }
  };

  // ---- classic LED rev bar: segments that get taller to the right, peak hold
  G.revbar = (g, w, h, t) => {
    const rpm = sm.rpm, RL = O.redline, maxK = Math.max(7, Math.floor(RL / 1000) + 1), MAX = maxK * 1000, N = maxK * 5;
    const f = rpm == null ? 0 : clamp(rpm / MAX, 0, 1), on = Math.round(f * N), st = state(), hot = rpm != null && rpm > RL;
    st.pk = Math.max(on, (st.pk || 0) - DT * 6);
    const wd = isWide(w, h), p = clamp(Math.min(w, h) * 0.06, 5, 16);
    const bx = wd ? Math.min(w * 0.3, h * 2) : p, bw = w - bx - p, by = wd ? h * 0.12 : h * 0.12, bh = wd ? h * 0.56 : h * 0.4;
    const sw = bw / N, segH = (i) => bh * (0.35 + 0.65 * (i / (N - 1)) ** 1.4), colOf = (i) => { const v = (i + 1) / N; return v > RL / MAX ? T.red : v > RL / MAX - 0.15 ? T.amber : T.green; };
    const seg = (pth, i) => { const hh = segH(i); pth.rect(bx + i * sw + sw * 0.14, by + bh - hh, sw * 0.72, hh); };
    layer(g, `rb|${bx | 0},${by | 0},${bw | 0},${bh | 0}|${N}|${RL}|${wd}`, w / 2, h / 2, Math.max(w, h), (x) => {
      const off = new Path2D(); for (let i = 0; i < N; i++) seg(off, i);
      x.fillStyle = 'rgba(255,255,255,.06)'; x.fill(off);
      const fs = clamp(bh * 0.2, 8, 18);
      for (let k = 0; k <= maxK; k++) text(x, String(k), bx + (k / maxK) * bw, by + bh + fs * 0.9, 600, fs, k * 1000 >= RL ? T.red : T.sub);
    });
    const groups = new Map();
    for (let i = 0; i < on; i++) { const c = colOf(i); let pth = groups.get(c); if (!pth) { pth = new Path2D(); groups.set(c, pth); } seg(pth, i); }
    for (const [c, pth] of groups) { g.fillStyle = rgba(c, 0.25 * Math.min(1.5, GK)); g.strokeStyle = g.fillStyle; g.lineWidth = sw * 0.5; g.stroke(pth); g.fillStyle = c; g.fill(pth); }
    const pk = Math.floor(st.pk);
    if (pk > on && pk > 0) { g.fillStyle = colOf(pk - 1); const hh = segH(pk - 1); g.fillRect(bx + (pk - 1) * sw + sw * 0.14, by + bh - hh, sw * 0.72, Math.max(2, hh * 0.08)); }
    const val = rpm == null ? '--' : String(Math.round(rpm / 10) * 10);
    if (wd) { const tw = bigNum(g, val, p, h * 0.42, bx - p * 2, h * 0.5, hot ? T.red : T.text, 'left'); text(g, rpm == null ? noVal() : 'rpm', p, h * 0.8, 600, clamp(h * 0.13, 9, 16), T.sub, 'left'); return tw; }
    bigNum(g, val, w / 2, h * 0.74, w * 0.8, Math.min(h * 0.28, w * 0.3), hot ? T.red : T.text);
    text(g, rpm == null ? noVal() : 'rpm', w / 2, h * 0.92, 600, clamp(Math.min(w, h) * 0.05, 9, 18), T.sub);
  };

  // ---- 0-30 mph launches: a live timer and your last five
  G.launch = (g, w, h, t) => {
    const km = metric(), lab = km ? '0-50 km/h' : '0-30 mph', run = trip.l0 != null ? (performance.now() - trip.l0) / 1000 : null;
    const L = trip.launches || [], shown = run != null ? run : L[0], best = trip.lBest;
    const note = run != null ? 'Timing…' : best ? `Best ${best.toFixed(2)} s` : sm.kmh == null ? noVal() : 'Starts when you pull away from a stop';
    if (isWide(w, h)) return wide(g, w, h, t, { name: lab, val: shown == null ? '--' : shown.toFixed(2), unit: 's', f: shown == null ? 0 : clamp(shown / 8, 0, 1), has: shown != null, barCol: run != null ? T.amber : T.accent, note });
    const m = Math.min(w, h), p = clamp(m * 0.07, 6, 18);
    title(g, lab, p, h * 0.1, clamp(m * 0.06, 10, 20));
    bigNum(g, shown == null ? '--' : shown.toFixed(2), w / 2, h * 0.3, w * 0.8, m * 0.24, run != null ? T.amber : T.text);
    text(g, note, w / 2, h * 0.46, 600, clamp(m * 0.05, 9, 18), run != null ? T.amber : T.sub);
    const top = h * 0.55, rowH = (h - top - p) / 5, mx = Math.max(6, ...L, 0.1);
    for (let i = 0; i < 5; i++) {
      const v = L[i], y = top + i * rowH, isBest = v != null && v === best, bw = (w - p * 2) * 0.72;
      rr(g, p, y + rowH * 0.2, bw, rowH * 0.6, rowH * 0.3); g.fillStyle = T.faint; g.fill();
      if (v != null) { rr(g, p, y + rowH * 0.2, Math.max(rowH * 0.6, bw * clamp(v / mx, 0, 1)), rowH * 0.6, rowH * 0.3); g.fillStyle = isBest ? T.green : rgba(T.accent, 0.6); g.fill(); }
      text(g, v == null ? '' : `${v.toFixed(2)}${isBest ? ' ★' : ''}`, w - p, y + rowH / 2, 500, clamp(rowH * 0.5, 8, 18), isBest ? T.green : T.sub, 'right');
    }
  };

  // ---- idle time: engine running while stopped, and the fuel it burned
  G.idle = (g, w, h, t) => {
    const idle = trip.idleSecs || 0, eng = trip.engSecs || 0, k = eng > 0 ? idle / eng : 0, km = metric();
    const fuel = km ? trip.idleL || 0 : (trip.idleL || 0) / 3.785, has = sm.rpm != null || eng > 0;
    const note = !has ? noVal() : `${Math.round(k * 100)}% of engine time · ${fuel.toFixed(2)} ${km ? 'L' : 'gal'} (${money(fuel * fuelPrice())})`;
    if (isWide(w, h)) return wide(g, w, h, t, { name: 'Idling', val: fmtDur(idle), f: k, has: eng > 0, barCol: k > 0.3 ? T.amber : T.accent, note });
    const m = Math.min(w, h), r = m * 0.38, cx = w / 2, cy = h * 0.44, tw = r * 0.1;
    ring(g, cx, cy, r, [[k, k > 0.3 ? T.amber : T.accent]], tw);
    title(g, 'Idling', cx, cy - r * 0.4, r * 0.14, 'center');
    bigNum(g, fmtDur(idle), cx, cy, r * 1.4, r * 0.42, T.text);
    text(g, eng > 0 ? `${Math.round(k * 100)}%` : '', cx, cy + r * 0.4, 600, r * 0.15, T.sub);
    fit(g, has ? `${fuel.toFixed(2)} ${km ? 'L' : 'gal'} burned idling (${money(fuel * fuelPrice())})` : noVal(), cx, Math.min(h - m * 0.05, cy + r * 1.3), w * 0.92, 500, clamp(m * 0.05, 9, 18), T.sub);
  };

  // ---- engine run time (PID 1F, else counted here)
  G.runtime = (g, w, h, t) => {
    const ecu = sm.runtime != null, secs = ecu ? sm.runtime : trip.engSecs || 0, has = ecu || sm.rpm != null || secs > 0;
    const src = ecu ? 'since the engine started' : has ? 'counted on this screen' : noVal();
    if (isWide(w, h)) return wide(g, w, h, t, { name: 'Engine running', val: has ? fmtDur(secs) : '--', f: frac(secs / 3600), has, barCol: T.accent, note: src });
    const m = Math.min(w, h), r = m * 0.4, cx = w / 2, cy = h / 2, tw = r * 0.06;
    ring(g, cx, cy, r, [[frac(secs / 60), T.accent]], tw);   // fills every minute
    ring(g, cx, cy, r * 0.84, [[frac(secs / 3600), T.b3]], tw * 0.6);   // fills every hour
    title(g, 'Engine running', cx, cy - r * 0.42, r * 0.12, 'center');
    bigNum(g, has ? fmtDur(secs) : '--', cx, cy, r * 1.35, r * 0.4, T.text);
    fit(g, src, cx, cy + r * 0.4, r * 1.5, 500, r * 0.1, T.sub);
  };

  // ---- distance and warm-ups since the trouble codes were cleared (PIDs 31, 30) + stored codes
  G.sincecodes = (g, w, h, t) => {
    const km = metric(), d = sm.dist_clr, dist = d == null ? null : km ? d : d * 0.621371, wu = sm.warmups;
    const codes = ((((S.state || {}).obd || {}).codes) || {}).stored || [], n = codes.length;
    const cl = n ? T.amber : T.green, cw = n ? `${n} trouble code${n > 1 ? 's' : ''} stored` : (((S.state || {}).obd || {}).codes) ? 'No trouble codes' : '';
    const note = [wu != null ? `${Math.round(wu)} warm-ups` : '', cw].filter(Boolean).join(' · ') || noVal();
    if (isWide(w, h)) return wide(g, w, h, t, { name: 'Since codes cleared', val: dist == null ? '--' : String(Math.round(dist)), unit: km ? 'km' : 'mi', f: dist == null ? 0 : clamp(dist / 5000, 0, 1), has: dist != null, barCol: cl, note, noteCol: n ? T.amber : T.sub });
    const m = Math.min(w, h), cx = w / 2;
    layer(g, `cel|${w | 0},${h | 0}|${n ? 1 : 0}`, cx, h * 0.22, m * 0.15, (x) => {   // engine light outline
      const s = m * 0.0085, ox = cx - 12 * s, oy = h * 0.22 - 7 * s;
      x.strokeStyle = n ? T.amber : rgba(T.green, 0.8); x.lineWidth = Math.max(2, s * 1.6); x.lineJoin = 'round';
      x.beginPath(); [[0, 6], [2, 6], [2, 4], [5, 4], [5, 2], [11, 2], [11, 4], [13, 4], [15, 7], [16, 7], [16, 13], [15, 13], [13, 15], [7, 15], [4, 12], [0, 12]].forEach(([a, b], i) => (i ? x.lineTo : x.moveTo).call(x, ox + a * s * 1.5, oy + b * s));
      x.closePath(); x.stroke();
    });
    bigNum(g, dist == null ? '--' : Math.round(dist).toLocaleString(), cx, h * 0.5, w * 0.82, m * 0.22, T.text);
    text(g, `${km ? 'km' : 'miles'} since codes were cleared`, cx, h * 0.66, 600, clamp(m * 0.05, 9, 18), T.sub);
    fit(g, note, cx, h * 0.8, w * 0.9, 600, clamp(m * 0.05, 9, 18), n ? T.amber : dist == null && !cw ? T.sub : T.green);
  };

  // ---- one-number gauges on the small arc
  G.baro = (g, w, h, t) => {   // PID 33, with the altitude it means
    const alt = (kpa) => 44330 * (1 - (kpa / 101.325) ** 0.1903);
    small(g, w, h, t, sm.baro, 70, 105, (v) => (metric() ? `${Math.round(v)}` : (v * 0.2953).toFixed(2)), metric() ? 'Air pressure kPa' : 'Air pressure inHg', () => T.b3,
      (v) => { const a = alt(v); return metric() ? `About ${Math.round(a / 10) * 10} m up` : `About ${(Math.round(a * 3.281 / 50) * 50).toLocaleString()} ft up`; });
  };
  G.timing = (g, w, h, t) => small(g, w, h, t, sm.timing, -10, 50, (v) => `${Math.round(v)}°`, 'Ignition timing', (v) => (v < 0 ? T.amber : T.accent), (v) => (v < 0 ? 'Retarded (knock?)' : 'Spark advance'));
  G.maf = (g, w, h, t) => small(g, w, h, t, sm.maf, 0, 150, (v) => v.toFixed(v < 100 ? 1 : 0), 'Airflow g/s', (v) => (v > 100 ? T.amber : T.accent), (v) => (v < 6 ? 'Idling' : v < 30 ? 'Cruising' : 'Breathing hard'));
  G.cat = (g, w, h, t) => small(g, w, h, t, sm.cat, 0, 900, fmtTemp, 'Catalyst temp', (v) => (v < 250 ? T.blue : v < 760 ? T.green : v < 850 ? T.amber : T.red),
    (v) => (v < 250 ? 'Warming up' : v < 760 ? 'Working' : v < 850 ? 'Very hot' : 'Too hot!'));

  // ---- fuel trims: how much the engine computer is adding (+) or pulling (-) fuel
  G.trims = (g, w, h, t) => {
    const s1 = sm.stft, l1 = sm.ltft, has = s1 != null || l1 != null, tot = (s1 || 0) + (l1 || 0);
    const word = !has ? noVal() : tot > 10 ? 'Running lean: adding fuel' : tot < -10 ? 'Running rich: pulling fuel' : 'Mixture is fine';
    const wc = !has ? T.sub : Math.abs(tot) > 15 ? T.red : Math.abs(tot) > 10 ? T.amber : T.green, wd = isWide(w, h);
    const p = clamp(Math.min(w, h) * 0.07, 6, 18), rows = [['Short term', s1], ['Long term', l1]];
    const top = wd ? p : h * 0.2, bot = wd ? h - p : h * 0.72, lw = wd ? Math.min(w * 0.2, 120) : 0;
    if (!wd) title(g, 'Fuel trim', p, h * 0.1, clamp(Math.min(w, h) * 0.06, 10, 20));
    const rh = (bot - top) / 2, bx = p + lw, bw = w - bx - p - (wd ? Math.min(w * 0.14, 80) : 0);
    rows.forEach(([lab, v], i) => {
      const y = top + i * rh, fs = clamp(rh * (wd ? 0.3 : 0.2), 9, 18), barY = wd ? y + rh * 0.3 : y + rh * 0.42, bh = wd ? rh * 0.4 : rh * 0.3, mid = bx + bw / 2;
      if (wd) text(g, lab, p, y + rh / 2, 600, fs, T.sub, 'left');
      else { text(g, lab, bx, y + rh * 0.18, 600, fs, T.sub, 'left'); text(g, v == null ? '--' : `${v > 0 ? '+' : ''}${v.toFixed(1)}%`, bx + bw, y + rh * 0.18, 400, fs * 1.3, T.text, 'right'); }
      rr(g, bx, barY, bw, bh, bh * 0.3); g.fillStyle = T.faint; g.fill();
      g.fillStyle = rgba(T.green, 0.12); g.fillRect(mid - bw * 0.2, barY, bw * 0.4, bh);   // ±10 % is normal
      if (v != null) { const k = clamp(v / 25, -1, 1), c = Math.abs(v) > 15 ? T.red : Math.abs(v) > 10 ? T.amber : T.accent; g.fillStyle = c; g.fillRect(Math.min(mid, mid + (bw / 2) * k), barY + bh * 0.15, Math.abs((bw / 2) * k), bh * 0.7); }
      g.fillStyle = 'rgba(255,255,255,.7)'; g.fillRect(mid - 1, barY - 3, 2, bh + 6);
      if (wd) text(g, v == null ? '--' : `${v > 0 ? '+' : ''}${v.toFixed(1)}%`, w - p, y + rh / 2, 400, fs * 1.3, T.text, 'right');
    });
    if (!wd) { text(g, '−25%', bx, bot + 4, 500, clamp(h * 0.035, 8, 12), T.sub, 'left'); text(g, '+25%', bx + bw, bot + 4, 500, clamp(h * 0.035, 8, 12), T.sub, 'right'); fit(g, word, w / 2, h * 0.86, w * 0.9, 600, clamp(Math.min(w, h) * 0.055, 9, 18), wc); }
  };

  // ---- engine map: where the engine spends its time (rpm across, load up), with you as a moving dot
  G.enginemap = (g, w, h, t) => {
    const p = clamp(Math.min(w, h) * 0.07, 6, 18), wd = isWide(w, h), fs = clamp(Math.min(w, h) * (wd ? 0.1 : 0.045), 8, 14);
    const top = wd ? p : clamp(h * 0.14, 20, 60), x0 = p + fs * 2.2, y0 = top, pw = w - x0 - p, ph = h - top - p - fs * 1.6;
    if (pw < 30 || ph < 20) return;
    if (!wd) title(g, 'Engine map: rpm × load', p, top * 0.5, clamp(top * 0.32, 10, 18));
    const RL = O.redline;
    layer(g, `em|${x0 | 0},${y0 | 0},${pw | 0},${ph | 0}|${RL}`, w / 2, h / 2, Math.max(w, h), (x) => {
      rr(x, x0, y0, pw, ph, 6); x.fillStyle = 'rgba(0,0,0,.28)'; x.fill();
      x.strokeStyle = 'rgba(255,255,255,.07)'; x.lineWidth = 1; x.beginPath();
      for (let k = 1; k < 8; k++) { const xx = x0 + (pw * k) / 8; x.moveTo(xx, y0); x.lineTo(xx, y0 + ph); }
      for (let k = 1; k < 4; k++) { const yy = y0 + (ph * k) / 4; x.moveTo(x0, yy); x.lineTo(x0 + pw, yy); }
      x.stroke();
      const rx = x0 + pw * clamp(RL / 8000, 0, 1); x.strokeStyle = 'rgba(255,77,77,.6)'; x.setLineDash([4, 4]); x.beginPath(); x.moveTo(rx, y0); x.lineTo(rx, y0 + ph); x.stroke(); x.setLineDash([]);
      for (let k = 0; k <= 8; k += 2) text(x, String(k), x0 + (pw * k) / 8, y0 + ph + fs * 0.9, 500, fs, T.sub);
      text(x, '100%', x0 - 4, y0 + fs * 0.5, 500, fs * 0.9, T.sub, 'right'); text(x, 'load', x0 - 4, y0 + ph / 2, 500, fs * 0.9, T.sub, 'right');
    });
    let mx = 0; for (let i = 0; i < EMAP.length; i++) if (EMAP[i] > mx) mx = EMAP[i];
    const cw = pw / EM_R, ch = ph / EM_L;
    if (mx > 0) for (let i = 0; i < EM_R; i++) for (let j = 0; j < EM_L; j++) {
      const v = EMAP[i * EM_L + j]; if (v <= 0) continue;
      const k = Math.sqrt(v / mx); g.fillStyle = rgba(k > 0.7 ? T.amber : T.accent, 0.12 + 0.6 * k);
      g.fillRect(x0 + i * cw + 1, y0 + ph - (j + 1) * ch + 1, cw - 2, ch - 2);
    }
    const st = state(), rpm = sm.rpm, load = sm.load;
    if (!st.tr) st.tr = [];
    if (rpm != null && load != null) {
      const px = x0 + pw * clamp(rpm / 8000, 0, 1), py = y0 + ph * (1 - clamp(load / 100, 0, 1));
      st.tr.push([px, py]); if (st.tr.length > 24) st.tr.shift();
      const pth = new Path2D(); st.tr.forEach(([a, b], i) => (i ? pth.lineTo(a, b) : pth.moveTo(a, b)));
      g.lineJoin = 'round'; g.lineCap = 'round'; g.strokeStyle = 'rgba(255,255,255,.35)'; g.lineWidth = 2; g.stroke(pth);
      g.fillStyle = rgba(T.accent, 0.3); circ(g, px, py, 9); g.fill(); g.fillStyle = '#fff'; circ(g, px, py, 4); g.fill();
    } else { st.tr.length = 0; text(g, noVal(), x0 + pw / 2, y0 + ph / 2, 500, fs * 1.2, T.sub); }
  };

  // ---- trip odometer: rolling drum digits
  G.odometer = (g, w, h, t) => {
    const km = metric(), val = (trip.km || 0) * (km ? 1 : 0.621371), digits = 5;   // 4 whole + tenths
    const m = Math.min(w, h), wd = isWide(w, h), p = clamp(m * 0.07, 6, 18);
    const dh = wd ? Math.min(h * 0.62, (w * 0.7) / (digits * 0.76)) : Math.min(h * 0.3, (w - p * 2) / (digits + 1) * 1.45), dw = dh * 0.68, gap = dw * 0.08;
    const tot = digits * dw + (digits - 1) * gap, x0 = wd ? p : (w - tot) / 2, y0 = wd ? (h - dh) / 2 : h * 0.42 - dh / 2;
    if (!wd) title(g, 'Trip', p, h * 0.1, clamp(m * 0.06, 10, 20));
    const spr = sprite(`odo|${dw | 0}x${dh | 0}`, dw, dh, (x, W, H) => {   // one drum window
      const gr = x.createLinearGradient(0, 0, 0, H); gr.addColorStop(0, '#000'); gr.addColorStop(0.18, '#1c1d20'); gr.addColorStop(0.5, '#2a2c30'); gr.addColorStop(0.82, '#1c1d20'); gr.addColorStop(1, '#000');
      x.fillStyle = gr; x.fillRect(0, 0, W, H);
    });
    const shade = sprite(`odosh|${dw | 0}x${dh | 0}`, dw, dh, (x, W, H) => {
      const gr = x.createLinearGradient(0, 0, 0, H); gr.addColorStop(0, 'rgba(0,0,0,.85)'); gr.addColorStop(0.25, 'rgba(0,0,0,0)'); gr.addColorStop(0.75, 'rgba(0,0,0,0)'); gr.addColorStop(1, 'rgba(0,0,0,.85)');
      x.fillStyle = gr; x.fillRect(0, 0, W, H);
    });
    const tenths = val * 10, whole = Math.floor(tenths);
    for (let i = 0; i < digits; i++) {
      const place = digits - 1 - i, x = x0 + i * (dw + gap), last = place === 0;   // place 0 = tenths
      const base = Math.floor(whole / 10 ** place) % 10, lower = whole % 10 ** place;
      const roll = last ? frac(tenths) : lower === 10 ** place - 1 ? frac(tenths) : 0;
      g.drawImage(spr, x, y0, dw, dh);
      if (last) { g.fillStyle = '#e9e6dc'; g.fillRect(x, y0, dw, dh); }
      g.save(); g.beginPath(); g.rect(x, y0, dw, dh); g.clip();
      const c = last ? '#141414' : '#f2f2f2', fpx = dh * 0.7;
      text(g, String(base), x + dw / 2, y0 + dh / 2 - roll * dh, 500, fpx, c);
      text(g, String((base + 1) % 10), x + dw / 2, y0 + dh * 1.5 - roll * dh, 500, fpx, c);
      g.restore();
      g.drawImage(shade, x, y0, dw, dh);
      g.strokeStyle = 'rgba(255,255,255,.18)'; g.lineWidth = 1; g.strokeRect(x + 0.5, y0 + 0.5, dw - 1, dh - 1);
    }
    const ux = x0 + tot + dw * 0.25, fs = clamp(dh * 0.24, 9, 22);
    if (wd) { text(g, km ? 'km' : 'mi', ux, y0 + dh * 0.3, 600, fs, T.sub, 'left'); text(g, fmtDur(trip.secs || 0), ux, y0 + dh * 0.75, 500, fs * 0.9, T.sub, 'left'); return; }
    text(g, km ? 'km' : 'miles', w / 2, y0 + dh + fs * 1.2, 600, fs, T.sub);
    text(g, sm.kmh == null && !trip.km ? noVal() : `Driving ${fmtDur(trip.secs || 0)}`, w / 2, y0 + dh + fs * 2.6, 500, fs * 0.85, T.sub);
  };

  // ---- fuel and temperature: the classic pair of little half-moon gauges
  G.fueltemp = (g, w, h, t) => {
    const fuel = sm.fuel, c = sm.coolant, fF = c == null ? null : c * 9 / 5 + 32;
    const ff = fuel == null ? null : clamp(fuel / 100, 0, 1), tf = fF == null ? null : clamp((fF - 100) / 160, 0, 1);
    const low = fuel != null && fuel < 15, hot = fF != null && fF >= 240, wd = isWide(w, h), tall = !wd && h > w * 0.72;
    const pair = [['E', 'F', 'Fuel', ff, low ? T.red : T.accent, fuel == null ? '--' : `${Math.round(fuel)}%`, [0, 0.15]],
      ['C', 'H', 'Temp', tf, hot ? T.red : fF != null && fF < 160 ? T.blue : T.green, c == null ? '--' : fmtTemp(c), [0.875, 1]]];
    pair.forEach(([lo, hi, lab, f, col, val, red], i) => {
      const cw = tall ? w : w / 2, chh = tall ? h / 2 : h, ox = tall ? 0 : i * cw, oy = tall ? i * chh : 0;
      const r = Math.min(cw * 0.4, chh * 0.62), cx = ox + cw / 2, cy = oy + chh * 0.62, a0 = Math.PI * 1.08, sw = Math.PI * 0.84;
      layer(g, `ft|${cx | 0},${cy | 0},${r | 0}|${i}`, cx, cy, r * 1.35, (x) => {
        arc(x, cx, cy, r, a0, a0 + sw, r * 0.05, P.light ? 'rgba(0,0,0,.4)' : 'rgba(255,255,255,.35)', 0, 'butt');
        arc(x, cx, cy, r, a0 + sw * red[0], a0 + sw * red[1], r * 0.08, T.red, 0, 'butt');
        x.strokeStyle = P.light ? '#222' : '#fff'; x.lineWidth = Math.max(1.5, r * 0.03); x.beginPath();
        for (let k = 0; k <= 4; k++) { const a = a0 + (sw * k) / 4, L = k % 2 ? 0.1 : 0.17; x.moveTo(cx + r * 1.03 * Math.cos(a), cy + r * 1.03 * Math.sin(a)); x.lineTo(cx + r * (1 - L) * Math.cos(a), cy + r * (1 - L) * Math.sin(a)); }
        x.stroke();
        text(x, lo, cx + r * 1.2 * Math.cos(a0), cy + r * 1.2 * Math.sin(a0) + r * 0.05, 700, r * 0.18, i ? T.blue : T.red);
        text(x, hi, cx + r * 1.2 * Math.cos(a0 + sw), cy + r * 1.2 * Math.sin(a0 + sw) + r * 0.05, 700, r * 0.18, i ? T.red : T.text);
        text(x, lab, cx, cy - r * 0.42, 600, r * 0.15, T.sub);
      });
      if (f != null) {
        const a = a0 + sw * f;
        g.strokeStyle = rgba(col, 0.25); g.lineWidth = r * 0.09; g.lineCap = 'round'; g.beginPath(); g.moveTo(cx + r * 0.1 * Math.cos(a), cy + r * 0.1 * Math.sin(a)); g.lineTo(cx + r * 0.95 * Math.cos(a), cy + r * 0.95 * Math.sin(a)); g.stroke();
        g.strokeStyle = col; g.lineWidth = Math.max(2, r * 0.035); g.stroke();
      }
      g.fillStyle = '#2a2d33'; circ(g, cx, cy, r * 0.09); g.fill(); g.fillStyle = col; circ(g, cx, cy, r * 0.04); g.fill();
      text(g, val, cx, cy + r * 0.3, 400, r * 0.2, (i ? hot : low) ? T.red : T.text);
    });
    if (fuel == null && c == null && !tall) text(g, noVal(), w / 2, h * 0.92, 500, clamp(Math.min(w, h) * 0.05, 9, 16), T.sub);
  };

  // ---- how long the engine spent in each 500 rpm band this drive
  G.rpmbands = (g, w, h, t) => {
    const RL = O.redline, maxK = Math.max(7, Math.floor(RL / 1000) + 1), n = Math.min(RB, maxK * 2), B = trip.rpmBands;
    const p = clamp(Math.min(w, h) * 0.07, 6, 18), wd = isWide(w, h), fs = clamp(Math.min(w, h) * (wd ? 0.1 : 0.05), 8, 15);
    const top = wd ? p : clamp(h * 0.16, 20, 70), bot = h - p - fs * 1.5 - (wd ? 0 : fs * 1.6), x0 = p, pw = w - p * 2, ph = bot - top;
    let mx = 0, tot = 0, best = -1; for (let i = 0; i < n; i++) { tot += B[i]; if (B[i] > mx) { mx = B[i]; best = i; } }
    if (!wd) title(g, 'Time at rpm, this drive', p, top * 0.5, clamp(top * 0.3, 10, 18));
    const cur = sm.rpm == null ? -1 : Math.min(n - 1, Math.floor(sm.rpm / 500)), bw = pw / n;
    for (let i = 0; i < n; i++) {
      const k = mx > 0 ? B[i] / mx : 0, hh = Math.max(2, ph * k), x = x0 + i * bw, red = i * 500 >= RL, c = red ? T.red : i === cur ? T.amber : T.accent;
      g.fillStyle = i === cur ? rgba(c, 0.95) : rgba(c, 0.25 + 0.5 * k);
      g.fillRect(x + bw * 0.12, bot - hh, bw * 0.76, hh);
      if (i === cur) { g.fillStyle = rgba(T.amber, 0.15); g.fillRect(x, top, bw, ph); }
    }
    for (let k = 0; k <= maxK; k += maxK > 8 ? 2 : 1) text(g, String(k), x0 + k * 2 * bw, bot + fs * 0.9, 500, fs, k * 1000 >= RL ? T.red : T.sub);
    if (!wd) fit(g, tot > 5 && best >= 0 ? `Mostly ${best * 500}–${best * 500 + 500} rpm (${Math.round((mx / tot) * 100)}%)` : sm.rpm == null ? noVal() : 'Collecting…', w / 2, h - p - fs * 0.6, w - p * 2, 600, fs, T.sub);
  };

  const fmtTemp = (v) => (tempF() ? `${Math.round(v * 9 / 5 + 32)}°` : `${Math.round(v)}°`);
  const noVal = () => ((((S.state || {}).obd || {}).status === 'connected') ? 'Not reported by your car' : 'No OBD adapter');
  function small(g, w, h, t, v, lo, hi, fmt, label, colFn, noteFn) {
    if (ARC) {
      const lab = [0, 1, 2, 3, 4].map((i) => { const x = lo + ((hi - lo) * i) / 4; return Math.abs(x) >= 10 || x === 0 ? String(Math.round(x)) : x.toFixed(1); });
      return arcGauge(g, w, h, t, { f: v == null ? 0 : clamp((v - lo) / (hi - lo), 0, 1), labels: lab, col: v == null ? T.sub : colFn(v), ncol: v == null ? T.sub : colFn(v),
        val: v == null ? '--' : fmt(v), unit: label, vcol: T.text, note: v == null ? noVal() : noteFn ? noteFn(v) : '' });
    }
    if (isWide(w, h)) {
      const col = v == null ? T.sub : colFn(v);
      return wide(g, w, h, t, { name: label, val: v == null ? '--' : fmt(v), f: v == null ? 0 : (v - lo) / (hi - lo), has: v != null,
        barCol: col, note: v == null ? noVal() : (noteFn ? noteFn(v) : ''), noteCol: col });
    }
    const r = Math.min(w * 0.43, h * 0.46), cx = w / 2, cy = h / 2 + r * 0.1, tw = r * 0.12;
    const mode = arcMode('solid'), key = `s|${cx | 0},${cy | 0},${r | 0}|${mode}`;
    faceBack(g, cx, cy, r * 0.94, true);
    layer(g, 't' + key, cx, cy, r * 1.15, (x) => track(x, cx, cy, r, mode, tw, 30));
    const k = v == null ? 0 : clamp((v - lo) / (hi - lo), 0, 1);
    if (v != null) arcFill(g, cx, cy, r, Math.max(0.004, k), tw, mode === 'segments' || mode === 'holo' ? (() => colFn(v)) : colFn(v), mode, 30);
    if (O.ticks !== 'face' && O.ticks !== 'none') layer(g, `o${key}|${O.ticks}`, cx, cy, r * 1.15, (x) => ticks(x, cx, cy, r * 0.97, ['', '', '', '', '', ''], null, true));
    // explicit needle choice: a short pointer riding the arc
    if (v != null && O.needle !== 'none' && (O.needle !== 'face' || (P.arc === 'none' && P.needle !== 'none'))) needle(g, cx, cy, r * 1.06, A0 + SWEEP * k, colFn(v), Math.max(2, r * 0.035), r * 0.7);
    frontDyn(g, cx, cy, r);
    valText(g, v == null ? '--' : fmt(v), cx, cy, r * 0.42, T.text);
    text(g, label, cx, cy + r * 0.45, 600, r * 0.15, T.sub);
    const note = v != null && noteFn ? noteFn(v) : '';
    if (note) text(g, note, cx, cy + r * 0.72, 500, r * 0.13, colFn(v));
    if (v == null) text(g, noVal(), cx, cy + r * 0.72, 500, r * 0.12, T.sub);
  }
  window.GAUGE_FACES = [['obsidian', 'Obsidian', 'True black dials: only a beam of light marks the reading'],
    ['halo', 'Halo', 'A soft ring of light breathes behind a floating number, the needle leaves a trail'],
    ['eclipse', 'Eclipse', 'A black disc in each dial with a corona flickering round it'],
    ['ion', 'Ion', 'Dashed rings turning like a particle accelerator, segment bars, a laser needle'],
    ['filament', 'Filament', 'A glowing wire in a dark glass tube, warm like an old valve amp'],
    ['real', 'Realistic', 'Like a real car: printed dials, orange needles, chrome rims'],
    ['motorsport', 'Motorsport', 'White race-team dials, black numbers, a red needle'],
    ['vintage', 'Vintage', 'Cream enamel and serif numbers, like a 1960s roadster'],
    ['f1', 'F1 digital', 'Black steering-wheel display: segment digits and green, red, purple light bands'],
    ['aviation', 'Aviation', 'Matte black aircraft instruments, white markings, four bezel screws'],
    ['oled', 'OLED black', 'True black with one clean colored arc: calm at night'],
    ['matrix', 'Terminal', 'Green code rain behind green terminal digits'],
    ['sapphire', 'Sapphire', 'Deep blue crystal dials in silver bezels'],
    ['ice', 'Ice', 'Frosted pale glass with frost ferns round the edge'],
    ['sunset', 'Sunset', 'Every dial is the evening sky going down'],
    ['rosegold', 'Rose gold', 'Dark chocolate dials, brushed rings, rose-gold bezels'],
    ['glitch', 'Cyberpunk', 'Yellow and cyan, hazard stripes, the picture glitches now and then'],
    ['jdm', '80s JDM', 'Matte black with the tri-color stripe and italic numbers of an 80s Japanese coupe'],
    ['luxe', 'Luxury watch', 'Sunburst dial with guilloché engraving, gold indices and hands, a date window'],
    ['tron', 'Tron', 'Light-cycle grid, cyan light trails, orange racers circling the rim'],
    ['lava', 'Lava', 'Black basalt with glowing cracks that breathe, molten value arc, rising embers'],
    ['crystal', 'Crystal', 'Faceted prismatic glass with a rainbow sheen and a passing glint'],
    ['retro', 'Retro VFD', '1980s amber vacuum-fluorescent display: segment digits and bar graphs'],
    ['blueprint', 'Blueprint', 'A technical drawing: grid paper, centre lines, hatched value band'],
    ['hologram', 'Hologram', 'Projected rings that turn in 3D, scanlines, a flicker of color'],
    ['synthwave', 'Synthwave', 'An outrun sunset in every dial, neon grid racing at your speed'],
    ['aurora', 'Aurora', 'Northern lights flow through the arc, the needle leaves a comet trail'],
    ['liquid', 'Liquid metal', 'Glossy mercury fills a glass tube, a glint runs along it'],
    ['particles', 'Particles', 'A stream of sparks races to the reading, faster when it climbs'],
    ['carbon', 'Carbon', 'Carbon weave, red blade needles, a digital readout in a recessed window'],
    ['glass', 'Glass', 'See-through: only a glowing rim and crisp marks over your background'],
    ['minimal', 'Minimal', 'Huge thin numbers and one hairline arc'],
    ['neon', 'Neon', 'Glowing rings that spin in your theme colors'], ['plasma', 'Plasma', 'Swirling liquid color inside every dial'],
    ['galaxy', 'Galaxy', 'Twinkling stars and a nebula'], ['chrome', 'Chrome', 'Polished bezels, black faces, red needles'],
    ['hud', 'HUD', 'Thin holographic lines, like a fighter jet'], ['classic', 'Classic', 'The original look']];
  // per-part options (settings.cluster.<key>); 'face' = whatever the chosen face does. Not used by the Realistic face.
  window.GAUGE_STYLE_OPTS = [
    ['needle', 'Needle', [['face', 'Face default'], ['blade', 'Blade'], ['laser', 'Laser'], ['comet', 'Comet trail'], ['classic', 'Classic'], ['none', 'None']]],
    ['ticks', 'Tick marks', [['face', 'Face default'], ['fine', 'Fine'], ['bold', 'Bold'], ['minimal', 'Dots'], ['none', 'None']]],
    ['numerals', 'Numbers', [['face', 'Face default'], ['thin', 'Thin'], ['bold', 'Bold'], ['digital', 'Digital'], ['none', 'None']]],
    ['arc', 'Value arc', [['face', 'Face default'], ['gradient', 'Gradient'], ['solid', 'Solid'], ['segments', 'Segments'], ['none', 'None']]],
    ['glow', 'Glow', 'range', 0, 100, 5],
    ['redline', 'Redline (rpm)', 'range', 4000, 9000, 250],
  ];
  window.GAUGE_LIST = [['tach', 'Tachometer', 'Engine rpm with a redline that glows'], ['speed', 'Speedometer', 'Big speed with a sweeping arc'],
    ['fuel', 'Fuel', 'A tank that sloshes as you drive, with range left'], ['coolant', 'Coolant temperature', 'Cold, normal and hot zones, warns if it overheats'],
    ['volts', 'Battery', 'Voltage and whether it’s charging'], ['mpg', 'Fuel economy', 'Right now and for the trip'],
    ['intake', 'Intake air', 'Air temperature going into the engine'], ['load', 'Engine load', 'How hard the engine is working'], ['throttle', 'Throttle', 'How far the pedal is pressed'],
    ['revleds', 'Shift lights', 'Race-style LEDs that flash at your shift point'], ['gforce', 'G-force', 'How hard you’re speeding up or braking'],
    ['zero60', '0-60 timer', 'Times every launch from a stop, keeps your best'], ['boost', 'Boost / vacuum', 'Intake manifold pressure in psi'],
    ['power', 'Horsepower', 'Rough power from the air the engine breathes'], ['oil', 'Oil temperature', 'If your car reports it'],
    ['ambient', 'Outside temp', 'From the car, or the weather'], ['flow', 'Fuel flow', 'Gallons per hour right now'],
    ['fuelorb', 'Liquid fuel orb', 'A glass ball of fuel that sloshes as you drive'], ['coolorb', 'Liquid coolant orb', 'Rises and changes color as it warms, boils when hot'],
    ['range', 'Range', 'Miles left in the tank'], ['peak', 'Peaks', 'Top speed and highest rpm this drive'], ['clock', 'Clock', 'An analog clock'],
    ['gear', 'Gear', 'Your virtual gear from speed and rpm, with shift hints'], ['rpmtrace', 'Rpm history', 'A glowing oscilloscope of the last minute of rpm'],
    ['speedtrace', 'Speed history', 'The last minute of speed as a glowing trace'], ['mpgtrace', 'Economy history', 'Economy second by second with your trip average'],
    ['eco', 'Eco score', 'How smoothly you drive: a leaf, or a flame'], ['trip', 'Trip computer', 'Distance, driving time, average speed and economy'],
    ['quarter', 'Quarter mile', 'Drag-strip lights and timer from a stop, with trap speed and best'], ['torque', 'Torque curve', 'Where you are on the engine’s torque curve, with horsepower'],
    ['air', 'Air intake', 'A breathing gauge: intake, outside air and manifold pressure'], ['battery', 'Battery cell', 'A battery that fills with voltage and charges with a bolt'],
    ['nowplaying', 'Now playing', 'Song progress ring with title, artist and an equalizer'], ['dualbars', 'Throttle & load', 'Twin LED columns with peak hold'],
    ['bigspeed', 'Digital speed', 'A huge speed number, a trend arrow and the last minute under it'], ['twin', 'Speed + tach', 'Speedometer with the tachometer as an inner ring'],
    ['revbar', 'Rev bar', 'Classic LED segment bar that grows to the redline, with peak hold'], ['horizon', 'Horizon', 'An aircraft horizon that pitches up as you speed up, down as you brake'],
    ['fueltemp', 'Fuel & temp', 'The classic pair of little half-moon gauges'], ['temps', 'Temperatures', 'Coolant, oil and intake air as three thermometers'],
    ['odometer', 'Trip odometer', 'Rolling drum digits for this drive’s distance'], ['drivetime', 'Driving time', 'Time moving vs stopped this drive'],
    ['avgspeed', 'Average speed', 'This drive’s average, with your speed now on the needle'], ['mpgbars', 'Economy now vs drive', 'Two columns: economy right now and this drive’s average'],
    ['tripcost', 'Fuel cost', 'What this drive’s fuel cost, and per mile'], ['idle', 'Idle time', 'Time and fuel spent idling this drive'],
    ['launch', '0-30 launches', 'Times every launch to 30 mph, keeps your last five'], ['rpmbands', 'Time at rpm', 'How long the engine spent in each rpm band this drive'],
    ['enginemap', 'Engine map', 'A heat map of rpm and load with you as a moving dot'], ['voltrace', 'Battery trend', 'Battery voltage over the last 10 minutes'],
    ['runtime', 'Engine run time', 'How long the engine has been running'], ['maf', 'Airflow', 'Air going into the engine, grams per second'],
    ['trims', 'Fuel trim', 'Is the engine running lean or rich (if your car reports it)'], ['timing', 'Ignition timing', 'Spark advance in degrees (if your car reports it)'],
    ['baro', 'Air pressure', 'Barometric pressure and the altitude it means (if your car reports it)'], ['cat', 'Catalyst temp', 'Catalytic converter temperature (if your car reports it)'],
    ['sincecodes', 'Since codes cleared', 'Distance and warm-ups since trouble codes were cleared, and stored codes']];

  // ---------------------------------------------------------------- loop: only runs while gauges are on screen
  let last = performance.now(), lastDraw = 0, LIST = [], listAt = -1e9;
  function frame(now) {
    // which gauges are on screen: looked up a few times a second (the lookup forces a layout pass)
    if (now - listAt > 400) { LIST = [...document.querySelectorAll('canvas[data-gauge]')].filter((c) => c.offsetParent !== null); listAt = now; }
    const list = LIST.filter((c) => c.isConnected);
    const dt = Math.min(0.1, (now - last) / 1000); last = now;
    if (!list.length) { setTimeout(() => requestAnimationFrame(frame), 400); return; }
    requestAnimationFrame(frame);
    if (settings().motion !== 'wild' && !(window.halfRate ? halfRate(now) : now - lastDraw >= 31)) return;   // 30 fps, in step with Flow
    const dtd = Math.min(0.1, Math.max(dt, (now - lastDraw) / 1000));
    update(dtd); lastDraw = now;
    theme();
    const t = settings().animate === false ? 0 : now / 1000;
    nowT = t; DT = clamp(dtd, 0.005, 0.1);
    readOpts();
    const dpr = Math.min(1.5, devicePixelRatio || 1); DPR = dpr; CW = 0;
    const xs = window.CL_XS || 1;   // cluster: the page is laid out wider than the screen and squeezed; draw only real pixels
    for (const c of list) {
      const w = c.clientWidth, h = c.clientHeight;
      if (!w || !h) continue;
      const bw = Math.round(w * dpr * xs), bh = Math.round(h * dpr);
      if (c.width !== bw || c.height !== bh) { c.width = bw; c.height = bh; }
      const g = c.getContext('2d');
      g.setTransform(dpr * xs, 0, 0, dpr, 0, 0);
      g.clearRect(0, 0, w, h);
      CUR = c; CW = w; CH = h; A0 = rad(135); SWEEP = rad(270); LIGHT = false;
      const pc = c.parentElement && c.parentElement.classList;
      ARC = pc && pc.contains('arcL') ? 'left' : pc && pc.contains('arcR') ? 'right' : null;
      (G[c.dataset.gauge] || G.speed)(g, w, h, t);
    }
  }
  requestAnimationFrame(frame);
})();
