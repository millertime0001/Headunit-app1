/* Pi Head Unit — TV (IPTV, Xtream Codes), 2026.11.17. Backend: backend/iptv.py (/iptv/*).
   One persistent element (TV.root) is moved into each freshly rendered .tv-screen, so re-renders never stop the video.
   Hooks in app.js: render() -> TV.mounted(section), go() leaving 'tv' -> TV.leave(), update() -> TV.sync().
   Layout: categories on the left, the list in the middle, the player on the right (tap it for full screen).
   Above about 5 mph the picture is hidden and only the sound plays. */
'use strict';
(function () {
  const T = {
    root: null, status: null, kind: 'live', cat: null, cats: {}, items: [], view: 'list', series: null, season: 0,
    playing: null, list: [], idx: -1, epg: [], full: false, err: '', loading: false, encTried: false, watch: 0, sw: null,
  };
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const q = (sel) => T.root && T.root.querySelector(sel);
  const ICO = (n, s = 22) => (typeof ico === 'function' ? ico(n, s) : '');
  const img = (u) => (u ? `/iptv/img?u=${encodeURIComponent(u)}` : '');
  const encSet = () => { try { return new Set(JSON.parse(localStorage.getItem('tv_enc') || '[]')); } catch (e) { return new Set(); } };
  const keyOf = (it) => `${it.kind}:${it.id}`;
  // "US: ESPN HD", "UK | BBC One", "[4K] Movie": the country/quality tag first isn't what you look for
  const bare = (n) => String(n || '').replace(/^\s*(\[[^\]]*\]|\([^)]*\)|[A-Z0-9]{2,4}\s*[:|\-–]\s*)+/, '').trim() || String(n || '');
  async function api(path, body) {
    const r = await fetch(path, body ? { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) } : {});
    const t = await r.text();
    let d; try { d = JSON.parse(t); } catch (e) { d = { error: t }; }
    if (!r.ok) throw new Error((d && d.error) || `Error ${r.status}`);
    return d;
  }
  const KINDS = [['live', 'Live TV', 'live'], ['movie', 'Movies', 'film'], ['series', 'Shows', 'series'], ['fav', 'Favorites', 'heart'], ['recent', 'Recent', 'history']];

  // ------------------------------------------------------------------ the shell
  function build() {
    const el = document.createElement('div');
    el.className = 'tv';
    el.innerHTML = `
      <aside class="tv-side">
        <div class="tv-brand"><span>TV</span><button class="tv-acct sink" data-tv="account" aria-label="TV provider">${ICO('settings', 20)}</button></div>
        <div class="tv-kinds">${KINDS.map(([k, l, i]) => `<button class="tv-kind sink" data-tvkind="${k}">${ICO(i, 22)}<span>${l}</span></button>`).join('')}</div>
        <div class="tv-cats" data-tvcats></div>
      </aside>
      <section class="tv-mid">
        <header class="tv-head"><button class="tv-back sink hidden" data-tv="back" aria-label="Back">${ICO('left', 22)}</button><h2 data-tvtitle></h2><span class="tv-count" data-tvcount></span>
          <div class="tv-az" data-tvaz></div></header>
        <div class="tv-items" data-tvitems></div>
      </section>
      <section class="tv-play">
        <div class="tv-screen-box" data-tv="full">
          <video class="tv-video" playsinline></video>
          <div class="tv-idle" data-tvidle>${ICO('tv', 54)}<b>Pick a channel</b><span>Tap one on the left. Tap the picture for full screen, swipe up or down to change channels.</span></div>
          <div class="tv-spin hidden" data-tvspin><div class="spinner"></div></div>
          <div class="tv-lock hidden" data-tvlock>${ICO('car', 40)}<b>Picture paused while driving</b><span>The sound keeps playing.</span></div>
          <div class="tv-osd" data-tvosd></div>
          <button class="tv-surf up sink" data-tv="prev" aria-label="Previous channel">${ICO('up', 30)}</button>
          <button class="tv-surf down sink" data-tv="next" aria-label="Next channel">${ICO('down', 30)}</button>
        </div>
        <div class="tv-info" data-tvinfo></div>
      </section>
      <div class="tv-sheet hidden" data-tvsheet></div>`;
    el.addEventListener('click', onClick);
    const box = el.querySelector('.tv-screen-box');
    box.addEventListener('pointerdown', (e) => { T.sw = { y: e.clientY, x: e.clientX, t: Date.now() }; });
    box.addEventListener('pointerup', (e) => {
      const s = T.sw; T.sw = null; if (!s) return;
      const dy = (window.huRot180 && huRot180() ? -1 : 1) * (e.clientY - s.y);
      if (Math.abs(dy) > 70 && Math.abs(dy) > Math.abs(e.clientX - s.x) && T.playing && T.playing.kind === 'live') { surf(dy < 0 ? 1 : -1); box._swiped = Date.now(); }
    });
    const v = el.querySelector('video');
    v.addEventListener('playing', () => { spin(false); T.err = ''; });
    v.addEventListener('waiting', () => spin(true));
    v.addEventListener('error', () => onFail());
    v.addEventListener('ended', () => onEnded());
    v.addEventListener('timeupdate', () => saveSpot());
    return el;
  }

  function mounted(sec) {
    if (!T.root) T.root = build();
    sec.appendChild(T.root);
    T.root.classList.toggle('full', T.full);
    if (!T.status) start(); else paintAll();
  }
  async function start() {
    try { T.status = await api('/iptv/status'); } catch (e) { T.status = { signed_in: false }; }
    if (!T.status.signed_in) return showSignin();
    hideSheet();
    pickKind(T.kind);
  }

  function paintAll() {
    if (!T.root) return;
    T.root.querySelectorAll('[data-tvkind]').forEach((b) => b.classList.toggle('on', b.dataset.tvkind === T.kind));
    paintCats(); paintItems(); paintInfo(); sync();
  }

  // ------------------------------------------------------------------ lists
  async function pickKind(k) {
    T.kind = k; T.view = 'list'; T.series = null;
    T.root.querySelectorAll('[data-tvkind]').forEach((b) => b.classList.toggle('on', b.dataset.tvkind === k));
    if (k === 'fav' || k === 'recent') {
      try { T.status = await api('/iptv/status'); } catch (e) { /* keep the last one */ }
      T.items = (T.status[k] || []).map((x) => Object.assign({}, x));
      T.cat = null; paintCats(); paintItems(); return;
    }
    if (!T.cats[k]) {
      setLoading(true);
      try { T.cats[k] = await api(`/iptv/categories?kind=${k}`); } catch (e) { T.cats[k] = null; setLoading(false); return showError(e.message); }
      setLoading(false);
    }
    const last = localStorage.getItem(`tv_cat_${k}`);
    const cats = T.cats[k] || [];
    pickCat(cats.some((c) => c.id === last) ? last : (cats[0] || {}).id || 'all');
  }
  async function pickCat(id) {
    T.cat = id; T.view = 'list';
    try { localStorage.setItem(`tv_cat_${T.kind}`, id); } catch (e) { /* optional */ }
    paintCats();
    setLoading(true);
    try {
      const items = await api(`/iptv/streams?kind=${T.kind}&cat=${encodeURIComponent(id)}`);
      T.items = items.map((x) => Object.assign({ kind: T.kind === 'series' ? 'series' : T.kind }, x));
    } catch (e) { T.items = []; showError(e.message); }
    setLoading(false);
    paintItems();
  }
  function paintCats() {
    const box = q('[data-tvcats]');
    if (!box) return;
    if (T.kind === 'fav' || T.kind === 'recent') { box.innerHTML = `<p class="tv-hint">${T.kind === 'fav' ? 'Hold a channel, movie or show to add it here.' : 'What you watched last, newest first.'}</p>`; return; }
    const cats = T.cats[T.kind] || [];
    box.innerHTML = [{ id: 'all', name: T.kind === 'live' ? 'All channels' : 'Everything' }, ...cats]
      .map((c) => `<button class="tv-cat sink ${c.id === T.cat ? 'on' : ''}" data-tvcat="${esc(c.id)}">${esc(c.name)}</button>`).join('');
    const on = box.querySelector('.on'); if (on) on.scrollIntoView({ block: 'nearest' });
  }
  const favSet = () => new Set(((T.status && T.status.fav) || []).map(keyOf));
  function paintItems() {
    const box = q('[data-tvitems]'), title = q('[data-tvtitle]'), count = q('[data-tvcount]'), az = q('[data-tvaz]'), back = q('[data-tv="back"]');
    if (!box) return;
    layout();
    back.classList.toggle('hidden', T.view !== 'series');
    if (T.view === 'series') return paintSeries();
    const cat = (T.cats[T.kind] || []).find((c) => c.id === T.cat);
    title.textContent = T.kind === 'fav' ? 'Favorites' : T.kind === 'recent' ? 'Recent' : cat ? cat.name : T.kind === 'live' ? 'All channels' : 'Everything';
    count.textContent = T.items.length ? `${T.items.length}` : '';
    const fav = favSet(), now = T.playing ? keyOf(T.playing) : '';
    if (!T.items.length) { box.innerHTML = `<div class="tv-empty">${T.loading ? '' : 'Nothing here yet.'}</div>`; az.innerHTML = ''; return; }
    const poster = T.kind === 'movie' || T.kind === 'series';
    box.className = `tv-items ${poster ? 'posters' : 'rows'}`;
    // big lists: draw in chunks so the screen never stalls
    const html = (it, i) => {
      const k = keyOf(it), logo = img(it.logo);
      if (poster || it.kind === 'movie' || it.kind === 'series') {
        return `<button class="tv-poster sink ${k === now ? 'on' : ''}" data-tvi="${i}" data-hold="tvfav:${i}">
          <span class="pimg">${logo ? `<img loading="lazy" src="${logo}" alt="" onerror="this.remove()">` : ICO(it.kind === 'series' ? 'series' : 'film', 34)}</span>
          <b>${esc(it.name)}</b><small>${esc([it.year, it.rating ? `★ ${it.rating}` : ''].filter(Boolean).join('  '))}</small>${fav.has(k) ? '<i class="fav">♥</i>' : ''}</button>`;
      }
      return `<button class="tv-row sink ${k === now ? 'on' : ''}" data-tvi="${i}" data-hold="tvfav:${i}">
        <span class="logo">${logo ? `<img loading="lazy" src="${logo}" alt="" onerror="this.remove()">` : `<em>${esc(bare(it.name).slice(0, 2))}</em>`}</span>
        <span class="tt"><b>${esc(it.name)}</b><small data-epgfor="${esc(it.id)}">${it.num ? `Channel ${esc(it.num)}` : ''}</small></span>
        ${fav.has(k) ? '<i class="fav">♥</i>' : ''}${k === now ? '<span class="eqm"><i></i><i></i><i></i></span>' : ''}</button>`;
    };
    box.innerHTML = T.items.slice(0, 160).map(html).join('');
    if (T.items.length > 160) {
      let n = 160;
      const more = () => { if (!box.isConnected || n >= T.items.length) return; box.insertAdjacentHTML('beforeend', T.items.slice(n, n + 200).map((it, j) => html(it, n + j)).join('')); n += 200; requestIdleCallback ? requestIdleCallback(more) : setTimeout(more, 30); };
      setTimeout(more, 60);
    }
    // A-Z jump bar for long lists
    if (T.items.length > 40) {
      const first = {}; T.items.forEach((it, i) => { const ch = bare(it.name).charAt(0).toUpperCase(); const k = /[A-Z]/.test(ch) ? ch : '#'; if (first[k] == null) first[k] = i; });
      az.innerHTML = Object.keys(first).sort().map((k) => `<button class="sink" data-tvaz="${first[k]}">${k}</button>`).join('');
    } else az.innerHTML = '';
    const on = box.querySelector('.on'); if (on) on.scrollIntoView({ block: 'center' });
  }

  async function openSeries(it) {
    T.view = 'series'; T.series = { name: it.name, cover: it.logo, id: it.id, seasons: [] }; T.season = 0;
    paintItems(); setLoading(true);
    try { T.series = Object.assign({ id: it.id }, await api(`/iptv/series?id=${it.id}`)); } catch (e) { showError(e.message); }
    setLoading(false);
    const last = localStorage.getItem(`tv_season_${it.id}`);
    T.season = Math.max(0, (T.series.seasons || []).findIndex((s) => String(s.season) === last));
    paintItems();
  }
  function paintSeries() {
    const s = T.series || {}, box = q('[data-tvitems]');
    q('[data-tvtitle]').textContent = s.name || '';
    q('[data-tvcount]').textContent = '';
    q('[data-tvaz]').innerHTML = (s.seasons || []).map((x, i) => `<button class="sink ${i === T.season ? 'on' : ''}" data-tvseason="${i}">S${esc(x.season)}</button>`).join('');
    const eps = ((s.seasons || [])[T.season] || {}).episodes || [];
    const now = T.playing ? keyOf(T.playing) : '';
    box.className = 'tv-items rows eps';
    box.innerHTML = (s.plot ? `<p class="tv-plot">${esc(s.plot)}</p>` : '') + eps.map((e, i) => {
      const pos = +localStorage.getItem(`tvpos:episode:${e.id}`) || 0, f = e.dur ? Math.min(1, pos / e.dur) : 0;
      return `<button class="tv-row ep sink ${`episode:${e.id}` === now ? 'on' : ''}" data-tvep="${i}">
        <span class="logo wide">${e.img ? `<img loading="lazy" src="${img(e.img)}" alt="" onerror="this.remove()">` : `<em>${esc(e.num)}</em>`}${f ? `<i class="seen" style="width:${(f * 100).toFixed(0)}%"></i>` : ''}</span>
        <span class="tt"><b>${esc(e.num ? `${e.num}. ` : '')}${esc(e.title)}</b><small>${e.dur ? `${Math.round(e.dur / 60)} min` : ''}${pos > 30 ? ` · ${f > 0.92 ? 'watched' : `resume at ${fmt(pos)}`}` : ''}</small></span></button>`;
    }).join('') || `<div class="tv-empty">${T.loading ? '' : 'No episodes listed.'}</div>`;
  }

  // ------------------------------------------------------------------ playing
  function play(it, list, idx) {
    T.playing = it; T.list = list || [it]; T.idx = idx ?? 0; T.encTried = false; T.err = '';
    const enc = encSet().has(keyOf(it));
    startStream(enc);
    if (typeof send === 'function') { const m = (S.state && S.state.media) || {}; if (m.status === 'playing') send('playpause'); }   // phone music off
    api('/iptv/recent', { item: it }).then((r) => { if (T.status) T.status.recent = r; }).catch(() => {});
    paintInfo(); markPlaying(); loadEpg();
  }
  function startStream(enc, at) {
    const it = T.playing, v = q('video');
    if (!it || !v) return;
    const ext = it.ext || '';
    const t = at != null ? at : it.kind === 'live' ? 0 : +localStorage.getItem(`tvpos:${keyOf(it)}`) || 0;
    T.offset = t > 20 ? t : 0;
    v.src = `/iptv/play?kind=${it.kind}&id=${it.id}&ext=${encodeURIComponent(ext)}&t=${T.offset}&enc=${enc ? 1 : 0}&r=${Date.now()}`;
    T.enc = enc;
    q('[data-tvidle]').classList.add('hidden');
    spin(true);
    v.play().catch(() => {});
    clearTimeout(T.watch);
    T.watch = setTimeout(() => {   // sound but no picture after 6 s: the video format didn't play, convert it
      if (T.playing === it && !T.enc && v.videoWidth === 0 && v.readyState >= 2) onFail();
    }, 6500);
  }
  function onFail() {
    const it = T.playing;
    if (!it) return;
    if (!T.enc && !T.encTried) {   // try once more with the picture converted, and remember it for this channel
      T.encTried = true;
      const s = encSet(); s.add(keyOf(it)); try { localStorage.setItem('tv_enc', JSON.stringify([...s].slice(-400))); } catch (e) { /* optional */ }
      return startStream(true, T.curTime());
    }
    spin(false);
    api('/iptv/status').then((st) => { T.status = st; T.err = st.error || 'This stream didn’t start.'; paintInfo(); }).catch(() => {});
  }
  T.curTime = () => { const v = q('video'); return (T.offset || 0) + ((v && v.currentTime) || 0); };
  function onEnded() {
    const it = T.playing;
    if (!it) return;
    if (it.kind === 'live') { T.retries = (T.retries || 0) + 1; if (T.retries <= 3) return startStream(T.enc, 0); return; }
    localStorage.removeItem(`tvpos:${keyOf(it)}`);
    if (it.kind === 'episode' && T.list[T.idx + 1]) play(T.list[T.idx + 1], T.list, T.idx + 1);   // next episode
  }
  function saveSpot() {
    const it = T.playing;
    if (!it || it.kind === 'live') return;
    const now = Date.now(); if (now - (T.savedAt || 0) < 5000) return; T.savedAt = now;
    try { localStorage.setItem(`tvpos:${keyOf(it)}`, String(Math.floor(T.curTime()))); } catch (e) { /* optional */ }
  }
  function surf(d) {
    if (!T.list.length) return;
    let i = T.idx;
    for (let n = 0; n < T.list.length; n++) { i = (i + d + T.list.length) % T.list.length; if (T.list[i].kind === 'live') break; }
    play(T.list[i], T.list, i);
    osd();
  }
  function stop() {
    const v = q('video');
    if (v) { v.pause(); v.removeAttribute('src'); v.load(); }
    clearTimeout(T.watch);
    T.playing = null;
    api('/iptv/stop', {}).catch(() => {});
    if (q('[data-tvidle]')) q('[data-tvidle]').classList.remove('hidden');
    spin(false); paintInfo(); markPlaying();
  }
  function layout() {   // movies/shows with nothing playing: use the whole width for posters
    if (T.root) T.root.classList.toggle('browse', !T.playing && (T.kind === 'movie' || T.kind === 'series'));
  }
  function markPlaying() {
    layout();
    const now = T.playing ? keyOf(T.playing) : '';
    T.root.querySelectorAll('[data-tvi]').forEach((b) => { const it = T.items[+b.dataset.tvi]; b.classList.toggle('on', !!it && keyOf(it) === now); });
  }
  async function loadEpg() {
    const it = T.playing;
    T.epg = [];
    if (!it || it.kind !== 'live') return;
    try { T.epg = await api(`/iptv/epg?id=${it.id}`); } catch (e) { T.epg = []; }
    if (T.playing === it) { paintInfo(); osd(); }
  }
  const fmt = (s) => { s = Math.max(0, Math.round(s)); const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), x = s % 60; return h ? `${h}:${String(m).padStart(2, '0')}:${String(x).padStart(2, '0')}` : `${m}:${String(x).padStart(2, '0')}`; };
  const hm = (t) => new Date(t * 1000).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
  function paintInfo() {
    const box = q('[data-tvinfo]');
    if (!box) return;
    const it = T.playing;
    if (!it) { box.innerHTML = T.err ? `<p class="tv-bad">${esc(T.err)}</p>` : ''; return; }
    const now = Date.now() / 1000, e0 = T.epg.find((e) => e.start <= now && e.end > now) || T.epg[0], e1 = T.epg.find((e) => e0 && e.start >= e0.end);
    const pf = e0 ? Math.min(1, Math.max(0, (now - e0.start) / (e0.end - e0.start))) : 0;
    const fav = favSet().has(keyOf(it));
    box.innerHTML = `
      <div class="tv-now">
        <span class="logo">${it.logo ? `<img src="${img(it.logo)}" alt="" onerror="this.remove()">` : ICO(it.kind === 'live' ? 'live' : 'film', 26)}</span>
        <div class="tt"><div class="lab">${it.kind === 'live' ? '<i class="live-dot"></i>Live' : it.kind === 'episode' ? esc(it.series || 'Episode') : 'Movie'}</div><b>${esc(it.name)}</b></div>
        <button class="icon-btn sink ${fav ? 'on' : ''}" data-tv="fav" aria-label="Favorite">${ICO('heart', 24)}</button>
        <button class="icon-btn sink" data-tv="stop" aria-label="Stop">${ICO('x', 24)}</button>
      </div>
      ${e0 ? `<div class="tv-epg"><div class="row1"><b>${esc(e0.title)}</b><span>${hm(e0.start)} – ${hm(e0.end)}</span></div>
        <div class="bar"><i style="width:${(pf * 100).toFixed(1)}%"></i></div>${e0.desc ? `<p>${esc(e0.desc)}</p>` : ''}
        ${e1 ? `<div class="next"><span>Next</span><b>${esc(e1.title)}</b><em>${hm(e1.start)}</em></div>` : ''}</div>` : ''}
      ${it.kind !== 'live' ? `<div class="tv-seek"><button class="btn small sink" data-tv="back30">${ICO('left', 18)}30 s</button><button class="btn small sink" data-tv="pause">Pause / play</button><button class="btn small sink" data-tv="fwd30">30 s${ICO('right', 18)}</button></div>` : ''}
      ${T.err ? `<p class="tv-bad">${esc(T.err)}</p>` : ''}`;
  }
  function osd() {
    const el = q('[data-tvosd]'), it = T.playing;
    if (!el || !it) return;
    const now = Date.now() / 1000, e0 = T.epg.find((e) => e.start <= now && e.end > now);
    el.innerHTML = `<b>${esc(it.name)}</b>${e0 ? `<span>${esc(e0.title)}</span>` : ''}`;
    el.classList.add('show'); clearTimeout(T.osdT); T.osdT = setTimeout(() => el.classList.remove('show'), 3200);
  }
  function spin(on) { const s = q('[data-tvspin]'); if (s) s.classList.toggle('hidden', !on); }
  function setLoading(on) { T.loading = on; if (T.root) T.root.classList.toggle('loading', on); }
  function showError(msg) { T.err = msg; const box = q('[data-tvitems]'); if (box) box.innerHTML = `<div class="tv-empty bad">${esc(msg)}<button class="btn small sink" data-tv="retry">Try again</button></div>`; }

  // ------------------------------------------------------------------ sign in + account
  function showSignin(err) {
    const sh = q('[data-tvsheet]');
    sh.classList.remove('hidden');
    sh.innerHTML = `<div class="tv-sheet-card">
      <div class="tv-sheet-ic">${ICO('tv', 44)}</div>
      <h1>Watch TV here</h1>
      <p>Sign in once with the Xtream Codes details from your TV provider. The picture and sound come through your phone's mobile data.</p>
      <div class="tv-step"><b>On your phone</b><span>Connected to the head unit, open Chrome and go to</span><code>10.42.0.1:8080/tv/setup</code><span>This screen picks it up by itself.</span></div>
      ${err ? `<p class="tv-bad">${esc(err)}</p>` : ''}
      <p class="tv-hint">Needs Head Unit Link 7.4 or newer on the phone (it carries the TV traffic).</p>
    </div>`;
    clearTimeout(T.pollT);
    const poll = async () => {
      if (!T.root || !T.root.isConnected) return;
      try { const st = await api('/iptv/status'); if (st.signed_in) { T.status = st; if (typeof toast === 'function') toast('Signed in to your TV provider'); return start(); } } catch (e) { /* again */ }
      T.pollT = setTimeout(poll, 3000);
    };
    T.pollT = setTimeout(poll, 3000);
  }
  function hideSheet() { const sh = q('[data-tvsheet]'); if (sh) sh.classList.add('hidden'); }
  function showAccount() {
    const st = T.status || {}, inf = st.info || {}, sh = q('[data-tvsheet]');
    const exp = inf.exp ? new Date(inf.exp * 1000).toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' }) : 'No end date';
    sh.classList.remove('hidden');
    sh.innerHTML = `<div class="tv-sheet-card">
      <h1>TV provider</h1>
      <div class="tv-kv"><span>Server</span><b>${esc(st.server)}</b></div>
      <div class="tv-kv"><span>Username</span><b>${esc(st.username)}</b></div>
      <div class="tv-kv"><span>Subscription ends</span><b>${esc(exp)}</b></div>
      <div class="tv-kv"><span>Screens allowed</span><b>${esc(inf.max ?? '?')}</b></div>
      <div class="tv-kv"><span>Through the phone</span><b>${st.via_phone ? 'Yes' : 'Not right now'}</b></div>
      <div class="tv-kv"><span>Live stream type</span><div class="seg">${[['ts', 'Standard'], ['m3u8', 'HLS']].map(([k, l]) => `<button class="sink ${st.live_format === k ? 'on' : ''}" data-tvfmt="${k}">${l}</button>`).join('')}</div></div>
      <div class="row" style="margin-top:1.2rem"><button class="btn sink" data-tv="close">Done</button><button class="btn sink" data-tv="logout">Sign out</button></div>
    </div>`;
  }

  // ------------------------------------------------------------------ taps
  function onClick(e) {
    if (Date.now() - (T.heldAt || 0) < 900) return;   // that was a long press (favorite), not a tap
    const b = e.target.closest('[data-tv],[data-tvkind],[data-tvcat],[data-tvi],[data-tvep],[data-tvaz],[data-tvseason],[data-tvfmt]');
    if (!b) return;
    const d = b.dataset;
    if (d.tvkind) return pickKind(d.tvkind);
    if (d.tvcat) return pickCat(d.tvcat);
    if (d.tvseason) { T.season = +d.tvseason; localStorage.setItem(`tv_season_${T.series.id}`, String(T.series.seasons[T.season].season)); return paintItems(); }
    if (d.tvaz) { const el = q(`[data-tvi="${d.tvaz}"]`); if (el) el.scrollIntoView({ block: 'start', behavior: 'smooth' }); return; }
    if (d.tvfmt) { api('/iptv/format', { live_format: d.tvfmt }).then((st) => { T.status = st; showAccount(); }); return; }
    if (d.tvi != null) {
      const it = T.items[+d.tvi];
      if (!it) return;
      if (it.kind === 'series') return openSeries(it);
      if (T.playing && keyOf(T.playing) === keyOf(it)) return setFull(true);   // tap again: full screen
      return play(it, T.items.filter((x) => x.kind === 'live' || x === it), T.items.filter((x) => x.kind === 'live' || x === it).indexOf(it));
    }
    if (d.tvep != null) {
      const eps = ((T.series.seasons || [])[T.season] || {}).episodes || [];
      const list = eps.map((x) => ({ kind: 'episode', id: x.id, name: `${x.num ? `${x.num}. ` : ''}${x.title}`, ext: x.ext, logo: x.img || T.series.cover, series: T.series.name, dur: x.dur }));
      return play(list[+d.tvep], list, +d.tvep);
    }
    const a = d.tv;
    if (a === 'full') { if (b._swiped && Date.now() - b._swiped < 400) return; if (!T.playing) return; return setFull(!T.full); }
    if (a === 'prev') { e.stopPropagation(); return surf(-1); }
    if (a === 'next') { e.stopPropagation(); return surf(1); }
    if (a === 'back') { T.view = 'list'; return paintItems(); }
    if (a === 'stop') return stop();
    if (a === 'retry') return T.kind === 'fav' || T.kind === 'recent' ? pickKind(T.kind) : (T.cats[T.kind] ? pickCat(T.cat || 'all') : pickKind(T.kind));
    if (a === 'fav' && T.playing) return toggleFav(T.playing);
    if (a === 'account') return showAccount();
    if (a === 'close') return hideSheet();
    if (a === 'logout') { api('/iptv/logout', {}).then(() => { T.status = null; T.cats = {}; stop(); start(); }); return; }
    const v = q('video');
    if (a === 'pause' && v) return v.paused ? v.play() : v.pause();
    if ((a === 'back30' || a === 'fwd30') && T.playing) return startStream(T.enc, Math.max(0, T.curTime() + (a === 'fwd30' ? 30 : -30)));
  }
  function toggleFav(it) {
    const on = favSet().has(keyOf(it));
    api('/iptv/fav', { item: Object.assign({}, it, { off: on }) }).then((r) => {
      T.status.fav = r; if (typeof toast === 'function') toast(on ? 'Removed from Favorites' : 'Added to Favorites');
      paintInfo(); if (T.kind === 'fav') pickKind('fav'); else paintItems();
    }).catch(() => {});
  }
  function hold(spec) {   // app.js long-press: "tvfav:<index>"
    const it = T.items[+String(spec).split(':')[1]];
    T.heldAt = Date.now();
    if (it) toggleFav(it);
  }
  function setFull(on) {
    T.full = on;
    if (T.root) T.root.classList.toggle('full', on);
    document.body.classList.toggle('tv-full', on);
    if (on) osd();
  }

  // ------------------------------------------------------------------ app.js hooks
  function sync() {   // every state update: the driving lock
    if (!T.root) return;
    const sp = S.state && S.state.speed, moving = !!(sp && sp.mps > 2.2 && Date.now() / 1000 - (sp.at || 0) < 15);
    T.root.classList.toggle('driving', moving);
    const lock = q('[data-tvlock]'); if (lock) lock.classList.toggle('hidden', !(moving && T.playing));
    if (moving && T.full) setFull(false);
  }
  function leave() {
    if (T.playing) stop();
    setFull(false);
    clearTimeout(T.pollT);
  }
  window.TV = { mounted, leave, sync, hold, stop };
})();
