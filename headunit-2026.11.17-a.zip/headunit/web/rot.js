// Head unit screen mounted upside down: the whole page is turned 180° (style.css, html.rot180, set in
// applyLook from Settings > Display > Rotation). The browser turns touch with it, so taps just work.
// Only code that does its own math with finger positions or element boxes needs these two helpers:
// they give both in the page's own (unturned) coordinates. On the cluster page they change nothing.
(function () {
  const on = () => document.documentElement.classList.contains('rot180');
  window.huRot180 = on;
  window.huPt = (e) => (on() ? { x: innerWidth - e.clientX, y: innerHeight - e.clientY } : { x: e.clientX, y: e.clientY });
  window.huBox = (el) => {
    const r = el.getBoundingClientRect();
    if (!on()) return r;
    return { left: innerWidth - r.right, top: innerHeight - r.bottom, right: innerWidth - r.left, bottom: innerHeight - r.top,
      width: r.width, height: r.height, x: innerWidth - r.right, y: innerHeight - r.bottom };
  };
}());
