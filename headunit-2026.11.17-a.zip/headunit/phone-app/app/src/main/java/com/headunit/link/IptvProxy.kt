package com.headunit.link

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.util.Log
import java.io.BufferedInputStream
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.URI
import kotlin.concurrent.thread

/**
 * A tiny HTTP proxy for the head unit's TV screen (2026.11.17, app 7.4).
 *
 * The Pi has no internet: its Wi-Fi is the car hotspot. It reaches this proxy with `adb forward tcp:8899 tcp:8899`,
 * so it only ever listens on 127.0.0.1 (nothing on any Wi-Fi network can use it). Every connection out goes over
 * the phone's internet network (mobile data preferred), even while the phone is joined to the Pi's Wi-Fi.
 *
 * Handles plain proxy requests ("GET http://host/path HTTP/1.1") and CONNECT tunnels (https).
 */
object IptvProxy {
    private const val TAG = "IptvProxy"
    private const val PORT = 8899
    @Volatile private var server: ServerSocket? = null
    private var cm: ConnectivityManager? = null

    fun start(context: Context) {
        if (server != null) return
        cm = context.getSystemService(ConnectivityManager::class.java)
        thread(name = "iptv-proxy", isDaemon = true) {
            try {
                val ss = ServerSocket()
                ss.reuseAddress = true
                ss.bind(InetSocketAddress(InetAddress.getByName("127.0.0.1"), PORT))
                server = ss
                Log.i(TAG, "listening on 127.0.0.1:$PORT")
                while (!ss.isClosed) {
                    val c = try { ss.accept() } catch (e: Exception) { break }
                    thread(isDaemon = true) { handle(c) }
                }
            } catch (e: Exception) {
                Log.w(TAG, "proxy stopped: $e")
            } finally {
                server = null
            }
        }
    }

    fun stop() {
        try { server?.close() } catch (_: Exception) { }
        server = null
    }

    /** The network to go out on: validated internet, mobile data first (the Pi's Wi-Fi has no internet). */
    private fun internet(): Network? {
        val c = cm ?: return null
        @Suppress("DEPRECATION")
        val nets = c.allNetworks.mapNotNull { n -> c.getNetworkCapabilities(n)?.let { n to it } }
            .filter { (_, caps) -> caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) }
        return nets.firstOrNull { it.second.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) }?.first
            ?: nets.firstOrNull()?.first
    }

    private fun connectOut(host: String, port: Int): Socket {
        val net = internet()
        val s = net?.socketFactory?.createSocket() ?: Socket()
        val addr = net?.getByName(host) ?: InetAddress.getByName(host)
        s.connect(InetSocketAddress(addr, port), 15000)
        s.tcpNoDelay = true
        return s
    }

    private fun readHead(input: InputStream): String? {
        val buf = ByteArrayOutputStream()
        var state = 0
        while (true) {
            val b = input.read()
            if (b < 0) return null
            buf.write(b)
            state = when {
                state == 0 && b == '\r'.code -> 1
                state == 1 && b == '\n'.code -> 2
                state == 2 && b == '\r'.code -> 3
                state == 3 && b == '\n'.code -> return buf.toString(Charsets.ISO_8859_1.name())
                b == '\r'.code -> 1
                else -> 0
            }
            if (buf.size() > 64 * 1024) return null
        }
    }

    private fun handle(client: Socket) {
        var out: Socket? = null
        try {
            client.soTimeout = 30000
            val cin = BufferedInputStream(client.getInputStream())
            val cout = client.getOutputStream()
            val head = readHead(cin) ?: return
            client.soTimeout = 0   // streams run for hours
            val lines = head.split("\r\n").filter { it.isNotEmpty() }
            val (method, target) = lines.first().split(" ").let { it[0] to it[1] }
            if (method.equals("CONNECT", true)) {
                val host = target.substringBeforeLast(":")
                val port = target.substringAfterLast(":").toIntOrNull() ?: 443
                out = connectOut(host, port)
                cout.write("HTTP/1.1 200 Connection established\r\n\r\n".toByteArray())
                cout.flush()
                pipe(cin, cout, out)
                return
            }
            val uri = URI(target)
            val host = uri.host ?: return
            val port = if (uri.port > 0) uri.port else 80
            val path = (uri.rawPath?.ifEmpty { "/" } ?: "/") + (uri.rawQuery?.let { "?$it" } ?: "")
            val sb = StringBuilder("$method $path HTTP/1.1\r\n")
            var hasHost = false
            for (l in lines.drop(1)) {
                val k = l.substringBefore(":").trim().lowercase()
                if (k == "proxy-connection" || k == "connection" || k == "keep-alive") continue
                if (k == "host") hasHost = true
                sb.append(l).append("\r\n")
            }
            if (!hasHost) sb.append("Host: ").append(if (uri.port > 0) "$host:$port" else host).append("\r\n")
            sb.append("Connection: close\r\n\r\n")
            out = connectOut(host, port)
            out.getOutputStream().write(sb.toString().toByteArray(Charsets.ISO_8859_1))
            out.getOutputStream().flush()
            pipe(cin, cout, out)
        } catch (e: Exception) {
            Log.d(TAG, "connection: $e")
            try { client.getOutputStream().write("HTTP/1.1 502 Bad Gateway\r\nConnection: close\r\n\r\n".toByteArray()) } catch (_: Exception) { }
        } finally {
            try { out?.close() } catch (_: Exception) { }
            try { client.close() } catch (_: Exception) { }
        }
    }

    /** Copies both ways until either side closes. Video streams run for hours, so no read timeout on them. */
    private fun pipe(cin: InputStream, cout: OutputStream, remote: Socket) {
        remote.soTimeout = 0
        val up = thread(isDaemon = true) {
            try { copy(cin, remote.getOutputStream()) } catch (_: Exception) { }
            try { remote.shutdownOutput() } catch (_: Exception) { }
        }
        try { copy(remote.getInputStream(), cout) } catch (_: Exception) { }
        up.interrupt()
    }

    private fun copy(i: InputStream, o: OutputStream) {
        val b = ByteArray(64 * 1024)
        while (true) {
            val n = i.read(b)
            if (n < 0) break
            o.write(b, 0, n)
            o.flush()
        }
    }
}
