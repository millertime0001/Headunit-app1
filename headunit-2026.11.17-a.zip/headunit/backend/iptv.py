"""IPTV (Xtream Codes) for the head unit's TV screen (web/tv.js). 2026.11.17.

The Pi has no internet of its own (its Wi-Fi is the car hotspot), so everything goes through the phone:
Head Unit Link runs a small HTTP proxy on the phone (IptvProxy.kt, 127.0.0.1:8899, sockets on mobile data), and the
Pi reaches it with `adb forward tcp:8899 tcp:8899`. No phone linked = it tries the provider directly.

Playback: one ffmpeg at a time (providers limit connections). It reads the provider's stream and writes fragmented
MP4 to a plain <video>: video copied when Chromium can play it (enc=0), or re-encoded to 720p H.264 (enc=1); audio
is always AAC stereo. The account lives in ~/.config/headunit/iptv.json (mode 0600).
"""
import asyncio
import base64
import hashlib
import json
import logging
import os
import time
from pathlib import Path
from urllib.parse import quote, urlsplit

from aiohttp import ClientSession, ClientTimeout, web

log = logging.getLogger("iptv")
PROXY_PORT = 8899
UA = "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"


class Iptv:
    def __init__(self, hub, conf_dir, tmp_dir):
        self.hub = hub
        self.file = Path(conf_dir) / "iptv.json"
        self.img_dir = Path(tmp_dir) / "iptv-img"
        self.data = self._load()
        self.cache = {}            # (action, arg) -> (time, value)
        self.proc = None           # the ffmpeg that's playing
        self.proxy = None          # "http://127.0.0.1:8899" when the phone tunnel is up
        self.route_at = 0
        self.last_error = ""
        self._prune_images()

    # ------------------------------------------------------------------ account file
    def _load(self):
        try:
            d = json.loads(self.file.read_text())
            return d if isinstance(d, dict) else {}
        except Exception:
            return {}

    def _save(self):
        try:
            self.file.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.file.with_suffix(".tmp")
            tmp.write_text(json.dumps(self.data))
            os.chmod(tmp, 0o600)
            tmp.replace(self.file)
        except OSError as e:
            log.warning("iptv save: %s", e)

    @property
    def acct(self):
        return self.data.get("account") or {}

    def status(self):
        a = self.acct
        return {"signed_in": bool(a.get("server") and a.get("username")), "server": a.get("server", ""),
                "username": a.get("username", ""), "info": self.data.get("info") or {}, "fav": self.data.get("fav") or [],
                "recent": self.data.get("recent") or [], "live_format": self.data.get("live_format", "ts"),
                "via_phone": bool(self.proxy), "error": self.last_error}

    # ------------------------------------------------------------------ getting online (through the phone)
    async def route(self, force=False):
        """Points tcp:8899 on the Pi at the phone's proxy. Returns the proxy URL, or None to go direct."""
        if not force and self.proxy and time.time() - self.route_at < 60:
            return self.proxy
        apps = getattr(self.hub, "apps", None)
        serial = None
        if apps:
            try:
                serial, _mode, _msg = await apps.find_phone(connect=True)
            except Exception as e:
                log.info("iptv: no phone (%s)", e)
        if not serial:
            self.proxy = None
            return None
        p = await asyncio.create_subprocess_exec("adb", "-s", serial, "forward", f"tcp:{PROXY_PORT}", f"tcp:{PROXY_PORT}",
                                                 stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.PIPE)
        _, err = await p.communicate()
        if p.returncode != 0:
            log.warning("iptv: adb forward failed: %s", err.decode(errors="replace").strip())
            self.proxy = None
            return None
        self.proxy, self.route_at = f"http://127.0.0.1:{PROXY_PORT}", time.time()
        return self.proxy

    async def fetch(self, url, as_json=True, timeout=20, retry=True):
        proxy = await self.route()
        try:
            async with ClientSession(timeout=ClientTimeout(total=timeout), headers={"User-Agent": self.data.get("ua") or UA}) as s:
                async with s.get(url, proxy=proxy, ssl=False) as r:
                    if r.status >= 400:
                        raise web.HTTPBadGateway(text=f"The provider answered {r.status}")
                    return await (r.json(content_type=None) if as_json else r.read())
        except web.HTTPException:
            raise
        except Exception as e:
            if retry:   # a stale tunnel (phone reconnected): set it up again once
                await self.route(force=True)
                return await self.fetch(url, as_json, timeout, retry=False)
            raise web.HTTPBadGateway(text=f"Couldn't reach the TV provider ({type(e).__name__}). Is the phone connected?")

    def api_url(self, **q):
        a = self.acct
        base = a["server"].rstrip("/")
        qs = "&".join(f"{k}={quote(str(v))}" for k, v in dict(username=a["username"], password=a["password"], **q).items())
        return f"{base}/player_api.php?{qs}"

    async def api(self, action=None, ttl=0, **q):
        key = (action, json.dumps(q, sort_keys=True))
        hit = self.cache.get(key)
        if ttl and hit and time.time() - hit[0] < ttl:
            return hit[1]
        args = dict(q)
        if action:
            args["action"] = action
        val = await self.fetch(self.api_url(**args))
        if ttl:
            self.cache[key] = (time.time(), val)
        return val

    # ------------------------------------------------------------------ sign in / out
    async def login(self, server, username, password):
        server = (server or "").strip()
        if server and "://" not in server:
            server = "http://" + server
        if not server or not username:
            raise web.HTTPBadRequest(text="Enter the server, username and password from your TV provider.")
        old = self.data.get("account")
        self.data["account"] = {"server": server.rstrip("/"), "username": username.strip(), "password": password}
        try:
            r = await self.fetch(self.api_url())
        except web.HTTPException as e:
            self.data["account"] = old
            raise e
        ui = (r or {}).get("user_info") or {}
        if str(ui.get("auth", "1")) == "0" or (ui.get("status") and ui.get("status") != "Active"):
            self.data["account"] = old
            raise web.HTTPForbidden(text=f"The provider said no: {ui.get('message') or ui.get('status') or 'wrong login'}.")
        exp = ui.get("exp_date")
        self.data["info"] = {"status": ui.get("status", ""), "exp": int(exp) if str(exp or "").isdigit() else None,
                             "max": ui.get("max_connections"), "active": ui.get("active_cons")}
        self.cache.clear()
        self._save()
        self.hub.changed()
        return self.status()

    def logout(self):
        self.stop()
        for k in ("account", "info"):
            self.data.pop(k, None)
        self.cache.clear()
        self._save()
        self.hub.changed()

    # ------------------------------------------------------------------ playback
    def stream_url(self, kind, sid, ext):
        a = self.acct
        base = a["server"].rstrip("/")
        path = {"live": "live", "movie": "movie", "episode": "series"}[kind]
        ext = ext if kind != "live" else self.data.get("live_format", "ts")
        return f"{base}/{path}/{quote(a['username'])}/{quote(a['password'])}/{sid}.{ext or 'mp4'}"

    def stop(self):
        p, self.proc = self.proc, None
        if p and p.returncode is None:
            try:
                p.kill()
            except ProcessLookupError:
                pass

    async def play(self, request, kind, sid, ext, start=0, enc=False):
        if kind not in ("live", "movie", "episode") or not str(sid).isdigit():
            raise web.HTTPBadRequest()
        self.stop()
        await asyncio.sleep(0.15)   # the provider sees the old connection close first
        url = self.stream_url(kind, sid, ext)
        proxy = await self.route()
        args = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-user_agent", self.data.get("ua") or UA]
        if proxy and urlsplit(url).scheme == "http":
            args += ["-http_proxy", proxy]
        args += ["-reconnect", "1", "-reconnect_streamed", "1", "-reconnect_on_network_error", "1", "-reconnect_delay_max", "4",
                 "-fflags", "+genpts+discardcorrupt", "-analyzeduration", "2000000", "-probesize", "2000000"]
        if start and kind != "live":
            args += ["-ss", str(int(start))]
        args += ["-i", url, "-map", "0:v:0?", "-map", "0:a:0?"]
        if enc:
            args += ["-vf", "yadif=0:-1:1,scale=-2:'min(720,ih)'", "-c:v", "libx264", "-preset", "ultrafast", "-tune", "zerolatency",
                     "-g", "50", "-pix_fmt", "yuv420p", "-b:v", "3M", "-maxrate", "4M", "-bufsize", "6M"]
        else:
            args += ["-c:v", "copy"]
        args += ["-c:a", "aac", "-ac", "2", "-ar", "48000", "-b:a", "160k",
                 "-f", "mp4", "-movflags", "frag_keyframe+empty_moov+default_base_moof", "-frag_duration", "500000", "pipe:1"]
        env = dict(os.environ)
        if proxy:   # https sources: ffmpeg tunnels through the proxy with CONNECT
            env["http_proxy"] = env["https_proxy"] = proxy
        self.last_error = ""
        proc = await asyncio.create_subprocess_exec(*args, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE, env=env)
        self.proc = proc
        errbuf = []

        async def errs():
            async for line in proc.stderr:
                t = line.decode(errors="replace").strip()
                if t:
                    errbuf.append(t)
                    del errbuf[:-6]
        err_task = asyncio.create_task(errs())
        try:
            first = await asyncio.wait_for(proc.stdout.read(65536), timeout=25)
        except asyncio.TimeoutError:
            first = b""
            errbuf.append("timed out waiting for the stream")
            try:
                proc.kill()
            except ProcessLookupError:
                pass
        if not first:
            await proc.wait()
            await err_task
            self.last_error = self._explain(" ".join(errbuf))
            log.warning("iptv play %s %s: %s", kind, sid, " | ".join(errbuf))
            if self.proc is proc:
                self.proc = None
            raise web.HTTPBadGateway(text=self.last_error)
        resp = web.StreamResponse(headers={"Content-Type": "video/mp4", "Cache-Control": "no-store"})
        await resp.prepare(request)
        try:
            await resp.write(first)
            while True:
                chunk = await proc.stdout.read(65536)
                if not chunk:
                    break
                await resp.write(chunk)
        except (ConnectionResetError, asyncio.CancelledError):
            pass
        finally:
            if proc.returncode is None:
                try:
                    proc.kill()
                except ProcessLookupError:
                    pass
            if self.proc is proc:
                self.proc = None
            err_task.cancel()
        return resp

    @staticmethod
    def _explain(err):
        e = err.lower()
        if "403" in e or "forbidden" in e:
            return "The provider refused the stream (too many screens in use, or the subscription ended)."
        if "404" in e:
            return "That channel isn't on the provider's server right now."
        if "timed out" in e or "connection refused" in e or "network" in e:
            return "Couldn't reach the TV provider. Is the phone connected and on mobile data?"
        return "This stream didn't start" + (f": {err[:120]}" if err else ".")

    # ------------------------------------------------------------------ logos and posters (cached on disk)
    def _prune_images(self):
        try:
            files = sorted(self.img_dir.glob("*"), key=lambda p: p.stat().st_mtime)
            for p in files[:-2500]:
                p.unlink()
        except OSError:
            pass

    async def image(self, u):
        if not u or not u.startswith(("http://", "https://")):
            raise web.HTTPNotFound()
        name = hashlib.sha1(u.encode()).hexdigest()
        f = self.img_dir / name
        if f.exists():
            return f.read_bytes()
        data = await self.fetch(u, as_json=False, timeout=12)
        if len(data) > 3 * 1024 * 1024:
            raise web.HTTPNotFound()
        self.img_dir.mkdir(parents=True, exist_ok=True)
        f.write_bytes(data)
        return data

    # ------------------------------------------------------------------ lists
    async def categories(self, kind):
        action = {"live": "get_live_categories", "movie": "get_vod_categories", "series": "get_series_categories"}[kind]
        cats = await self.api(action, ttl=1800) or []
        return [{"id": str(c.get("category_id")), "name": c.get("category_name") or "?"} for c in cats if isinstance(c, dict)]

    async def streams(self, kind, cat):
        action = {"live": "get_live_streams", "movie": "get_vod_streams", "series": "get_series"}[kind]
        q = {"category_id": cat} if cat and cat != "all" else {}
        items = await self.api(action, ttl=1200, **q) or []
        out = []
        for s in items:
            if not isinstance(s, dict):
                continue
            if kind == "live":
                out.append({"id": s.get("stream_id"), "name": s.get("name") or "", "logo": s.get("stream_icon") or "", "num": s.get("num"),
                            "epg": bool(s.get("epg_channel_id")), "archive": bool(s.get("tv_archive"))})
            elif kind == "movie":
                out.append({"id": s.get("stream_id"), "name": s.get("name") or "", "logo": s.get("stream_icon") or "",
                            "ext": s.get("container_extension") or "mp4", "rating": s.get("rating") or ""})
            else:
                out.append({"id": s.get("series_id"), "name": s.get("name") or "", "logo": s.get("cover") or "",
                            "rating": s.get("rating") or "", "year": (s.get("releaseDate") or s.get("release_date") or "")[:4]})
        return out

    async def series(self, sid):
        info = await self.api("get_series_info", ttl=1200, series_id=sid) or {}
        eps = info.get("episodes") or {}
        seasons = []
        for num in sorted(eps, key=lambda x: int(x) if str(x).isdigit() else 0):
            seasons.append({"season": num, "episodes": [{
                "id": e.get("id"), "title": e.get("title") or f"Episode {e.get('episode_num')}", "num": e.get("episode_num"),
                "ext": e.get("container_extension") or "mp4", "dur": (e.get("info") or {}).get("duration_secs") or 0,
                "img": (e.get("info") or {}).get("movie_image") or ""} for e in eps[num] if isinstance(e, dict)]})
        i = info.get("info") or {}
        return {"name": i.get("name") or "", "plot": i.get("plot") or "", "cover": i.get("cover") or "", "seasons": seasons}

    async def epg(self, sid):
        r = await self.api("get_short_epg", ttl=120, stream_id=sid, limit=3) or {}
        out = []
        for e in (r.get("epg_listings") or [])[:3]:
            def b64(x):
                try:
                    return base64.b64decode(x).decode("utf-8", "replace")
                except Exception:
                    return x or ""
            try:
                start, end = int(e.get("start_timestamp")), int(e.get("stop_timestamp"))
            except (TypeError, ValueError):
                continue
            out.append({"title": b64(e.get("title")), "desc": b64(e.get("description"))[:240], "start": start, "end": end})
        return out

    def remember(self, key, item):
        lst = [x for x in (self.data.get(key) or []) if not (x.get("kind") == item.get("kind") and str(x.get("id")) == str(item.get("id")))]
        if key == "fav" and item.get("off"):
            self.data[key] = lst
        else:
            item = {k: item.get(k) for k in ("kind", "id", "name", "logo", "ext", "series", "pos", "dur") if item.get(k) is not None}
            item["at"] = int(time.time())
            lst.insert(0, item)
            self.data[key] = lst[:60 if key == "fav" else 30]
        self._save()
        return self.data[key]


# ---------------------------------------------------------------------- HTTP routes
def _near(request):
    """The car screen itself, or the phone on the Pi's Wi-Fi / through adb (for signing in from the phone)."""
    return request.remote in ("127.0.0.1", "::1") or (request.remote or "").startswith("10.42.0.")


def setup_routes(app, hub, web_dir):
    tv = hub.iptv

    def guard(request):
        if not _near(request):
            raise web.HTTPForbidden()

    async def status(request):
        guard(request)
        return web.json_response(tv.status())

    async def login(request):
        guard(request)
        b = await request.json()
        try:
            return web.json_response(await tv.login(b.get("server"), b.get("username"), b.get("password") or ""))
        except web.HTTPException as e:
            return web.json_response({"error": e.text}, status=e.status)

    async def logout(request):
        guard(request)
        tv.logout()
        return web.json_response({"ok": True})

    async def cats(request):
        guard(request)
        try:
            return web.json_response(await tv.categories(request.query.get("kind", "live")))
        except web.HTTPException as e:
            return web.json_response({"error": e.text}, status=e.status)
        except KeyError:
            raise web.HTTPBadRequest()

    async def streams(request):
        guard(request)
        try:
            return web.json_response(await tv.streams(request.query.get("kind", "live"), request.query.get("cat", "all")))
        except web.HTTPException as e:
            return web.json_response({"error": e.text}, status=e.status)

    async def series(request):
        guard(request)
        try:
            return web.json_response(await tv.series(request.query.get("id", "")))
        except web.HTTPException as e:
            return web.json_response({"error": e.text}, status=e.status)

    async def epg(request):
        guard(request)
        try:
            return web.json_response(await tv.epg(request.query.get("id", "")))
        except Exception:
            return web.json_response([])

    async def play(request):
        guard(request)
        q = request.query
        try:
            start = float(q.get("t") or 0)
        except ValueError:
            start = 0
        return await tv.play(request, q.get("kind", "live"), q.get("id", ""), q.get("ext", ""), start, q.get("enc") == "1")

    async def stop(request):
        guard(request)
        tv.stop()
        return web.json_response({"ok": True})

    async def remember(request):
        guard(request)
        b = await request.json()
        key = "fav" if request.path.endswith("/fav") else "recent"
        return web.json_response(tv.remember(key, b.get("item") or {}))

    async def fmt(request):
        guard(request)
        b = await request.json()
        if b.get("live_format") in ("ts", "m3u8"):
            tv.data["live_format"] = b["live_format"]
            tv._save()
        return web.json_response(tv.status())

    async def img(request):
        guard(request)
        try:
            data = await tv.image(request.query.get("u", ""))
        except web.HTTPException:
            raise web.HTTPNotFound()
        except Exception:
            raise web.HTTPNotFound()
        return web.Response(body=data, content_type="image/jpeg", headers={"Cache-Control": "max-age=86400"})

    async def setup_page(request):
        return web.FileResponse(Path(web_dir) / "tvsetup.html", headers={"Cache-Control": "no-cache"})

    r = app.router
    r.add_get("/iptv/status", status)
    r.add_post("/iptv/login", login)
    r.add_post("/iptv/logout", logout)
    r.add_get("/iptv/categories", cats)
    r.add_get("/iptv/streams", streams)
    r.add_get("/iptv/series", series)
    r.add_get("/iptv/epg", epg)
    r.add_get("/iptv/play", play)
    r.add_post("/iptv/stop", stop)
    r.add_post("/iptv/fav", remember)
    r.add_post("/iptv/recent", remember)
    r.add_post("/iptv/format", fmt)
    r.add_get("/iptv/img", img)
    r.add_get("/tv/setup", setup_page)
