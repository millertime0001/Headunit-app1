package com.headunit.link

import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONObject

data class NavInfo(
    val active: Boolean,
    val title: String = "",
    val text: String = "",
    val sub: String = "",
    val icon: String? = null,
)

data class MediaInfo(val title: String, val artist: String, val art: String?)

/** Shared state between the notification listener, the link service and the screen. */
object Bus {
    val nav = MutableStateFlow(NavInfo(false))
    val media = MutableStateFlow<MediaInfo?>(null)
    val status = MutableStateFlow("Not running")
    val weather = MutableStateFlow("No weather yet")
    val queue = MutableStateFlow<JSONObject?>(null)    // "Up next" of the playing app
    val library = MutableStateFlow<JSONObject?>(null)  // the YouTube Music list being browsed
}
